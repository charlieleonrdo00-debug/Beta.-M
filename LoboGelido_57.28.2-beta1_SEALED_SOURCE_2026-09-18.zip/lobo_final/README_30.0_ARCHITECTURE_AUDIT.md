# Lobo Gélido 30.0 — Deep Architecture Audit

## Scope

This pass reviewed the C++ runtime, memory/MMU, scheduler/thread model, CPU backend selection, JIT boundary, GPU capability model, Android JNI boundary, build configuration, tests, and project documentation.

## Concrete corrections

1. **JIT availability semantics** — a stub provider no longer makes diagnostics report an available JIT. Availability now means that a provider successfully initialized.
2. **Scheduler ownership of virtual time** — `ThreadManager::dispatch_next()` no longer advances the global scheduler. The outer runtime loop owns guest-time advancement, preventing double advancement.
3. **Address-space invalidation epochs** — map/unmap operations now advance the write epoch, so exclusive reservations cannot survive memory topology changes.
4. **Android JNI boundary** — JNI declarations were moved out of `MainActivity` into `RuntimeBridge`, reducing UI/runtime coupling.
5. **Android build metadata** — version metadata is aligned to 30.0 and C++20 requirements are explicit.
6. **Release test integrity** — test executables retain assertions in Release builds.
7. **Synthetic GPU state** — the core does not claim Vulkan hardware until a real platform probe attaches capabilities.
8. **Lifecycle reset** — runtime stop/reprepare paths clear the kernel, MMU and guest memory state.

## Test evidence

- Release build: **19/19 CTest passed**.
- AddressSanitizer + UndefinedBehaviorSanitizer build: **19/19 CTest passed**.
- New regression suite: `architecture_hardening`.

## Architectural rule going forward

The runtime is split into explicit layers:

`Android UI -> RuntimeBridge -> RuntimeCoordinator -> Kernel/CPU/MMU/GPU -> platform backends`

Platform capabilities must be queried, not fabricated. Backend names must reflect successful initialization. Virtual time has one owner. Native UI code must not own emulator state.

## Known limits

The real Dynarmic source tree is not bundled in this package. The adapter boundary exists, but a real Dynarmic-enabled build still requires the external source tree. Vulkan device creation/presentation is likewise not implemented by this core-only package.
