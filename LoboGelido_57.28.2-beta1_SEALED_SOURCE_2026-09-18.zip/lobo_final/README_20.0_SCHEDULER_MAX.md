# Lobo Gélido 20.0 — Scheduler Max

Esta iteración reemplaza el scheduler mínimo de 19.0 por un scheduler de tiempo virtual determinista, orientado a un runtime de emulación real.

## Cambios

- Orden determinista por tick, prioridad y secuencia.
- Event IDs estables para cancelación O(1) a nivel de API.
- Eventos one-shot y periódicos.
- `schedule_after()` para temporización relativa.
- Protección contra tormentas de eventos mediante presupuesto por ejecución.
- Lazy pruning de eventos cancelados.
- Estadísticas de ejecución, cancelación, diferimiento y pico de cola.
- Manejo seguro de overflow de `uint64_t`.
- `run_for()` y `next_deadline()` para integración con un scheduler de CPU/kernel.
- Integración de métricas del scheduler en `RuntimeCoordinator`.
- Nuevo test dedicado de scheduler.

## Validación

CMake/CTest en host: **13/13 pruebas pasan**.

Esto valida la arquitectura del scheduler y su integración con el runtime, pero no significa que la compatibilidad con el kernel de Nintendo Switch esté completa. La siguiente frontera para elevar compatibilidad real es conectar este scheduler a primitivas HLE de hilos, sincronización, timers, IPC y afinidad/prioridad de CPU.

## Licencia / origen

El scheduler de esta versión es código original de Lobo Gélido. No incluye firmware, claves, ROMs ni otros activos propietarios.
