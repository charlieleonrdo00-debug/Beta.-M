#include "shader_cache.h"
#include <fstream>
#include <iomanip>
#include <sstream>

namespace lg::graphics {

std::filesystem::path ShaderCache::file(const ShaderCacheKey& k) const {
    std::ostringstream s;
    s << std::hex << k.program << '_' << k.device << '_' << k.format << ".bin";
    return root_ / s.str();
}

bool ShaderCache::put(const ShaderCacheKey& k, const std::vector<uint8_t>& d) {
    std::error_code ec;
    std::filesystem::create_directories(root_, ec);
    const auto path = file(k);
    const auto tmp = path.string() + ".tmp";
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write(reinterpret_cast<const char*>(d.data()), static_cast<std::streamsize>(d.size()));
    f.close();
    if (!f) return false;
    std::filesystem::rename(tmp, path, ec);
    if (ec) {
        std::filesystem::remove(path, ec);
        ec.clear();
        std::filesystem::rename(tmp, path, ec);
    }
    return !ec;
}

bool ShaderCache::get(const ShaderCacheKey& k, std::vector<uint8_t>& d) const {
    std::ifstream f(file(k), std::ios::binary | std::ios::ate);
    if (!f) return false;
    const auto n = f.tellg();
    if (n < 0) return false;
    d.resize(static_cast<size_t>(n));
    f.seekg(0);
    return bool(f.read(reinterpret_cast<char*>(d.data()), n));
}

void ShaderCache::clear() {
    std::error_code ec;
    std::filesystem::remove_all(root_, ec);
}

} // namespace lg::graphics
