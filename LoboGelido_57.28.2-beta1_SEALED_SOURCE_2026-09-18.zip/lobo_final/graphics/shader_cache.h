#pragma once
#include <cstdint>
#include <filesystem>
#include <vector>

namespace lg::graphics {

struct ShaderCacheKey {
    uint64_t program{};
    uint64_t device{};
    uint32_t format{1};
    bool operator==(const ShaderCacheKey&) const = default;
};

class ShaderCache {
public:
    explicit ShaderCache(std::filesystem::path root): root_(std::move(root)) {}
    bool put(const ShaderCacheKey& key, const std::vector<uint8_t>& data);
    bool get(const ShaderCacheKey& key, std::vector<uint8_t>& data) const;
    void clear();
private:
    std::filesystem::path file(const ShaderCacheKey&) const;
    std::filesystem::path root_;
};

} // namespace lg::graphics
