# Lobo Gélido 27.0 — Dynarmic A64 Bridge

## What changed

- Added a concrete `DynarmicProvider` implementing the Lobo Gélido `JitProvider` contract.
- Added A64 register/SIMD/PC/SP/FPCR/FPSR/PSTATE synchronization.
- Added memory callbacks backed by `AddressSpace`.
- Added exclusive-store integration using the existing write-epoch reservation model.
- Added interpreter fallback routing from Dynarmic callbacks.
- Added JIT code-cache invalidation to runtime recovery.
- Runtime now selects Dynarmic automatically when a real Dynarmic build is linked; otherwise it safely falls back to Tier-1 BlockBackend.
- Added CMake integration through `LOBOGELIDO_ENABLE_DYNARMIC` and `LOBOGELIDO_DYNARMIC_SOURCE_DIR`.

## Important status

This repository copy does **not** contain the Dynarmic source tree because the build environment could not retrieve it from the network. Therefore the default 27.0 host build intentionally remains JIT-disabled and is not presented as a real Dynarmic build.

To produce a real JIT build, provide an actual Dynarmic source tree and configure:

```text
-DLOBOGELIDO_ENABLE_DYNARMIC=ON
-DLOBOGELIDO_DYNARMIC_SOURCE_DIR=/path/to/dynarmic
```

Dynarmic's current public API exposes `Dynarmic::A64::Jit`, register/vector accessors, `Run`, `ClearCache`, and `InvalidateCacheRange`; the adapter targets that API. Dynarmic supports AArch64 hosts and Android and is licensed under 0BSD. The project must retain Dynarmic and its bundled dependency license notices when redistributed.
