# Lobo Gélido 32.0 — Build desde el celular

Este paquete añade un workflow de GitHub Actions para compilar el APK ARM64 sin necesitar un computador local.

## Uso

1. Crea un repositorio en GitHub.
2. Sube el contenido de este paquete al repositorio.
3. Abre **Actions**.
4. Selecciona **Lobo Gelido - Android APK**.
5. Pulsa **Run workflow**.
6. Cuando termine correctamente, abre la ejecución y descarga el artefacto **Lobo-Gelido-32.0-APK**.
7. Extrae el APK en el teléfono e instálalo.

El workflow ejecuta la compilación en un runner Linux hospedado y conserva el APK como artefacto.

Nota: esta versión no incorpora firmware, claves ni juegos. Dynarmic sigue siendo opcional y no se descarga automáticamente.
