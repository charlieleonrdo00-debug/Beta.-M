# Lobo Gélido 46.0 — Vulkan Graphics Pipeline

46.0 advances the Android Vulkan path from a real render pass to an explicit graphics-pipeline foundation.

## Implemented
- Real `VkPipelineLayout` creation.
- Real `VkGraphicsPipeline` creation from caller-provided validated SPIR-V vertex/fragment modules.
- Vertex input contract: location 0 = `vec2` position, location 1 = `vec3` color, 20-byte stride.
- Dynamic viewport/scissor.
- Triangle-list rasterization with no culling and one color attachment.
- Host-visible/coherent Vulkan vertex buffer allocation and upload.
- Command recording helpers for pipeline/vertex-buffer binding and `vkCmdDraw(3,1,0,0)`.
- Diagnostics for shader modules, graphics pipeline state and vertex-buffer bytes.
- Android CMake now includes the graphics-pipeline and SPIR-V implementation units.

## Important limitation
The runtime does not bundle proprietary Switch shaders or firmware. A graphics pipeline is created only when valid SPIR-V shader modules are supplied by the caller. Therefore this version establishes the real Vulkan execution path but does not claim full Switch shader translation or game compatibility.

## Validation
Host CTest is expected to validate the lifecycle/API surface. Android Vulkan object creation still requires an Android device/runtime with Vulkan support.
