#include "gpu_device.h"
#include <sstream>

namespace lg::gpu {

core::Result<void> GpuDevice::initialize() {
    shutdown();
    return core::Result<void>::Error("Vulkan device not attached");
}

core::Result<void> GpuDevice::initialize(const DeviceInfo& actual) {
    if (actual.backend != Backend::Vulkan || !actual.initialized) {
        shutdown();
        return core::Result<void>::Error("invalid Vulkan device capabilities");
    }
    info_ = actual;
    return core::Result<void>::Ok();
}

void GpuDevice::shutdown() noexcept { info_ = {}; }

std::string GpuDevice::capability_string() const {
    std::ostringstream out;
    out << info_.api << " " << ((info_.api_version >> 22) & 0x7F) << '.'
        << ((info_.api_version >> 12) & 0x3FF) << " "
        << "timeline=" << (info_.timeline_semaphore ? 1 : 0)
        << " dynamic_rendering=" << (info_.dynamic_rendering ? 1 : 0)
        << " descriptor_indexing=" << (info_.descriptor_indexing ? 1 : 0)
        << " shader_int16=" << (info_.shader_int16 ? 1 : 0);
    return out.str();
}

} // namespace lg::gpu
