#include "guest_gpu_translator.h"
#include <sstream>

namespace lg::gpu {

core::Result<GpuCommand> GuestGpuTranslator::translate(const GuestGpuPacket& p) const {
    GpuCommand c{};
    c.a=p.a; c.b=p.b; c.c=p.c; c.d=p.d;
    c.x=p.x; c.y=p.y; c.z=p.z; c.w=p.w;
    switch (p.opcode) {
    case SetViewport: c.op=GpuOp::SetViewport; break;
    case SetScissor: c.op=GpuOp::SetScissor; break;
    case BindPipeline: c.op=GpuOp::BindPipeline; break;
    case BindVertexBuffer: c.op=GpuOp::BindVertexBuffer; break;
    case BindDescriptorSet: c.op=GpuOp::BindDescriptorSet; break;
    case Draw: c.op=GpuOp::Draw; break;
    case Clear: c.op=GpuOp::Clear; break;
    case Barrier: c.op=GpuOp::Barrier; break;
    default: return core::Result<GpuCommand>::Error("unsupported guest GPU opcode");
    }
    return core::Result<GpuCommand>::Ok(c);
}

core::Result<std::vector<GpuCommand>> GuestGpuTranslator::translate(const std::vector<GuestGpuPacket>& packets) {
    std::vector<GpuCommand> out;
    out.reserve(packets.size());
    for (const auto& p : packets) {
        ++stats_.packets;
        auto r=translate(p);
        if (!r.ok()) { ++stats_.rejected; return core::Result<std::vector<GpuCommand>>::Error(r.error()); }
        out.push_back(r.value());
        ++stats_.translated;
    }
    return core::Result<std::vector<GpuCommand>>::Ok(std::move(out));
}

std::string GuestGpuTranslator::diagnostics() const {
    std::ostringstream s;
    s << "guestGpuPackets=" << stats_.translated << "/" << stats_.packets
      << ";rejected=" << stats_.rejected;
    return s.str();
}

} // namespace lg::gpu
