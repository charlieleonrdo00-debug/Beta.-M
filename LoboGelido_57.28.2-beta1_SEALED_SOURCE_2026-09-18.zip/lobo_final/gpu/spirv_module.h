#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "../core/result.h"

namespace lg::gpu {

struct SpirvModule {
    std::vector<uint32_t> words;
    uint32_t bound{0};
    bool valid() const noexcept { return words.size() >= 5 && words[0] == 0x07230203u && bound != 0; }
};

core::Result<SpirvModule> validate_spirv(const std::vector<uint32_t>& words);

} // namespace lg::gpu
