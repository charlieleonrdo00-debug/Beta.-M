#include "spirv_module.h"

namespace lg::gpu {
core::Result<SpirvModule> validate_spirv(const std::vector<uint32_t>& words) {
    if (words.size() < 5) return core::Result<SpirvModule>::Error("SPIR-V module too small");
    if (words[0] != 0x07230203u) return core::Result<SpirvModule>::Error("invalid SPIR-V magic");
    if (words[4] == 0) return core::Result<SpirvModule>::Error("invalid SPIR-V bound");
    size_t i = 5;
    while (i < words.size()) {
        const uint32_t op = words[i];
        const uint16_t wc = static_cast<uint16_t>(op >> 16);
        if (wc == 0 || i + wc > words.size()) return core::Result<SpirvModule>::Error("malformed SPIR-V instruction");
        i += wc;
    }
    SpirvModule m; m.words = words; m.bound = words[3];
    return core::Result<SpirvModule>::Ok(std::move(m));
}
} // namespace lg::gpu
