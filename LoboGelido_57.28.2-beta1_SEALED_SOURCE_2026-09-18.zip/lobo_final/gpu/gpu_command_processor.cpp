#include "gpu_command_processor.h"
#include <sstream>
namespace lg::gpu {
core::Result<void> GpuCommandProcessor::validate_and_apply(const GpuCommand& c) {
    switch (c.op) {
    case GpuOp::SetViewport:
        if (!(c.z > 0.0f && c.w > 0.0f)) return core::Result<void>::Error("viewport dimensions must be positive");
        state_.viewport_x=c.x; state_.viewport_y=c.y; state_.viewport_w=c.z; state_.viewport_h=c.w; break;
    case GpuOp::SetScissor:
        if (c.a==0 || c.b==0) return core::Result<void>::Error("scissor dimensions must be nonzero");
        state_.scissor_w=c.a; state_.scissor_h=c.b; break;
    case GpuOp::BindPipeline: state_.pipeline_id=c.a; state_.shader_program_id=c.b; break;
    case GpuOp::BindVertexBuffer: state_.vertex_buffer_id=c.a; break;
    case GpuOp::BindDescriptorSet: if(c.a==0)return core::Result<void>::Error("descriptor set id must be nonzero"); state_.descriptor_set_id=c.a; break;
    case GpuOp::Draw:
        if (c.a==0 || state_.pipeline_id==0 || state_.vertex_buffer_id==0) return core::Result<void>::Error("draw requires pipeline, vertex buffer and nonzero vertex count");
        ++state_.draws; ++stats_.draws; break;
    case GpuOp::Clear: ++state_.clears; ++stats_.clears; break;
    case GpuOp::Barrier: ++state_.barriers; ++stats_.barriers; break;
    default: return core::Result<void>::Error("unknown GPU operation");
    }
    return core::Result<void>::Ok();
}
core::Result<void> GpuCommandProcessor::submit(const GpuCommand& c) {
    ++stats_.submitted;
    auto r=validate_and_apply(c); if(!r.ok()){++stats_.invalid; return r;}
    commands_.push_back(c); ++stats_.executed; return core::Result<void>::Ok();
}
core::Result<void> GpuCommandProcessor::submit(const std::vector<GpuCommand>& cs) {
    for(const auto& c:cs){auto r=submit(c); if(!r.ok()) return r;} return core::Result<void>::Ok();
}
core::Result<std::vector<uint32_t>> GpuCommandProcessor::compile_graph(RenderGraph& graph) const {
    if(commands_.empty()) return core::Result<std::vector<uint32_t>>::Ok({});
    uint32_t id=1; uint32_t previous=0;
    for(const auto& c:commands_){
        PassType type=(c.op==GpuOp::Draw)?PassType::Graphics:((c.op==GpuOp::Barrier)?PassType::Transfer:PassType::Graphics);
        Pass p{type,id,{}}; if(previous) p.depends_on.push_back(previous); auto r=graph.add(std::move(p)); if(!r.ok()) return core::Result<std::vector<uint32_t>>::Error(r.error()); previous=id++;
    }
    return graph.compile();
}
void GpuCommandProcessor::reset() noexcept { commands_.clear(); state_=GpuState{}; stats_=GpuCommandStats{}; }
std::string GpuCommandProcessor::diagnostics() const { std::ostringstream s; s<<"gpuCmds="<<stats_.executed<<"/"<<stats_.submitted<<";draws="<<stats_.draws<<";clears="<<stats_.clears<<";barriers="<<stats_.barriers<<";invalid="<<stats_.invalid<<";pipeline="<<state_.pipeline_id<<";program="<<state_.shader_program_id<<";vbo="<<state_.vertex_buffer_id<<";descriptor="<<state_.descriptor_set_id; return s.str(); }
} // namespace lg::gpu
