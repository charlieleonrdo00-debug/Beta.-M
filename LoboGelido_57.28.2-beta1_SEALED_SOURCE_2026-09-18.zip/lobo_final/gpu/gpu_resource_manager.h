#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>
#include "../core/result.h"
namespace lg::gpu {
enum class ResourceType : uint8_t { Buffer, Image, Sampler, DescriptorSet };
struct BufferDesc { uint64_t size{}; uint32_t usage{}; };
struct ImageDesc { uint32_t width{}, height{}, layers{1}; uint32_t format{}; uint32_t usage{}; };
struct Resource { uint32_t id{}; ResourceType type{}; uint64_t size{}; std::string name; bool alive{true}; };
struct DescriptorBinding { uint32_t binding{}; uint32_t resource_id{}; uint32_t type{}; };
class GpuResourceManager {
public:
 core::Result<uint32_t> create_buffer(const BufferDesc&, std::string name = {});
 core::Result<uint32_t> create_image(const ImageDesc&, std::string name = {});
 core::Result<uint32_t> create_descriptor_set();
 core::Result<void> bind_descriptor(uint32_t set, uint32_t binding, uint32_t resource, uint32_t type);
 core::Result<void> destroy(uint32_t id);
 const Resource* get(uint32_t id) const noexcept;
 bool exists(uint32_t id) const noexcept { return resources_.count(id) != 0; }
 size_t resource_count() const noexcept { return resources_.size(); }
 size_t descriptor_binding_count(uint32_t set) const noexcept;
 void reset() noexcept;
 std::string diagnostics() const;
private:
 uint32_t next_id_{1};
 std::unordered_map<uint32_t, Resource> resources_;
 std::unordered_map<uint32_t, std::vector<DescriptorBinding>> descriptors_;
};
}
