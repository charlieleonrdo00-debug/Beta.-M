#pragma once
#include <array>
#include <cstdint>

namespace lg::gpu {

struct CacheKey {
    std::array<uint64_t, 4> words{};
    bool operator==(const CacheKey&) const noexcept = default;
};

} // namespace lg::gpu
