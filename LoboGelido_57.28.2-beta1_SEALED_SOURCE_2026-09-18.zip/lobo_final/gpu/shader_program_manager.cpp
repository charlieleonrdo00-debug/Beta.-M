#include "shader_program_manager.h"
#include <sstream>
#include <algorithm>
#include <unordered_map>
#include <limits>

namespace lg::gpu {

namespace {
constexpr uint16_t OpTypeVoid = 19;
constexpr uint16_t OpTypeBool = 20;
constexpr uint16_t OpTypeInt = 21;
constexpr uint16_t OpTypeFloat = 22;
constexpr uint16_t OpTypeVector = 23;
constexpr uint16_t OpTypeMatrix = 24;
constexpr uint16_t OpTypeImage = 25;
constexpr uint16_t OpTypeSampler = 26;
constexpr uint16_t OpTypeSampledImage = 27;
constexpr uint16_t OpTypeArray = 28;
constexpr uint16_t OpTypeRuntimeArray = 29;
constexpr uint16_t OpTypeStruct = 30;
constexpr uint16_t OpTypePointer = 32;
constexpr uint16_t OpConstant = 43;
constexpr uint16_t OpVariable = 59;
constexpr uint16_t OpDecorate = 71;
constexpr uint32_t DecorationBinding = 33;
constexpr uint32_t DecorationDescriptorSet = 34;

constexpr uint32_t StorageClassUniformConstant = 0;
constexpr uint32_t StorageClassUniform = 2;
constexpr uint32_t StorageClassStorageBuffer = 12;

struct TypeInfo {
    uint16_t op{};
    std::vector<uint32_t> operands;
};
struct DecorationInfo {
    bool has_set{false};
    bool has_binding{false};
    uint32_t set{};
    uint32_t binding{};
};

uint32_t constant_u32(const std::unordered_map<uint32_t, TypeInfo>&,
                      const std::unordered_map<uint32_t, uint64_t>& constants,
                      uint32_t id) {
    auto it = constants.find(id);
    if (it == constants.end() || it->second > std::numeric_limits<uint32_t>::max()) return 1;
    return static_cast<uint32_t>(it->second);
}

ShaderResourceType classify_descriptor(const std::unordered_map<uint32_t, TypeInfo>& types,
                                       uint32_t pointee, uint32_t storage) {
    auto it = types.find(pointee);
    if (it == types.end()) return ShaderResourceType::UniformBuffer;
    if (storage == StorageClassStorageBuffer) return ShaderResourceType::StorageBuffer;
    if (storage == StorageClassUniformConstant) {
        const uint16_t op = it->second.op;
        if (op == OpTypeImage || op == OpTypeSampler || op == OpTypeSampledImage)
            return ShaderResourceType::SampledImage;
    }
    return ShaderResourceType::UniformBuffer;
}

void unwrap_descriptor_array(const std::unordered_map<uint32_t, TypeInfo>& types,
                             const std::unordered_map<uint32_t, uint64_t>& constants,
                             uint32_t& type_id, uint32_t& count) {
    count = 1;
    for (;;) {
        auto it = types.find(type_id);
        if (it == types.end()) return;
        if (it->second.op == OpTypeArray && it->second.operands.size() >= 2) {
            const uint32_t length_id = it->second.operands[1];
            const uint32_t n = constant_u32(types, constants, length_id);
            if (n == 0 || count > std::numeric_limits<uint32_t>::max() / n) {
                count = 0;
                return;
            }
            count *= n;
            type_id = it->second.operands[0];
            continue;
        }
        // Runtime arrays are valid SPIR-V but their descriptor count is not statically known.
        // Keep the interface explicit by reporting count 1; the backend can reject unsupported
        // runtime-sized descriptor arrays later.
        if (it->second.op == OpTypeRuntimeArray && !it->second.operands.empty()) {
            type_id = it->second.operands[0];
        }
        return;
    }
}
} // namespace

uint64_t ShaderProgramManager::hash_words(const std::vector<uint32_t>& words,
                                          ShaderStage stage) noexcept {
    // FNV-1a 64-bit: deterministic cache key, not a cryptographic identity.
    uint64_t h = 1469598103934665603ull ^ static_cast<uint64_t>(stage);
    for (uint32_t w : words) {
        h ^= static_cast<uint64_t>(w);
        h *= 1099511628211ull;
    }
    return h;
}

core::Result<uint32_t> ShaderProgramManager::add_shader(
    const std::vector<uint32_t>& spirv, ShaderStage stage, std::string name) {
    auto validated = validate_spirv(spirv);
    if (!validated.ok()) return core::Result<uint32_t>::Error(validated.error());
    const uint64_t key = hash_words(spirv, stage);
    if (auto it = shader_by_hash_.find(key); it != shader_by_hash_.end())
        return core::Result<uint32_t>::Ok(it->second);

    const uint32_t id = next_shader_id_++;
    shaders_.emplace(id, ShaderRecord{id, stage, std::move(validated.value()), std::move(name), key});
    shader_by_hash_.emplace(key, id);
    return core::Result<uint32_t>::Ok(id);
}

core::Result<uint32_t> ShaderProgramManager::create_program(
    uint32_t vertex_shader, uint32_t fragment_shader) {
    const auto* vs = shader(vertex_shader);
    const auto* fs = shader(fragment_shader);
    if (!vs || !fs) return core::Result<uint32_t>::Error("shader program references an unknown shader");
    if (vs->stage != ShaderStage::Vertex || fs->stage != ShaderStage::Fragment)
        return core::Result<uint32_t>::Error("graphics program requires vertex + fragment shaders");

    const uint64_t key = (static_cast<uint64_t>(vertex_shader) << 32) | fragment_shader;
    if (auto it = program_by_key_.find(key); it != program_by_key_.end())
        return core::Result<uint32_t>::Ok(it->second);

    const uint32_t id = next_program_id_++;
    programs_.emplace(id, ShaderProgram{id, vertex_shader, fragment_shader, key, {}});
    program_by_key_.emplace(key, id);
    return core::Result<uint32_t>::Ok(id);
}

core::Result<void> ShaderProgramManager::set_resource_interface(
    uint32_t program_id, std::vector<ShaderResourceBinding> bindings) {
    auto it = programs_.find(program_id);
    if (it == programs_.end()) return core::Result<void>::Error("unknown shader program");
    std::sort(bindings.begin(), bindings.end(), [](const auto& a, const auto& b) {
        if (a.set != b.set) return a.set < b.set;
        return a.binding < b.binding;
    });
    for (size_t i = 0; i < bindings.size(); ++i) {
        const auto& b = bindings[i];
        if (b.count == 0) return core::Result<void>::Error("shader resource count must be nonzero");
        if ((b.stage_mask & 0x3u) == 0) return core::Result<void>::Error("shader resource stage mask must include vertex or fragment");
        if (i && bindings[i - 1].set == b.set && bindings[i - 1].binding == b.binding)
            return core::Result<void>::Error("duplicate shader resource binding");
    }
    it->second.resources = std::move(bindings);
    return core::Result<void>::Ok();
}

const std::vector<ShaderResourceBinding>* ShaderProgramManager::resource_interface(uint32_t program_id) const noexcept {
    const auto* p = program(program_id);
    return p ? &p->resources : nullptr;
}

core::Result<void> ShaderProgramManager::validate_resource_interface(uint32_t program_id) const {
    const auto* p = program(program_id);
    if (!p) return core::Result<void>::Error("unknown shader program");
    for (const auto& b : p->resources) {
        if (b.count == 0) return core::Result<void>::Error("shader resource count must be nonzero");
        if ((b.stage_mask & 0x3u) == 0) return core::Result<void>::Error("shader resource stage mask must include vertex or fragment");
    }
    return core::Result<void>::Ok();
}

const ShaderRecord* ShaderProgramManager::shader(uint32_t id) const noexcept {
    auto it = shaders_.find(id); return it == shaders_.end() ? nullptr : &it->second;
}
const ShaderProgram* ShaderProgramManager::program(uint32_t id) const noexcept {
    auto it = programs_.find(id); return it == programs_.end() ? nullptr : &it->second;
}
void ShaderProgramManager::clear() noexcept {
    shaders_.clear(); programs_.clear(); shader_by_hash_.clear(); program_by_key_.clear();
    next_shader_id_ = 1; next_program_id_ = 1;
}

core::Result<std::vector<ShaderResourceBinding>> ShaderProgramManager::reflect_shader_interface(
    uint32_t shader_id) const {
    const auto* record = shader(shader_id);
    if (!record) return core::Result<std::vector<ShaderResourceBinding>>::Error("unknown shader");
    const auto& words = record->module.words;
    if (words.size() < 5)
        return core::Result<std::vector<ShaderResourceBinding>>::Error("invalid SPIR-V module");

    std::unordered_map<uint32_t, TypeInfo> types;
    std::unordered_map<uint32_t, uint64_t> constants;
    std::unordered_map<uint32_t, DecorationInfo> decorations;

    size_t i = 5;
    while (i < words.size()) {
        const uint32_t first = words[i];
        const uint16_t wc = static_cast<uint16_t>(first >> 16);
        const uint16_t op = static_cast<uint16_t>(first & 0xffffu);
        if (wc == 0 || i + wc > words.size())
            return core::Result<std::vector<ShaderResourceBinding>>::Error("malformed SPIR-V instruction");
        const uint32_t* o = words.data() + i + 1;
        const size_t n = wc - 1;

        auto type_with_result = [&](uint16_t expected_op, size_t min_operands) {
            if (op == expected_op && n >= min_operands) {
                const uint32_t id = o[0];
                types[id] = TypeInfo{op, std::vector<uint32_t>(o + 1, o + n)};
            }
        };
        if (op == OpTypeVoid || op == OpTypeBool || op == OpTypeInt || op == OpTypeFloat ||
            op == OpTypeVector || op == OpTypeMatrix || op == OpTypeImage ||
            op == OpTypeSampler || op == OpTypeSampledImage || op == OpTypeArray ||
            op == OpTypeRuntimeArray || op == OpTypeStruct || op == OpTypePointer) {
            if (n < 1) return core::Result<std::vector<ShaderResourceBinding>>::Error("SPIR-V type missing result id");
            type_with_result(op, 1);
        } else if (op == OpConstant && n >= 3) {
            uint64_t value = o[2];
            if (n >= 4) value |= static_cast<uint64_t>(o[3]) << 32;
            constants[o[1]] = value;
        } else if (op == OpDecorate && n >= 3) {
            const uint32_t target = o[0];
            auto& d = decorations[target];
            if (o[1] == DecorationBinding) { d.has_binding = true; d.binding = o[2]; }
            else if (o[1] == DecorationDescriptorSet) { d.has_set = true; d.set = o[2]; }
        }
        i += wc;
    }

    std::vector<ShaderResourceBinding> result;
    for (size_t at = 5; at < words.size();) {
        const uint16_t wc = static_cast<uint16_t>(words[at] >> 16);
        const uint16_t op = static_cast<uint16_t>(words[at] & 0xffffu);
        if (wc == 0 || at + wc > words.size())
            return core::Result<std::vector<ShaderResourceBinding>>::Error("malformed SPIR-V instruction");
        const uint32_t* o = words.data() + at + 1;
        const size_t n = wc - 1;
        if (op == OpVariable && n >= 3) {
            const uint32_t result_type = o[0];
            const uint32_t variable_id = o[1];
            const uint32_t storage = o[2];
            auto dit = decorations.find(variable_id);
            auto pit = types.find(result_type);
            if (dit != decorations.end() && dit->second.has_set && dit->second.has_binding &&
                pit != types.end() && pit->second.op == OpTypePointer && pit->second.operands.size() >= 2) {
                uint32_t pointee = pit->second.operands[1];
                uint32_t count = 1;
                unwrap_descriptor_array(types, constants, pointee, count);
                if (count == 0)
                    return core::Result<std::vector<ShaderResourceBinding>>::Error("descriptor array count overflow");
                // Only descriptor-backed storage classes are reflected here. Input/output
                // variables intentionally remain outside this descriptor interface.
                if (storage == StorageClassUniformConstant || storage == StorageClassUniform ||
                    storage == StorageClassStorageBuffer) {
                    const uint32_t stage_mask =
                        record->stage == ShaderStage::Vertex ? 0x1u : 0x2u;
                    result.push_back(ShaderResourceBinding{
                        dit->second.set, dit->second.binding,
                        classify_descriptor(types, pointee, storage), count, stage_mask});
                }
            }
        }
        at += wc;
    }

    std::sort(result.begin(), result.end(), [](const auto& a, const auto& b) {
        if (a.set != b.set) return a.set < b.set;
        return a.binding < b.binding;
    });
    for (size_t j = 1; j < result.size(); ++j) {
        if (result[j-1].set == result[j].set && result[j-1].binding == result[j].binding) {
            if (result[j-1].type != result[j].type || result[j-1].count != result[j].count)
                return core::Result<std::vector<ShaderResourceBinding>>::Error(
                    "shader declares conflicting descriptor metadata");
            result[j-1].stage_mask |= result[j].stage_mask;
            result.erase(result.begin() + static_cast<std::ptrdiff_t>(j));
            --j;
        }
    }
    return core::Result<std::vector<ShaderResourceBinding>>::Ok(std::move(result));
}

core::Result<std::vector<std::vector<ShaderResourceBinding>>> ShaderProgramManager::descriptor_bindings_by_set(uint32_t program_id) const {
    const auto* iface = resource_interface(program_id);
    if (!iface) return core::Result<std::vector<std::vector<ShaderResourceBinding>>>::Error("unknown shader program");
    uint32_t max_set = 0;
    for (const auto& r : *iface) max_set = std::max(max_set, r.set);
    std::vector<std::vector<ShaderResourceBinding>> grouped(static_cast<size_t>(max_set) + 1u);
    for (const auto& r : *iface) {
        auto& set = grouped[r.set];
        auto it = std::find_if(set.begin(), set.end(), [&](const auto& existing) { return existing.binding == r.binding; });
        if (it != set.end()) {
            if (it->type != r.type || it->count != r.count || it->stage_mask != r.stage_mask)
                return core::Result<std::vector<std::vector<ShaderResourceBinding>>>::Error("conflicting duplicate descriptor binding");
            continue;
        }
        set.push_back(r);
    }
    for (auto& set : grouped) {
        std::sort(set.begin(), set.end(), [](const auto& a, const auto& b) { return a.binding < b.binding; });
    }
    return core::Result<std::vector<std::vector<ShaderResourceBinding>>>::Ok(std::move(grouped));
}

core::Result<void> ShaderProgramManager::reflect_program_interface(uint32_t program_id) {
    auto* p = const_cast<ShaderProgram*>(program(program_id));
    if (!p) return core::Result<void>::Error("unknown shader program");
    auto vs = reflect_shader_interface(p->vertex_shader);
    if (!vs.ok()) return core::Result<void>::Error(vs.error());
    auto fs = reflect_shader_interface(p->fragment_shader);
    if (!fs.ok()) return core::Result<void>::Error(fs.error());

    std::vector<ShaderResourceBinding> merged = vs.value();
    for (const auto& f : fs.value()) {
        auto it = std::find_if(merged.begin(), merged.end(), [&](const auto& b) {
            return b.set == f.set && b.binding == f.binding;
        });
        if (it == merged.end()) {
            merged.push_back(f);
        } else {
            if (it->type != f.type || it->count != f.count)
                return core::Result<void>::Error("vertex/fragment descriptor interface mismatch");
            it->stage_mask |= f.stage_mask;
        }
    }
    std::sort(merged.begin(), merged.end(), [](const auto& a, const auto& b) {
        if (a.set != b.set) return a.set < b.set;
        return a.binding < b.binding;
    });
    p->resources = std::move(merged);
    return validate_resource_interface(program_id);
}

std::string ShaderProgramManager::diagnostics() const {
    std::ostringstream s; s << "shaders=" << shaders_.size() << ";programs=" << programs_.size();
    return s.str();
}
} // namespace lg::gpu
