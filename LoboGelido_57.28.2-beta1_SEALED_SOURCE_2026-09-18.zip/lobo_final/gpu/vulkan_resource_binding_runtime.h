#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include "shader_program_manager.h"
#include "vulkan_descriptor_backend.h"
#include "vulkan_pipeline.h"
#include "vulkan_resource_backend.h"
#include "../core/result.h"

namespace lg::gpu {

// Coordinates reflected shader interfaces, descriptor layouts/sets, resource writes,
// and the active Vulkan pipeline. It is intentionally backend-facing and does not
// contain Nintendo proprietary packet definitions or assets.
class VulkanResourceBindingRuntime {
public:
    core::Result<void> initialize(ShaderProgramManager* programs,
                                   VulkanDescriptorBackend* descriptors,
                                   VulkanResourceBackend* resources,
                                   VulkanPipeline* pipelines);
    core::Result<void> prepare_program(uint32_t program_id, uint32_t first_layout_id = 0x10000u,
                                       uint32_t first_set_id = 0x20000u);
    core::Result<void> prepare_pipeline(uint32_t pipeline_id, void* render_pass, uint32_t program_id);
    core::Result<void> bind_buffer(uint32_t program_id, uint32_t set, uint32_t binding,
                                   uint32_t resource_id, uint64_t offset = 0, uint64_t range = 0);
    core::Result<void> bind_sampled_image(uint32_t program_id, uint32_t set, uint32_t binding,
                                          uint32_t resource_id);
    core::Result<void> update(uint32_t program_id, uint32_t set);
    core::Result<void> validate(uint32_t program_id, uint32_t set) const;
    core::Result<void> bind(void* command_buffer, uint32_t pipeline_id, uint32_t program_id, uint32_t set);
    uint32_t descriptor_set_id(uint32_t program_id, uint32_t set) const noexcept;
    uint32_t descriptor_layout_id(uint32_t program_id, uint32_t set) const noexcept;
    size_t prepared_program_count() const noexcept;
    size_t prepared_set_count() const noexcept;
    void reset() noexcept;
    std::string diagnostics() const;
private:
    struct ProgramBinding { uint32_t first_layout_id{}; uint32_t first_set_id{}; uint32_t set_count{}; };
    ShaderProgramManager* programs_{};
    VulkanDescriptorBackend* descriptors_{};
    VulkanResourceBackend* resources_{};
    VulkanPipeline* pipelines_{};
    std::unordered_map<uint32_t, ProgramBinding> programs_map_;
};
}
