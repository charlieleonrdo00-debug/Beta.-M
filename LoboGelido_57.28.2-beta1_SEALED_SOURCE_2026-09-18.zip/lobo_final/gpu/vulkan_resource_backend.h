#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include "../core/result.h"
#include "gpu_resource_manager.h"

namespace lg::gpu {

class VulkanResourceBackend {
public:
    VulkanResourceBackend();
    ~VulkanResourceBackend();
    VulkanResourceBackend(const VulkanResourceBackend&) = delete;
    VulkanResourceBackend& operator=(const VulkanResourceBackend&) = delete;

    core::Result<void> initialize(void* physical_device, void* device);
    core::Result<uint64_t> create_buffer(uint32_t resource_id, const BufferDesc& desc);
    core::Result<uint64_t> create_image(uint32_t resource_id, const ImageDesc& desc);
    core::Result<void> destroy_resource(uint32_t resource_id, ResourceType type);
    void shutdown() noexcept;
    bool ready() const noexcept { return ready_; }
    size_t live_buffers() const noexcept { return live_buffers_; }
    size_t live_images() const noexcept { return live_images_; }
    size_t live_memory_bytes() const noexcept { return live_memory_bytes_; }
    void* buffer_handle(uint32_t resource_id) const noexcept;
    void* image_view(uint32_t resource_id) const noexcept;
    std::string diagnostics() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
    void* physical_device_{nullptr};
    void* device_{nullptr};
    bool ready_{false};
    size_t live_buffers_{0};
    size_t live_images_{0};
    size_t live_memory_bytes_{0};
};

} // namespace lg::gpu
