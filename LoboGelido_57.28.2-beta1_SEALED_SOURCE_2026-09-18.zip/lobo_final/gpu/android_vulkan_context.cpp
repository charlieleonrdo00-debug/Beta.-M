#include "android_vulkan_context.h"
#if defined(__ANDROID__)
#ifndef VK_USE_PLATFORM_ANDROID_KHR
#define VK_USE_PLATFORM_ANDROID_KHR
#endif
#include <vulkan/vulkan.h>
#include <android/native_window.h>
#include <cstring>
#include <sstream>
#include <vector>

namespace lg::gpu {
namespace {
const char* result_name(VkResult r) {
    switch (r) { case VK_SUCCESS: return "VK_SUCCESS"; case VK_ERROR_INCOMPATIBLE_DRIVER: return "VK_ERROR_INCOMPATIBLE_DRIVER"; case VK_ERROR_EXTENSION_NOT_PRESENT: return "VK_ERROR_EXTENSION_NOT_PRESENT"; case VK_ERROR_INITIALIZATION_FAILED: return "VK_ERROR_INITIALIZATION_FAILED"; default: return "VkResult"; }
}
}

AndroidVulkanContext::~AndroidVulkanContext() { shutdown(); }

core::Result<void> AndroidVulkanContext::initialize(void* android_surface) {
    shutdown();
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "Lobo Gelido";
    app.applicationVersion = VK_MAKE_VERSION(40, 0, 0);
    app.pEngineName = "Lobo Gelido Runtime";
    app.engineVersion = VK_MAKE_VERSION(40, 0, 0);
    app.apiVersion = VK_API_VERSION_1_1;

    std::vector<const char*> exts = {VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME};
    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &app; ci.enabledExtensionCount = static_cast<uint32_t>(exts.size()); ci.ppEnabledExtensionNames = exts.data();
    VkInstance instance{};
    VkResult r = vkCreateInstance(&ci, nullptr, &instance);
    if (r != VK_SUCCESS) return core::Result<void>::Error(result_name(r));
    instance_ = reinterpret_cast<void*>(instance);

    uint32_t count = 0;
    r = vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (r != VK_SUCCESS || count == 0) { shutdown(); return core::Result<void>::Error("no Vulkan physical device"); }
    std::vector<VkPhysicalDevice> devices(count); vkEnumeratePhysicalDevices(instance, &count, devices.data());
    VkPhysicalDevice chosen = VK_NULL_HANDLE; uint32_t family = UINT32_MAX;
    for (auto pd : devices) {
        uint32_t qcount = 0; vkGetPhysicalDeviceQueueFamilyProperties(pd, &qcount, nullptr);
        std::vector<VkQueueFamilyProperties> q(qcount); vkGetPhysicalDeviceQueueFamilyProperties(pd, &qcount, q.data());
        for (uint32_t i=0;i<qcount;++i) if ((q[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && (q[i].queueFlags & VK_QUEUE_COMPUTE_BIT)) { chosen=pd; family=i; break; }
        if (chosen) break;
    }
    if (!chosen) { shutdown(); return core::Result<void>::Error("no graphics/compute Vulkan queue"); }
    physical_device_ = reinterpret_cast<void*>(chosen); graphics_queue_family_ = family;
    VkPhysicalDeviceProperties props{}; vkGetPhysicalDeviceProperties(chosen, &props); gpu_name_ = props.deviceName; api_version_ = props.apiVersion;

    float priority = 1.0f; VkDeviceQueueCreateInfo qi{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO}; qi.queueFamilyIndex=family; qi.queueCount=1; qi.pQueuePriorities=&priority;
    std::vector<const char*> dev_exts;
    if (android_surface) dev_exts.push_back(VK_KHR_SWAPCHAIN_EXTENSION_NAME);
    VkPhysicalDeviceFeatures features{};
    VkDeviceCreateInfo di{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO}; di.queueCreateInfoCount=1; di.pQueueCreateInfos=&qi; di.pEnabledFeatures=&features;
    if (!dev_exts.empty()) { di.enabledExtensionCount=static_cast<uint32_t>(dev_exts.size()); di.ppEnabledExtensionNames=dev_exts.data(); }
    VkDevice device{}; r=vkCreateDevice(chosen,&di,nullptr,&device);
    if(r!=VK_SUCCESS){shutdown();return core::Result<void>::Error(result_name(r));}
    device_=reinterpret_cast<void*>(device);
    VkQueue queue{}; vkGetDeviceQueue(device,family,0,&queue); graphics_queue_=reinterpret_cast<void*>(queue);

    if (android_surface) {
        ANativeWindow* window = reinterpret_cast<ANativeWindow*>(android_surface);
        VkAndroidSurfaceCreateInfoKHR si{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR}; si.window=window;
        VkSurfaceKHR surface{}; r=vkCreateAndroidSurfaceKHR(instance,&si,nullptr,&surface);
        if(r!=VK_SUCCESS){shutdown();return core::Result<void>::Error(result_name(r));}
        surface_=reinterpret_cast<void*>(surface); surface_ready_=true;
        VkBool32 present = VK_FALSE; vkGetPhysicalDeviceSurfaceSupportKHR(chosen,family,surface,&present);
        if (!present) { shutdown(); return core::Result<void>::Error("graphics queue cannot present to Android surface"); }
    }
    ready_=true; return core::Result<void>::Ok();
}

void AndroidVulkanContext::shutdown() noexcept {
    const auto device = reinterpret_cast<VkDevice>(device_);
    const auto instance = reinterpret_cast<VkInstance>(instance_);
    const auto surface = reinterpret_cast<VkSurfaceKHR>(surface_);
    if(device) vkDeviceWaitIdle(device);
    if(surface && instance) vkDestroySurfaceKHR(instance,surface,nullptr);
    if(device) vkDestroyDevice(device,nullptr);
    if(instance) vkDestroyInstance(instance,nullptr);
    instance_=physical_device_=device_=surface_=graphics_queue_=nullptr; api_version_=0; graphics_queue_family_=UINT32_MAX; ready_=surface_ready_=false; gpu_name_.clear();
}
std::string AndroidVulkanContext::diagnostics() const { std::ostringstream s; s<<"Vulkan="<<(ready_?"READY":"OFF")<<";surface="<<(surface_ready_?"READY":"OFF")<<";gpu="<<(gpu_name_.empty()?"none":gpu_name_)<<";queue="<<graphics_queue_family_; return s.str(); }
} // namespace lg::gpu
#else
namespace lg::gpu { AndroidVulkanContext::~AndroidVulkanContext() = default; core::Result<void> AndroidVulkanContext::initialize(void*) { return core::Result<void>::Error("Android Vulkan backend unavailable on host"); } void AndroidVulkanContext::shutdown() noexcept {} std::string AndroidVulkanContext::diagnostics() const { return "Vulkan=OFF;surface=OFF;gpu=none;queue=none"; } }
#endif
