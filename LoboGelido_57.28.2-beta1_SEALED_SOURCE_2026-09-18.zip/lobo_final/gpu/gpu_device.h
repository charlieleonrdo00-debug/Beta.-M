#pragma once
#include <cstdint>
#include <string>
#include "../core/result.h"

namespace lg::gpu {

enum class Backend : uint8_t { None, Vulkan };

struct DeviceInfo {
    Backend backend{Backend::None};
    const char* api{"None"};
    uint32_t api_version{};
    bool timeline_semaphore{false};
    bool dynamic_rendering{false};
    bool descriptor_indexing{false};
    bool shader_int16{false};
    bool initialized{false};
};

class GpuDevice {
public:
    // Core builds do not fabricate Vulkan capabilities. A platform backend must
    // supply the capabilities it actually queried from VkPhysicalDevice.
    core::Result<void> initialize();
    core::Result<void> initialize(const DeviceInfo& actual_capabilities);
    void shutdown() noexcept;
    bool ready() const noexcept { return info_.initialized; }
    const DeviceInfo& info() const noexcept { return info_; }
    std::string capability_string() const;
private:
    DeviceInfo info_{};
};

} // namespace lg::gpu
