#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include "../core/result.h"

namespace lg::gpu {

class VulkanGpuRuntime {
public:
    VulkanGpuRuntime();
    ~VulkanGpuRuntime();
    VulkanGpuRuntime(const VulkanGpuRuntime&) = delete;
    VulkanGpuRuntime& operator=(const VulkanGpuRuntime&) = delete;

    core::Result<void> initialize(void* physical_device, void* device, uint32_t queue_family);
    void shutdown() noexcept;

    // Records timestamps into an already-recording command buffer. On devices
    // without timestamp support these are harmless no-ops and return false.
    bool write_begin_timestamp(void* command_buffer) noexcept;
    bool write_end_timestamp(void* command_buffer) noexcept;
    void collect_completed() noexcept;

    bool ready() const noexcept { return ready_; }
    bool timestamp_supported() const noexcept { return timestamp_supported_; }
    double last_gpu_ms() const noexcept { return last_gpu_ms_; }
    std::string diagnostics() const;

private:
    struct Impl;
    void* physical_device_{nullptr};
    void* device_{nullptr};
    uint32_t queue_family_{0};
    bool ready_{false};
    bool timestamp_supported_{false};
    double last_gpu_ms_{0.0};
    std::unique_ptr<Impl> impl_;
};

} // namespace lg::gpu
