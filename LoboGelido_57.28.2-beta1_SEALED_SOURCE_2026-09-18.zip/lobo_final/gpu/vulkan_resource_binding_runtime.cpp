#include "vulkan_resource_binding_runtime.h"
#include <sstream>

namespace lg::gpu {
core::Result<void> VulkanResourceBindingRuntime::initialize(ShaderProgramManager* programs,
                                                             VulkanDescriptorBackend* descriptors,
                                                             VulkanResourceBackend* resources,
                                                             VulkanPipeline* pipelines) {
    reset();
    if (!programs || !descriptors || !resources || !pipelines)
        return core::Result<void>::Error("invalid GPU resource binding runtime dependencies");
    if (!descriptors->ready() || !resources->ready() || !pipelines->ready())
        return core::Result<void>::Error("GPU resource binding runtime dependencies are not ready");
    programs_ = programs; descriptors_ = descriptors; resources_ = resources; pipelines_ = pipelines;
    return core::Result<void>::Ok();
}

core::Result<void> VulkanResourceBindingRuntime::prepare_program(uint32_t program_id,
                                                                  uint32_t first_layout_id,
                                                                  uint32_t first_set_id) {
    if (!programs_ || !descriptors_ || !resources_ || !pipelines_)
        return core::Result<void>::Error("GPU resource binding runtime not initialized");
    if (!programs_->program(program_id)) return core::Result<void>::Error("unknown shader program");
    auto grouped = programs_->descriptor_bindings_by_set(program_id);
    if (!grouped.ok()) return core::Result<void>::Error(grouped.error());
    auto layouts = descriptors_->create_layouts_for_program(*programs_, program_id, first_layout_id);
    if (!layouts.ok()) return core::Result<void>::Error(layouts.error());
    for (size_t i = 0; i < layouts.value().size(); ++i) {
        const uint32_t sid = first_set_id + static_cast<uint32_t>(i);
        if (descriptors_->set_layout_id(sid) == 0) {
            auto ar = descriptors_->allocate_set(sid, layouts.value()[i]);
            if (!ar.ok()) return core::Result<void>::Error(ar.error());
        } else if (descriptors_->set_layout_id(sid) != layouts.value()[i]) {
            return core::Result<void>::Error("descriptor set id is already associated with another layout");
        }
    }
    programs_map_[program_id] = ProgramBinding{first_layout_id, first_set_id, static_cast<uint32_t>(layouts.value().size())};
    return core::Result<void>::Ok();
}

core::Result<void> VulkanResourceBindingRuntime::prepare_pipeline(uint32_t pipeline_id, void* render_pass, uint32_t program_id) {
    auto it = programs_map_.find(program_id);
    if (it == programs_map_.end()) {
        auto r = prepare_program(program_id);
        if (!r.ok()) return r;
        it = programs_map_.find(program_id);
    }
    if (pipelines_->has_pipeline_variant_for_program(pipeline_id, program_id)) return core::Result<void>::Ok();
    return pipelines_->create_graphics_pipeline_variant_from_program_auto_layouts(
        pipeline_id, render_pass, *programs_, program_id, *descriptors_, it->second.first_layout_id);
}

core::Result<void> VulkanResourceBindingRuntime::bind_buffer(uint32_t program_id, uint32_t set, uint32_t binding,
                                                             uint32_t resource_id, uint64_t offset, uint64_t range) {
    auto it = programs_map_.find(program_id);
    if (it == programs_map_.end()) { auto r = prepare_program(program_id); if (!r.ok()) return r; it = programs_map_.find(program_id); }
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    return descriptors_->bind_buffer(it->second.first_set_id + set, binding, resource_id, offset, range);
}

core::Result<void> VulkanResourceBindingRuntime::bind_sampled_image(uint32_t program_id, uint32_t set, uint32_t binding,
                                                                    uint32_t resource_id) {
    auto it = programs_map_.find(program_id);
    if (it == programs_map_.end()) { auto r = prepare_program(program_id); if (!r.ok()) return r; it = programs_map_.find(program_id); }
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    return descriptors_->bind_sampled_image(it->second.first_set_id + set, binding, resource_id);
}

core::Result<void> VulkanResourceBindingRuntime::update(uint32_t program_id, uint32_t set) {
    auto it = programs_map_.find(program_id); if (it == programs_map_.end()) return core::Result<void>::Error("shader program has not been prepared");
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    const uint32_t sid = it->second.first_set_id + set;
    auto v = descriptors_->validate_set_against_program(sid, *programs_, program_id, set); if (!v.ok()) return v;
    return descriptors_->update(sid);
}

core::Result<void> VulkanResourceBindingRuntime::validate(uint32_t program_id, uint32_t set) const {
    auto it = programs_map_.find(program_id); if (it == programs_map_.end()) return core::Result<void>::Error("shader program has not been prepared");
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    return descriptors_->validate_set_against_program(it->second.first_set_id + set, *programs_, program_id, set);
}

core::Result<void> VulkanResourceBindingRuntime::bind(void* command_buffer, uint32_t pipeline_id, uint32_t program_id, uint32_t set) {
    if (!command_buffer) return core::Result<void>::Error("command buffer is null");
    auto it = programs_map_.find(program_id);
    if (it == programs_map_.end()) { auto r = prepare_program(program_id); if (!r.ok()) return r; it = programs_map_.find(program_id); }
    if (set >= it->second.set_count) return core::Result<void>::Error("descriptor set index is outside the program interface");
    if (!pipelines_->has_pipeline_variant_for_program(pipeline_id, program_id)) return core::Result<void>::Error("pipeline variant for shader program is not ready");
    const uint32_t sid = it->second.first_set_id + set;
    auto v = descriptors_->validate_set_against_program(sid, *programs_, program_id, set); if (!v.ok()) return v;
    auto u = descriptors_->update(sid); if (!u.ok()) return u;
    void* layout = pipelines_->pipeline_layout_handle(pipeline_id); if (!layout) return core::Result<void>::Error("pipeline layout for resource binding is unavailable");
    descriptors_->bind_set(command_buffer, layout, sid, set);
    return core::Result<void>::Ok();
}

uint32_t VulkanResourceBindingRuntime::descriptor_set_id(uint32_t program_id, uint32_t set) const noexcept {
    auto it=programs_map_.find(program_id); if(it==programs_map_.end()||set>=it->second.set_count)return 0; return it->second.first_set_id+set;
}
uint32_t VulkanResourceBindingRuntime::descriptor_layout_id(uint32_t program_id, uint32_t set) const noexcept {
    auto it=programs_map_.find(program_id); if(it==programs_map_.end()||set>=it->second.set_count)return 0; return it->second.first_layout_id+set;
}
size_t VulkanResourceBindingRuntime::prepared_program_count() const noexcept { return programs_map_.size(); }
size_t VulkanResourceBindingRuntime::prepared_set_count() const noexcept { size_t n=0; for(const auto& [_,p]:programs_map_) n+=p.set_count; return n; }
void VulkanResourceBindingRuntime::reset() noexcept { programs_map_.clear(); programs_=nullptr; descriptors_=nullptr; resources_=nullptr; pipelines_=nullptr; }
std::string VulkanResourceBindingRuntime::diagnostics() const { std::ostringstream s; s<<"vkBindingRuntime="<<(programs_?"READY":"OFF")<<";programs="<<prepared_program_count()<<";sets="<<prepared_set_count(); return s.str(); }
}
