#include "vulkan_command_executor.h"
#include <sstream>
#if defined(__ANDROID__)
#include <vulkan/vulkan.h>
namespace lg::gpu {
core::Result<uint32_t> VulkanCommandExecutor::execute(void* cb, const GpuCommandProcessor& processor, VulkanPipeline* pipeline, const VulkanDescriptorBackend* descriptors, const VulkanResourceBackend* resources, const ShaderProgramManager* programs, void* render_pass, VulkanResourceBindingRuntime* binding_runtime) const {
    if (!cb) return core::Result<uint32_t>::Error("Vulkan command buffer is null");
    uint32_t done = 0;
    VkCommandBuffer cmd = reinterpret_cast<VkCommandBuffer>(cb);
    for (const auto& c : processor.commands()) {
        ++submitted_;
        switch (c.op) {
        case GpuOp::SetViewport: {
            VkViewport vp{}; vp.x=c.x; vp.y=c.y; vp.width=c.z; vp.height=c.w; vp.minDepth=0.0f; vp.maxDepth=1.0f;
            vkCmdSetViewport(cmd,0,1,&vp); ++done; ++executed_; break;
        }
        case GpuOp::SetScissor: {
            VkRect2D sc{}; sc.offset={static_cast<int32_t>(c.x),static_cast<int32_t>(c.y)}; sc.extent={c.a,c.b};
            vkCmdSetScissor(cmd,0,1,&sc); ++done; ++executed_; break;
        }
        case GpuOp::BindPipeline: {
            if (!pipeline) { ++rejected_; return core::Result<uint32_t>::Error("graphics pipeline runtime is required"); }
            const uint32_t pipeline_id = processor.state().pipeline_id;
            const uint32_t program_id = processor.state().shader_program_id;
            if (program_id != 0) {
                if (!programs || !render_pass) { ++rejected_; return core::Result<uint32_t>::Error("shader program binding requires program manager and render pass"); }
                if (!programs->program(program_id)) { ++rejected_; return core::Result<uint32_t>::Error("requested shader program is not registered"); }
                if (binding_runtime) {
                    auto cr = binding_runtime->prepare_pipeline(pipeline_id, render_pass, program_id);
                    if (!cr.ok()) { ++rejected_; return core::Result<uint32_t>::Error(cr.error()); }
                } else if (!pipeline->has_pipeline_variant_for_program(pipeline_id, program_id)) {
                    auto cr = pipeline->create_graphics_pipeline_variant_from_program(pipeline_id, render_pass, *programs, program_id);
                    if (!cr.ok()) { ++rejected_; return core::Result<uint32_t>::Error(cr.error()); }
                }
            } else if (!pipeline->has_pipeline_variant(pipeline_id)) {
                ++rejected_; return core::Result<uint32_t>::Error("requested graphics pipeline variant is not ready");
            }
            if(!pipeline->bind_graphics_pipeline(cmd, pipeline_id)) { ++rejected_; return core::Result<uint32_t>::Error("requested graphics pipeline variant is not ready"); }
            ++done; ++executed_; break;
        }
        case GpuOp::BindVertexBuffer:
            if (!pipeline) { ++rejected_; return core::Result<uint32_t>::Error("pipeline runtime is required for vertex binding"); }
            if(!resources || !pipeline->bind_vertex_buffer(cmd, resources, processor.state().vertex_buffer_id, c.b)){ ++rejected_; return core::Result<uint32_t>::Error("requested vertex buffer resource is not ready"); } ++done; ++executed_; break;
        case GpuOp::BindDescriptorSet: {
            if (!pipeline || !descriptors || !descriptors->ready()) { ++rejected_; return core::Result<uint32_t>::Error("descriptor backend is not ready"); }
            uint32_t set_id=c.a; uint32_t first_set=c.b;
            if (processor.state().shader_program_id != 0 && programs && binding_runtime) {
                auto br = binding_runtime->bind(cmd, processor.state().pipeline_id, processor.state().shader_program_id, first_set);
                if (!br.ok()) { ++rejected_; return core::Result<uint32_t>::Error(br.error()); }
            } else {
                if (processor.state().shader_program_id != 0 && programs) {
                    auto vr = descriptors->validate_set_against_program(set_id, *programs, processor.state().shader_program_id, first_set);
                    if (!vr.ok()) { ++rejected_; return core::Result<uint32_t>::Error(vr.error()); }
                }
                void* layout=pipeline->pipeline_layout_handle(processor.state().pipeline_id); if(!layout){ ++rejected_; return core::Result<uint32_t>::Error("pipeline layout variant is not ready"); }
                descriptors->bind_set(cmd,layout,set_id,first_set);
            }
            ++done; ++executed_; break; }
        case GpuOp::Draw:
            if (!pipeline || !resources || !pipeline->draw(cmd, processor.state().pipeline_id, resources, processor.state().vertex_buffer_id, c.a ? c.a : 3, c.b, c.c)) { ++rejected_; return core::Result<uint32_t>::Error("draw requires a ready Vulkan graphics pipeline and vertex buffer"); }
            ++draws_; ++executed_; ++done; break;
        case GpuOp::Clear: {
            VkClearAttachment a{}; a.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT; a.colorAttachment=0; a.clearValue.color.float32[0]=c.x; a.clearValue.color.float32[1]=c.y; a.clearValue.color.float32[2]=c.z; a.clearValue.color.float32[3]=c.w;
            VkClearRect r{}; r.rect.offset={0,0}; r.rect.extent={processor.state().viewport_w>0?static_cast<uint32_t>(processor.state().viewport_w):1u, processor.state().viewport_h>0?static_cast<uint32_t>(processor.state().viewport_h):1u}; r.baseArrayLayer=0; r.layerCount=1;
            vkCmdClearAttachments(cmd,1,&a,1,&r); ++clears_; ++executed_; ++done; break;
        }
        case GpuOp::Barrier: {
            VkMemoryBarrier b{VK_STRUCTURE_TYPE_MEMORY_BARRIER}; b.srcAccessMask=VK_ACCESS_MEMORY_READ_BIT|VK_ACCESS_MEMORY_WRITE_BIT; b.dstAccessMask=VK_ACCESS_MEMORY_READ_BIT|VK_ACCESS_MEMORY_WRITE_BIT;
            vkCmdPipelineBarrier(cmd,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,0,1,&b,0,nullptr,0,nullptr);
            ++barriers_; ++executed_; ++done; break;
        }
        default: ++rejected_; return core::Result<uint32_t>::Error("unsupported GPU operation");
        }
    }
    return core::Result<uint32_t>::Ok(done);
}
std::string VulkanCommandExecutor::diagnostics() const { std::ostringstream s; s<<"vkExec="<<executed_<<"/"<<submitted_<<";draws="<<draws_<<";clears="<<clears_<<";barriers="<<barriers_<<";rejected="<<rejected_; return s.str(); }
}
#else
namespace lg::gpu {
core::Result<uint32_t> VulkanCommandExecutor::execute(void*, const GpuCommandProcessor&, VulkanPipeline*, const VulkanDescriptorBackend*, const VulkanResourceBackend*, const ShaderProgramManager*, void*, VulkanResourceBindingRuntime*) const { ++rejected_; return core::Result<uint32_t>::Error("Android Vulkan command executor unavailable on host"); }
std::string VulkanCommandExecutor::diagnostics() const { return "vkExec=0/0;draws=0;clears=0;barriers=0;rejected=0"; }
}
#endif
