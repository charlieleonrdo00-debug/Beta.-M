#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "../core/result.h"
#include "spirv_module.h"
#include "shader_program_manager.h"
#include "vulkan_descriptor_backend.h"

namespace lg::gpu {

class VulkanResourceBackend;

class VulkanPipeline {
public:
    VulkanPipeline();
    ~VulkanPipeline();
    VulkanPipeline(const VulkanPipeline&) = delete;
    VulkanPipeline& operator=(const VulkanPipeline&) = delete;

    core::Result<void> initialize(void* physical_device, void* device);
    core::Result<void> create_shader_module(const SpirvModule& module, uint32_t stage, std::string debug_name);
    core::Result<void> create_graphics_pipeline(void* render_pass, const std::vector<void*>& descriptor_set_layouts = {});
    core::Result<void> create_graphics_pipeline_variant(uint32_t pipeline_id, void* render_pass, const std::vector<void*>& descriptor_set_layouts = {});
    core::Result<void> create_graphics_pipeline_variant_from_program(uint32_t pipeline_id, void* render_pass,
                                                                       const ShaderProgramManager& programs,
                                                                       uint32_t program_id,
                                                                       const std::vector<void*>& descriptor_set_layouts = {});
    core::Result<void> create_graphics_pipeline_variant_from_program_auto_layouts(uint32_t pipeline_id, void* render_pass,
                                                                                     const ShaderProgramManager& programs,
                                                                                     uint32_t program_id,
                                                                                     VulkanDescriptorBackend& descriptors,
                                                                                     uint32_t first_layout_id);
    core::Result<void> create_vertex_buffer(const void* data, size_t bytes);
    void bind_graphics_pipeline(void* command_buffer) const noexcept;
    bool bind_graphics_pipeline(void* command_buffer, uint32_t pipeline_id) const noexcept;
    bool has_pipeline_variant(uint32_t pipeline_id) const noexcept;
    bool has_pipeline_variant_for_program(uint32_t pipeline_id, uint32_t program_id) const noexcept;
    void bind_vertex_buffer(void* command_buffer) const noexcept;
    bool bind_vertex_buffer(void* command_buffer, const VulkanResourceBackend* resources, uint32_t resource_id, uint64_t offset = 0) const noexcept;
    bool draw(void* command_buffer, uint32_t vertex_count, uint32_t first_vertex = 0) const noexcept;
    bool draw(void* command_buffer, uint32_t pipeline_id, uint32_t vertex_count, uint32_t first_vertex = 0) const noexcept;
    bool draw(void* command_buffer, uint32_t pipeline_id, const VulkanResourceBackend* resources, uint32_t resource_id, uint32_t vertex_count, uint32_t first_vertex = 0, uint64_t offset = 0) const noexcept;
    bool draw_triangle(void* command_buffer) const noexcept;
    void bind_descriptor_set(void* command_buffer, uint32_t set_index, void* descriptor_set) const noexcept;
    void* pipeline_layout_handle() const noexcept;
    void* pipeline_layout_handle(uint32_t pipeline_id) const noexcept;
    bool graphics_pipeline_ready() const noexcept { return graphics_pipeline_ready_; }
    void shutdown() noexcept;
    bool ready() const noexcept { return ready_; }
    size_t shader_count() const noexcept { return shader_count_; }
    size_t vertex_bytes() const noexcept { return vertex_bytes_; }
    size_t pipeline_variant_count() const noexcept { return pipeline_variant_count_; }
    std::string diagnostics() const;

private:
    struct Impl;
    void* physical_device_{nullptr};
    void* device_{nullptr};
    std::unique_ptr<Impl> impl_;
    bool ready_{false};
    bool graphics_pipeline_ready_{false};
    size_t shader_count_{0};
    size_t vertex_bytes_{0};
    size_t pipeline_variant_count_{0};
};

} // namespace lg::gpu
