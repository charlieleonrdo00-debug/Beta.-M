#pragma once
#include <cstdint>
#include <string>
#include "../core/result.h"

namespace lg::gpu {

class AndroidVulkanContext {
public:
    AndroidVulkanContext() = default;
    ~AndroidVulkanContext();
    AndroidVulkanContext(const AndroidVulkanContext&) = delete;
    AndroidVulkanContext& operator=(const AndroidVulkanContext&) = delete;

    core::Result<void> initialize(void* android_surface);
    void shutdown() noexcept;
    bool ready() const noexcept { return ready_; }
    bool surface_ready() const noexcept { return surface_ready_; }
    std::string diagnostics() const;

    uint32_t api_version() const noexcept { return api_version_; }
    uint32_t graphics_queue_family() const noexcept { return graphics_queue_family_; }
    void* instance_handle() const noexcept { return instance_; }
    void* physical_device_handle() const noexcept { return physical_device_; }
    void* device_handle() const noexcept { return device_; }
    void* surface_handle() const noexcept { return surface_; }
    void* graphics_queue_handle() const noexcept { return graphics_queue_; }

private:
    void* instance_{nullptr};
    void* physical_device_{nullptr};
    void* device_{nullptr};
    void* surface_{nullptr};
    void* graphics_queue_{nullptr};
    uint32_t api_version_{0};
    uint32_t graphics_queue_family_{UINT32_MAX};
    bool ready_{false};
    bool surface_ready_{false};
    std::string gpu_name_;
};

} // namespace lg::gpu
