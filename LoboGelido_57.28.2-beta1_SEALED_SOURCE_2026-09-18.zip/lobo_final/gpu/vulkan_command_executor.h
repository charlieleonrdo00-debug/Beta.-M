#pragma once
#include <cstdint>
#include <string>
#include "gpu_command_processor.h"
#include "vulkan_pipeline.h"
#include "vulkan_descriptor_backend.h"
#include "vulkan_resource_backend.h"
#include "shader_program_manager.h"
#include "vulkan_resource_binding_runtime.h"

namespace lg::gpu {

// Executes the clean-room backend-neutral command stream against a live Vulkan
// command buffer. Guest packet decoding remains separate from Vulkan details.
class VulkanCommandExecutor {
public:
    core::Result<uint32_t> execute(void* command_buffer,
                                   const GpuCommandProcessor& processor,
                                   VulkanPipeline* pipeline = nullptr,
                                   const VulkanDescriptorBackend* descriptors = nullptr,
                                   const VulkanResourceBackend* resources = nullptr,
                                   const ShaderProgramManager* programs = nullptr,
                                   void* render_pass = nullptr,
                                   VulkanResourceBindingRuntime* binding_runtime = nullptr) const;
    std::string diagnostics() const;

private:
    mutable uint64_t submitted_{0};
    mutable uint64_t executed_{0};
    mutable uint64_t rejected_{0};
    mutable uint64_t draws_{0};
    mutable uint64_t clears_{0};
    mutable uint64_t barriers_{0};
};

} // namespace lg::gpu
