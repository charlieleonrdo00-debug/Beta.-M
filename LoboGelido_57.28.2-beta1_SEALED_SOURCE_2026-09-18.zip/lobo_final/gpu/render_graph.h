#pragma once
#include <cstdint>
#include <vector>
#include "../core/result.h"

namespace lg::gpu {

enum class PassType : uint8_t { Graphics, Compute, Transfer };

struct Pass {
    PassType type{};
    uint32_t id{};
    std::vector<uint32_t> depends_on;
};

class RenderGraph {
public:
    core::Result<void> add(Pass pass);
    core::Result<std::vector<uint32_t>> compile() const;
    void clear() noexcept { passes_.clear(); }
    const std::vector<Pass>& passes() const noexcept { return passes_; }
private:
    std::vector<Pass> passes_;
};

} // namespace lg::gpu
