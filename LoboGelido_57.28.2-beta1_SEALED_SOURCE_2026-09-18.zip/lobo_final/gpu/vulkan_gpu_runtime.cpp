#include "vulkan_gpu_runtime.h"
#if defined(__ANDROID__)
#include <vulkan/vulkan.h>
#include <sstream>
#include <vector>

namespace lg::gpu {
struct VulkanGpuRuntime::Impl {
    VkPipelineCache pipeline_cache{VK_NULL_HANDLE};
    VkQueryPool timestamps{VK_NULL_HANDLE};
    float timestamp_period{0.0f};
    bool query_ready{false};
};
namespace { template<class T> T as(void* p){ return reinterpret_cast<T>(p); } }
VulkanGpuRuntime::VulkanGpuRuntime() = default;
VulkanGpuRuntime::~VulkanGpuRuntime(){ shutdown(); }
core::Result<void> VulkanGpuRuntime::initialize(void* pd, void* d, uint32_t qf){
    shutdown();
    if(!pd || !d) return core::Result<void>::Error("invalid Vulkan GPU runtime handles");
    physical_device_=pd; device_=d; queue_family_=qf; impl_=std::make_unique<Impl>();
    VkDevice dev=as<VkDevice>(device_); VkPhysicalDevice phy=as<VkPhysicalDevice>(physical_device_);
    VkPipelineCacheCreateInfo pci{VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO};
    if(vkCreatePipelineCache(dev,&pci,nullptr,&impl_->pipeline_cache)!=VK_SUCCESS){ shutdown(); return core::Result<void>::Error("pipeline cache creation failed"); }
    VkPhysicalDeviceProperties props{}; vkGetPhysicalDeviceProperties(phy,&props); impl_->timestamp_period=props.limits.timestampPeriod;
    uint32_t family_count=0; vkGetPhysicalDeviceQueueFamilyProperties(phy,&family_count,nullptr);
    if(qf>=family_count){ shutdown(); return core::Result<void>::Error("invalid Vulkan queue family"); }
    std::vector<VkQueueFamilyProperties> families(family_count); vkGetPhysicalDeviceQueueFamilyProperties(phy,&family_count,families.data());
    timestamp_supported_=families[qf].timestampValidBits != 0 && impl_->timestamp_period > 0.0f;
    if(timestamp_supported_){
        VkQueryPoolCreateInfo qi{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO}; qi.queryType=VK_QUERY_TYPE_TIMESTAMP; qi.queryCount=2;
        if(vkCreateQueryPool(dev,&qi,nullptr,&impl_->timestamps)==VK_SUCCESS) impl_->query_ready=true; else timestamp_supported_=false;
    }
    ready_=true; return core::Result<void>::Ok();
}
bool VulkanGpuRuntime::write_begin_timestamp(void* cb) noexcept{ if(!timestamp_supported_||!impl_||!impl_->query_ready||!cb)return false; vkCmdResetQueryPool(as<VkCommandBuffer>(cb),impl_->timestamps,0,2); vkCmdWriteTimestamp(as<VkCommandBuffer>(cb),VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,impl_->timestamps,0); return true; }
bool VulkanGpuRuntime::write_end_timestamp(void* cb) noexcept{ if(!timestamp_supported_||!impl_||!impl_->query_ready||!cb)return false; vkCmdWriteTimestamp(as<VkCommandBuffer>(cb),VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,impl_->timestamps,1); return true; }
void VulkanGpuRuntime::collect_completed() noexcept{
    if(!timestamp_supported_||!impl_||!impl_->query_ready)return;
    uint64_t data[2]{}; VkResult r=vkGetQueryPoolResults(as<VkDevice>(device_),impl_->timestamps,0,2,sizeof(data),data,sizeof(uint64_t)*2,VK_QUERY_RESULT_64_BIT);
    if(r==VK_SUCCESS && data[1]>=data[0]) last_gpu_ms_=(double)(data[1]-data[0])*(double)impl_->timestamp_period/1000000.0;
}
void VulkanGpuRuntime::shutdown() noexcept{ if(device_&&impl_){VkDevice d=as<VkDevice>(device_);if(impl_->timestamps)vkDestroyQueryPool(d,impl_->timestamps,nullptr);if(impl_->pipeline_cache)vkDestroyPipelineCache(d,impl_->pipeline_cache,nullptr);}impl_.reset();physical_device_=device_=nullptr;queue_family_=0;ready_=timestamp_supported_=false;last_gpu_ms_=0.0; }
std::string VulkanGpuRuntime::diagnostics() const{ std::ostringstream s; s<<"gpuRuntime="<<(ready_?"READY":"OFF")<<";pipelineCache="<<(impl_&&impl_->pipeline_cache?"READY":"OFF")<<";timestamps="<<(timestamp_supported_?"ON":"OFF")<<";gpuMs="<<last_gpu_ms_; return s.str(); }
}
#else
namespace lg::gpu { struct VulkanGpuRuntime::Impl {}; VulkanGpuRuntime::VulkanGpuRuntime()=default; VulkanGpuRuntime::~VulkanGpuRuntime()=default; core::Result<void> VulkanGpuRuntime::initialize(void*,void*,uint32_t){return core::Result<void>::Error("Android Vulkan GPU runtime unavailable on host");} void VulkanGpuRuntime::shutdown() noexcept{} bool VulkanGpuRuntime::write_begin_timestamp(void*) noexcept{return false;} bool VulkanGpuRuntime::write_end_timestamp(void*) noexcept{return false;} void VulkanGpuRuntime::collect_completed() noexcept{} std::string VulkanGpuRuntime::diagnostics()const{return "gpuRuntime=OFF;pipelineCache=OFF;timestamps=OFF;gpuMs=0";} }
#endif
