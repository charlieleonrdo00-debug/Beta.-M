#include "render_graph.h"
#include <unordered_map>
#include <unordered_set>

namespace lg::gpu {

core::Result<void> RenderGraph::add(Pass pass) {
    for (const auto& existing : passes_) {
        if (existing.id == pass.id) return core::Result<void>::Error("duplicate render pass id");
    }
    passes_.push_back(std::move(pass));
    return core::Result<void>::Ok();
}

core::Result<std::vector<uint32_t>> RenderGraph::compile() const {
    std::unordered_map<uint32_t, size_t> index;
    for (size_t i = 0; i < passes_.size(); ++i) index.emplace(passes_[i].id, i);
    std::vector<uint32_t> indegree(passes_.size());
    std::vector<std::vector<size_t>> edges(passes_.size());
    for (size_t i = 0; i < passes_.size(); ++i) {
        std::unordered_set<uint32_t> unique;
        for (uint32_t dep : passes_[i].depends_on) {
            if (!unique.insert(dep).second) continue;
            auto it = index.find(dep);
            if (it == index.end()) return core::Result<std::vector<uint32_t>>::Error("render graph dependency missing");
            edges[it->second].push_back(i);
            ++indegree[i];
        }
    }
    std::vector<size_t> ready;
    for (size_t i = 0; i < passes_.size(); ++i) if (indegree[i] == 0) ready.push_back(i);
    std::vector<uint32_t> order;
    order.reserve(passes_.size());
    for (size_t cursor = 0; cursor < ready.size(); ++cursor) {
        const size_t node = ready[cursor];
        order.push_back(passes_[node].id);
        for (size_t next : edges[node]) if (--indegree[next] == 0) ready.push_back(next);
    }
    if (order.size() != passes_.size()) return core::Result<std::vector<uint32_t>>::Error("render graph cycle");
    return core::Result<std::vector<uint32_t>>::Ok(std::move(order));
}

} // namespace lg::gpu
