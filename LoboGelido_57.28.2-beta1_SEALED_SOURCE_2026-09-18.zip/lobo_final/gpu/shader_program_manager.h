#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>
#include "spirv_module.h"
#include "../core/result.h"

namespace lg::gpu {

// Backend-neutral shader/program registry. It validates SPIR-V once, deduplicates
// identical modules, and groups vertex/fragment modules into immutable programs.
// Vulkan object creation remains in VulkanPipeline; no proprietary shader code is bundled.
enum class ShaderStage : uint32_t { Vertex = 1u, Fragment = 2u };

struct ShaderRecord {
    uint32_t id{};
    ShaderStage stage{};
    SpirvModule module{};
    std::string name;
    uint64_t hash{};
};

enum class ShaderResourceType : uint32_t { UniformBuffer = 0u, StorageBuffer = 1u, SampledImage = 2u };

// Backend-neutral descriptor contract for a graphics program. set/binding identify
// the guest resource slot; stage_mask uses ShaderStage bits (Vertex=1, Fragment=2).
struct ShaderResourceBinding {
    uint32_t set{};
    uint32_t binding{};
    ShaderResourceType type{};
    uint32_t count{1};
    uint32_t stage_mask{};
};

struct ShaderProgram {
    uint32_t id{};
    uint32_t vertex_shader{};
    uint32_t fragment_shader{};
    uint64_t key{};
    std::vector<ShaderResourceBinding> resources;
};

class ShaderProgramManager {
public:
    core::Result<uint32_t> add_shader(const std::vector<uint32_t>& spirv,
                                       ShaderStage stage,
                                       std::string name = {});
    core::Result<uint32_t> create_program(uint32_t vertex_shader,
                                          uint32_t fragment_shader);
    const ShaderRecord* shader(uint32_t id) const noexcept;
    const ShaderProgram* program(uint32_t id) const noexcept;
    core::Result<void> set_resource_interface(uint32_t program_id,
                                               std::vector<ShaderResourceBinding> bindings);
    const std::vector<ShaderResourceBinding>* resource_interface(uint32_t program_id) const noexcept;
    core::Result<void> validate_resource_interface(uint32_t program_id) const;
    core::Result<std::vector<ShaderResourceBinding>> reflect_shader_interface(uint32_t shader_id) const;
    core::Result<void> reflect_program_interface(uint32_t program_id);
    core::Result<std::vector<std::vector<ShaderResourceBinding>>> descriptor_bindings_by_set(uint32_t program_id) const;
    size_t shader_count() const noexcept { return shaders_.size(); }
    size_t program_count() const noexcept { return programs_.size(); }
    void clear() noexcept;
    std::string diagnostics() const;

private:
    static uint64_t hash_words(const std::vector<uint32_t>& words, ShaderStage stage) noexcept;
    uint32_t next_shader_id_{1};
    uint32_t next_program_id_{1};
    std::unordered_map<uint32_t, ShaderRecord> shaders_;
    std::unordered_map<uint32_t, ShaderProgram> programs_;
    std::unordered_map<uint64_t, uint32_t> shader_by_hash_;
    std::unordered_map<uint64_t, uint32_t> program_by_key_;
};

} // namespace lg::gpu
