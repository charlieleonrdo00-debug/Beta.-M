#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "gpu_command_processor.h"

namespace lg::gpu {

// Backend-neutral guest GPU packet. This is intentionally a clean-room
// intermediate format: it does not copy or expose proprietary Switch packet
// definitions. A future guest-facing decoder can feed this translator.
struct GuestGpuPacket {
    uint32_t opcode{};
    uint32_t a{}, b{}, c{}, d{};
    float x{}, y{}, z{}, w{};
};

struct GuestGpuTranslationStats {
    uint64_t packets{};
    uint64_t translated{};
    uint64_t rejected{};
};

class GuestGpuTranslator {
public:
    // Compact, documented intermediate opcodes. They map 1:1 onto the
    // backend-neutral GpuOp stream and can be emitted by any guest decoder.
    // BindPipeline uses: a=pipeline_id, b=shader_program_id (0 means unspecified).
    enum Opcode : uint32_t {
        SetViewport = 1, SetScissor = 2, BindPipeline = 3,
        BindVertexBuffer = 4, BindDescriptorSet = 5, Draw = 6,
        Clear = 7, Barrier = 8
    };

    core::Result<GpuCommand> translate(const GuestGpuPacket& packet) const;
    core::Result<std::vector<GpuCommand>> translate(const std::vector<GuestGpuPacket>& packets);
    void reset() noexcept { stats_ = {}; }
    const GuestGpuTranslationStats& stats() const noexcept { return stats_; }
    std::string diagnostics() const;

private:
    GuestGpuTranslationStats stats_{};
};

} // namespace lg::gpu
