#pragma once
#include <cstdint>
#include <string>
#include <memory>
#include "../core/result.h"
#include "vulkan_gpu_runtime.h"
#include "vulkan_pipeline.h"
#include "render_graph.h"
#include "gpu_command_processor.h"
#include "vulkan_command_executor.h"
#include "shader_program_manager.h"
#include "vulkan_resource_backend.h"
#include "vulkan_descriptor_backend.h"
#include "vulkan_resource_binding_runtime.h"
#include <vector>

namespace lg::gpu {

class VulkanPresenter {
public:
    VulkanPresenter();
    ~VulkanPresenter();
    VulkanPresenter(const VulkanPresenter&) = delete;
    VulkanPresenter& operator=(const VulkanPresenter&) = delete;

    core::Result<void> initialize(void* instance, void* physical_device, void* device,
                                  void* surface, uint32_t queue_family, void* queue);
    core::Result<void> recreate(uint32_t width, uint32_t height);
    core::Result<void> draw_frame();
    // Additive native-only smoke path: clears and presents without guest GPU commands.
    core::Result<void> draw_clear_frame();
    core::Result<void> submit_commands(const std::vector<GpuCommand>& commands);
    ShaderProgramManager& shader_programs() noexcept { return shader_programs_; }
    VulkanResourceBindingRuntime& resource_binding_runtime() noexcept { return resource_binding_runtime_; }
    const ShaderProgramManager& shader_programs() const noexcept { return shader_programs_; }
    void shutdown() noexcept;

    bool ready() const noexcept { return ready_; }
    uint32_t image_count() const noexcept { return image_count_; }
    uint32_t width() const noexcept { return width_; }
    uint32_t height() const noexcept { return height_; }
    std::string diagnostics() const;

private:
    struct Impl;
    void* instance_{nullptr};
    void* physical_device_{nullptr};
    void* device_{nullptr};
    void* surface_{nullptr};
    void* queue_{nullptr};
    uint32_t queue_family_{0};
    uint32_t image_count_{0};
    uint32_t width_{0};
    uint32_t height_{0};
    bool ready_{false};
    std::unique_ptr<Impl> impl_;
    VulkanGpuRuntime gpu_runtime_;
    VulkanPipeline pipeline_runtime_;
    VulkanResourceBackend resource_backend_;
    VulkanDescriptorBackend descriptor_backend_;
    RenderGraph render_graph_;
    GpuCommandProcessor command_processor_;
    VulkanCommandExecutor command_executor_;
    ShaderProgramManager shader_programs_;
    VulkanResourceBindingRuntime resource_binding_runtime_;
};

} // namespace lg::gpu
