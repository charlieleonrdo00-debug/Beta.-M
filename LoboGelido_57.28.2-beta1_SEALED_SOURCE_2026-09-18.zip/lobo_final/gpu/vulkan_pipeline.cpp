#include "vulkan_pipeline.h"
#include "vulkan_resource_backend.h"
#if defined(__ANDROID__)
#include <vulkan/vulkan.h>
#include <cstring>
#include <sstream>
#include <vector>
#include <unordered_map>
namespace lg::gpu {
struct VulkanPipeline::Impl {
    struct Shader { VkShaderModule module{}; uint32_t stage{}; std::string name; uint64_t key{}; };
    struct Variant { VkPipelineLayout layout{}; VkPipeline pipeline{}; uint32_t id{}; uint32_t program_id{}; };
    std::vector<Shader> shaders;
    VkPipelineLayout layout{VK_NULL_HANDLE};
    VkPipeline pipeline{VK_NULL_HANDLE};
    std::unordered_map<uint32_t, Variant> variants;
    std::unordered_map<uint64_t, VkShaderModule> shader_cache;
    VkBuffer vertex_buffer{VK_NULL_HANDLE};
    VkDeviceMemory vertex_memory{VK_NULL_HANDLE};
    size_t vertex_bytes{0};
};
template<class T> static T as(void* p){ return reinterpret_cast<T>(p); }
VulkanPipeline::VulkanPipeline()=default;
VulkanPipeline::~VulkanPipeline(){shutdown();}
core::Result<void> VulkanPipeline::initialize(void* pd, void* d){
    shutdown(); if(!pd||!d)return core::Result<void>::Error("invalid Vulkan pipeline handles");
    physical_device_=pd; device_=d; impl_=std::make_unique<Impl>(); ready_=true; return core::Result<void>::Ok();
}
core::Result<void> VulkanPipeline::create_shader_module(const SpirvModule& m,uint32_t stage,std::string name){
    if(!ready_||!impl_)return core::Result<void>::Error("pipeline runtime not initialized");
    if(!m.valid())return core::Result<void>::Error("invalid SPIR-V module");
    if(stage==0)return core::Result<void>::Error("shader stage must be nonzero");
    VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO}; ci.codeSize=m.words.size()*sizeof(uint32_t); ci.pCode=m.words.data();
    VkShaderModule sm{}; if(vkCreateShaderModule(as<VkDevice>(device_),&ci,nullptr,&sm)!=VK_SUCCESS)return core::Result<void>::Error("shader module creation failed");
    uint64_t key=1469598103934665603ull ^ static_cast<uint64_t>(stage); for(uint32_t w:m.words){key^=static_cast<uint64_t>(w); key*=1099511628211ull;}
    impl_->shaders.push_back({sm,stage,std::move(name),key}); impl_->shader_cache[key]=sm; shader_count_=impl_->shaders.size(); return core::Result<void>::Ok();
}
core::Result<void> VulkanPipeline::create_graphics_pipeline(void* render_pass, const std::vector<void*>& descriptor_set_layouts){
    return create_graphics_pipeline_variant(0, render_pass, descriptor_set_layouts);
}
core::Result<void> VulkanPipeline::create_graphics_pipeline_variant(uint32_t pipeline_id, void* render_pass, const std::vector<void*>& descriptor_set_layouts){
    if(!ready_||!impl_) return core::Result<void>::Error("pipeline runtime not initialized");
    if(!render_pass) return core::Result<void>::Error("render pass is null");
    if(impl_->shaders.size()<2) return core::Result<void>::Error("graphics pipeline requires vertex and fragment shaders");
    VkDevice dev=as<VkDevice>(device_);
    auto old=impl_->variants.find(pipeline_id);
    if(old!=impl_->variants.end()){
        if(old->second.pipeline) vkDestroyPipeline(dev,old->second.pipeline,nullptr);
        if(old->second.layout) vkDestroyPipelineLayout(dev,old->second.layout,nullptr);
        impl_->variants.erase(old);
    }
    std::vector<VkDescriptorSetLayout> set_layouts; set_layouts.reserve(descriptor_set_layouts.size());
    for(void* h:descriptor_set_layouts){ if(!h)return core::Result<void>::Error("null descriptor set layout"); set_layouts.push_back(as<VkDescriptorSetLayout>(h)); }
    VkPipelineLayoutCreateInfo li{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO}; li.setLayoutCount=static_cast<uint32_t>(set_layouts.size()); li.pSetLayouts=set_layouts.data();
    VkPipelineLayout layout{};
    if(vkCreatePipelineLayout(dev,&li,nullptr,&layout)!=VK_SUCCESS)return core::Result<void>::Error("pipeline layout creation failed");
    std::vector<VkPipelineShaderStageCreateInfo> stages; stages.reserve(impl_->shaders.size());
    for(const auto& sh:impl_->shaders){VkPipelineShaderStageCreateInfo si{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};si.stage=static_cast<VkShaderStageFlagBits>(sh.stage);si.module=sh.module;si.pName="main";stages.push_back(si);}
    VkVertexInputBindingDescription binding{}; binding.binding=0; binding.stride=5*sizeof(float); binding.inputRate=VK_VERTEX_INPUT_RATE_VERTEX;
    VkVertexInputAttributeDescription attrs[2]{}; attrs[0].location=0;attrs[0].binding=0;attrs[0].format=VK_FORMAT_R32G32_SFLOAT;attrs[0].offset=0; attrs[1].location=1;attrs[1].binding=0;attrs[1].format=VK_FORMAT_R32G32B32_SFLOAT;attrs[1].offset=2*sizeof(float);
    VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO}; vi.vertexBindingDescriptionCount=1;vi.pVertexBindingDescriptions=&binding;vi.vertexAttributeDescriptionCount=2;vi.pVertexAttributeDescriptions=attrs;
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO}; ia.topology=VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO}; vp.viewportCount=1;vp.scissorCount=1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO}; rs.polygonMode=VK_POLYGON_MODE_FILL;rs.cullMode=VK_CULL_MODE_NONE;rs.frontFace=VK_FRONT_FACE_COUNTER_CLOCKWISE;rs.lineWidth=1.0f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO}; ms.rasterizationSamples=VK_SAMPLE_COUNT_1_BIT;
    VkPipelineColorBlendAttachmentState cb{}; cb.colorWriteMask=0xF;
    VkPipelineColorBlendStateCreateInfo blend{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO}; blend.attachmentCount=1;blend.pAttachments=&cb;
    VkDynamicState dyns[2]={VK_DYNAMIC_STATE_VIEWPORT,VK_DYNAMIC_STATE_SCISSOR}; VkPipelineDynamicStateCreateInfo dyn{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};dyn.dynamicStateCount=2;dyn.pDynamicStates=dyns;
    VkGraphicsPipelineCreateInfo pi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO}; pi.stageCount=static_cast<uint32_t>(stages.size());pi.pStages=stages.data();pi.pVertexInputState=&vi;pi.pInputAssemblyState=&ia;pi.pViewportState=&vp;pi.pRasterizationState=&rs;pi.pMultisampleState=&ms;pi.pColorBlendState=&blend;pi.pDynamicState=&dyn;pi.layout=layout;pi.renderPass=as<VkRenderPass>(render_pass);pi.subpass=0;
    VkPipeline pipeline{};
    if(vkCreateGraphicsPipelines(dev,VK_NULL_HANDLE,1,&pi,nullptr,&pipeline)!=VK_SUCCESS){vkDestroyPipelineLayout(dev,layout,nullptr);return core::Result<void>::Error("graphics pipeline creation failed");}
    impl_->variants.emplace(pipeline_id,Impl::Variant{layout,pipeline,pipeline_id,0});
    if(pipeline_id==0){impl_->layout=layout;impl_->pipeline=pipeline;graphics_pipeline_ready_=true;}
    pipeline_variant_count_=impl_->variants.size();
    return core::Result<void>::Ok();
}
core::Result<void> VulkanPipeline::create_graphics_pipeline_variant_from_program(
    uint32_t pipeline_id, void* render_pass, const ShaderProgramManager& programs, uint32_t program_id,
    const std::vector<void*>& descriptor_set_layouts) {
    if (!ready_ || !impl_) return core::Result<void>::Error("pipeline runtime not initialized");
    const auto* program = programs.program(program_id);
    if (!program) return core::Result<void>::Error("unknown shader program");
    const auto* vs = programs.shader(program->vertex_shader);
    const auto* fs = programs.shader(program->fragment_shader);
    if (!vs || !fs || vs->stage != ShaderStage::Vertex || fs->stage != ShaderStage::Fragment)
        return core::Result<void>::Error("shader program is not a complete graphics program");

    auto ensure = [&](const ShaderRecord& rec, uint32_t vk_stage) -> core::Result<VkShaderModule> {
        auto it = impl_->shader_cache.find(rec.hash ^ (static_cast<uint64_t>(vk_stage) << 56));
        if (it != impl_->shader_cache.end()) return core::Result<VkShaderModule>::Ok(it->second);
        VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
        ci.codeSize = rec.module.words.size() * sizeof(uint32_t);
        ci.pCode = rec.module.words.data();
        VkShaderModule sm{};
        if (vkCreateShaderModule(as<VkDevice>(device_), &ci, nullptr, &sm) != VK_SUCCESS)
            return core::Result<VkShaderModule>::Error("shader module creation failed");
        impl_->shader_cache[rec.hash ^ (static_cast<uint64_t>(vk_stage) << 56)] = sm;
        impl_->shaders.push_back({sm, vk_stage, rec.name, rec.hash});
        shader_count_ = impl_->shaders.size();
        return core::Result<VkShaderModule>::Ok(sm);
    };

    auto vsm = ensure(*vs, VK_SHADER_STAGE_VERTEX_BIT);
    if (!vsm.ok()) return core::Result<void>::Error(vsm.error());
    auto fsm = ensure(*fs, VK_SHADER_STAGE_FRAGMENT_BIT);
    if (!fsm.ok()) return core::Result<void>::Error(fsm.error());

    VkDevice dev=as<VkDevice>(device_);
    auto old=impl_->variants.find(pipeline_id);
    if(old!=impl_->variants.end()){
        if(old->second.pipeline) vkDestroyPipeline(dev,old->second.pipeline,nullptr);
        if(old->second.layout) vkDestroyPipelineLayout(dev,old->second.layout,nullptr);
        impl_->variants.erase(old);
    }
    std::vector<VkDescriptorSetLayout> set_layouts; set_layouts.reserve(descriptor_set_layouts.size());
    for(void* h:descriptor_set_layouts){ if(!h)return core::Result<void>::Error("null descriptor set layout"); set_layouts.push_back(as<VkDescriptorSetLayout>(h)); }
    VkPipelineLayoutCreateInfo li{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    li.setLayoutCount=static_cast<uint32_t>(set_layouts.size()); li.pSetLayouts=set_layouts.data();
    VkPipelineLayout layout{};
    if(vkCreatePipelineLayout(dev,&li,nullptr,&layout)!=VK_SUCCESS)return core::Result<void>::Error("pipeline layout creation failed");

    VkPipelineShaderStageCreateInfo stages[2]{};
    stages[0].sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO; stages[0].stage=VK_SHADER_STAGE_VERTEX_BIT; stages[0].module=vsm.value(); stages[0].pName="main";
    stages[1].sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO; stages[1].stage=VK_SHADER_STAGE_FRAGMENT_BIT; stages[1].module=fsm.value(); stages[1].pName="main";
    VkVertexInputBindingDescription binding{}; binding.binding=0; binding.stride=5*sizeof(float); binding.inputRate=VK_VERTEX_INPUT_RATE_VERTEX;
    VkVertexInputAttributeDescription attrs[2]{}; attrs[0].location=0;attrs[0].binding=0;attrs[0].format=VK_FORMAT_R32G32_SFLOAT;attrs[0].offset=0; attrs[1].location=1;attrs[1].binding=0;attrs[1].format=VK_FORMAT_R32G32B32_SFLOAT;attrs[1].offset=2*sizeof(float);
    VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO}; vi.vertexBindingDescriptionCount=1;vi.pVertexBindingDescriptions=&binding;vi.vertexAttributeDescriptionCount=2;vi.pVertexAttributeDescriptions=attrs;
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO}; ia.topology=VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO}; vp.viewportCount=1;vp.scissorCount=1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO}; rs.polygonMode=VK_POLYGON_MODE_FILL;rs.cullMode=VK_CULL_MODE_NONE;rs.frontFace=VK_FRONT_FACE_COUNTER_CLOCKWISE;rs.lineWidth=1.0f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO}; ms.rasterizationSamples=VK_SAMPLE_COUNT_1_BIT;
    VkPipelineColorBlendAttachmentState cb{}; cb.colorWriteMask=0xF;
    VkPipelineColorBlendStateCreateInfo blend{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO}; blend.attachmentCount=1;blend.pAttachments=&cb;
    VkDynamicState dyns[2]={VK_DYNAMIC_STATE_VIEWPORT,VK_DYNAMIC_STATE_SCISSOR}; VkPipelineDynamicStateCreateInfo dyn{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};dyn.dynamicStateCount=2;dyn.pDynamicStates=dyns;
    VkGraphicsPipelineCreateInfo pi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO}; pi.stageCount=2;pi.pStages=stages;pi.pVertexInputState=&vi;pi.pInputAssemblyState=&ia;pi.pViewportState=&vp;pi.pRasterizationState=&rs;pi.pMultisampleState=&ms;pi.pColorBlendState=&blend;pi.pDynamicState=&dyn;pi.layout=layout;pi.renderPass=as<VkRenderPass>(render_pass);pi.subpass=0;
    VkPipeline pipeline{};
    if(vkCreateGraphicsPipelines(dev,VK_NULL_HANDLE,1,&pi,nullptr,&pipeline)!=VK_SUCCESS){vkDestroyPipelineLayout(dev,layout,nullptr);return core::Result<void>::Error("graphics pipeline creation failed");}
    impl_->variants.emplace(pipeline_id,Impl::Variant{layout,pipeline,pipeline_id,program_id});
    if(pipeline_id==0){impl_->layout=layout;impl_->pipeline=pipeline;graphics_pipeline_ready_=true;}
    pipeline_variant_count_=impl_->variants.size();
    return core::Result<void>::Ok();
}

core::Result<void> VulkanPipeline::create_graphics_pipeline_variant_from_program_auto_layouts(
    uint32_t pipeline_id, void* render_pass, const ShaderProgramManager& programs, uint32_t program_id,
    VulkanDescriptorBackend& descriptors, uint32_t first_layout_id) {
    auto layout_ids = descriptors.create_layouts_for_program(programs, program_id, first_layout_id);
    if (!layout_ids.ok()) return core::Result<void>::Error(layout_ids.error());
    std::vector<void*> handles;
    handles.reserve(layout_ids.value().size());
    for (uint32_t id : layout_ids.value()) {
        void* handle = descriptors.layout_handle(id);
        if (!handle) return core::Result<void>::Error("generated descriptor layout handle is unavailable");
        handles.push_back(handle);
    }
    return create_graphics_pipeline_variant_from_program(pipeline_id, render_pass, programs, program_id, handles);
}

core::Result<void> VulkanPipeline::create_vertex_buffer(const void* data,size_t bytes){
    if(!ready_||!impl_) return core::Result<void>::Error("pipeline runtime not initialized");
    if(!data||bytes==0||bytes% (5*sizeof(float))!=0) return core::Result<void>::Error("vertex data must contain position/color vertices");
    VkDevice dev=as<VkDevice>(device_); VkPhysicalDevice pd=as<VkPhysicalDevice>(physical_device_);
    if(impl_->vertex_buffer){vkDestroyBuffer(dev,impl_->vertex_buffer,nullptr);impl_->vertex_buffer=VK_NULL_HANDLE;}
    if(impl_->vertex_memory){vkFreeMemory(dev,impl_->vertex_memory,nullptr);impl_->vertex_memory=VK_NULL_HANDLE;}
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};bi.size=bytes;bi.usage=VK_BUFFER_USAGE_VERTEX_BUFFER_BIT;bi.sharingMode=VK_SHARING_MODE_EXCLUSIVE;
    if(vkCreateBuffer(dev,&bi,nullptr,&impl_->vertex_buffer)!=VK_SUCCESS)return core::Result<void>::Error("vertex buffer creation failed");
    VkMemoryRequirements req{};vkGetBufferMemoryRequirements(dev,impl_->vertex_buffer,&req);VkPhysicalDeviceMemoryProperties mp{};vkGetPhysicalDeviceMemoryProperties(pd,&mp);uint32_t type=UINT32_MAX;
    for(uint32_t i=0;i<mp.memoryTypeCount;++i) if((req.memoryTypeBits&(1u<<i))&&(mp.memoryTypes[i].propertyFlags&(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT))==(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)){type=i;break;}
    if(type==UINT32_MAX){vkDestroyBuffer(dev,impl_->vertex_buffer,nullptr);impl_->vertex_buffer=VK_NULL_HANDLE;return core::Result<void>::Error("no host-visible vertex memory type");}
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};ai.allocationSize=req.size;ai.memoryTypeIndex=type;
    if(vkAllocateMemory(dev,&ai,nullptr,&impl_->vertex_memory)!=VK_SUCCESS){vkDestroyBuffer(dev,impl_->vertex_buffer,nullptr);impl_->vertex_buffer=VK_NULL_HANDLE;return core::Result<void>::Error("vertex memory allocation failed");}
    void* mapped=nullptr; if(vkMapMemory(dev,impl_->vertex_memory,0,bytes,0,&mapped)!=VK_SUCCESS){vkFreeMemory(dev,impl_->vertex_memory,nullptr);vkDestroyBuffer(dev,impl_->vertex_buffer,nullptr);impl_->vertex_memory=VK_NULL_HANDLE;impl_->vertex_buffer=VK_NULL_HANDLE;return core::Result<void>::Error("vertex memory mapping failed");}
    std::memcpy(mapped,data,bytes);vkUnmapMemory(dev,impl_->vertex_memory);if(vkBindBufferMemory(dev,impl_->vertex_buffer,impl_->vertex_memory,0)!=VK_SUCCESS)return core::Result<void>::Error("vertex buffer binding failed");impl_->vertex_bytes=bytes;vertex_bytes_=bytes;return core::Result<void>::Ok();
}
void VulkanPipeline::bind_graphics_pipeline(void* cb) const noexcept{bind_graphics_pipeline(cb,0);}
bool VulkanPipeline::has_pipeline_variant(uint32_t pipeline_id) const noexcept{if(!impl_)return false;auto it=impl_->variants.find(pipeline_id);return it!=impl_->variants.end()&&it->second.pipeline!=VK_NULL_HANDLE;}
bool VulkanPipeline::has_pipeline_variant_for_program(uint32_t pipeline_id,uint32_t program_id) const noexcept{if(!impl_)return false;auto it=impl_->variants.find(pipeline_id);return it!=impl_->variants.end()&&it->second.pipeline!=VK_NULL_HANDLE&&it->second.program_id==program_id;}
bool VulkanPipeline::bind_graphics_pipeline(void* cb,uint32_t pipeline_id) const noexcept{if(!impl_||!cb)return false;auto it=impl_->variants.find(pipeline_id);if(it==impl_->variants.end()||!it->second.pipeline)return false;vkCmdBindPipeline(as<VkCommandBuffer>(cb),VK_PIPELINE_BIND_POINT_GRAPHICS,it->second.pipeline);return true;}
void VulkanPipeline::bind_vertex_buffer(void* cb) const noexcept{if(impl_&&impl_->vertex_buffer&&cb){VkDeviceSize off=0;VkBuffer b=impl_->vertex_buffer;vkCmdBindVertexBuffers(as<VkCommandBuffer>(cb),0,1,&b,&off);}}
bool VulkanPipeline::bind_vertex_buffer(void* cb,const VulkanResourceBackend* resources,uint32_t resource_id,uint64_t offset) const noexcept{if(!impl_||!cb||!resources)return false;auto h=resources->buffer_handle(resource_id);if(!h)return false;VkBuffer b=reinterpret_cast<VkBuffer>(h);VkDeviceSize off=offset;vkCmdBindVertexBuffers(as<VkCommandBuffer>(cb),0,1,&b,&off);return true;}
bool VulkanPipeline::draw(void* cb,uint32_t vertex_count,uint32_t first_vertex) const noexcept{return draw(cb,0,vertex_count,first_vertex);}
bool VulkanPipeline::draw(void* cb,uint32_t pipeline_id,uint32_t vertex_count,uint32_t first_vertex) const noexcept{if(!impl_||!cb||!impl_->vertex_buffer||vertex_count==0)return false;if((static_cast<uint64_t>(first_vertex)+vertex_count)*5*sizeof(float)>impl_->vertex_bytes)return false;if(!bind_graphics_pipeline(cb,pipeline_id))return false;bind_vertex_buffer(cb);vkCmdDraw(as<VkCommandBuffer>(cb),vertex_count,1,first_vertex,0);return true;}
bool VulkanPipeline::draw(void* cb,uint32_t pipeline_id,const VulkanResourceBackend* resources,uint32_t resource_id,uint32_t vertex_count,uint32_t first_vertex,uint64_t offset) const noexcept{if(!impl_||!cb||!resources||vertex_count==0)return false;if(!bind_graphics_pipeline(cb,pipeline_id))return false;if(!bind_vertex_buffer(cb,resources,resource_id,offset))return false;vkCmdDraw(as<VkCommandBuffer>(cb),vertex_count,1,first_vertex,0);return true;}
bool VulkanPipeline::draw_triangle(void* cb) const noexcept{return draw(cb,0,3,0);}
void VulkanPipeline::bind_descriptor_set(void* cb,uint32_t set_index,void* descriptor_set) const noexcept{if(!impl_||!cb||!descriptor_set)return;auto it=impl_->variants.find(0);if(it==impl_->variants.end())return;VkDescriptorSet s=as<VkDescriptorSet>(descriptor_set);vkCmdBindDescriptorSets(as<VkCommandBuffer>(cb),VK_PIPELINE_BIND_POINT_GRAPHICS,it->second.layout,set_index,1,&s,0,nullptr);}
void* VulkanPipeline::pipeline_layout_handle() const noexcept{return pipeline_layout_handle(0);}
void* VulkanPipeline::pipeline_layout_handle(uint32_t pipeline_id) const noexcept{if(!impl_)return nullptr;auto it=impl_->variants.find(pipeline_id);if(it==impl_->variants.end())return nullptr;return reinterpret_cast<void*>(it->second.layout);}
void VulkanPipeline::shutdown() noexcept{if(device_&&impl_){auto d=as<VkDevice>(device_);if(impl_->vertex_buffer)vkDestroyBuffer(d,impl_->vertex_buffer,nullptr);if(impl_->vertex_memory)vkFreeMemory(d,impl_->vertex_memory,nullptr);for(auto&[_,v]:impl_->variants){if(v.pipeline)vkDestroyPipeline(d,v.pipeline,nullptr);if(v.layout)vkDestroyPipelineLayout(d,v.layout,nullptr);}for(auto&s:impl_->shaders)if(s.module)vkDestroyShaderModule(d,s.module,nullptr);}impl_.reset();physical_device_=device_=nullptr;ready_=false;graphics_pipeline_ready_=false;shader_count_=0;vertex_bytes_=0;pipeline_variant_count_=0;}
std::string VulkanPipeline::diagnostics()const{std::ostringstream s;s<<"pipelineRuntime="<<(ready_?"READY":"OFF")<<";shaderModules="<<shader_count_<<";graphicsPipeline="<<(graphics_pipeline_ready_?"READY":"OFF")<<";pipelineVariants="<<pipeline_variant_count_<<";vertexBytes="<<vertex_bytes_;return s.str();}
} // namespace lg::gpu

#else
namespace lg::gpu { struct VulkanPipeline::Impl{}; VulkanPipeline::VulkanPipeline()=default; VulkanPipeline::~VulkanPipeline()=default; core::Result<void> VulkanPipeline::initialize(void*,void*){return core::Result<void>::Error("Android Vulkan pipeline unavailable on host");} core::Result<void> VulkanPipeline::create_shader_module(const SpirvModule&,uint32_t,std::string){return core::Result<void>::Error("Android Vulkan pipeline unavailable on host");} core::Result<void> VulkanPipeline::create_graphics_pipeline(void*, const std::vector<void*>&){return core::Result<void>::Error("Android Vulkan pipeline unavailable on host");} core::Result<void> VulkanPipeline::create_graphics_pipeline_variant(uint32_t,void*, const std::vector<void*>&){return core::Result<void>::Error("Android Vulkan pipeline unavailable on host");} core::Result<void> VulkanPipeline::create_graphics_pipeline_variant_from_program(uint32_t,void*, const ShaderProgramManager&,uint32_t,const std::vector<void*>&){return core::Result<void>::Error("Android Vulkan pipeline unavailable on host");} core::Result<void> VulkanPipeline::create_graphics_pipeline_variant_from_program_auto_layouts(uint32_t,void*,const ShaderProgramManager&,uint32_t,VulkanDescriptorBackend&,uint32_t){return core::Result<void>::Error("Android Vulkan pipeline unavailable on host");} core::Result<void> VulkanPipeline::create_vertex_buffer(const void*,size_t){return core::Result<void>::Error("Android Vulkan pipeline unavailable on host");} void VulkanPipeline::bind_graphics_pipeline(void*)const noexcept{} bool VulkanPipeline::bind_graphics_pipeline(void*,uint32_t)const noexcept{return false;} bool VulkanPipeline::has_pipeline_variant(uint32_t)const noexcept{return false;} bool VulkanPipeline::has_pipeline_variant_for_program(uint32_t,uint32_t)const noexcept{return false;} void VulkanPipeline::bind_vertex_buffer(void*)const noexcept{} bool VulkanPipeline::bind_vertex_buffer(void*,const VulkanResourceBackend*,uint32_t,uint64_t)const noexcept{return false;} bool VulkanPipeline::draw(void*,uint32_t,uint32_t)const noexcept{return false;} bool VulkanPipeline::draw(void*,uint32_t,uint32_t,uint32_t)const noexcept{return false;} bool VulkanPipeline::draw(void*,uint32_t,const VulkanResourceBackend*,uint32_t,uint32_t,uint32_t,uint64_t)const noexcept{return false;} bool VulkanPipeline::draw_triangle(void*)const noexcept{return false;} void VulkanPipeline::bind_descriptor_set(void*,uint32_t,void*)const noexcept{} void* VulkanPipeline::pipeline_layout_handle()const noexcept{return nullptr;} void* VulkanPipeline::pipeline_layout_handle(uint32_t)const noexcept{return nullptr;} void VulkanPipeline::shutdown()noexcept{} std::string VulkanPipeline::diagnostics()const{return "pipelineRuntime=OFF;shaderModules=0;graphicsPipeline=OFF;vertexBytes=0";} }
#endif
