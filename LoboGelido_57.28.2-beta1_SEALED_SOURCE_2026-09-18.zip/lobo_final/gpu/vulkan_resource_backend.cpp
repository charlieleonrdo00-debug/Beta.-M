#include "vulkan_resource_backend.h"
#include <sstream>
#include <utility>
#include <unordered_map>
#if defined(__ANDROID__)
#include <vulkan/vulkan.h>
namespace lg::gpu {
struct VulkanResourceBackend::Impl {
    struct Buffer { VkBuffer buffer{}; VkDeviceMemory memory{}; VkDeviceSize size{}; };
    struct Image { VkImage image{}; VkDeviceMemory memory{}; VkImageView view{}; VkDeviceSize size{}; };
    std::unordered_map<uint32_t, Buffer> buffers;
    std::unordered_map<uint32_t, Image> images;
};
namespace { template<class T> T as(void* p){ return reinterpret_cast<T>(p); }
uint32_t memory_type(VkPhysicalDevice pd, uint32_t bits, VkMemoryPropertyFlags flags) {
    VkPhysicalDeviceMemoryProperties p{}; vkGetPhysicalDeviceMemoryProperties(pd, &p);
    for(uint32_t i=0;i<p.memoryTypeCount;++i) if((bits&(1u<<i)) && (p.memoryTypes[i].propertyFlags&flags)==flags) return i;
    return UINT32_MAX;
}
}
VulkanResourceBackend::VulkanResourceBackend()=default;
VulkanResourceBackend::~VulkanResourceBackend(){shutdown();}
core::Result<void> VulkanResourceBackend::initialize(void* pd, void* d){
    shutdown(); if(!pd||!d) return core::Result<void>::Error("invalid Vulkan resource handles");
    physical_device_=pd; device_=d; impl_=std::make_unique<Impl>(); ready_=true; return core::Result<void>::Ok();
}
core::Result<uint64_t> VulkanResourceBackend::create_buffer(uint32_t id,const BufferDesc& desc){
    if(!ready_) return core::Result<uint64_t>::Error("Vulkan resource backend not ready");
    if(!desc.size) return core::Result<uint64_t>::Error("buffer size must be nonzero");
    if(impl_->buffers.count(id)||impl_->images.count(id)) return core::Result<uint64_t>::Error("resource id already backed by Vulkan");
    VkDevice d=as<VkDevice>(device_); VkPhysicalDevice pd=as<VkPhysicalDevice>(physical_device_);
    VkBufferCreateInfo ci{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO}; ci.size=desc.size; ci.usage=desc.usage?desc.usage:VK_BUFFER_USAGE_VERTEX_BUFFER_BIT|VK_BUFFER_USAGE_INDEX_BUFFER_BIT|VK_BUFFER_USAGE_STORAGE_BUFFER_BIT; ci.sharingMode=VK_SHARING_MODE_EXCLUSIVE;
    VkBuffer b{}; VkResult r=vkCreateBuffer(d,&ci,nullptr,&b); if(r!=VK_SUCCESS) return core::Result<uint64_t>::Error("vkCreateBuffer failed");
    VkMemoryRequirements mr{}; vkGetBufferMemoryRequirements(d,b,&mr); uint32_t mt=memory_type(pd,mr.memoryTypeBits,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    if(mt==UINT32_MAX){vkDestroyBuffer(d,b,nullptr); return core::Result<uint64_t>::Error("no host-visible Vulkan memory type for buffer");}
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO}; ai.allocationSize=mr.size; ai.memoryTypeIndex=mt; VkDeviceMemory mem{};
    r=vkAllocateMemory(d,&ai,nullptr,&mem); if(r!=VK_SUCCESS){vkDestroyBuffer(d,b,nullptr);return core::Result<uint64_t>::Error("vkAllocateMemory failed");}
    r=vkBindBufferMemory(d,b,mem,0); if(r!=VK_SUCCESS){vkFreeMemory(d,mem,nullptr);vkDestroyBuffer(d,b,nullptr);return core::Result<uint64_t>::Error("vkBindBufferMemory failed");}
    impl_->buffers.emplace(id,Impl::Buffer{b,mem,desc.size}); ++live_buffers_; live_memory_bytes_+=mr.size; return core::Result<uint64_t>::Ok(static_cast<uint64_t>(reinterpret_cast<uintptr_t>(b)));
}
core::Result<uint64_t> VulkanResourceBackend::create_image(uint32_t id,const ImageDesc& desc){
    if(!ready_) return core::Result<uint64_t>::Error("Vulkan resource backend not ready");
    if(!desc.width||!desc.height) return core::Result<uint64_t>::Error("image dimensions must be nonzero");
    if(impl_->buffers.count(id)||impl_->images.count(id)) return core::Result<uint64_t>::Error("resource id already backed by Vulkan");
    VkDevice d=as<VkDevice>(device_); VkPhysicalDevice pd=as<VkPhysicalDevice>(physical_device_);
    VkFormat fmt=desc.format?static_cast<VkFormat>(desc.format):VK_FORMAT_R8G8B8A8_UNORM;
    VkImageCreateInfo ci{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO}; ci.imageType=VK_IMAGE_TYPE_2D;ci.format=fmt;ci.extent={desc.width,desc.height,1};ci.mipLevels=1;ci.arrayLayers=desc.layers?desc.layers:1;ci.samples=VK_SAMPLE_COUNT_1_BIT;ci.tiling=VK_IMAGE_TILING_OPTIMAL;ci.usage=desc.usage?desc.usage:VK_IMAGE_USAGE_SAMPLED_BIT|VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;ci.sharingMode=VK_SHARING_MODE_EXCLUSIVE;ci.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED;
    VkImage image{}; VkResult r=vkCreateImage(d,&ci,nullptr,&image); if(r!=VK_SUCCESS)return core::Result<uint64_t>::Error("vkCreateImage failed");
    VkMemoryRequirements mr{};vkGetImageMemoryRequirements(d,image,&mr);uint32_t mt=memory_type(pd,mr.memoryTypeBits,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);if(mt==UINT32_MAX){vkDestroyImage(d,image,nullptr);return core::Result<uint64_t>::Error("no device-local Vulkan memory type for image");}
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};ai.allocationSize=mr.size;ai.memoryTypeIndex=mt;VkDeviceMemory mem{};r=vkAllocateMemory(d,&ai,nullptr,&mem);if(r!=VK_SUCCESS){vkDestroyImage(d,image,nullptr);return core::Result<uint64_t>::Error("vkAllocateMemory failed for image");}r=vkBindImageMemory(d,image,mem,0);if(r!=VK_SUCCESS){vkFreeMemory(d,mem,nullptr);vkDestroyImage(d,image,nullptr);return core::Result<uint64_t>::Error("vkBindImageMemory failed");}
    VkImageView view{};VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};vi.image=image;vi.viewType=desc.layers>1?VK_IMAGE_VIEW_TYPE_2D_ARRAY:VK_IMAGE_VIEW_TYPE_2D;vi.format=fmt;vi.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;vi.subresourceRange.levelCount=1;vi.subresourceRange.layerCount=desc.layers?desc.layers:1;r=vkCreateImageView(d,&vi,nullptr,&view);if(r!=VK_SUCCESS){vkFreeMemory(d,mem,nullptr);vkDestroyImage(d,image,nullptr);return core::Result<uint64_t>::Error("vkCreateImageView failed");}
    impl_->images.emplace(id,Impl::Image{image,mem,view,mr.size});++live_images_;live_memory_bytes_+=mr.size;return core::Result<uint64_t>::Ok(static_cast<uint64_t>(reinterpret_cast<uintptr_t>(image)));
}
core::Result<void> VulkanResourceBackend::destroy_resource(uint32_t id,ResourceType type){
    if(!impl_) return core::Result<void>::Error("Vulkan resource backend not initialized"); VkDevice d=as<VkDevice>(device_);
    if(type==ResourceType::Buffer){auto it=impl_->buffers.find(id);if(it==impl_->buffers.end())return core::Result<void>::Error("Vulkan buffer does not exist");live_memory_bytes_-=it->second.size;vkDestroyBuffer(d,it->second.buffer,nullptr);vkFreeMemory(d,it->second.memory,nullptr);impl_->buffers.erase(it);--live_buffers_;return core::Result<void>::Ok();}
    if(type==ResourceType::Image){auto it=impl_->images.find(id);if(it==impl_->images.end())return core::Result<void>::Error("Vulkan image does not exist");live_memory_bytes_-=it->second.size;vkDestroyImageView(d,it->second.view,nullptr);vkDestroyImage(d,it->second.image,nullptr);vkFreeMemory(d,it->second.memory,nullptr);impl_->images.erase(it);--live_images_;return core::Result<void>::Ok();}
    return core::Result<void>::Error("resource type has no Vulkan allocation yet");
}
void VulkanResourceBackend::shutdown() noexcept { if(device_&&impl_){VkDevice d=as<VkDevice>(device_);for(auto&[_,b]:impl_->buffers){vkDestroyBuffer(d,b.buffer,nullptr);vkFreeMemory(d,b.memory,nullptr);}for(auto&[_,i]:impl_->images){vkDestroyImageView(d,i.view,nullptr);vkDestroyImage(d,i.image,nullptr);vkFreeMemory(d,i.memory,nullptr);}}impl_.reset();physical_device_=device_=nullptr;ready_=false;live_buffers_=live_images_=live_memory_bytes_=0;}
void* VulkanResourceBackend::buffer_handle(uint32_t id) const noexcept {
#if defined(__ANDROID__)
 if(!impl_) return nullptr; auto it=impl_->buffers.find(id); return it==impl_->buffers.end()?nullptr:reinterpret_cast<void*>(it->second.buffer);
#else
 (void)id; return nullptr;
#endif
}
void* VulkanResourceBackend::image_view(uint32_t id) const noexcept {
#if defined(__ANDROID__)
 if(!impl_) return nullptr; auto it=impl_->images.find(id); return it==impl_->images.end()?nullptr:reinterpret_cast<void*>(it->second.view);
#else
 (void)id; return nullptr;
#endif
}
std::string VulkanResourceBackend::diagnostics() const {std::ostringstream s;s<<"vkResources="<<(ready_?"READY":"OFF")<<";buffers="<<live_buffers_<<";images="<<live_images_<<";memory="<<live_memory_bytes_;return s.str();}
}
#else
#include <sstream>
namespace lg::gpu { struct VulkanResourceBackend::Impl {}; VulkanResourceBackend::VulkanResourceBackend()=default; VulkanResourceBackend::~VulkanResourceBackend()=default; core::Result<void> VulkanResourceBackend::initialize(void*,void*){return core::Result<void>::Error("Android Vulkan resource backend unavailable on host");} core::Result<uint64_t> VulkanResourceBackend::create_buffer(uint32_t,const BufferDesc&){return core::Result<uint64_t>::Error("Android Vulkan resource backend unavailable on host");} core::Result<uint64_t> VulkanResourceBackend::create_image(uint32_t,const ImageDesc&){return core::Result<uint64_t>::Error("Android Vulkan resource backend unavailable on host");} core::Result<void> VulkanResourceBackend::destroy_resource(uint32_t,ResourceType){return core::Result<void>::Error("Android Vulkan resource backend unavailable on host");} void VulkanResourceBackend::shutdown() noexcept{} std::string VulkanResourceBackend::diagnostics() const{return "vkResources=OFF;buffers=0;images=0;memory=0";} }
#endif
