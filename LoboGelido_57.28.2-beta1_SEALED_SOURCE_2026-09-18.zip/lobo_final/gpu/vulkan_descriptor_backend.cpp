#include "vulkan_descriptor_backend.h"
#include "vulkan_resource_backend.h"
#include <algorithm>
#include <sstream>
#include <unordered_map>

#if defined(__ANDROID__)
#include <vulkan/vulkan.h>
namespace lg::gpu {
struct VulkanDescriptorBackend::Impl {
    struct Layout { VkDescriptorSetLayout layout{}; std::vector<VulkanDescriptorBindingDesc> bindings; };
    struct Pending { uint32_t resource{}; uint64_t offset{}, range{}; bool image{}; };
    struct Set { VkDescriptorSet set{}; uint32_t layout{}; std::unordered_map<uint32_t, Pending> pending; };
    VkDescriptorPool pool{};
    std::unordered_map<uint32_t, Layout> layouts;
    std::unordered_map<uint32_t, Set> sets;
};
static VkDevice dev(void* p){ return reinterpret_cast<VkDevice>(p); }
static VkPhysicalDevice phys(void* p){ return reinterpret_cast<VkPhysicalDevice>(p); }

VulkanDescriptorBackend::VulkanDescriptorBackend()=default;
VulkanDescriptorBackend::~VulkanDescriptorBackend(){shutdown();}

core::Result<void> VulkanDescriptorBackend::initialize(void* pd, void* d, VulkanResourceBackend* r){
    shutdown();
    if(!pd||!d||!r||!r->ready()) return core::Result<void>::Error("invalid Vulkan descriptor backend handles");
    physical_device_=pd; device_=d; resources_=r; impl_=std::make_unique<Impl>();
    VkDescriptorPoolSize sizes[]={{VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,256},{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,256},{VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,256}};
    VkDescriptorPoolCreateInfo ci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    ci.flags=VK_DESCRIPTOR_POOL_CREATE_FREE_DESCRIPTOR_SET_BIT; ci.maxSets=256; ci.poolSizeCount=3; ci.pPoolSizes=sizes;
    if(vkCreateDescriptorPool(dev(d),&ci,nullptr,&impl_->pool)!=VK_SUCCESS) return core::Result<void>::Error("vkCreateDescriptorPool failed");
    ready_=true; return core::Result<void>::Ok();
}

core::Result<void> VulkanDescriptorBackend::create_layout(uint32_t id,const std::vector<VulkanDescriptorBindingDesc>& bs){
    if(!ready_||!impl_) return core::Result<void>::Error("descriptor backend not ready");
    if(impl_->layouts.count(id)) return core::Result<void>::Error("descriptor layout already exists");
    std::vector<VkDescriptorSetLayoutBinding> vkbs; vkbs.reserve(bs.size());
    for(const auto& b:bs){
        if(!b.count || !b.stage_flags) return core::Result<void>::Error("invalid descriptor binding");
        vkbs.push_back({b.binding,static_cast<VkDescriptorType>(b.descriptor_type),b.count,static_cast<VkShaderStageFlags>(b.stage_flags),nullptr});
    }
    VkDescriptorSetLayoutCreateInfo ci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    ci.bindingCount=static_cast<uint32_t>(vkbs.size()); ci.pBindings=vkbs.data(); VkDescriptorSetLayout l{};
    if(vkCreateDescriptorSetLayout(dev(device_),&ci,nullptr,&l)!=VK_SUCCESS) return core::Result<void>::Error("vkCreateDescriptorSetLayout failed");
    impl_->layouts.emplace(id,Impl::Layout{l,bs}); ++live_layouts_; return core::Result<void>::Ok();
}

core::Result<std::vector<uint32_t>> VulkanDescriptorBackend::create_layouts_for_program(const ShaderProgramManager& programs,uint32_t program_id,uint32_t first_layout_id){
    if(!ready_) return core::Result<std::vector<uint32_t>>::Error("descriptor backend not ready");
    auto grouped=programs.descriptor_bindings_by_set(program_id);
    if(!grouped.ok()) return core::Result<std::vector<uint32_t>>::Error(grouped.error());
    std::vector<uint32_t> ids; ids.reserve(grouped.value().size());
    for(size_t set_index=0;set_index<grouped.value().size();++set_index){
        const uint32_t id=first_layout_id+static_cast<uint32_t>(set_index);
        if(impl_->layouts.count(id)){ ids.push_back(id); continue; }
        std::vector<VulkanDescriptorBindingDesc> bindings;
        for(const auto& r:grouped.value()[set_index]){
            uint32_t type=0;
            switch(r.type){case ShaderResourceType::UniformBuffer:type=VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;break;case ShaderResourceType::StorageBuffer:type=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;break;case ShaderResourceType::SampledImage:type=VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;break;default:return core::Result<std::vector<uint32_t>>::Error("unsupported shader resource type");}
            uint32_t stages=0; if(r.stage_mask&1u) stages|=VK_SHADER_STAGE_VERTEX_BIT; if(r.stage_mask&2u) stages|=VK_SHADER_STAGE_FRAGMENT_BIT;
            if(!stages||!r.count) return core::Result<std::vector<uint32_t>>::Error("invalid reflected descriptor binding");
            bindings.push_back({r.binding,type,r.count,stages});
        }
        auto created=create_layout(id,bindings); if(!created.ok()) return core::Result<std::vector<uint32_t>>::Error(created.error()); ids.push_back(id);
    }
    return core::Result<std::vector<uint32_t>>::Ok(std::move(ids));
}

core::Result<void> VulkanDescriptorBackend::allocate_set(uint32_t sid,uint32_t lid){
    if(!ready_||!impl_) return core::Result<void>::Error("descriptor backend not ready");
    auto it=impl_->layouts.find(lid); if(it==impl_->layouts.end()) return core::Result<void>::Error("descriptor layout does not exist");
    if(impl_->sets.count(sid)) return core::Result<void>::Error("descriptor set already exists");
    VkDescriptorSetAllocateInfo ai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO}; ai.descriptorPool=impl_->pool; ai.descriptorSetCount=1; ai.pSetLayouts=&it->second.layout;
    VkDescriptorSet s{}; if(vkAllocateDescriptorSets(dev(device_),&ai,&s)!=VK_SUCCESS) return core::Result<void>::Error("vkAllocateDescriptorSets failed");
    impl_->sets.emplace(sid,Impl::Set{s,lid,{}}); ++live_sets_; return core::Result<void>::Ok();
}

core::Result<void> VulkanDescriptorBackend::bind_buffer(uint32_t sid,uint32_t binding,uint32_t rid,uint64_t off,uint64_t range){
    if(!impl_) return core::Result<void>::Error("descriptor backend not initialized"); auto it=impl_->sets.find(sid); if(it==impl_->sets.end()) return core::Result<void>::Error("descriptor set does not exist");
    auto* r=resources_->get(rid); if(!r||r->type!=ResourceType::Buffer) return core::Result<void>::Error("descriptor buffer resource invalid");
    it->second.pending[binding]={rid,off,range,false}; return core::Result<void>::Ok();
}
core::Result<void> VulkanDescriptorBackend::bind_sampled_image(uint32_t sid,uint32_t binding,uint32_t rid){
    if(!impl_) return core::Result<void>::Error("descriptor backend not initialized"); auto it=impl_->sets.find(sid); if(it==impl_->sets.end()) return core::Result<void>::Error("descriptor set does not exist");
    auto* r=resources_->get(rid); if(!r||r->type!=ResourceType::Image) return core::Result<void>::Error("descriptor image resource invalid");
    it->second.pending[binding]={rid,0,0,true}; return core::Result<void>::Ok();
}

core::Result<void> VulkanDescriptorBackend::update(uint32_t sid){
    if(!impl_) return core::Result<void>::Error("descriptor backend not initialized"); auto it=impl_->sets.find(sid); if(it==impl_->sets.end()) return core::Result<void>::Error("descriptor set does not exist");
    auto lit=impl_->layouts.find(it->second.layout); if(lit==impl_->layouts.end()) return core::Result<void>::Error("descriptor set layout does not exist");
    std::vector<VkWriteDescriptorSet> writes; std::vector<VkDescriptorBufferInfo> buffers; std::vector<VkDescriptorImageInfo> images;
    writes.reserve(it->second.pending.size()); buffers.reserve(it->second.pending.size()); images.reserve(it->second.pending.size());
    for(const auto& [binding,p]:it->second.pending){
        auto bit=std::find_if(lit->second.bindings.begin(),lit->second.bindings.end(),[&](const auto& b){return b.binding==binding;});
        if(bit==lit->second.bindings.end()) return core::Result<void>::Error("descriptor binding is not present in layout");
        VkWriteDescriptorSet w{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET}; w.dstSet=it->second.set; w.dstBinding=binding; w.descriptorCount=1; w.descriptorType=static_cast<VkDescriptorType>(bit->descriptor_type);
        if(p.image){ if(w.descriptorType!=VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE) return core::Result<void>::Error("image resource bound to non-image descriptor"); VkDescriptorImageInfo q{}; q.imageView=reinterpret_cast<VkImageView>(resources_->image_view(p.resource)); if(!q.imageView) return core::Result<void>::Error("descriptor image view unavailable"); q.imageLayout=VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL; images.push_back(q); w.pImageInfo=&images.back(); }
        else { if(w.descriptorType!=VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER && w.descriptorType!=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER) return core::Result<void>::Error("buffer resource bound to non-buffer descriptor"); VkDescriptorBufferInfo q{}; q.buffer=reinterpret_cast<VkBuffer>(resources_->buffer_handle(p.resource)); if(!q.buffer) return core::Result<void>::Error("descriptor buffer handle unavailable"); q.offset=p.offset; q.range=p.range?p.range:VK_WHOLE_SIZE; buffers.push_back(q); w.pBufferInfo=&buffers.back(); }
        writes.push_back(w);
    }
    if(!writes.empty()) vkUpdateDescriptorSets(dev(device_),static_cast<uint32_t>(writes.size()),writes.data(),0,nullptr);
    return core::Result<void>::Ok();
}

core::Result<void> VulkanDescriptorBackend::validate_set_against_program(uint32_t sid,const ShaderProgramManager& programs,uint32_t program_id,uint32_t set_index) const{
    if(!impl_) return core::Result<void>::Error("descriptor backend not initialized"); auto sit=impl_->sets.find(sid); if(sit==impl_->sets.end()) return core::Result<void>::Error("descriptor set does not exist");
    auto lit=impl_->layouts.find(sit->second.layout); if(lit==impl_->layouts.end()) return core::Result<void>::Error("descriptor set layout does not exist"); const auto* iface=programs.resource_interface(program_id); if(!iface) return core::Result<void>::Error("unknown shader program");
    for(const auto& req:*iface){
        if(req.set != set_index) continue;
        auto bit=std::find_if(lit->second.bindings.begin(),lit->second.bindings.end(),[&](const auto& b){return b.binding==req.binding;}); if(bit==lit->second.bindings.end()) return core::Result<void>::Error("shader resource binding is missing from descriptor layout");
        uint32_t expected=0; switch(req.type){case ShaderResourceType::UniformBuffer:expected=VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;break;case ShaderResourceType::StorageBuffer:expected=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;break;case ShaderResourceType::SampledImage:expected=VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;break;default:return core::Result<void>::Error("unsupported shader resource type");}
        if(bit->descriptor_type!=expected||bit->count!=req.count) return core::Result<void>::Error("descriptor layout does not match shader interface");
        uint32_t required=0; if(req.stage_mask&1u) required|=VK_SHADER_STAGE_VERTEX_BIT; if(req.stage_mask&2u) required|=VK_SHADER_STAGE_FRAGMENT_BIT; if((bit->stage_flags&required)!=required) return core::Result<void>::Error("descriptor stage visibility does not cover shader interface");
    }
    return core::Result<void>::Ok();
}
uint32_t VulkanDescriptorBackend::set_layout_id(uint32_t sid) const noexcept{if(!impl_)return 0;auto it=impl_->sets.find(sid);return it==impl_->sets.end()?0u:it->second.layout;}
void VulkanDescriptorBackend::bind_set(void* cb,void* pl,uint32_t sid,uint32_t first) const noexcept{if(!impl_||!cb||!pl)return;auto it=impl_->sets.find(sid);if(it==impl_->sets.end())return;VkDescriptorSet s=it->second.set;vkCmdBindDescriptorSets(reinterpret_cast<VkCommandBuffer>(cb),VK_PIPELINE_BIND_POINT_GRAPHICS,reinterpret_cast<VkPipelineLayout>(pl),first,1,&s,0,nullptr);}
void* VulkanDescriptorBackend::layout_handle(uint32_t id) const noexcept{if(!impl_)return nullptr;auto it=impl_->layouts.find(id);return it==impl_->layouts.end()?nullptr:reinterpret_cast<void*>(it->second.layout);}
void VulkanDescriptorBackend::shutdown() noexcept{if(device_&&impl_){VkDevice d=dev(device_);for(auto&[_,s]:impl_->sets)if(s.set)vkFreeDescriptorSets(d,impl_->pool,1,&s.set);for(auto&[_,l]:impl_->layouts)if(l.layout)vkDestroyDescriptorSetLayout(d,l.layout,nullptr);if(impl_->pool)vkDestroyDescriptorPool(d,impl_->pool,nullptr);}impl_.reset();physical_device_=device_=nullptr;resources_=nullptr;ready_=false;live_layouts_=live_sets_=0;}
std::string VulkanDescriptorBackend::diagnostics() const{std::ostringstream s;s<<"vkDescriptors="<<(ready_?"READY":"OFF")<<";layouts="<<live_layouts_<<";sets="<<live_sets_;return s.str();}
}
#else
namespace lg::gpu {
struct VulkanDescriptorBackend::Impl{};
VulkanDescriptorBackend::VulkanDescriptorBackend()=default; VulkanDescriptorBackend::~VulkanDescriptorBackend()=default;
core::Result<void> VulkanDescriptorBackend::initialize(void*,void*,VulkanResourceBackend*){return core::Result<void>::Error("Android Vulkan descriptor backend unavailable on host");}
core::Result<void> VulkanDescriptorBackend::create_layout(uint32_t,const std::vector<VulkanDescriptorBindingDesc>&){return core::Result<void>::Error("Android Vulkan descriptor backend unavailable on host");}
core::Result<std::vector<uint32_t>> VulkanDescriptorBackend::create_layouts_for_program(const ShaderProgramManager&,uint32_t,uint32_t){return core::Result<std::vector<uint32_t>>::Error("Android Vulkan descriptor backend unavailable on host");}
core::Result<void> VulkanDescriptorBackend::allocate_set(uint32_t,uint32_t){return core::Result<void>::Error("Android Vulkan descriptor backend unavailable on host");}
core::Result<void> VulkanDescriptorBackend::bind_buffer(uint32_t,uint32_t,uint32_t,uint64_t,uint64_t){return core::Result<void>::Error("Android Vulkan descriptor backend unavailable on host");}
core::Result<void> VulkanDescriptorBackend::bind_sampled_image(uint32_t,uint32_t,uint32_t){return core::Result<void>::Error("Android Vulkan descriptor backend unavailable on host");}
core::Result<void> VulkanDescriptorBackend::update(uint32_t){return core::Result<void>::Error("Android Vulkan descriptor backend unavailable on host");}
core::Result<void> VulkanDescriptorBackend::validate_set_against_program(uint32_t,const ShaderProgramManager&,uint32_t,uint32_t) const{return core::Result<void>::Error("Android Vulkan descriptor backend unavailable on host");}
uint32_t VulkanDescriptorBackend::set_layout_id(uint32_t) const noexcept{return 0;} void VulkanDescriptorBackend::bind_set(void*,void*,uint32_t,uint32_t) const noexcept{} void* VulkanDescriptorBackend::layout_handle(uint32_t) const noexcept{return nullptr;}
void VulkanDescriptorBackend::shutdown() noexcept{} std::string VulkanDescriptorBackend::diagnostics() const{return "vkDescriptors=OFF;layouts=0;sets=0";}
}
#endif
