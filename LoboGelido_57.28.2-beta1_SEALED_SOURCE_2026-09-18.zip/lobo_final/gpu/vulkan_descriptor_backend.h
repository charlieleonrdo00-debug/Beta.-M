#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "../core/result.h"
#include "gpu_resource_manager.h"
#include "shader_program_manager.h"

namespace lg::gpu {
class VulkanResourceBackend;

struct VulkanDescriptorBindingDesc { uint32_t binding{}; uint32_t descriptor_type{}; uint32_t count{1}; uint32_t stage_flags{}; };

class VulkanDescriptorBackend {
public:
    VulkanDescriptorBackend();
    ~VulkanDescriptorBackend();
    VulkanDescriptorBackend(const VulkanDescriptorBackend&) = delete;
    VulkanDescriptorBackend& operator=(const VulkanDescriptorBackend&) = delete;
    core::Result<void> initialize(void* physical_device, void* device, VulkanResourceBackend* resources);
    core::Result<void> create_layout(uint32_t layout_id, const std::vector<VulkanDescriptorBindingDesc>& bindings);
    core::Result<std::vector<uint32_t>> create_layouts_for_program(const ShaderProgramManager& programs,
                                                                    uint32_t program_id,
                                                                    uint32_t first_layout_id);
    core::Result<void> allocate_set(uint32_t set_id, uint32_t layout_id);
    core::Result<void> bind_buffer(uint32_t set_id, uint32_t binding, uint32_t resource_id, uint64_t offset = 0, uint64_t range = 0);
    core::Result<void> bind_sampled_image(uint32_t set_id, uint32_t binding, uint32_t resource_id);
    core::Result<void> update(uint32_t set_id);
    core::Result<void> validate_set_against_program(uint32_t set_id,
                                                     const ShaderProgramManager& programs,
                                                     uint32_t program_id, uint32_t set_index = 0) const;
    uint32_t set_layout_id(uint32_t set_id) const noexcept;
    void bind_set(void* command_buffer, void* pipeline_layout, uint32_t set_id, uint32_t first_set = 0) const noexcept;
    void* layout_handle(uint32_t layout_id) const noexcept;
    void shutdown() noexcept;
    bool ready() const noexcept { return ready_; }
    size_t live_layouts() const noexcept { return live_layouts_; }
    size_t live_sets() const noexcept { return live_sets_; }
    std::string diagnostics() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
    void* physical_device_{}; void* device_{}; VulkanResourceBackend* resources_{};
    bool ready_{}; size_t live_layouts_{}; size_t live_sets_{};
};
}
