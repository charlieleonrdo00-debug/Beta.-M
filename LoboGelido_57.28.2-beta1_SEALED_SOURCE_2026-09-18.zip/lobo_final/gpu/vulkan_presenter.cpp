#include "vulkan_presenter.h"
#if defined(__ANDROID__)
#include <vulkan/vulkan.h>
#include <algorithm>
#include <sstream>
#include <vector>

namespace lg::gpu {

// Frame-pacing configuration (Frente 1).
// Up to 3 frames may be recorded/submitted before the CPU has to block on the
// oldest one, so CPU frame preparation overlaps GPU execution instead of the
// old 1-fence design that serialised the whole loop. The real count is capped
// to the swapchain image count in recreate().
static constexpr uint32_t kMaxFramesInFlight = 3;
static constexpr uint64_t kFrameTimeoutNs = 1000000000ull; // 1 s; generous, avoids false timeouts under load

struct VulkanPresenter::Impl {
    VkSwapchainKHR swapchain{VK_NULL_HANDLE};
    std::vector<VkImage> images;
    std::vector<VkImageView> views;
    VkCommandPool pool{VK_NULL_HANDLE};
    std::vector<VkCommandBuffer> commands;
    std::vector<uint8_t> initialized;
    // Synchronisation for N frames-in-flight:
    std::vector<VkSemaphore> acquire;         // image-available, one PER FRAME-IN-FLIGHT
    std::vector<VkSemaphore> present;         // render-finished, one PER SWAPCHAIN IMAGE
    std::vector<VkFence> in_flight;           // one PER FRAME-IN-FLIGHT (owned)
    std::vector<VkFence> images_in_flight;    // per image -> the frame fence currently using it (NOT owned)
    uint32_t frames_in_flight{2};
    uint32_t current_frame{0};
    VkFormat format{VK_FORMAT_UNDEFINED};
    VkRenderPass render_pass{VK_NULL_HANDLE};
    std::vector<VkFramebuffer> framebuffers;

    // Destroys every owned synchronisation object and clears the tracking
    // vectors. images_in_flight holds non-owning copies of in_flight fences, so
    // it is only cleared, never destroyed (that would be a double free).
    void destroy_sync(VkDevice dev) noexcept {
        for (auto s : acquire) if (s) vkDestroySemaphore(dev, s, nullptr);
        acquire.clear();
        for (auto s : present) if (s) vkDestroySemaphore(dev, s, nullptr);
        present.clear();
        for (auto f : in_flight) if (f) vkDestroyFence(dev, f, nullptr);
        in_flight.clear();
        images_in_flight.clear();
        current_frame = 0;
    }

    // Waits on THIS frame slot's fence, acquires the next swapchain image with
    // the per-frame image-available semaphore, and serialises against any
    // earlier in-flight frame still using the acquired image. It deliberately
    // does NOT reset the frame fence: if acquire returns VK_ERROR_OUT_OF_DATE_KHR
    // (or any error) the caller early-returns, and the fence must stay signaled
    // so the next frame reusing this slot does not block forever on an
    // unsignaled fence. This is the core "endurecimiento tras vkResetFences"
    // fix — the reset now lives in end_frame(), only once submission is certain.
    VkResult begin_frame(VkDevice dev, uint32_t& index, VkFence& frame_fence, VkSemaphore& img_available) {
        frame_fence = in_flight[current_frame];
        img_available = acquire[current_frame];
        vkWaitForFences(dev, 1, &frame_fence, VK_TRUE, kFrameTimeoutNs);
        VkResult r = vkAcquireNextImageKHR(dev, swapchain, kFrameTimeoutNs, img_available, VK_NULL_HANDLE, &index);
        if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) return r; // includes OUT_OF_DATE; caller handles
        if (images_in_flight[index] != VK_NULL_HANDLE)
            vkWaitForFences(dev, 1, &images_in_flight[index], VK_TRUE, kFrameTimeoutNs);
        images_in_flight[index] = frame_fence;
        return r;
    }

    // Resets the frame fence (only now, once committed to submitting), submits
    // the recorded command buffer waiting on the image-available semaphore at
    // COLOR_ATTACHMENT_OUTPUT and signalling the per-image render-finished
    // semaphore + the frame fence, presents, and advances the frame index.
    VkResult end_frame(VkDevice dev, VkQueue q, uint32_t index, VkFence frame_fence,
                       VkSemaphore img_available, VkCommandBuffer cmd) {
        VkSemaphore render_done = present[index];
        VkPipelineStageFlags stage = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        vkResetFences(dev, 1, &frame_fence);
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.waitSemaphoreCount = 1; si.pWaitSemaphores = &img_available; si.pWaitDstStageMask = &stage;
        si.commandBufferCount = 1; si.pCommandBuffers = &cmd;
        si.signalSemaphoreCount = 1; si.pSignalSemaphores = &render_done;
        VkResult r = vkQueueSubmit(q, 1, &si, frame_fence);
        if (r != VK_SUCCESS) return r;
        VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
        pi.waitSemaphoreCount = 1; pi.pWaitSemaphores = &render_done;
        pi.swapchainCount = 1; pi.pSwapchains = &swapchain; pi.pImageIndices = &index;
        r = vkQueuePresentKHR(q, &pi);
        current_frame = (current_frame + 1) % frames_in_flight;
        return r;
    }
};

namespace {
template<class T> T as(void* p){return reinterpret_cast<T>(p);}
const char* rn(VkResult r){switch(r){case VK_SUCCESS:return "VK_SUCCESS";case VK_SUBOPTIMAL_KHR:return "VK_SUBOPTIMAL_KHR";case VK_ERROR_OUT_OF_DATE_KHR:return "VK_ERROR_OUT_OF_DATE_KHR";case VK_ERROR_INITIALIZATION_FAILED:return "VK_ERROR_INITIALIZATION_FAILED";default:return "VkResult";}}
} // namespace

VulkanPresenter::VulkanPresenter() = default;
VulkanPresenter::~VulkanPresenter(){shutdown();}
core::Result<void> VulkanPresenter::initialize(void* i,void* pd,void* d,void* s,uint32_t qf,void* q){shutdown();if(!i||!pd||!d||!s||!q)return core::Result<void>::Error("invalid Vulkan presenter handles");instance_=i;physical_device_=pd;device_=d;surface_=s;queue_=q;queue_family_=qf;impl_=std::make_unique<Impl>(); auto gr=gpu_runtime_.initialize(physical_device_, device_, queue_family_); if(!gr.ok()){ shutdown(); return gr; } auto rr=resource_backend_.initialize(physical_device_, device_); if(!rr.ok()){ shutdown(); return rr; } auto dr=descriptor_backend_.initialize(physical_device_, device_, &resource_backend_); if(!dr.ok()){ shutdown(); return dr; } auto pr=pipeline_runtime_.initialize(physical_device_, device_); if(!pr.ok()){ shutdown(); return pr; } auto br=resource_binding_runtime_.initialize(&shader_programs_, &descriptor_backend_, &resource_backend_, &pipeline_runtime_); if(!br.ok()){ shutdown(); return br; } return recreate(0,0);}
core::Result<void> VulkanPresenter::recreate(uint32_t rw,uint32_t rh){
 if(!impl_||!device_||!physical_device_||!surface_) return core::Result<void>::Error("presenter not initialized");
 VkDevice dev=as<VkDevice>(device_); VkPhysicalDevice pd=as<VkPhysicalDevice>(physical_device_); VkSurfaceKHR surf=as<VkSurfaceKHR>(surface_);
 if(impl_->swapchain){vkDeviceWaitIdle(dev);for(auto fb:impl_->framebuffers) if(fb) vkDestroyFramebuffer(dev,fb,nullptr); impl_->framebuffers.clear(); if(impl_->render_pass) vkDestroyRenderPass(dev,impl_->render_pass,nullptr); impl_->render_pass=VK_NULL_HANDLE; for(auto v:impl_->views)vkDestroyImageView(dev,v,nullptr);impl_->views.clear();if(impl_->pool)vkDestroyCommandPool(dev,impl_->pool,nullptr);impl_->pool=VK_NULL_HANDLE;
        impl_->destroy_sync(dev);
        vkDestroySwapchainKHR(dev,impl_->swapchain,nullptr);impl_->swapchain=VK_NULL_HANDLE;impl_->images.clear();impl_->commands.clear();impl_->initialized.clear();}
 VkSurfaceCapabilitiesKHR caps{}; VkResult r=vkGetPhysicalDeviceSurfaceCapabilitiesKHR(pd,surf,&caps);if(r!=VK_SUCCESS)return core::Result<void>::Error(rn(r));
 uint32_t n=0;vkGetPhysicalDeviceSurfaceFormatsKHR(pd,surf,&n,nullptr);if(!n)return core::Result<void>::Error("surface has no formats");std::vector<VkSurfaceFormatKHR> fs(n);vkGetPhysicalDeviceSurfaceFormatsKHR(pd,surf,&n,fs.data());
 VkSurfaceFormatKHR fmt=fs[0];for(auto f:fs)if(f.format==VK_FORMAT_B8G8R8A8_UNORM&&f.colorSpace==VK_COLOR_SPACE_SRGB_NONLINEAR_KHR){fmt=f;break;}
 uint32_t pm=0;vkGetPhysicalDeviceSurfacePresentModesKHR(pd,surf,&pm,nullptr);if(!pm)return core::Result<void>::Error("surface has no present modes");std::vector<VkPresentModeKHR> modes(pm);vkGetPhysicalDeviceSurfacePresentModesKHR(pd,surf,&pm,modes.data());VkPresentModeKHR mode=VK_PRESENT_MODE_FIFO_KHR;for(auto m:modes)if(m==VK_PRESENT_MODE_MAILBOX_KHR){mode=m;break;}
 VkExtent2D ex=caps.currentExtent;if(ex.width==UINT32_MAX){ex.width=std::clamp(rw?rw:1280u,caps.minImageExtent.width,caps.maxImageExtent.width);ex.height=std::clamp(rh?rh:720u,caps.minImageExtent.height,caps.maxImageExtent.height);}
 uint32_t count=std::max(caps.minImageCount,2u);if(caps.maxImageCount)count=std::min(count,caps.maxImageCount);
 VkSwapchainCreateInfoKHR ci{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};ci.surface=surf;ci.minImageCount=count;ci.imageFormat=fmt.format;ci.imageColorSpace=fmt.colorSpace;ci.imageExtent=ex;ci.imageArrayLayers=1;ci.imageUsage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;ci.imageSharingMode=VK_SHARING_MODE_EXCLUSIVE;ci.preTransform=caps.currentTransform;ci.compositeAlpha=VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;ci.presentMode=mode;ci.clipped=VK_TRUE;
 r=vkCreateSwapchainKHR(dev,&ci,nullptr,&impl_->swapchain);if(r!=VK_SUCCESS)return core::Result<void>::Error(rn(r));
 uint32_t ic=0;vkGetSwapchainImagesKHR(dev,impl_->swapchain,&ic,nullptr);impl_->images.resize(ic);vkGetSwapchainImagesKHR(dev,impl_->swapchain,&ic,impl_->images.data());impl_->format=fmt.format;
 impl_->views.resize(ic);for(uint32_t i=0;i<ic;++i){VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};vi.image=impl_->images[i];vi.viewType=VK_IMAGE_VIEW_TYPE_2D;vi.format=fmt.format;vi.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;vi.subresourceRange.levelCount=1;vi.subresourceRange.layerCount=1;r=vkCreateImageView(dev,&vi,nullptr,&impl_->views[i]);if(r!=VK_SUCCESS)return core::Result<void>::Error(rn(r));}
 VkAttachmentDescription color{};
 color.format=fmt.format; color.samples=VK_SAMPLE_COUNT_1_BIT; color.loadOp=VK_ATTACHMENT_LOAD_OP_CLEAR; color.storeOp=VK_ATTACHMENT_STORE_OP_STORE; color.stencilLoadOp=VK_ATTACHMENT_LOAD_OP_DONT_CARE; color.stencilStoreOp=VK_ATTACHMENT_STORE_OP_DONT_CARE; color.initialLayout=VK_IMAGE_LAYOUT_PRESENT_SRC_KHR; color.finalLayout=VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
 VkAttachmentReference color_ref{}; color_ref.attachment=0; color_ref.layout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
 VkSubpassDescription sub{}; sub.pipelineBindPoint=VK_PIPELINE_BIND_POINT_GRAPHICS; sub.colorAttachmentCount=1; sub.pColorAttachments=&color_ref;
 VkSubpassDependency dep0{}; dep0.srcSubpass=VK_SUBPASS_EXTERNAL; dep0.dstSubpass=0; dep0.srcStageMask=VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT; dep0.dstStageMask=VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT; dep0.srcAccessMask=0; dep0.dstAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT; dep0.dependencyFlags=VK_DEPENDENCY_BY_REGION_BIT;
 VkSubpassDependency dep1{}; dep1.srcSubpass=0; dep1.dstSubpass=VK_SUBPASS_EXTERNAL; dep1.srcStageMask=VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT; dep1.dstStageMask=VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT; dep1.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT; dep1.dstAccessMask=VK_ACCESS_MEMORY_READ_BIT; dep1.dependencyFlags=VK_DEPENDENCY_BY_REGION_BIT;
 VkRenderPassCreateInfo rp{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO}; rp.attachmentCount=1; rp.pAttachments=&color; rp.subpassCount=1; rp.pSubpasses=&sub; rp.dependencyCount=2; VkSubpassDependency deps[2]={dep0,dep1}; rp.pDependencies=deps;
 r=vkCreateRenderPass(dev,&rp,nullptr,&impl_->render_pass); if(r!=VK_SUCCESS)return core::Result<void>::Error(rn(r));
 impl_->framebuffers.resize(ic); for(uint32_t i=0;i<ic;++i){ VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO}; fi.renderPass=impl_->render_pass; fi.attachmentCount=1; fi.pAttachments=&impl_->views[i]; fi.width=ex.width; fi.height=ex.height; fi.layers=1; r=vkCreateFramebuffer(dev,&fi,nullptr,&impl_->framebuffers[i]); if(r!=VK_SUCCESS)return core::Result<void>::Error(rn(r)); }
VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};pi.queueFamilyIndex=queue_family_;pi.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;r=vkCreateCommandPool(dev,&pi,nullptr,&impl_->pool);if(r!=VK_SUCCESS)return core::Result<void>::Error(rn(r));
 impl_->commands.resize(ic);impl_->initialized.assign(ic, 0);VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};ai.commandPool=impl_->pool;ai.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;ai.commandBufferCount=ic;r=vkAllocateCommandBuffers(dev,&ai,impl_->commands.data());if(r!=VK_SUCCESS)return core::Result<void>::Error(rn(r));
 // --- Frames-in-flight synchronisation objects ---
 impl_->frames_in_flight = std::max(1u, std::min(kMaxFramesInFlight, ic));
 impl_->current_frame = 0;
 VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
 // Per-frame image-available semaphores.
 impl_->acquire.resize(impl_->frames_in_flight, VK_NULL_HANDLE);
 for(auto& sem: impl_->acquire){ if(vkCreateSemaphore(dev,&si,nullptr,&sem)!=VK_SUCCESS){ impl_->destroy_sync(dev); return core::Result<void>::Error("acquire semaphore creation failed"); } }
 // Per-image render-finished semaphores (one per swapchain image avoids reusing a
 // semaphore that a still-pending present is waiting on).
 impl_->present.resize(ic, VK_NULL_HANDLE);
 for(auto& sem: impl_->present){ if(vkCreateSemaphore(dev,&si,nullptr,&sem)!=VK_SUCCESS){ impl_->destroy_sync(dev); return core::Result<void>::Error("present semaphore creation failed"); } }
 // Per-frame fences, created signaled so the first wait returns immediately.
 VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO}; fci.flags=VK_FENCE_CREATE_SIGNALED_BIT;
 impl_->in_flight.resize(impl_->frames_in_flight, VK_NULL_HANDLE);
 for(auto& f: impl_->in_flight){ if(vkCreateFence(dev,&fci,nullptr,&f)!=VK_SUCCESS){ impl_->destroy_sync(dev); return core::Result<void>::Error("fence creation failed"); } }
 // No frame owns any image yet.
 impl_->images_in_flight.assign(ic, VK_NULL_HANDLE);
 width_=ex.width;height_=ex.height;image_count_=ic;ready_=true;return core::Result<void>::Ok();
}
core::Result<void> VulkanPresenter::draw_frame(){
 if(!ready_||!impl_)return core::Result<void>::Error("presenter not ready");
 VkDevice dev=as<VkDevice>(device_);VkQueue q=as<VkQueue>(queue_);
 uint32_t index=0; VkFence frame_fence=VK_NULL_HANDLE; VkSemaphore img_available=VK_NULL_HANDLE;
 VkResult r=impl_->begin_frame(dev, index, frame_fence, img_available);
 if(r==VK_ERROR_OUT_OF_DATE_KHR)return recreate(width_,height_);
 if(r!=VK_SUCCESS&&r!=VK_SUBOPTIMAL_KHR)return core::Result<void>::Error(rn(r));
 gpu_runtime_.collect_completed();
 VkCommandBuffer cmd=impl_->commands[index];
 auto graph=render_graph_.compile(); if(!graph.ok()) return core::Result<void>::Error(graph.error());
 vkResetCommandBuffer(cmd,0);
 VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
 if(vkBeginCommandBuffer(cmd,&bi)!=VK_SUCCESS)return core::Result<void>::Error("command buffer begin failed");
 gpu_runtime_.write_begin_timestamp(cmd);
 VkClearValue clear{}; clear.color.float32[0]=0.01f; clear.color.float32[1]=0.02f; clear.color.float32[2]=0.06f; clear.color.float32[3]=1.0f;
 VkRenderPassBeginInfo rbi{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO}; rbi.renderPass=impl_->render_pass; rbi.framebuffer=impl_->framebuffers[index]; rbi.renderArea.extent={width_,height_}; rbi.clearValueCount=1; rbi.pClearValues=&clear;
 vkCmdBeginRenderPass(cmd,&rbi,VK_SUBPASS_CONTENTS_INLINE);
 if (command_processor_.commands().empty()) {
   GpuCommand fallback{}; fallback.op=GpuOp::Clear; fallback.x=0.01f; fallback.y=0.02f; fallback.z=0.06f; fallback.w=1.0f;
   GpuCommandProcessor local; local.submit(fallback);
   auto ex=command_executor_.execute(cmd,local,&pipeline_runtime_,&descriptor_backend_,&resource_backend_,&shader_programs_,reinterpret_cast<void*>(impl_->render_pass), &resource_binding_runtime_); if(!ex.ok()){ vkCmdEndRenderPass(cmd); return core::Result<void>::Error(ex.error()); }
 } else {
   auto ex=command_executor_.execute(cmd,command_processor_,&pipeline_runtime_,&descriptor_backend_,&resource_backend_,&shader_programs_,reinterpret_cast<void*>(impl_->render_pass), &resource_binding_runtime_); if(!ex.ok()){ vkCmdEndRenderPass(cmd); return core::Result<void>::Error(ex.error()); }
 }
 vkCmdEndRenderPass(cmd);
 gpu_runtime_.write_end_timestamp(cmd);
 if(vkEndCommandBuffer(cmd)!=VK_SUCCESS)return core::Result<void>::Error("command buffer end failed");
 impl_->initialized[index]=1;
 r=impl_->end_frame(dev, q, index, frame_fence, img_available, cmd);
 if(r==VK_ERROR_OUT_OF_DATE_KHR||r==VK_SUBOPTIMAL_KHR)return recreate(width_,height_);
 return r==VK_SUCCESS?core::Result<void>::Ok():core::Result<void>::Error(rn(r));
}
core::Result<void> VulkanPresenter::submit_commands(const std::vector<GpuCommand>& commands){
    if(!ready_) return core::Result<void>::Error("presenter not ready");
    command_processor_.reset();
    auto r=command_processor_.submit(commands);
    if(!r.ok()) return r;
    return core::Result<void>::Ok();
}
core::Result<void> VulkanPresenter::draw_clear_frame(){
 if(!ready_||!impl_) return core::Result<void>::Error("presenter not ready");
 VkDevice dev=as<VkDevice>(device_); VkQueue q=as<VkQueue>(queue_);
 uint32_t index=0; VkFence frame_fence=VK_NULL_HANDLE; VkSemaphore img_available=VK_NULL_HANDLE;
 VkResult r=impl_->begin_frame(dev, index, frame_fence, img_available);
 if(r==VK_ERROR_OUT_OF_DATE_KHR){ auto rr=recreate(width_,height_); return rr.ok()?core::Result<void>::Error("swapchain recreated; retry frame"):rr; }
 if(r!=VK_SUCCESS&&r!=VK_SUBOPTIMAL_KHR) return core::Result<void>::Error(rn(r));
 VkCommandBuffer cmd=impl_->commands[index];
 r=vkResetCommandBuffer(cmd,0); if(r!=VK_SUCCESS) return core::Result<void>::Error(rn(r));
 VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO}; bi.flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
 r=vkBeginCommandBuffer(cmd,&bi); if(r!=VK_SUCCESS) return core::Result<void>::Error(rn(r));
 VkClearValue clear{}; clear.color.float32[0]=0.01f; clear.color.float32[1]=0.02f; clear.color.float32[2]=0.06f; clear.color.float32[3]=1.0f;
 VkRenderPassBeginInfo rbi{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO}; rbi.renderPass=impl_->render_pass; rbi.framebuffer=impl_->framebuffers[index]; rbi.renderArea.extent={width_,height_}; rbi.clearValueCount=1; rbi.pClearValues=&clear;
 vkCmdBeginRenderPass(cmd,&rbi,VK_SUBPASS_CONTENTS_INLINE); vkCmdEndRenderPass(cmd);
 r=vkEndCommandBuffer(cmd); if(r!=VK_SUCCESS) return core::Result<void>::Error(rn(r));
 impl_->initialized[index]=1;
 r=impl_->end_frame(dev, q, index, frame_fence, img_available, cmd);
 if(r==VK_ERROR_OUT_OF_DATE_KHR||r==VK_SUBOPTIMAL_KHR){ auto rr=recreate(width_,height_); return rr.ok()?core::Result<void>::Ok():rr; }
 return r==VK_SUCCESS?core::Result<void>::Ok():core::Result<void>::Error(rn(r));
}
void VulkanPresenter::shutdown() noexcept{if(device_&&impl_){VkDevice d=as<VkDevice>(device_);vkDeviceWaitIdle(d);for(auto fb:impl_->framebuffers) if(fb) vkDestroyFramebuffer(d,fb,nullptr); if(impl_->render_pass) vkDestroyRenderPass(d,impl_->render_pass,nullptr); for(auto v:impl_->views)vkDestroyImageView(d,v,nullptr);if(impl_->pool)vkDestroyCommandPool(d,impl_->pool,nullptr);impl_->destroy_sync(d);if(impl_->swapchain)vkDestroySwapchainKHR(d,impl_->swapchain,nullptr);}gpu_runtime_.shutdown();descriptor_backend_.shutdown();resource_backend_.shutdown();pipeline_runtime_.shutdown();render_graph_.clear();command_processor_.reset();shader_programs_.clear();resource_binding_runtime_.reset();impl_.reset();instance_=physical_device_=device_=surface_=queue_=nullptr;queue_family_=image_count_=width_=height_=0;ready_=false;}
std::string VulkanPresenter::diagnostics()const{std::ostringstream s;s<<"presenter="<<(ready_?"READY":"OFF")<<";extent="<<width_<<"x"<<height_<<";images="<<image_count_<<";framesInFlight="<<(impl_?impl_->frames_in_flight:0)<<";presentSemaphores="<<(impl_?impl_->present.size():0)<<";renderPass="<<(impl_&&impl_->render_pass?"READY":"OFF")<<";framebuffers="<<(impl_?impl_->framebuffers.size():0)<<";"<<gpu_runtime_.diagnostics()<<";"<<pipeline_runtime_.diagnostics()<<";"<<resource_backend_.diagnostics()<<";"<<descriptor_backend_.diagnostics()<<";"<<resource_binding_runtime_.diagnostics()<<";"<<command_processor_.diagnostics()<<";"<<command_executor_.diagnostics();return s.str();}
}
#else
namespace lg::gpu { struct VulkanPresenter::Impl {}; VulkanPresenter::VulkanPresenter()=default; VulkanPresenter::~VulkanPresenter()=default; core::Result<void> VulkanPresenter::initialize(void*,void*,void*,void*,uint32_t,void*){return core::Result<void>::Error("Android Vulkan presenter unavailable on host");} core::Result<void> VulkanPresenter::recreate(uint32_t,uint32_t){return core::Result<void>::Error("Android Vulkan presenter unavailable on host");} core::Result<void> VulkanPresenter::draw_frame(){return core::Result<void>::Error("Android Vulkan presenter unavailable on host");} core::Result<void> VulkanPresenter::draw_clear_frame(){return core::Result<void>::Error("Android Vulkan presenter unavailable on host");} core::Result<void> VulkanPresenter::submit_commands(const std::vector<GpuCommand>&){return core::Result<void>::Error("Android Vulkan presenter unavailable on host");} void VulkanPresenter::shutdown() noexcept {} std::string VulkanPresenter::diagnostics() const{return "presenter=OFF;extent=0x0;images=0";} }
#endif
