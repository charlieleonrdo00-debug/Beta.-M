#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "../core/result.h"
#include "render_graph.h"

namespace lg::gpu {

// Original, backend-neutral GPU command stream used as the bridge between the
// guest-facing runtime and Vulkan. It intentionally does not encode proprietary
// Switch command packets; a future guest translator can emit these operations.
enum class GpuOp : uint8_t { SetViewport, SetScissor, BindPipeline, BindVertexBuffer, BindDescriptorSet, Draw, Clear, Barrier };

struct GpuCommand { GpuOp op{}; uint32_t a{}, b{}, c{}, d{}; float x{}, y{}, z{}, w{}; };

struct GpuState {
    float viewport_x{}, viewport_y{}, viewport_w{1}, viewport_h{1};
    uint32_t scissor_w{1}, scissor_h{1};
    uint32_t pipeline_id{}, shader_program_id{}, vertex_buffer_id{}, descriptor_set_id{};
    uint64_t draws{}, clears{}, barriers{};
};

struct GpuCommandStats { uint64_t submitted{}, executed{}, draws{}, clears{}, barriers{}, invalid{}; };

class GpuCommandProcessor {
public:
    core::Result<void> submit(const GpuCommand& command);
    core::Result<void> submit(const std::vector<GpuCommand>& commands);
    core::Result<std::vector<uint32_t>> compile_graph(RenderGraph& graph) const;
    void reset() noexcept;
    const std::vector<GpuCommand>& commands() const noexcept { return commands_; }
    const GpuState& state() const noexcept { return state_; }
    const GpuCommandStats& stats() const noexcept { return stats_; }
    bool has_draw_work() const noexcept { return state_.draws != 0; }
    std::string diagnostics() const;
private:
    core::Result<void> validate_and_apply(const GpuCommand& command);
    std::vector<GpuCommand> commands_;
    GpuState state_{};
    GpuCommandStats stats_{};
};

} // namespace lg::gpu
