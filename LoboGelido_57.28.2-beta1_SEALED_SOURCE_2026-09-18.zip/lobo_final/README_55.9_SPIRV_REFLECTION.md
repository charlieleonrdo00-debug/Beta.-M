# Lobo Gélido 55.9 — SPIR-V Reflection

55.9 adds backend-neutral descriptor reflection for registered SPIR-V modules.

## What is reflected

The reflection pass reads the SPIR-V instruction stream and extracts descriptor-backed
variables carrying `DescriptorSet` and `Binding` decorations. It recognizes:

- Uniform buffers
- Storage buffers
- Sampled images
- Fixed-size descriptor arrays
- Vertex/fragment stage visibility

`reflect_program_interface()` merges the vertex and fragment interfaces and rejects
incompatible type/count declarations for the same set/binding.

## Scope

This is deliberately a lightweight clean-room reflection layer. It does not bundle
third-party shader compilers, proprietary Nintendo shaders, firmware, keys, or games.
It is not a complete SPIR-V reflection implementation: push constants, acceleration
structures, storage images, specialization constants, and advanced descriptor
features remain future work.

## Validation

The host test suite exercises single-stage reflection, descriptor arrays, stage masks,
program merging, and interface validation.
