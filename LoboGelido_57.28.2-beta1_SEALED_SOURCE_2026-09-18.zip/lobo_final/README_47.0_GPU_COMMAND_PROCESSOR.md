# Lobo Gélido 47.0 — GPU Command Processor Foundation

## Objetivo
Construir la capa intermedia que recibe operaciones gráficas del runtime y las transforma en un flujo backend-neutral que posteriormente podrá traducirse a Vulkan. Esta versión no pretende decodificar ni copiar comandos propietarios del Switch.

## Implementado
- `gpu/gpu_command_processor.h/.cpp`.
- Stream de operaciones: viewport, scissor, bind pipeline, bind vertex buffer, draw, clear y barrier.
- Validación de estado antes de aceptar un draw.
- Estado GPU explícito y estadísticas de comandos válidos/invalidos.
- Conversión del stream a un `RenderGraph` ordenado y con dependencias.
- Diagnóstico del command processor.
- Test unitario y build integrado en CMake.

## Seguridad/alcance
El formato es original de Lobo Gélido. No contiene firmware, keys, ROMs, comandos propietarios ni código extraído de Michel/Eden.

## Próximo paso
Conectar esta capa a un traductor de comandos del runtime invitado y, en paralelo, introducir recursos GPU, descriptores y traducción de shaders para que un `Draw` pueda terminar en un `vkCmdDraw*` real con recursos correspondientes.

## Validación
29/29 CTest pasan en host.

El APK Android no se construyó en este entorno porque no está disponible el toolchain Android completo.
