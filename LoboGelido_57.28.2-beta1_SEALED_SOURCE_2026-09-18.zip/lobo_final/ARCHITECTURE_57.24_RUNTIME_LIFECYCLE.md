# Lobo Gélido 57.24 — RuntimeCoordinator + Android Lifecycle

## Ownership

- `RuntimeCoordinator` owns the core runtime state machine and all guest execution resources.
- `NativeRuntimeHost` owns JNI-facing native resources and serializes runtime/Vulkan calls.
- `GameSurfaceView` owns the Android render thread and waits for it to finish before Vulkan teardown.
- `MainActivity` owns navigation/UI only.
- `RuntimeLifecycleController` owns Activity lifecycle policy.

## Runtime state machine

`COLD -> PREPARING -> READY -> RUNNING <-> PAUSED -> STOPPED`

`RUNNING/PAUSED -> RECOVERING -> previous state`

Any preparation/execution failure enters `ERROR` and requires a new prepare/stop cycle.

## Preparation pipeline

1. Reset previous runtime resources.
2. Prepare `Session`.
3. Create guest fastmem and MMU mappings.
4. Detect/load executable content.
5. Create process and capabilities.
6. Register HLE services.
7. Initialize CPU/GPU backends.
8. Create the main guest thread.
9. Enter `READY`.

Each stage has one responsibility and failure propagates immediately.

## Android lifecycle policy

- `onPause`: pause a running guest session.
- `onResume`: resume only a session that was paused by Activity lifecycle.
- `surfaceDestroyed`: stop the render thread and then tear down Vulkan.
- `onDestroy`: stop the native session exactly once.
- Explicit navigation calls `stopForNavigation()` rather than relying on Activity lifecycle callbacks.

This avoids accidentally restarting a manually paused game and prevents a render thread from using Vulkan after teardown.

## FD ownership

`selectContentFd()` duplicates the SAF descriptor with `dup()`. Native owns the duplicate. Java closes its detached descriptor immediately after a successful hand-off. Native closes its duplicate during session stop or replacement.

## Metrics

Runtime FPS remains execution-time FPS. Presentation cadence belongs to Vulkan/presenter metrics and must not be conflated with guest CPU timing.
