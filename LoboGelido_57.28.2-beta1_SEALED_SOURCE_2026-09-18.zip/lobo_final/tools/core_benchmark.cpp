#include "../cpu/interpreter.h"
#include "../memory/address_space.h"
#include <chrono>
#include <iostream>
int main(){
    lg::memory::AddressSpace m; m.map(0x1000,0x1000);
    // B . +0: a hot single-instruction dispatch loop, useful for measuring
    // decode-cache and interpreter dispatch overhead without touching memory.
    m.write32(0x1000,0x14000000u);
    lg::cpu::CpuState s{}; s.pc=0x1000; lg::cpu::Interpreter cpu(m);
    auto t=std::chrono::steady_clock::now(); auto n=cpu.run(s,1000000);
    auto us=std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now()-t).count();
    const double mips=us?double(n)/double(us):0.0;
    std::cout<<"instructions="<<n<<" elapsed_us="<<us<<" MIPS="<<mips<<"\n";
    return n==1000000?0:1;
}
