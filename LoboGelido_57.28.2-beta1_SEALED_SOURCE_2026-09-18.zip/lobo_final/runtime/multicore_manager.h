#pragma once
#include <string>
#include "../platform_registry.h"

namespace lg::runtime {

/** Resolves a game to an internal core without exposing platform selection in the UI. */
class MultiCoreManager {
public:
    struct Resolution {
        platform::Detection detection;
        bool launchable{false};
        std::string core_id;
    };

    Resolution resolve(const std::string& path) const;
};

} // namespace lg::runtime
