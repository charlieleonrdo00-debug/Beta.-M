#include "multicore_manager.h"

namespace lg::runtime {
MultiCoreManager::Resolution MultiCoreManager::resolve(const std::string& path) const {
    const auto detection = platform::detect_path(path);
    Resolution r{detection, false, ""};
    if (detection.platform != platform::Platform::Unknown) {
        if (const auto* core = platform::CoreRegistry::find(detection.platform)) {
            r.core_id = core->id;
            // Registry resolution means the frontend knows which backend is required. Actual
            // emulation availability is checked by the backend at launch; never fake readiness.
            r.launchable = false; // Detection is available; gameplay requires a real backend implementation.
        }
    }
    return r;
}
}
