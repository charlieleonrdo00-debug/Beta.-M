#include "runtime_coordinator.h"

#include "../cpu/dynarmic_provider.h"
#include "../loader/content_loader.h"
#include "../system/filesystem_service.h"
#include "../system/hl_services.h"

#include <limits>
#include <sstream>

namespace lg::runtime {
namespace {
constexpr uint64_t kGuestBase = 0x10000000ull;
constexpr uint64_t kGuestSize = 16ull * 1024 * 1024;
constexpr uint64_t kDefaultQuantum = 64;
constexpr uint8_t kMainPriority = 64;

core::Result<void> execute_guest_state(cpu::Interpreter& cpu, cpu::CpuState& state) {
    if (!cpu.step(state)) return core::Result<void>::Error("guest thread fault");
    return core::Result<void>::Ok();
}

const char* state_name(State state) noexcept {
    switch (state) {
        case State::Cold: return "COLD";
        case State::Preparing: return "PREPARING";
        case State::Ready: return "READY";
        case State::Running: return "RUNNING";
        case State::Paused: return "PAUSED";
        case State::Recovering: return "RECOVERING";
        case State::Stopped: return "STOPPED";
        case State::Error: return "ERROR";
    }
    return "UNKNOWN";
}
} // namespace

core::Result<void> InterpreterBackend::execute(uint64_t guest_pc) {
    state_.pc = guest_pc;
    if (!cpu_.step(state_)) return core::Result<void>::Error("interpreter fault");
    return core::Result<void>::Ok();
}

RuntimeCoordinator::RuntimeCoordinator()
    : shader_cache_("shader_cache"), watchdog_(std::chrono::milliseconds(500)) {
    auto interpreter = std::make_unique<InterpreterBackend>(memory_, mmu_);
    interpreter_backend_ = interpreter.get();
    backends_.add(std::move(interpreter));

    auto block = std::make_unique<cpu::BlockBackend>(memory_, mmu_, kDefaultQuantum);
    block_backend_ = block.get();
    backends_.add(std::move(block));

    auto provider = cpu::make_dynarmic_provider(memory_, mmu_, interpreter_backend_->interpreter());
    if (provider) {
        auto jit = std::make_unique<cpu::JitBackend>(std::move(provider));
        jit_backend_ = jit.get();
        backends_.add(std::move(jit));
    }
}

State RuntimeCoordinator::state() const noexcept {
    std::lock_guard lock(mutex_);
    return state_;
}

RuntimeMetrics RuntimeCoordinator::metrics() const {
    std::lock_guard lock(mutex_);
    return metrics_;
}

uint64_t RuntimeCoordinator::entry_point() const noexcept {
    std::lock_guard lock(mutex_);
    return entry_point_;
}

const system::ProcessManager::Process* RuntimeCoordinator::process() const noexcept {
    std::lock_guard lock(mutex_);
    return kernel_.processes().current();
}

const char* RuntimeCoordinator::cpu_backend_name() const noexcept {
    std::lock_guard lock(mutex_);
    return backend_ ? backend_->name() : "none";
}

bool RuntimeCoordinator::transition(State expected, State next) noexcept {
    if (state_ != expected) return false;
    state_ = next;
    return true;
}

core::Result<void> RuntimeCoordinator::fail(const char* message) {
    state_ = State::Error;
    return core::Result<void>::Error(message);
}

void RuntimeCoordinator::reset_runtime_state() noexcept {
    gpu_.shutdown();
    if (jit_backend_) jit_backend_->invalidate_all();
    if (interpreter_backend_) interpreter_backend_->interpreter().clear_decode_cache();
    if (block_backend_) block_backend_->clear();
    mmu_.clear();
    memory_.clear();
    if (main_process_) kernel_.processes().stop(main_process_);
    kernel_.reset();
    main_thread_ = 0;
    main_process_ = 0;
    entry_point_ = 0;
    backend_ = nullptr;
}

core::Result<void> RuntimeCoordinator::prepare() {
    return prepare(std::string{});
}

core::Result<void> RuntimeCoordinator::prepare(const std::string& content_path) {
    std::lock_guard lock(mutex_);
    if (state_ != State::Cold && state_ != State::Stopped)
        return core::Result<void>::Error("runtime is not Cold/Stopped");

    reset_runtime_state();
    state_ = State::Preparing;
    metrics_ = {};

    auto session_result = session_.prepare();
    if (!session_result.ok()) return fail(session_result.error().c_str());

    if (auto r = prepare_memory(); !r.ok()) return fail(r.error().c_str());
    if (auto r = load_content(content_path); !r.ok()) return fail(r.error().c_str());
    if (auto r = initialize_services(); !r.ok()) return fail(r.error().c_str());
    if (auto r = initialize_backends(); !r.ok()) return fail(r.error().c_str());
    if (auto r = create_main_thread(); !r.ok()) return fail(r.error().c_str());

    last_progress_ = std::chrono::steady_clock::now();
    state_ = State::Ready;
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::prepare_memory() {
    if (!memory_.enable_fastmem(kGuestSize, kGuestBase))
        return core::Result<void>::Error("failed to create fastmem guest arena");
    if (!memory_.map(kGuestBase, kGuestSize))
        return core::Result<void>::Error("failed to create guest memory");
    if (!mmu_.map(kGuestBase, kGuestBase, kGuestSize,
                  memory::Read | memory::Write | memory::Execute | memory::User))
        return core::Result<void>::Error("failed to map guest memory");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::load_content(const std::string& content_path) {
    entry_point_ = 0;
    if (content_path.empty()) return core::Result<void>::Ok();

    const auto info = loader::ContentLoader::inspect(content_path);
    if (!info.valid) return core::Result<void>::Error("game content is invalid or unreadable");
    if (info.format != loader::Format::Nro && info.format != loader::Format::Nso)
        return core::Result<void>::Error("runtime executes NRO/NSO plaintext only; secure NSP/XCI/NCA pipeline is not implemented");

    loader::LoadResult loaded{};
    if (!loader::ContentLoader::load_plaintext(info, memory_, loaded))
        return core::Result<void>::Error("failed to load plaintext game image");

    mmu_.clear();
    constexpr uint64_t page = memory::Mmu::PageSize;
    for (const auto& segment : info.segments) {
        const uint64_t base = segment.load_address & ~memory::Mmu::PageMask;
        const uint64_t end_unaligned = segment.load_address + segment.file_size;
        if (end_unaligned < segment.load_address)
            return core::Result<void>::Error("content segment address overflow");
        if (end_unaligned > std::numeric_limits<uint64_t>::max() - (page - 1))
            return core::Result<void>::Error("content segment alignment overflow");
        const uint64_t end = (end_unaligned + page - 1) & ~memory::Mmu::PageMask;
        if (end <= base || !mmu_.map(base, base, end - base, segment.permissions))
            return core::Result<void>::Error("failed to map executable segment into MMU");
    }

    const uint64_t stack_page =
        (memory_.fastmem_guest_base() + memory_.fastmem_size() - page) & ~memory::Mmu::PageMask;
    if (!mmu_.map(stack_page, stack_page, page, memory::Read | memory::Write | memory::User))
        return core::Result<void>::Error("failed to map guest stack");

    entry_point_ = loaded.entry_point;
    const auto process_id = kernel_.processes().create("main", content_path, loaded.entry_point,
                                                        loaded.image_base, loaded.image_size,
                                                        loaded.segment_count);
    if (!process_id) return core::Result<void>::Error("failed to create guest process");
    main_process_ = process_id;

    if (!kernel_.capabilities().grant(process_id, "svc:system") ||
        !kernel_.capabilities().grant(process_id, "svc:filesystem"))
        return core::Result<void>::Error("failed to initialize process capabilities");
    if (!kernel_.processes().mark_initialized(process_id))
        return core::Result<void>::Error("failed to initialize guest process");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::initialize_services() {
    if (!kernel_.services().register_service(
            "sm:", system::make_system_service(kernel_.scheduler()), "svc:system"))
        return core::Result<void>::Error("failed to register system service");
    if (!kernel_.services().register_service(
            "fsp-srv:", system::make_filesystem_service(), "svc:filesystem"))
        return core::Result<void>::Error("failed to register filesystem service");
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::initialize_backends() {
    auto gpu_result = gpu_.initialize();
    if (!gpu_result.ok()) gpu_.shutdown(); // GPU remains optional until Android surface attachment.

    if (auto r = interpreter_backend_->initialize(); !r.ok()) return r;
    if (auto r = block_backend_->initialize(); !r.ok()) return r;
    bool jit_available = false;
    if (jit_backend_) {
        const auto jit_result = jit_backend_->initialize();
        jit_available = jit_result.ok() && jit_backend_->available();
    }
    backend_ = backends_.select_best(jit_available);
    if (!backend_) return core::Result<void>::Error("no CPU backend");

    metrics_.mmu_ready = true;
    metrics_.gpu_ready = gpu_.ready();
    metrics_.shader_cache_ready = true;
    metrics_.cpu_backend = backend_->name();
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::create_main_thread() {
    if (!entry_point_ && main_process_)
        return core::Result<void>::Error("game image has no entry point");

    const uint64_t pc = entry_point_ ? entry_point_ : kGuestBase;
    const uint64_t sp = memory_.fastmem_guest_base() + memory_.fastmem_size() - 16;
    return create_guest_thread("main", kMainPriority, pc, sp);
}

core::Result<void> RuntimeCoordinator::start() {
    std::lock_guard lock(mutex_);
    if (!transition(State::Ready, State::Running))
        return core::Result<void>::Error("runtime is not Ready");

    auto result = session_.start();
    if (!result.ok()) { state_ = State::Error; return result; }
    if (main_process_ && !kernel_.processes().start(main_process_))
        return fail("failed to start guest process");

    last_progress_ = std::chrono::steady_clock::now();
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::pause() {
    std::lock_guard lock(mutex_);
    if (!transition(State::Running, State::Paused))
        return core::Result<void>::Error("runtime is not Running");
    auto result = session_.pause();
    if (!result.ok()) { state_ = State::Running; return result; }
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::resume() {
    std::lock_guard lock(mutex_);
    if (!transition(State::Paused, State::Running))
        return core::Result<void>::Error("runtime is not Paused");
    auto result = session_.resume();
    if (!result.ok()) { state_ = State::Paused; return result; }
    last_progress_ = std::chrono::steady_clock::now();
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::stop() {
    std::lock_guard lock(mutex_);
    if (state_ == State::Cold || state_ == State::Stopped) {
        if (state_ == State::Cold) session_.stop();
        state_ = State::Stopped;
        return core::Result<void>::Ok();
    }

    const auto result = session_.stop();
    reset_runtime_state();
    metrics_.mmu_ready = false;
    metrics_.gpu_ready = false;
    metrics_.shader_cache_ready = false;
    state_ = State::Stopped;
    return result;
}

core::Result<void> RuntimeCoordinator::run_frame(uint64_t guest_pc) {
    std::lock_guard lock(mutex_);
    if (state_ != State::Running) return core::Result<void>::Error("runtime is not Running");
    if (!backend_) return core::Result<void>::Error("CPU backend unavailable");

    const auto begin = std::chrono::steady_clock::now();
    if (watchdog_.expired(last_progress_)) {
        state_ = State::Recovering;
        ++metrics_.recoveries;
        if (interpreter_backend_) interpreter_backend_->interpreter().clear_decode_cache();
        if (block_backend_) block_backend_->clear();
        if (jit_backend_) jit_backend_->invalidate_all();
        mmu_.invalidate_all();
        last_progress_ = std::chrono::steady_clock::now();
        state_ = State::Running;
    }

    if (main_thread_) {
        const auto quantum = kernel_.threads().recommended_quantum(main_thread_, kDefaultQuantum);
        if (auto r = dispatch_guest_thread(quantum); !r.ok()) {
            ++metrics_.faults;
            return fail(r.error().c_str());
        }
    } else if (auto r = backend_->execute(guest_pc); !r.ok()) {
        ++metrics_.faults;
        return fail(r.error().c_str());
    }

    const auto guest_ticks = main_thread_ ? kernel_.threads().last_dispatch_ticks() : kDefaultQuantum;
    const auto now = kernel_.scheduler().now();
    const auto target = now > std::numeric_limits<uint64_t>::max() - guest_ticks
        ? std::numeric_limits<uint64_t>::max() : now + guest_ticks;
    const auto scheduler_run = kernel_.scheduler().run_until(target);
    metrics_.scheduler_ticks = kernel_.scheduler().now();
    metrics_.scheduler_executed += scheduler_run.executed;
    metrics_.scheduler_cancelled += scheduler_run.cancelled;
    metrics_.scheduler_deferred += scheduler_run.budget_exhausted ? 1 : 0;
    metrics_.scheduler_queue_peak = kernel_.scheduler().stats().queue_peak;
    metrics_.scheduler_decisions = kernel_.threads().scheduler_decisions();
    metrics_.scheduler_fairness_rotations = kernel_.threads().fairness_rotations();
    metrics_.scheduler_guest_cpu_ticks = kernel_.threads().total_cpu_ticks();
    kernel_.timers().pump(kernel_.scheduler().now());

    ++metrics_.frames;
    if (jit_backend_ && backend_ == jit_backend_ && jit_backend_->available()) {
        // JIT providers own instruction accounting.
    } else if (block_backend_) {
        metrics_.instructions = block_backend_->instructions();
    } else if (interpreter_backend_) {
        metrics_.instructions = interpreter_backend_->instruction_count();
    }

    const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now() - begin).count();
    metrics_.cpu_ns += static_cast<uint64_t>(elapsed);
    metrics_.frame_time_ms = elapsed / 1e6;
    // RuntimeCoordinator measures guest execution time only. Presentation FPS belongs to the presenter.
    metrics_.fps = elapsed ? 1e9 / static_cast<double>(elapsed) : 0.0;
    last_progress_ = std::chrono::steady_clock::now();
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::create_guest_thread(
    const char* name, uint8_t priority, uint64_t pc, uint64_t sp) {
    if (!interpreter_backend_) return core::Result<void>::Error("CPU backend unavailable");
    const auto id = kernel_.threads().create(
        name ? name : "guest", priority,
        [this](system::ThreadManager::ThreadId tid) {
            auto* ctx = kernel_.contexts().get(tid);
            if (!ctx) return;

            core::Result<void> result = core::Result<void>::Ok();
            if (jit_backend_ && backend_ == jit_backend_) {
                auto r = jit_backend_->execute_state(*ctx, kernel_.threads().active_quantum());
                if (!r.ok()) result = core::Result<void>::Error(r.error().c_str());
                else kernel_.threads().report_current_consumed_ticks(r.value());
            } else if (block_backend_) {
                auto r = block_backend_->execute_state(*ctx, kernel_.threads().active_quantum());
                if (!r.ok()) result = core::Result<void>::Error(r.error().c_str());
                else kernel_.threads().report_current_consumed_ticks(r.value());
            } else {
                result = execute_guest_state(interpreter_backend_->interpreter(), *ctx);
                if (result.ok()) kernel_.threads().report_current_consumed_ticks(1);
            }

            if (!result.ok()) {
                ctx->halted = true;
                kernel_.threads().terminate(tid);
                return;
            }
            if (ctx->halted) kernel_.threads().terminate(tid);
        });

    if (!id) return core::Result<void>::Error("failed to create guest thread");
    if (!kernel_.contexts().create(id, pc, sp))
        return core::Result<void>::Error("failed to create guest CPU context");
    if (!main_thread_) main_thread_ = id;
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::dispatch_guest_thread(uint64_t quantum) {
    if (state_ != State::Running) return core::Result<void>::Error("runtime is not Running");
    const auto before = kernel_.threads().context_switches();
    if (!kernel_.threads().dispatch_next(quantum))
        return core::Result<void>::Error("no runnable guest thread");
    const auto after = kernel_.threads().context_switches();
    metrics_.thread_context_switches = after;
    if (after != before) ++metrics_.guest_dispatches;
    return core::Result<void>::Ok();
}

core::Result<void> RuntimeCoordinator::recover(const char* reason) {
    std::lock_guard lock(mutex_);
    (void)reason;
    if (state_ != State::Running && state_ != State::Paused)
        return core::Result<void>::Error("runtime is not recoverable in current state");
    const State previous = state_;
    state_ = State::Recovering;
    ++metrics_.recoveries;
    if (interpreter_backend_) interpreter_backend_->interpreter().clear_decode_cache();
    if (block_backend_) block_backend_->clear();
    if (jit_backend_) jit_backend_->invalidate_all();
    mmu_.invalidate_all();
    last_progress_ = std::chrono::steady_clock::now();
    state_ = previous;
    return core::Result<void>::Ok();
}

std::string RuntimeCoordinator::diagnostics() const {
    std::lock_guard lock(mutex_);
    std::ostringstream out;
    out << "Runtime=" << state_name(state_)
        << " CPU=" << (backend_ ? backend_->name() : "none")
        << " JIT=" << (jit_backend_ && jit_backend_->available() ? "provider" : "unavailable")
        << " MMU=" << (metrics_.mmu_ready ? "ready" : "off")
        << " GPU=" << (metrics_.gpu_ready ? "ready" : "off")
        << " shaders=" << (metrics_.shader_cache_ready ? "ready" : "off")
        << " frames=" << metrics_.frames
        << " faults=" << metrics_.faults
        << " recoveries=" << metrics_.recoveries
        << " threads=" << kernel_.threads().size()
        << " switches=" << kernel_.threads().context_switches()
        << " guest_dispatches=" << metrics_.guest_dispatches
        << " blocks=" << (block_backend_ ? block_backend_->block_count() : 0)
        << " block_hits=" << (block_backend_ ? block_backend_->hot_hits() : 0)
        << " entry=0x" << std::hex << entry_point_ << std::dec;
    return out.str();
}

} // namespace lg::runtime
