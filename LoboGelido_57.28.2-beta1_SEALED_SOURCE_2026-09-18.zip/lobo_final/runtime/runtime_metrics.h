#pragma once
#include <cstdint>
#include <string>

namespace lg::runtime {
struct RuntimeMetrics {
    uint64_t frames{};
    uint64_t instructions{};
    uint64_t scheduler_ticks{};
    uint64_t scheduler_executed{};
    uint64_t scheduler_cancelled{};
    uint64_t scheduler_deferred{};
    uint64_t scheduler_queue_peak{};
    uint64_t scheduler_decisions{};
    uint64_t scheduler_fairness_rotations{};
    uint64_t scheduler_guest_cpu_ticks{};
    uint64_t cpu_ns{};
    uint64_t gpu_ns{};
    uint64_t shader_hits{};
    uint64_t shader_misses{};
    uint64_t recoveries{};
    uint64_t faults{};
    uint64_t thread_context_switches{};
    uint64_t guest_dispatches{};
    double fps{};
    double frame_time_ms{};
    const char* cpu_backend{"none"};
    bool mmu_ready{};
    bool gpu_ready{};
    bool shader_cache_ready{};
};
}
