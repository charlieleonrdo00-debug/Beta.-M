#pragma once
#include <chrono>
#include <cstdint>
#include <mutex>
#include <string>

#include "runtime_metrics.h"
#include "../core/result.h"
#include "../core/session.h"
#include "../cpu/backend.h"
#include "../cpu/backend_manager.h"
#include "../cpu/interpreter.h"
#include "../cpu/block_backend.h"
#include "../cpu/jit_backend.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"
#include "../system/kernel.h"
#include "../gpu/gpu_device.h"
#include "../graphics/shader_cache.h"
#include "../recovery/watchdog.h"

namespace lg::runtime {

enum class State { Cold, Preparing, Ready, Running, Paused, Recovering, Stopped, Error };

class InterpreterBackend final : public cpu::Backend {
public:
    InterpreterBackend(memory::AddressSpace& memory, memory::Mmu& mmu) : cpu_(memory, mmu) {}
    core::Result<void> initialize() override { return core::Result<void>::Ok(); }
    core::Result<void> execute(uint64_t guest_pc) override;
    const char* name() const noexcept override { return "Interpreter"; }
    cpu::BackendKind kind() const noexcept override { return cpu::BackendKind::Interpreter; }
    cpu::Interpreter& interpreter() noexcept { return cpu_; }
    uint64_t instruction_count() const noexcept { return state_.instructions; }
private:
    cpu::Interpreter cpu_;
    cpu::CpuState state_{};
};

class RuntimeCoordinator final {
public:
    RuntimeCoordinator();
    ~RuntimeCoordinator() = default;

    RuntimeCoordinator(const RuntimeCoordinator&) = delete;
    RuntimeCoordinator& operator=(const RuntimeCoordinator&) = delete;

    core::Result<void> prepare();
    core::Result<void> prepare(const std::string& content_path);
    core::Result<void> start();
    core::Result<void> pause();
    core::Result<void> resume();
    core::Result<void> stop();
    core::Result<void> run_frame(uint64_t guest_pc);
    core::Result<void> create_guest_thread(const char* name, uint8_t priority, uint64_t pc, uint64_t sp = 0);
    core::Result<void> dispatch_guest_thread(uint64_t quantum = 64);
    core::Result<void> recover(const char* reason);

    State state() const noexcept;
    RuntimeMetrics metrics() const;
    uint64_t entry_point() const noexcept;
    const system::ProcessManager::Process* process() const noexcept;
    const char* cpu_backend_name() const noexcept;
    std::string diagnostics() const;

private:
    core::Result<void> prepare_memory();
    core::Result<void> load_content(const std::string& content_path);
    core::Result<void> initialize_services();
    core::Result<void> initialize_backends();
    core::Result<void> create_main_thread();
    core::Result<void> fail(const char* message);
    void reset_runtime_state() noexcept;
    bool transition(State expected, State next) noexcept;

    mutable std::mutex mutex_;
    core::Session session_;
    memory::AddressSpace memory_;
    memory::Mmu mmu_;
    system::Kernel kernel_;
    gpu::GpuDevice gpu_;
    graphics::ShaderCache shader_cache_;
    recovery::Watchdog watchdog_;
    cpu::BackendManager backends_;
    InterpreterBackend* interpreter_backend_{};
    cpu::BlockBackend* block_backend_{};
    cpu::JitBackend* jit_backend_{};
    cpu::Backend* backend_{};
    uint64_t main_thread_{};
    system::ProcessManager::ProcessId main_process_{};
    RuntimeMetrics metrics_{};
    State state_{State::Cold};
    std::chrono::steady_clock::time_point last_progress_{};
    uint64_t entry_point_{};
};

} // namespace lg::runtime
