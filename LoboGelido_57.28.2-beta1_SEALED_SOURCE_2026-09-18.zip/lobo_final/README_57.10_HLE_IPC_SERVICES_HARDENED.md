# Lobo Gélido 57.10 — HLE / IPC / Services Hardened

## Alcance

Este bloque refuerza la capa de sistema sin modificar la interfaz Android ni Vulkan.

### Cambios
- IPC limita el payload a 1 MiB para evitar colas descontroladas.
- `IpcManager` evita registrar dos veces al mismo hilo como waiter de un canal.
- Al enviar, se limpian waiters inválidos y se despierta el primer hilo válido.
- `ServiceRegistry` expone conteo, consulta y listado determinista de servicios.
- El servicio de sistema incorpora un comando de versión HLE estable.
- Se mantienen intactos CPU, MMU, GPU y la UI de la versión 57.9.9.

## Verificación

Build CMake del núcleo y suite CTest completa: **36/36 PASS (100%)**.

Esta versión no implica compatibilidad comercial completa con Nintendo Switch; es una mejora de infraestructura HLE/IPC para continuar implementando servicios reales.
