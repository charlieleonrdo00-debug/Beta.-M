# Lobo Gélido 28.0 — GPU/Vulkan Foundation

28.0 advances the graphics side without pretending that a production Switch renderer is already complete.

## Added
- Vulkan capability model isolated from the guest emulation domain.
- Capability reporting for timeline semaphores, dynamic rendering, descriptor indexing and shader int16.
- Deterministic render-graph compilation with dependency validation and cycle detection.
- Atomic shader-cache writes and cache keys that include program/device/format identity.
- GPU/render-graph/shader-cache integration test.
- Android version 28.0, ARM64-only target.

## Status
The Vulkan device model is a capability foundation. A real Android `VkInstance`/`VkDevice` and production Switch GPU translation layer are still separate milestones. No Nintendo firmware, keys or games are bundled.

Dynarmic remains an optional real backend: the adapter exists, but the actual Dynarmic source tree must be supplied at build time with `LOBOGELIDO_DYNARMIC_SOURCE_DIR`.
