# Lobo Gélido 24.0 — Tier-1 Block Runtime

This release adds a **Tier-1 block execution backend** over the existing ARM64 interpreter.

## What changed

- `cpu/block_backend.*`: bounded guest-block execution with entry-point metadata, hit counters and instruction accounting.
- Runtime now selects the Block backend for frame execution instead of single-step Interpreter dispatch.
- Strict instruction validation remains enabled, so self-modifying code cannot silently reuse stale decoded instructions.
- Recovery clears both interpreter and block metadata.
- Android native build includes the new backend.
- Android version: `24.0` / `versionCode 2400`.

## Important accuracy note

This is **not native machine-code JIT yet**. It is a tier-1 block executor designed to reduce backend dispatch overhead and establish the block cache/invalidation boundary needed for a real Dynarmic tier-2 JIT.

The official Dynarmic project supports ARM64 guest code, AArch64 hosts and Android, making it the intended tier-2 integration target when its source can be vendored into the project with its license and build files intact.

## Validation

Host CTest: **16/16 passed**.
