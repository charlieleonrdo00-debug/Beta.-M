# Lobo Gélido 48.0 — GPU Resources & Descriptors

## Objetivo
Construir la capa de recursos GPU que sigue al procesador de comandos 47.0: buffers, imágenes y descriptor sets con bindings validados.

## Implementado
- Gestor backend-neutral de recursos GPU.
- IDs estables para buffers, imágenes y descriptor sets.
- Validación de tamaños y dimensiones.
- Bindings de descriptor con actualización por binding.
- Eliminación segura de recursos y limpieza de bindings que los referencian.
- Diagnósticos de cantidad de recursos y bindings.
- Pruebas automatizadas.

## Estado
Esta capa prepara el camino para conectar recursos reales de Vulkan. En esta versión el gestor de recursos es deliberadamente backend-neutral; no se presenta como una implementación completa de memoria GPU de Switch.

No incluye firmware, keys, ROMs ni contenido propietario.
