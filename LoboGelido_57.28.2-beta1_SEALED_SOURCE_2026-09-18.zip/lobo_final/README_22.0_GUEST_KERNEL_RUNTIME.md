# Lobo Gélido 22.0 — Guest Kernel Runtime

Esta fase conecta la arquitectura de kernel 21.0 con primitives de ejecución guest: contexto CPU por hilo, temporizadores, IPC bloqueante y servicios HLE mínimos.

## Implementado

- `GuestThreadContextManager`: un `CpuState` independiente por hilo guest.
- `RuntimeCoordinator::create_guest_thread()` y `dispatch_guest_thread()`: ejecución de instrucciones sobre el contexto del hilo seleccionado.
- `TimerManager`: temporizadores one-shot y periódicos sobre el reloj virtual.
- `IpcManager`: canales, colas de mensajes y desbloqueo de waiters.
- `SystemService`: primer servicio HLE (`sm:`) con consulta de tick virtual y versión del runtime.
- `Kernel`: ahora compone Scheduler, ThreadManager, SyncManager, ServiceRegistry, IPC, timers y contextos CPU.
- Android/CMake actualizados para incluir toda la nueva capa.

## Validación

15/15 pruebas nativas pasan.

## Límite técnico

Esto es una capa de kernel/HLE propia y determinista; todavía no pretende ser una implementación completa del kernel de Nintendo Switch. No se incluyen firmware, claves, ROMs ni contenido propietario.
