# Lobo Gélido 57.9.9 — CPU/MMU cache hardening

- Keeps the optional interpreter decode cache coherent with AddressSpace write epochs.
- Invalidates the decode cache when MMU mappings change.
- Preserves strict instruction-word validation as the default.
- Adds a regression test for self-modifying guest code while strict validation is disabled.
- Android/native version metadata is aligned to 57.9.9.

This release does not change the visual UI. It is an internal correctness hardening step.
