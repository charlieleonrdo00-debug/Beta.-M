# Lobo Gélido — ARM64 Android Emulator Core

Lobo Gélido is an original Android emulator project focused on a modular ARM64 execution core, deterministic runtime services, an Android-first frontend, and a Vulkan-oriented graphics architecture.

## Current baseline — 32.0 QA / Architecture Hardening

This tree has been audited through the 29.0 QA/architecture hardening pass; 30.0 adds the second hardening pass and Android boundary refactor.

### Verified
- ARM64 interpreter, decoder, ASIMD/NEON and exclusive-monitor paths.
- Tier-1 block execution with validated interpreter fallback.
- Optional Dynarmic A64 JIT adapter. Dynarmic is **not bundled**; the source tree must be supplied explicitly at build time.
- MMU with software TLB and checked permissions.
- Deterministic scheduler, guest threads, synchronization, IPC, timers and guest contexts.
- Runtime lifecycle including stop → prepare reuse.
- Transactional address-space mapping and explicit memory reset.
- Vulkan capability model that no longer fabricates hardware readiness.
- Render-graph dependency validation and persistent shader-cache foundation.
- Android ARM64 packaging configuration.
- 18/18 native CTest cases passing in a Release build with assertions explicitly enabled for tests.

## Important status boundary

The core does **not** claim a production Switch GPU translator, real Android Vulkan device/surface integration, complete HLE/service coverage, complete HID/audio implementation, or broad game compatibility yet. Those are subsequent engineering milestones.

The runtime diagnostics distinguish real capabilities from placeholders. Until an Android Vulkan backend supplies actual queried device capabilities, `GPU=off` is intentional.

No Nintendo firmware, keys, game ROMs, or other proprietary Nintendo assets are bundled.

## Build

Host validation:

```text
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
ctest --test-dir build --output-on-failure
```

Optional Dynarmic integration:

```text
cmake -S . -B build \
  -DLOBOGELIDO_ENABLE_DYNARMIC=ON \
  -DLOBOGELIDO_DYNARMIC_SOURCE_DIR=/path/to/dynarmic
```

The optional adapter is intentionally explicit so a build cannot silently report JIT support that is not actually linked.

## 30.0 architecture audit

The 30.0 pass is a deep hardening release: JNI is isolated behind `RuntimeBridge`, virtual-time ownership is unambiguous, JIT availability is truthful, and memory topology changes invalidate exclusive reservations. See `README_30.0_ARCHITECTURE_AUDIT.md`.
