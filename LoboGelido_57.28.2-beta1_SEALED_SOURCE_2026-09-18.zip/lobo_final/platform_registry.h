#pragma once
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace lg::platform {

enum class Platform { Unknown, GameBoyColor, GameBoyAdvance, Nintendo64, NintendoDS, GameCube, Wii, Nintendo3DS, NintendoSwitch };

struct Detection {
    Platform platform{Platform::Unknown};
    int confidence{};
    bool supported_by_frontend{};
    std::string reason;
};

const char* name(Platform) noexcept;
const char* core_id(Platform) noexcept;
Detection detect_path(std::string_view path);
Detection detect_magic(const std::vector<uint8_t>& bytes, std::string_view path = {});

class CoreRegistry {
public:
    struct CoreDescriptor { Platform platform; const char* id; const char* display_name; };
    static const std::vector<CoreDescriptor>& all();
    static const CoreDescriptor* find(Platform platform);
};

} // namespace lg::platform
