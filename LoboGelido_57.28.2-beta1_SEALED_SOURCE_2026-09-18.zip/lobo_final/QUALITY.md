# Quality Gates 3.0

Antes de considerar una versión "release":
- C++20 sin warnings nuevos.
- Tests de CPU, memoria, scheduler e IPC.
- Tests de caché GPU y serialización.
- Benchmark estable de 10+ minutos.
- Prueba de suspensión/reanudación.
- Prueba de presión térmica.
- Crash recovery verificado.
- Sin regresiones de frametime P95/P99.
- Resultados guardados y comparables.

Una feature que empeora la estabilidad no entra sólo porque sea llamativa.
