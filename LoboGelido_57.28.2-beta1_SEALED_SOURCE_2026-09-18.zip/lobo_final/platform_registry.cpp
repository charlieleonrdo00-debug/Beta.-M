#include "platform_registry.h"
#include <algorithm>
#include <cctype>
#include <filesystem>

namespace lg::platform {

const char* name(Platform p) noexcept {
    switch (p) {
        case Platform::GameBoyColor: return "Game Boy Color";
        case Platform::GameBoyAdvance: return "Game Boy Advance";
        case Platform::Nintendo64: return "Nintendo 64";
        case Platform::NintendoDS: return "Nintendo DS";
        case Platform::GameCube: return "GameCube";
        case Platform::Wii: return "Wii";
        case Platform::Nintendo3DS: return "Nintendo 3DS";
        case Platform::NintendoSwitch: return "Nintendo Switch";
        default: return "Unknown";
    }
}

const char* core_id(Platform p) noexcept {
    switch (p) {
        case Platform::GameBoyColor: return "gbc";
        case Platform::GameBoyAdvance: return "gba";
        case Platform::Nintendo64: return "n64";
        case Platform::NintendoDS: return "nds";
        case Platform::GameCube: return "gc";
        case Platform::Wii: return "wii";
        case Platform::Nintendo3DS: return "3ds";
        case Platform::NintendoSwitch: return "switch";
        default: return "unknown";
    }
}

static std::string lower(std::string_view s) {
    std::string out(s);
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c){ return char(std::tolower(c)); });
    return out;
}

Detection detect_path(std::string_view path) {
    const auto p = lower(path);
    auto ext = lower(std::filesystem::path(p).extension().string());
    if (ext == ".gb" || ext == ".gbc") return {Platform::GameBoyColor, 96, true, "Game Boy cartridge extension"};
    if (ext == ".gba") return {Platform::GameBoyAdvance, 96, true, "Game Boy Advance cartridge extension"};
    if (ext == ".z64" || ext == ".n64" || ext == ".v64") return {Platform::Nintendo64, 96, true, "Nintendo 64 cartridge extension"};
    if (ext == ".nds") return {Platform::NintendoDS, 96, true, "Nintendo DS cartridge extension"};
    if (ext == ".3ds" || ext == ".cci" || ext == ".cia" || ext == ".cxi") return {Platform::Nintendo3DS, 92, true, "Nintendo 3DS container extension"};
    if (ext == ".rvz") return {Platform::Wii, 95, true, "RVZ container extension"};
    if (ext == ".gcm" || ext == ".gcz" || ext == ".iso") {
        if (p.find("wii") != std::string::npos) return {Platform::Wii, 75, true, "Wii hint in path"};
        return {Platform::GameCube, 70, true, "optical-disc image; platform needs header inspection"};
    }
    if (ext == ".nro" || ext == ".nso" || ext == ".nca" || ext == ".xci" || ext == ".nsp") return {Platform::NintendoSwitch, 97, true, "Nintendo Switch content extension"};
    return {};
}

Detection detect_magic(const std::vector<uint8_t>& b, std::string_view path) {
    auto by_path = detect_path(path);
    if (b.size() >= 4) {
        if (b[0]=='N'&&b[1]=='R'&&b[2]=='O'&&b[3]=='0') return {Platform::NintendoSwitch, 100, true, "NRO0 header"};
        if (b[0]=='N'&&b[1]=='S'&&b[2]=='O'&&b[3]=='0') return {Platform::NintendoSwitch, 100, true, "NSO0 header"};
        if ((b[0]=='N'&&b[1]=='C'&&b[2]=='A'&&(b[3]=='2'||b[3]=='3'))) return {Platform::NintendoSwitch, 100, true, "NCA header"};
    }
    if (b.size() >= 4) {
        // GameCube/Wii disc images carry the Nintendo magic at the beginning.
        if (b[0]=='G'&&b[1]=='C'&&b[2]=='E'&&b[3]=='E') return {Platform::GameCube, 100, true, "GameCube disc magic"};
        if (b[0]=='R'&&b[1]=='V'&&b[2]=='Z'&&b[3]=='0') return {Platform::Wii, 100, true, "RVZ container"};
        // N64 has a characteristic 0x80371240 word in one of the common byte orders.
        if ((b[0]==0x80&&b[1]==0x37&&b[2]==0x12&&b[3]==0x40) || (b[0]==0x37&&b[1]==0x80&&b[2]==0x40&&b[3]==0x12) || (b[0]==0x40&&b[1]==0x12&&b[2]==0x37&&b[3]==0x80)) return {Platform::Nintendo64, 98, true, "Nintendo 64 boot signature"};
    }
    return by_path;
}

const std::vector<CoreRegistry::CoreDescriptor>& CoreRegistry::all() {
    static const std::vector<CoreDescriptor> cores = {
        {Platform::GameBoyColor, "gbc", "Game Boy Color Core"},
        {Platform::GameBoyAdvance, "gba", "Game Boy Advance Core"},
        {Platform::Nintendo64, "n64", "Nintendo 64 Core"},
        {Platform::NintendoDS, "nds", "Nintendo DS Core"},
        {Platform::GameCube, "gc", "GameCube Core"},
        {Platform::Wii, "wii", "Wii Core"},
        {Platform::Nintendo3DS, "3ds", "Nintendo 3DS Core"},
        {Platform::NintendoSwitch, "switch", "Nintendo Switch Core"}
    };
    return cores;
}

const CoreRegistry::CoreDescriptor* CoreRegistry::find(Platform p) {
    const auto& cores = all();
    const auto it = std::find_if(cores.begin(), cores.end(), [p](const CoreDescriptor& c){ return c.platform == p; });
    return it == cores.end() ? nullptr : &*it;
}

} // namespace lg::platform
