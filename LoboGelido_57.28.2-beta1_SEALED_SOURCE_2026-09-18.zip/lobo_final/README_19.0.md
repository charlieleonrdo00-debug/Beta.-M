# Lobo Gélido 19.0 — Beyond 100 Runtime Architecture

19.0 is a runtime architecture milestone, not a claim of full Switch compatibility.

## What changed
- RuntimeCoordinator is the native composition root.
- Session lifecycle is connected to the coordinator through JNI.
- CPU backend selection is explicit and replaceable.
- Interpreter backend is a real executable backend using the existing ARM64 interpreter + MMU.
- Guest memory and MMU are initialized during runtime preparation.
- Scheduler, GPU device, shader cache and watchdog are owned by the runtime coordinator.
- Runtime diagnostics report lifecycle, backend, memory/GPU readiness, faults and recoveries.
- Android version target is 19.0 / versionCode 1900.
- 12 native core tests pass.

## Deliberately not claimed
- Dynarmic/JIT is not yet integrated.
- A production Vulkan renderer is not yet integrated.
- Nintendo firmware, keys, ROMs or other proprietary assets are not included.
- Compatibility is not represented as 100% until measured against real software.

## Engineering target
The project uses a >100% internal maturity scale. Above 100% means stronger architecture, testing, observability, recovery and optimization beyond basic feature completeness. It is not a claim that compatibility or FPS can exceed physical 100%.
