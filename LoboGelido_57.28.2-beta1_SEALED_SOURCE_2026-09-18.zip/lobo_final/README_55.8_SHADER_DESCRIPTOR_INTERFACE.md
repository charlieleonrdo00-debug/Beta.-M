# Lobo Gélido 55.9 — Shader/Descriptor Interface

This increment adds a backend-neutral resource contract to `ShaderProgram`. Programs can declare descriptor set/binding/type/count/stage visibility requirements. The Vulkan descriptor backend validates a bound descriptor set against that contract before it is submitted with a program-backed pipeline.

## Contract
- `ShaderResourceType`: uniform buffer, storage buffer, sampled image.
- `ShaderResourceBinding`: set, binding, count and stage mask.
- `ShaderProgramManager::set_resource_interface()` stores a sorted, validated interface.
- `VulkanDescriptorBackend::validate_set_against_program()` checks the active descriptor set for required bindings, descriptor types, counts and stage visibility.

## Scope
This is an interface/validation layer, not SPIR-V reflection. It does not infer bindings from arbitrary shaders. A later stage can add SPIR-V reflection and automatic layout generation.
