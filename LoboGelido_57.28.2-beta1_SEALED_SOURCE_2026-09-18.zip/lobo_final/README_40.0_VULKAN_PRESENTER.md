# Lobo Gélido 40.0 — Vulkan Presenter

Esta versión construye el siguiente escalón del runtime Vulkan Android sobre 39.0.

## Implementado
- `VulkanPresenter` independiente del contexto Android.
- Selección de formato de superficie y modo FIFO/Mailbox cuando está disponible.
- Creación y recreación del swapchain.
- Image views para las imágenes del swapchain.
- Command pool y command buffers.
- Semáforos de adquisición/presentación y fence por frame.
- `vkAcquireNextImageKHR`, submit y `vkQueuePresentKHR`.
- Manejo de `VK_ERROR_OUT_OF_DATE_KHR` y `VK_SUBOPTIMAL_KHR` mediante recreación.
- JNI para `drawVulkanFrame()` y diagnóstico del presenter.
- El contexto Vulkan expone únicamente los handles que ya creó realmente.

## Limitación deliberada
Todavía no se dibuja una escena real: el command buffer de esta etapa sirve para validar el ciclo de adquisición/sincronización/presentación. La siguiente etapa conecta render passes/dynamic rendering, imágenes de color y shaders.

## Validación host
25/25 CTest pasaron. El APK Android no se declara compilado en este entorno porque no está disponible el toolchain Android completo.
