# Lobo Gélido 32.0 — CPU Context + Dynarmic Integration Boundary

## Objetivo

Esta versión endurece la frontera entre el contexto ARM64 de cada hilo invitado y el backend JIT. No declara Dynarmic disponible salvo que su fuente real se enlace durante la configuración de CMake.

## Cambios

- `CpuState::reset()` para eliminar estado arquitectónico entre vidas de un hilo.
- `GuestThreadContextManager::create()` reinicia un contexto si se reutiliza un ID.
- El adaptador Dynarmic ya no confunde ticks de ejecución con instrucciones retiradas.
- La invalidación del JIT detiene ejecución, limpia código traducido y estado exclusivo.
- Prueba de contrato que distingue proveedor Dynarmic real de proveedor ausente.
- Se mantiene Fastmem desactivado hasta disponer de un arena contiguo estable; no se sacrifica corrección por una optimización prematura.

## Estado real

Dynarmic es opcional. La integración real se activa solamente con:

```text
-DLOBOGELIDO_ENABLE_DYNARMIC=ON
-DLOBOGELIDO_DYNARMIC_SOURCE_DIR=/ruta/al/arbol/dynarmic
```

El árbol Dynarmic no se incluye en este paquete.

## Validación

Release: 20/20 pruebas.
