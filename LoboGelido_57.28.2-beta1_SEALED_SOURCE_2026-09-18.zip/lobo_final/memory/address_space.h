#pragma once
#include <cstdint>
#include <optional>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <atomic>
#include <memory>
namespace lg::memory {
class AddressSpace { public:
    AddressSpace() = default;
    explicit AddressSpace(uint64_t fastmem_size) { enable_fastmem(fastmem_size); }
    bool map(uint64_t guest, uint64_t size); bool unmap(uint64_t guest, uint64_t size); void clear() noexcept;
    std::optional<uint8_t> read8(uint64_t a) const; std::optional<uint32_t> read32(uint64_t a) const; std::optional<uint64_t> read64(uint64_t a) const;
    void write8(uint64_t a,uint8_t v); void write32(uint64_t a,uint32_t v); void write64(uint64_t a,uint64_t v);
    uint8_t* host_ptr(uint64_t a); const uint8_t* host_ptr(uint64_t a) const;
    uint64_t write_epoch() const noexcept { return write_epoch_.load(std::memory_order_relaxed); }

    // Optional contiguous guest arena used by JIT fastmem backends. It is deliberately
    // separate from the page map so correctness never depends on fastmem being enabled.
    bool enable_fastmem(uint64_t size, uint64_t guest_base = 0);
    bool has_fastmem() const noexcept { return fastmem_ != nullptr; }
    uint64_t fastmem_size() const noexcept { return fastmem_size_; }
    uint64_t fastmem_guest_base() const noexcept { return fastmem_guest_base_; }
    bool fastmem_contains(uint64_t a, uint64_t size = 1) const noexcept;
    uint8_t* fastmem_base() noexcept { return fastmem_.get(); }
    const uint8_t* fastmem_base() const noexcept { return fastmem_.get(); }
private:
    std::unordered_map<uint64_t,std::vector<uint8_t>> pages_;
    std::unordered_set<uint64_t> mapped_pages_;
    std::unique_ptr<uint8_t[]> fastmem_;
    // One byte per guest page in the contiguous arena. This avoids an
    // unordered_set lookup on every JIT memory access.
    std::vector<uint8_t> fastmem_mapped_pages_;
    uint64_t fastmem_size_{};
    uint64_t fastmem_guest_base_{};
    static constexpr uint64_t P=4096;
    std::atomic<uint64_t> write_epoch_{0};
};
}
