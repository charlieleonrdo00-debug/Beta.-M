#include "mmu.h"
#include <limits>
namespace lg::memory {

bool Mmu::map(uint64_t va, uint64_t pa, uint64_t size, uint32_t perms) {
    constexpr uint32_t ValidPermissions = Read | Write | Execute | User;
    if (!size || !perms || (perms & ~ValidPermissions) || (va & PageMask) || (pa & PageMask) ||
        va > std::numeric_limits<uint64_t>::max() - (size - 1) ||
        pa > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t pages = ((size - 1) >> PageBits) + 1;
    const uint64_t first_vpn = va >> PageBits;
    const uint64_t first_ppn = pa >> PageBits;
    if (pages - 1 > std::numeric_limits<uint64_t>::max() - first_vpn ||
        pages - 1 > std::numeric_limits<uint64_t>::max() - first_ppn) return false;
    for (uint64_t i=0;i<pages;++i) {
        const uint64_t vpn=first_vpn+i;
        if (page_table_.contains(vpn)) return false;
    }
    for (uint64_t i=0;i<pages;++i) page_table_[first_vpn+i] = Entry{first_ppn+i, perms};
    invalidate_all(); ++generation_; return true;
}

bool Mmu::unmap(uint64_t va, uint64_t size) {
    if (!size || (va & PageMask) || va > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t pages=((size-1)>>PageBits)+1;
    const uint64_t first_vpn=va>>PageBits;
    if (pages - 1 > std::numeric_limits<uint64_t>::max() - first_vpn) return false;
    for(uint64_t i=0;i<pages;++i) page_table_.erase(first_vpn+i);
    invalidate_all(); ++generation_; return true;
}

void Mmu::invalidate_all() noexcept { for(auto &e:tlb_) e.valid=false; }
void Mmu::clear() noexcept { page_table_.clear(); invalidate_all(); ++generation_; }
void Mmu::invalidate_page(uint64_t va) noexcept { auto &e=tlb_[slot(va>>PageBits)]; e.valid=false; }

core::Result<Translation> Mmu::translate(uint64_t va, bool write, bool execute) const {
    const uint64_t vpn=va>>PageBits; const auto idx=slot(vpn); const auto &t=tlb_[idx];
    if(t.valid && t.virtual_page==vpn) {
        if((write && !(t.permissions&Write)) || (execute && !(t.permissions&Execute)) || (!write && !execute && !(t.permissions&Read))) return core::Result<Translation>::Error("permission fault");
        return core::Result<Translation>::Ok(Translation{(t.physical_page<<PageBits)|(va&PageMask),t.permissions});
    }
    auto it=page_table_.find(vpn); if(it==page_table_.end()) return core::Result<Translation>::Error("translation fault");
    if((write && !(it->second.permissions&Write)) || (execute && !(it->second.permissions&Execute)) || (!write && !execute && !(it->second.permissions&Read))) return core::Result<Translation>::Error("permission fault");
    tlb_[idx]=TlbEntry{vpn,it->second.physical,it->second.permissions,true};
    return core::Result<Translation>::Ok(Translation{(it->second.physical<<PageBits)|(va&PageMask),it->second.permissions});
}
}
