#pragma once
#include <cstdint>
#include <array>
#include <unordered_map>
#include "../core/result.h"

namespace lg::memory {

enum Permission : uint32_t { Read=1u, Write=2u, Execute=4u, User=8u };
struct Translation { uint64_t physical{}; uint32_t permissions{}; };

class Mmu {
public:
    static constexpr uint64_t PageBits = 12;
    static constexpr uint64_t PageSize = 1ull << PageBits;
    static constexpr uint64_t PageMask = PageSize - 1;
    bool map(uint64_t virtual_base, uint64_t physical_base, uint64_t size, uint32_t permissions);
    bool unmap(uint64_t virtual_base, uint64_t size);
    void invalidate_all() noexcept;
    void clear() noexcept;
    void invalidate_page(uint64_t virtual_address) noexcept;
    uint64_t generation() const noexcept { return generation_; }
    core::Result<Translation> translate(uint64_t virtual_address, bool write, bool execute=false) const;
private:
    struct Entry { uint64_t physical{}; uint32_t permissions{}; };
    struct TlbEntry { uint64_t virtual_page{}; uint64_t physical_page{}; uint32_t permissions{}; bool valid{}; };
    std::unordered_map<uint64_t, Entry> page_table_;
    mutable std::array<TlbEntry, 1024> tlb_{};
    uint64_t generation_{};
    static size_t slot(uint64_t vpn) noexcept { return static_cast<size_t>((vpn * 11400714819323198485ull) >> 54); }
};

} // namespace lg::memory
