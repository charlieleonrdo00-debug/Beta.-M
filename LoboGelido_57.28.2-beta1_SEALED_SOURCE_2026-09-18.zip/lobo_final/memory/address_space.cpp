#include <cstring>
#include <limits>
#include <algorithm>
#include "address_space.h"
namespace lg::memory {

bool AddressSpace::enable_fastmem(uint64_t size, uint64_t guest_base) {
    if (size == 0 || (size & (P - 1)) != 0) return false;
    if (size > (1ull << 32)) return false; // bounded mobile-friendly arena
    auto storage = std::make_unique<uint8_t[]>(size);
    std::memset(storage.get(), 0, static_cast<size_t>(size));
    fastmem_ = std::move(storage);
    fastmem_size_ = size;
    fastmem_mapped_pages_.assign(static_cast<size_t>(size / P), 0);
    fastmem_guest_base_ = guest_base;
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
    return true;
}
bool AddressSpace::fastmem_contains(uint64_t a, uint64_t size) const noexcept {
    if (!fastmem_ || size == 0 || a < fastmem_guest_base_) return false;
    const uint64_t off = a - fastmem_guest_base_;
    return off < fastmem_size_ && size <= fastmem_size_ - off;
}

bool AddressSpace::map(uint64_t g,uint64_t size){
    if(!size || g > std::numeric_limits<uint64_t>::max() - (size - 1)) return false;
    const uint64_t first=g&~(P-1);
    const uint64_t pages=((size-1)/P)+1;
    if (pages - 1 > (std::numeric_limits<uint64_t>::max() - first) / P) return false;
    for(uint64_t i=0;i<pages;++i){
        const uint64_t p=first+i*P;
        if(pages_.contains(p) || mapped_pages_.contains(p)) return false;
    }
    for(uint64_t i=0;i<pages;++i){
        const uint64_t p=first+i*P;
        mapped_pages_.insert(p);
        if (fastmem_contains(p, P)) {
            fastmem_mapped_pages_[static_cast<size_t>((p - fastmem_guest_base_) / P)] = 1;
        } else {
            pages_.try_emplace(p, P);
        }
    }
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
    return true;
}
bool AddressSpace::unmap(uint64_t g,uint64_t size){
    if(!size||g>std::numeric_limits<uint64_t>::max()-(size-1))return false;
    const uint64_t first=g&~(P-1), pages=((size-1)/P)+1;
    if (pages - 1 > (std::numeric_limits<uint64_t>::max() - first) / P) return false;
    for(uint64_t i=0;i<pages;++i){
        const uint64_t p=first+i*P;
        pages_.erase(p);
        mapped_pages_.erase(p);
        if (fastmem_contains(p, P)) {
            fastmem_mapped_pages_[static_cast<size_t>((p - fastmem_guest_base_) / P)] = 0;
        }
    }
    write_epoch_.fetch_add(1,std::memory_order_relaxed);return true;
}
uint8_t* AddressSpace::host_ptr(uint64_t a){
    if (fastmem_ && a >= fastmem_guest_base_ && a - fastmem_guest_base_ < fastmem_size_) {
        auto page = a & ~(P - 1);
        const auto page_index = static_cast<size_t>((page - fastmem_guest_base_) / P);
        if (page_index < fastmem_mapped_pages_.size() && fastmem_mapped_pages_[page_index])
            return fastmem_.get() + (a - fastmem_guest_base_);
    }
    auto it=pages_.find(a&~(P-1));return it==pages_.end()?nullptr:it->second.data()+(a&(P-1));
}
const uint8_t* AddressSpace::host_ptr(uint64_t a)const{
    if (fastmem_ && a >= fastmem_guest_base_ && a - fastmem_guest_base_ < fastmem_size_) {
        auto page = a & ~(P - 1);
        const auto page_index = static_cast<size_t>((page - fastmem_guest_base_) / P);
        if (page_index < fastmem_mapped_pages_.size() && fastmem_mapped_pages_[page_index])
            return fastmem_.get() + (a - fastmem_guest_base_);
    }
    auto it=pages_.find(a&~(P-1));return it==pages_.end()?nullptr:it->second.data()+(a&(P-1));
}
std::optional<uint8_t> AddressSpace::read8(uint64_t a)const{auto p=host_ptr(a);return p?std::optional<uint8_t>(*p):std::nullopt;}
std::optional<uint32_t> AddressSpace::read32(uint64_t a) const {
    if (a > std::numeric_limits<uint64_t>::max() - 3) return std::nullopt;
    if (const auto* p = host_ptr(a); p && ((a & (P - 1)) <= P - 4)) {
        uint32_t value{};
        std::memcpy(&value, p, sizeof(value));
        return value;
    }
    uint32_t value{};
    for (unsigned i = 0; i < 4; ++i) {
        const auto byte = read8(a + i);
        if (!byte) return std::nullopt;
        value |= uint32_t(*byte) << (8 * i);
    }
    return value;
}

std::optional<uint64_t> AddressSpace::read64(uint64_t a) const {
    if (a > std::numeric_limits<uint64_t>::max() - 7) return std::nullopt;
    if (const auto* p = host_ptr(a); p && ((a & (P - 1)) <= P - 8)) {
        uint64_t value{};
        std::memcpy(&value, p, sizeof(value));
        return value;
    }
    uint64_t value{};
    for (unsigned i = 0; i < 8; ++i) {
        const auto byte = read8(a + i);
        if (!byte) return std::nullopt;
        value |= uint64_t(*byte) << (8 * i);
    }
    return value;
}
void AddressSpace::write8(uint64_t a,uint8_t v){if(auto p=host_ptr(a)){*p=v;write_epoch_.fetch_add(1,std::memory_order_relaxed);}}
void AddressSpace::write32(uint64_t a,uint32_t v){if (a > std::numeric_limits<uint64_t>::max() - 3) return; if(auto p=host_ptr(a);p && ((a&(P-1))<=P-4)){std::memcpy(p,&v,4);write_epoch_.fetch_add(1,std::memory_order_relaxed);return;}for(unsigned i=0;i<4;i++)write8(a+i,uint8_t(v>>(8*i)));}
void AddressSpace::write64(uint64_t a,uint64_t v){if (a > std::numeric_limits<uint64_t>::max() - 7) return; if(auto p=host_ptr(a);p && ((a&(P-1))<=P-8)){std::memcpy(p,&v,8);write_epoch_.fetch_add(1,std::memory_order_relaxed);return;}for(unsigned i=0;i<8;i++)write8(a+i,uint8_t(v>>(8*i)));}
}

void lg::memory::AddressSpace::clear() noexcept {
    pages_.clear();
    mapped_pages_.clear();
    std::fill(fastmem_mapped_pages_.begin(), fastmem_mapped_pages_.end(), uint8_t{0});
    write_epoch_.fetch_add(1, std::memory_order_relaxed);
}
