# Lobo Gélido 57.21 — Functional Settings Wiring

This revision preserves the emulator/runtime code and strengthens the Android settings layer without replacing the content pipeline.

## Preserved
- SAF keys URI, firmware URI and games-folder URI persistence.
- Game catalog scanning and game file recognition.
- GPU driver manager storage/selection.
- RuntimeBridge/JNI and native CPU/MMU/RAM/IPC/Vulkan sources are not rewritten.

## Newly wired at Android/UI level
- Settings navigation now includes Multiplayer, File Manager and Applets panels.
- File Manager reads the currently granted games-folder URI through ContentRecognition and displays real recognized files.
- Shader and pipeline cache buttons now perform real deletion/recreation of app cache subdirectories (`cache/shaders`, `cache/pipelines`) instead of only showing a toast.
- Touch control mappings are applied to the RuntimeBridge input contract for A/B/X/Y/L/R/+/− according to the selected game's persisted mapping.
- Selected game is persisted to the runtime settings namespace before a game session starts.
- Multiplayer/Applet settings persist through the existing advanced-settings store.

## Important verification boundary
The following settings are still persistence/UI configuration unless a corresponding native/runtime consumer exists: many advanced GPU/Vulkan switches, audio backend/latency, network services, CPU priority/multicore/JIT toggles, and GPU driver package selection. This revision does **not** fake native support for those options.

Firmware and keys are currently selected, persisted and recognized by the Android content layer; the existing native runtime prepare path does not yet consume those URIs as a secure firmware/key pipeline. This is intentionally not fabricated in this UI pass.

## Build status
A Gradle 8.13 executable was not present in the working container during this revision, so no APK build is claimed here.
