# Lobo Gélido 54.0 — Guest GPU Translation Foundation

## Objetivo

54.0 añade una capa intermedia limpia entre un futuro decoder del GPU invitado y el backend Vulkan existente.

## Qué incorpora

- `GuestGpuPacket`: formato intermedio neutral para paquetes GPU.
- `GuestGpuTranslator`: traducción determinista a `GpuCommandProcessor`.
- Ocho operaciones: viewport, scissor, pipeline, vertex buffer, descriptor set, draw, clear y barrier.
- Estadísticas de paquetes traducidos/rechazados.
- Prueba de integración traductor → `GpuCommandProcessor`.

## Alcance

No se copian definiciones propietarias de comandos de Nintendo ni se implementa aquí un decoder de paquetes Switch. El siguiente paso es construir un decoder/translator específico del protocolo GPU invitado a partir de comportamiento/documentación legítimamente disponible y conectarlo a esta capa.
