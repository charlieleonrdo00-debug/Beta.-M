# Lobo Gélido 57.22 — Auditoría frente a Eden

## Qué hace Eden que importa para Lobo Gélido

La versión Android de Eden/Yuzu no genera una carátula a partir del nombre del archivo. Su biblioteca obtiene metadatos nativos del contenedor: `GameMetadata.getTitle()`, `getProgramId()`, `getVersion()` y, especialmente, `getIcon()`. El icono termina en el adaptador de juegos, donde se decodifica el `ByteArray` recibido por JNI y se carga en el `ImageView`.

La cadena relevante es:

`GameMetadata.getIcon(path)` → JNI `getIcon()` → `GetRomMetadata(path).icon` → `loader->ReadIcon(...)` → Android `BitmapFactory.decodeByteArray(...)`.

Eso explica la diferencia principal con Lobo Gélido 57.21: Lobo actualmente busca una imagen lateral en la carpeta y después consulta Wikipedia por el título. No existe todavía un `ReadIcon` equivalente para los contenedores NSP/XCI/NCA. Además, el loader actual de Lobo solo ejecuta NRO/NSO plaintext y reconoce NCA, pero no implementa todavía el pipeline completo de PFS/HFS0 + NCA + claves que Eden usa para leer el control metadata.

## Ajustes visibles detectados en Eden

La APK analizada contiene referencias a estas familias de configuración: renderer/Vulkan, resolución, escalado, VSync, filtros/AA, ASTC, NVDEC, async shaders/presentation, frame generation, GPU fence behavior, CPU backend/accuracy, memoria, audio, overlay/input, game folders, GPU driver manager, perfiles, depuración/logging y configuración por juego.

También aparecen identificadores para `prod.keys`, firmware, perfiles, overlays, quick settings, FPS, haptics, D-pad/joystick y gestor de drivers. Eden mantiene una arquitectura donde Android refleja las claves de configuración del núcleo y las modificaciones pasan al estado de `Settings::values`, en lugar de limitarse a guardar texto de UI.

## Qué queda alineado en Lobo Gélido

Lobo Gélido 57.21 ya tiene pantallas para:

- gráficos, Vulkan y controlador GPU
- audio
- controles y mapeos por juego
- perfiles y usuario
- firmware, keys y carpeta de juegos
- gestor de archivos
- overlay/FPS
- diagnóstico/depuración
- red/multijugador
- applets
- rutas y configuración Android

La diferencia pendiente no es la existencia de las pantallas, sino conectar las opciones que todavía son preferencias de UI con consumidores reales del runtime. No se deben presentar como funciones nativas completas hasta que el backend las consuma.

## Cambio 57.22 para carátulas

Se mantiene la prioridad:

1. carátula proporcionada por el usuario junto al juego;
2. carátula de Eden Boxart usando un slug derivado estrictamente del título;
3. Wikipedia como último fallback.

No se acepta una imagen por coincidencia parcial arbitraria. Si ninguna fuente entrega una coincidencia válida, la biblioteca conserva `CARÁTULA NO DISPONIBLE`.

## Próxima integración nativa necesaria

Para igualar realmente a Eden, el siguiente paso técnico es añadir a Lobo Gélido un lector de metadata de juegos que exponga por JNI:

- título
- Title ID
- versión
- desarrollador/editor
- icono embebido

El punto de integración correcto es el loader, no la interfaz. Eso requiere ampliar el soporte de contenedores NSP/XCI/NCA y su acceso a `control`/NACP; no conviene simularlo desde Kotlin.
