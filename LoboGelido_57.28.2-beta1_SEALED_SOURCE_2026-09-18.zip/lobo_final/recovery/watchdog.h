#pragma once
#include <chrono>

namespace lg::recovery {

class Watchdog {
public:
    explicit Watchdog(std::chrono::milliseconds timeout)
        : timeout_(timeout) {}

    bool expired(std::chrono::steady_clock::time_point last_progress) const noexcept {
        return std::chrono::steady_clock::now() - last_progress > timeout_;
    }
private:
    std::chrono::milliseconds timeout_;
};

} // namespace lg::recovery
