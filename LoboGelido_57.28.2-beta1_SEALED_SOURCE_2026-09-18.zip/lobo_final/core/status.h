#pragma once
#include <cstdint>

namespace lg::core {

enum class StatusCode : uint8_t {
    Ok,
    InvalidState,
    InvalidArgument,
    NotSupported,
    OutOfMemory,
    IoError,
    DeviceError,
    InternalError
};

} // namespace lg::core
