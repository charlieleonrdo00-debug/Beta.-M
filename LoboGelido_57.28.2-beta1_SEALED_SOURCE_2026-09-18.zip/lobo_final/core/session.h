#pragma once
#include <atomic>
#include "result.h"

namespace lg::core {

enum class SessionState { Created, Ready, Running, Paused, Stopping, Stopped, Error };

class Session {
public:
    Result<void> prepare();
    Result<void> start();
    Result<void> pause();
    Result<void> resume();
    Result<void> stop();
    SessionState state() const noexcept { return state_.load(); }

private:
    std::atomic<SessionState> state_{SessionState::Created};
};

} // namespace lg::core
