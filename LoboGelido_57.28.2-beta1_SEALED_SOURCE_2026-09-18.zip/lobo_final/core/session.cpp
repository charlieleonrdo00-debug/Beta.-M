#include "session.h"

namespace lg::core {

Result<void> Session::prepare() {
    auto state = state_.load();
    if (state == SessionState::Ready) return Result<void>::Ok();
    if (state != SessionState::Created && state != SessionState::Stopped)
        return Result<void>::Error("session is not in Created/Stopped state");
    if (!state_.compare_exchange_strong(state, SessionState::Ready))
        return Result<void>::Error("session state changed during prepare");
    return Result<void>::Ok();
}

Result<void> Session::start() {
    auto expected = SessionState::Ready;
    if (!state_.compare_exchange_strong(expected, SessionState::Running))
        return Result<void>::Error("session is not Ready");
    return Result<void>::Ok();
}

Result<void> Session::pause() {
    auto expected = SessionState::Running;
    if (!state_.compare_exchange_strong(expected, SessionState::Paused))
        return Result<void>::Error("session is not Running");
    return Result<void>::Ok();
}

Result<void> Session::resume() {
    auto expected = SessionState::Paused;
    if (!state_.compare_exchange_strong(expected, SessionState::Running))
        return Result<void>::Error("session is not Paused");
    return Result<void>::Ok();
}

Result<void> Session::stop() {
    auto s = state_.load();
    if (s == SessionState::Stopped) return Result<void>::Ok();
    if (s == SessionState::Created) {
        state_.store(SessionState::Stopped);
        return Result<void>::Ok();
    }
    state_.store(SessionState::Stopping);
    state_.store(SessionState::Stopped);
    return Result<void>::Ok();
}

} // namespace lg::core
