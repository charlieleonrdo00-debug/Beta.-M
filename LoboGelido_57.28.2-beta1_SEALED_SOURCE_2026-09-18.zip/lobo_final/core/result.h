#pragma once
#include <string>
#include <utility>
#include <variant>

namespace lg::core {

template <typename T>
class Result {
public:
    static Result Ok(T value) { return Result(std::move(value)); }
    static Result Error(std::string message) { return Result(std::move(message)); }

    bool ok() const noexcept { return std::holds_alternative<T>(value_); }
    const T& value() const { return std::get<T>(value_); }
    const std::string& error() const { return std::get<std::string>(value_); }

private:
    explicit Result(T value) : value_(std::move(value)) {}
    explicit Result(std::string error) : value_(std::move(error)) {}
    std::variant<T, std::string> value_;
};

template <>
class Result<void> {
public:
    static Result Ok() { return Result(true, {}); }
    static Result Error(std::string message) { return Result(false, std::move(message)); }
    bool ok() const noexcept { return ok_; }
    const std::string& error() const { return error_; }
private:
    Result(bool ok, std::string error) : ok_(ok), error_(std::move(error)) {}
    bool ok_;
    std::string error_;
};

} // namespace lg::core
