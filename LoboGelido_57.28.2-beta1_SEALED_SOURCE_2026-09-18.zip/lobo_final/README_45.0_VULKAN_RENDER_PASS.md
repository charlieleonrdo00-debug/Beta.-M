# Lobo Gélido 45.0 — Vulkan Render Pass

## Objetivo
Conecta el presenter Android a un render pass Vulkan real y framebuffers por imagen de swapchain.

## Implementación
- `VkRenderPass` con un attachment de color.
- `VkFramebuffer` por imagen de swapchain.
- Transición PRESENT → COLOR_ATTACHMENT → PRESENT gestionada por el render pass.
- `vkCmdBeginRenderPass` / `vkCmdEndRenderPass` en cada frame.
- Clear real mediante `LOAD_OP_CLEAR`.
- Se conservan timestamps GPU y semáforos por imagen de 42.0.
- `VulkanGpuRuntime` y `VulkanPipeline` se inicializan con handles Vulkan reales.

## Alcance
Esto es un graphics pass real, pero todavía no dibuja geometría: no se incluye un shader propietario ni contenido de juegos. El siguiente paso es introducir un pipeline gráfico original mínimo y después conectar recursos/commands del emulador.

## Validación
Las pruebas host cubren las interfaces portables. La ruta Vulkan Android requiere el SDK/NDK y un dispositivo Vulkan para validación en hardware.
