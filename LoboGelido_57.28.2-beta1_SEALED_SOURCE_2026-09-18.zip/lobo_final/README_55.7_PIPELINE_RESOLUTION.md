# Lobo Gélido 55.9 — Pipeline Resolution

55.9 conecta el `pipeline_id` y `shader_program_id` del flujo Guest GPU con la creación perezosa de variantes Vulkan.

- `VulkanCommandExecutor` resuelve una variante cuando recibe un programa registrado.
- La variante se crea mediante `ShaderProgramManager` y `VulkanPipeline`.
- El `VulkanPresenter` expone el gestor de programas para registrar SPIR-V proporcionado por el integrador.
- Si el programa no está registrado, el executor rechaza el comando en lugar de inventar shaders.
- No se incluyen firmware, claves, ROMs ni shaders propietarios.

## Flujo

`GuestGpuPacket → GpuCommand → pipeline_id + shader_program_id → ShaderProgramManager → VulkanPipeline variant → vkCmdBindPipeline → Draw`

La creación real de un pipeline requiere SPIR-V válido para Vulkan y un render pass compatible.

La variante guarda el `program_id`; si un mismo `pipeline_id` cambia de programa, se reconstruye en lugar de reutilizar un pipeline con shaders equivocados.
