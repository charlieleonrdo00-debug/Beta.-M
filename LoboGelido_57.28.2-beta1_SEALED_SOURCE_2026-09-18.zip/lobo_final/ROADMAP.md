# Roadmap de implementación

## P0 — Build reproducible
- Android 15+
- NDK 27+
- CMake
- arm64-v8a
- CI local y checks de compilación

## P1 — Núcleo ejecutable
- Session lifecycle
- CPU interpreter
- Memory manager
- Scheduler
- Diagnostics

## P2 — CPU de alto rendimiento
- AArch64 decoder completo
- IR
- block cache
- JIT backend
- NCE adapter
- NEON-aware helpers

## P3 — Sistema Switch
- Loader de contenidos soportados
- Kernel/HLE
- IPC
- filesystem virtual
- save data
- applets esenciales

## P4 — GPU
- command processor
- shader translation/cache
- pipeline cache
- texture cache
- Vulkan synchronization
- presentation pacing

## P5 — Multimedia/input
- audio backend
- controller abstraction
- touch/motion
- rumble
- latency metrics

## P6 — Android excellence
- thermal-aware policy
- device capability detection
- driver profiles
- background shader preparation
- crash recovery/safe mode

## P7 — Validation
- golden tests
- CPU instruction tests
- memory tests
- GPU shader tests
- regression suite
- performance benchmark suite

## P8 — Optimization
Optimizar únicamente después de medir. Evitar "features" cosméticas que no mejoren
compatibilidad, estabilidad o rendimiento.


## 32.0 CPU Context + Dynarmic Boundary
Contexto ARM64 por hilo saneado, contabilidad correcta de ticks/instrucciones e invalidación segura del JIT.


## 35.0 — Architecture Superiority / Ataque 1 completado

Primera fase ejecutada: **CPU runtime real ↔ MMU**. Los callbacks del proveedor Dynarmic pasan ahora por la MMU, el fetch exige Execute, los accesos cruzados por página traducen cada byte y las traducciones JIT se invalidan al cambiar el epoch de memoria o la generación de mappings.

Siguiente fase: **Memory Architecture / Fastmem**, construyendo un guest arena contiguo y seguro antes de activar fastmem nativo.
