# Lobo Gélido 26.0 — JIT Bridge

26.0 introduces the Tier-2 JIT integration boundary between the guest runtime and an external native JIT provider.

## What is real in this release
- `JitBackend` is a first-class CPU backend.
- `JitProvider` defines initialization, execution, and invalidation contracts.
- Runtime diagnostics expose whether a JIT provider is actually configured.
- Android/CMake know about the JIT backend.
- The default open build intentionally installs an `UnavailableJIT` provider, so the active backend remains Tier-1 Block/Interpreter.

## What is not claimed
- Dynarmic source is not bundled in this package.
- Native JIT execution is not enabled by the default build.
- No Nintendo firmware, keys, ROMs, or proprietary assets are included.

## Next integration target
Connect an externally supplied Dynarmic adapter to `JitProvider`, including guest CPU state mapping, memory callbacks, invalidation, and exception/exit handling. Only after those tests pass should the runtime select `JIT` as its active backend.
