# Lobo Gélido 57.9.7 — MMU + Memory/JIT hardening

This revision continues the CPU/JIT hardening line without changing the UI.

## Changes
- MMU mapping/unmapping page-count arithmetic no longer relies on `size + PageMask`, avoiding integer overflow at extreme sizes.
- MMU rejects zero/unknown permission bits and validates page-number arithmetic before committing mappings.
- AddressSpace mapping/unmapping now uses overflow-safe page counts and indexed page iteration instead of potentially wrapping `p += 4096` loops.
- Interpreter translation no longer falls back to a host pointer when an active MMU rejects a guest virtual address. This preserves guest unmapped and permission faults.
- Existing Dynarmic cache invalidation remains tied to write epoch and MMU generation.

## Scope
This is correctness hardening, not a claim of full Switch MMU/loader compatibility. Full multi-level page tables, ASLR/relocations, compressed NSO/NRO handling, NCA/NSP/XCI content services, and broader HLE remain future work.
