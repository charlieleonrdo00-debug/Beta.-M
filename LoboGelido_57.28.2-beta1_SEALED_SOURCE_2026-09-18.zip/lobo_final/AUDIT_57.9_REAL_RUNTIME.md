# Lobo Gélido 57.9 — Auditoría y corrección de runtime/UI

## Hallazgos confirmados
1. `showGameRuntime()` era un mock visual: no conectaba ninguna superficie Android con Vulkan.
2. `RuntimeBridge` ya tenía JNI para Vulkan, pero ninguna vista llamaba a `initializeVulkan()`/`drawVulkanFrame()`.
3. No existía una capa táctil real para D-pad/A/B/X/Y.
4. El catálogo persistía URIs sin comprobar que el documento siguiera existiendo; eso podía dejar tarjetas fantasma.
5. La pantalla de detalle y rendimiento contenían valores sintéticos (59.8 FPS, 16.7 ms, 16.3 GB, 8.2 h, etc.) que no provenían del runtime.
6. `RuntimeCoordinator::run_frame()` restablecía el PC del hilo invitado al `guest_pc` en cada frame, impidiendo progreso normal de ejecución.
7. El loader nativo actual sólo puede ejecutar NRO/NSO plaintext. NSP/XCI/NCA no se pueden presentar como ejecutables reales todavía porque falta el pipeline de contenido seguro/FS/crypto.

## Correcciones aplicadas
- Nueva `GameSurfaceView`: `SurfaceHolder.Callback` + hilo de render dedicado + ciclo Vulkan real.
- Nuevo `SwitchTouchOverlay`: D-pad, A/B/X/Y, L/R, +/- con multitouch y puente JNI.
- `RuntimeBridge` ampliado con FD de SAF, frame de runtime, métricas e input.
- JNI ahora conserva un file descriptor real del juego mediante `/proc/self/fd/<fd>` y lo cierra al detener la sesión.
- `RuntimeCoordinator.prepare(content_path)` valida y carga NRO/NSO plaintext antes de crear el hilo invitado.
- La sesión ya no se abre si el contenido no existe, no se puede leer o el runtime lo rechaza.
- La biblioteca filtra documentos inexistentes/no legibles/no compatibles, evitando juegos fantasma.
- Se eliminaron valores de rendimiento y metadata inventados de las pantallas de juego/rendimiento.
- El PC del guest queda persistente en el contexto del hilo; no se reinicia en cada frame.
- Los fallos de ejecución del guest pasan a `ERROR` en lugar de recuperarse falsamente y seguir mostrando un frame vacío.

## Límite técnico actual
Esto deja la arquitectura conectada de extremo a extremo para **contenido NRO/NSO plaintext** y una superficie Vulkan real. No significa todavía compatibilidad completa con juegos comerciales NSP/XCI: para eso faltan el sistema de archivos del juego, claves/crypto, NCA/NPDM/KIP y servicios de Horizon necesarios para ejecutar títulos comerciales. La aplicación ya no disimula esa ausencia con gameplay o métricas falsas.
