# Lobo Gélido 33.0 — Strength Upgrade

## Objetivo
Elevar las áreas donde Lobo Gélido ya era fuerte: experiencia de usuario, personalización, accesibilidad, perfiles por juego, preparación de inicio y adaptación de rendimiento.

## Cambios aplicados
- **AutoTuner reforzado:** política determinista para presión de CPU/GPU, temperatura, resolución, shaders asíncronos, GPU async, presentación async y número de workers de pipelines.
- **Prueba nueva de AutoTuner:** cubre estado estable, cuello de botella GPU y presión térmica.
- **Perfiles por juego mejorados:** clasificación `ENTRY/BALANCED/HIGH_END`, reporte de optimización y nivel de confianza; se evita ejecutar dos veces la optimización durante el arranque.
- **Inicio optimizado:** la preparación de perfiles se ejecuta una sola vez por juego, con etapas más cortas y sin fingir comprobaciones de capacidades que el runtime no haya expuesto.
- **Accesibilidad centralizada:** gestos, vibración y sonidos de interfaz ahora tienen propiedades persistentes en `AppSettingsStore` en vez de claves dispersas.
- **Accesibilidad UI:** controles de acción del renderer tienen foco, click y descripciones accesibles.
- **Reducción de movimiento:** se conserva como ajuste global para que las futuras animaciones respeten la preferencia.

## Validación
- Compilación del núcleo C++: correcta.
- CTest: **21/21 pruebas pasan**.
- No se afirma que exista APK compilado en este entorno: la máquina no contiene el Android SDK/Gradle necesario para producirlo localmente.
- Dynarmic real y Vulkan Android siguen siendo dependencias/backend de integración externa; esta versión no los inventa ni los incluye como código propietario.

## Licencias / contenido
No se incluyen firmware, claves, ROMs ni contenido propietario. La integración con código externo sigue separada y debe respetar sus licencias.
