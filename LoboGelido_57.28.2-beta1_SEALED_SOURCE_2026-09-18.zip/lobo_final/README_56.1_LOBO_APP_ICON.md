# Lobo Gélido 56.1 — Application Identity & Launcher Icon

This revision applies the supplied Lobo Gélido wolf artwork as the Android launcher identity.

## Architecture

```text
Android Launcher
      │
      ▼
@mipmap/ic_launcher
      │
      ├── Android 26+: adaptive icon
      │      ├── dark ice background
      │      └── wolf foreground artwork
      │
      └── legacy density PNGs
      │
      ▼
Lobo Gélido MainActivity
      │
      ├── Lobo Gélido UI / first-run setup
      └── RuntimeBridge
             │
             ├── CPU / MMU / Scheduler
             ├── Guest GPU
             └── Vulkan Resource Binding Runtime
```

## Branding implementation

- `android:icon="@mipmap/ic_launcher"`
- `android:roundIcon="@mipmap/ic_launcher_round"`
- Adaptive icon resources for Android 8.0+.
- Density-specific launcher fallbacks for older Android resource selection.
- The supplied wolf artwork is used as the visual source; no Nintendo artwork is bundled.

## Version

Android application version name: `56.0`.

This package is source code; an Android Gradle wrapper/build artifact is not bundled in this repository snapshot.
