# Compilar Lobo Gélido desde GitHub Codespaces (sin PC)

## Causa del error observado

El proyecto usa **Android Gradle Plugin 8.13.x**. Esa versión requiere **Gradle 8.13**. Si Codespaces ejecuta el `gradle` global 9.x, el plugin puede fallar al intentar crear `AndroidProblemReporterProvider` por cambios internos de Gradle (`InternalProblems`/`InternalProblemReporter`).

**No hay que actualizar a Gradle 9.5/9.6 para este proyecto.** La combinación estable para esta rama es:

- AGP 8.13.x
- Gradle 8.13.x
- JDK 17
- compileSdk 36
- Build Tools 36.0.0
- NDK 27.3.13750724
- CMake 3.22.1

## En Codespaces

Desde la carpeta `android` ejecuta:

```bash
./build-apk.sh
```

El script descarga Gradle 8.13 en la caché del usuario y evita usar el Gradle global 9.x.

El APK Debug queda en:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## CI

El workflow `.github/workflows/build-apk.yml` ya fija JDK 17 y Gradle 8.13 y publica el APK como artefacto `Lobo-Gelido-56.1-APK`.
