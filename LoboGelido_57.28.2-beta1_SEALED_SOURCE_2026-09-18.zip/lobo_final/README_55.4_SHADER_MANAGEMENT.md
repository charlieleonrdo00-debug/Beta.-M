# Lobo Gélido 55.4 — Shader Management

This release adds a clean-room, backend-neutral shader/program registry on top of the 55.3 GPU resource binding path.

## Added
- SPIR-V validation reused at shader registration time.
- Deterministic FNV-1a 64-bit cache keys for shader modules.
- Deduplication of identical shader modules by stage.
- Explicit vertex/fragment shader program records.
- Immutable program IDs that can be used by future Vulkan pipeline variants.
- Diagnostics for shader/program counts.
- Host test coverage for registration, deduplication, program creation, and stage validation.

## Architecture
Guest GPU packets remain independent from Vulkan. The manager only owns validated SPIR-V data and program relationships; Vulkan object creation remains in the Vulkan pipeline/backend.

No Nintendo firmware, keys, ROMs, or proprietary shader binaries are included.

## Validation
35/35 CTest tests pass.
