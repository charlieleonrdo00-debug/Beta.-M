# Lobo Gélido 10.1 — Frontend y diagnóstico

## Frontend 100%
- Navegación inferior de 5 secciones: Juegos, Rendimiento, Diagnóstico, Ajustes e Info.
- Biblioteca persistente mediante Storage Access Framework.
- Añadir, preparar sesión y quitar contenido.
- Estado de sesión actual.
- Pantalla de rendimiento con actualización periódica del estado nativo.
- Ajustes persistentes con interruptores.
- Restauración de preferencias.
- Información de arquitectura, privacidad y licencias.
- Diseño oscuro consistente y adaptable a Android.

## Diagnóstico 100% de la capa de frontend/runtime
- Versión del runtime.
- Uptime de la sesión.
- Arquitectura ARM64.
- Estado del núcleo CPU.
- Estado de MMU/TLB.
- Primitivas atómicas.
- Estado de la capa Vulkan.
- Frame pacing.
- Estado de contenido.
- Telemetría local.
- Actualización manual.
- Copia al portapapeles.

### Nota
Este 100% significa cobertura completa de las funciones previstas para esta capa de interfaz y diagnóstico. No significa que el backend de emulación Switch ya sea 100% completo.
