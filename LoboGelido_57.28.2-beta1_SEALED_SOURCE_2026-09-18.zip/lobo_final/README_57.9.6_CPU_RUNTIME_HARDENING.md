# Lobo Gélido 57.9.6 — CPU/runtime hardening

This revision hardens the guest-thread lifecycle. When a CPU context reaches its terminal `halted` state, `RuntimeCoordinator` now terminates the corresponding guest thread instead of allowing the scheduler to return it to the ready queue. CPU execution errors also terminate the affected thread before propagating the runtime error.

The architectural CPU context is retained for diagnostics; only scheduling is stopped. This prevents repeated dispatch of a halted context and makes terminal execution states explicit.

Validation performed on the host: `test_thread_manager` passes and `runtime/runtime_coordinator.cpp` compiles with C++20 warnings enabled.
