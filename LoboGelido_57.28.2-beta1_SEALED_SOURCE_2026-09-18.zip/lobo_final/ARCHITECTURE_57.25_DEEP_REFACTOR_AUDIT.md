# Lobo Gélido 57.25 — Deep Clean Architecture Refactor & Audit

## Scope
This revision is based on `LoboGelido_57.25_Clean_Application_Data_Domain.zip` and preserves the native C++ runtime/Vulkan/CPU/MMU/IPC implementation. The UI visual layer was not redesigned.

## Structural changes

### Presentation / MainActivity
- `MainActivity` no longer accesses `ContentResolver`, `SharedPreferences`, `DocumentFile`, `openFileDescriptor`, `takePersistableUriPermission`, `ZipInputStream`, or `GameCatalogStore`.
- Game launch is delegated to `RuntimeLaunchController`.
- SAF picker construction is reduced to an Android UI adapter (`launchSafPicker`); SAF permission/storage operations live in Data/Application controllers.
- Keys, firmware and game-folder selection are asynchronous and return to the main thread only for UI updates.
- Long-running game-folder scans use daemon worker executors.
- Activity callbacks use `WeakReference` so workers do not retain a destroyed Activity.

### Domain
- Game metadata now owns library state required by the application layer: favorite, last played, compatibility, size and modification time.
- Added explicit SAF permission contract.
- Profile model moved to Domain.
- Profile optimization consumes `GameOptimizationInput`, so the use case no longer depends on UI models.
- Firmware validation policy supports expected hashes and detached signatures.

### Data
- `AndroidSettingsRepository` is the only persistence implementation for application settings.
- `AndroidSafRepository` owns persisted SAF permissions and stream/FD access.
- `AndroidKeyRepository` parses keys and stores the original key file encrypted with an Android Keystore AES-GCM key. Plaintext key material is not logged or stored in SharedPreferences.
- `AndroidFirmwareRepository` validates recognized firmware sources and copies firmware content into private application storage with path sanitization. ZIP extraction prevents path traversal.
- `AndroidGameRepository` is the library source of truth; the legacy `GameCatalogStore` was removed from the active architecture.
- `AndroidProfileRepository` persists Domain profiles.

### Application
- Empty/stub UseCases were replaced with executable UseCases.
- `SetupController` orchestrates keys, firmware, SAF permissions and game-folder operations.
- `RuntimeLaunchController` owns the SAF FD hand-off to the native runtime.
- `RuntimeControlFacade` exposes native runtime telemetry/control without making `MainActivity` an owner of native state.
- Runtime telemetry is sampled on a daemon worker every 250 ms and served from an atomic snapshot.

## Performance / threading audit

1. No native C++ source was modified by this refactor.
2. The native C++ build was configured with Dynarmic disabled for the standalone verification build.
3. Native CTest result: **43/43 passed, 0 failed**.
4. Game scanning, key import/validation, firmware installation and runtime launch are off the Android main thread.
5. MainActivity does not perform SAF file opening or persistent-storage writes directly.
6. The runtime native FD contract remains: Java detaches the descriptor, native duplicates it, then the detached Java descriptor is closed immediately.
7. Runtime telemetry is lock-contained and sampled outside the UI thread.
8. No `catch (Throwable)` exists in the refactored Application/Data layers.
9. No `TODO`, `NotImplementedException`, `UnsupportedOperationException`, or empty UseCase contract was found in the new Domain/Application layers.

## Important verification boundary
The Android Gradle build could not be executed in this environment because the required Gradle 8.13 distribution was unavailable and the environment could not download it. Domain and Application UseCase Kotlin sources were separately syntax-compiled with `kotlinc`; the native C++ suite was fully executed.

Therefore this artifact is **structurally audited and native-verified**, but an Android `assembleDebug` run remains the final build gate.

## Eden reference comparison
The supplied Library did not expose an Eden source archive during this audit. The technical matrix therefore uses the current public Eden upstream repository and recent upstream engineering changes as the external reference, not a claim about an unseen user-provided archive.

Current Eden evidence includes:
- Dynarmic as a modern C++20 ARM dynamic recompiler with Android/AArch64 support.
- Recent Android Vulkan worker-count controls and Dynarmic dispatcher/decoder/IR improvements.
- Recent Android frame-pacing/surface work intended to reduce CPU/GPU desynchronization and latency.
- Recent page-table allocation work reducing per-entry memory overhead.
- Recent Vulkan maintenance reducing unnecessary image copies and memory-bandwidth pressure.

Lobo Gélido currently has a hardened runtime lifecycle, Fastmem/MMU/TLB path, Vulkan presenter/resource binding tests, scheduler/runtime synchronization and clean Android orchestration, but it does **not** yet have feature parity with Eden's mature production Vulkan backend or Dynarmic integration.

## Technical comparison matrix — Lobo Gélido vs current Eden reference

| Area | Lobo Gélido 57.25 | Eden current reference | Gap / implication |
|---|---|---|---|
| Android composition | MainActivity delegates persistence, SAF, content launch, setup and profiles to Application/Data. | Eden has a mature Android frontend integrated with a large native core. | Lobo's boundary is cleaner locally; Eden has broader production integration. |
| SAF / persistence | Dedicated SAF repository; settings repository; async key/firmware/game operations. | Eden has mature Android settings/storage integration. | Lobo's new boundary is strong, but needs Android build validation and broader migration of remaining UI facades. |
| Keys | Parser + validation + Android Keystore AES-GCM encrypted payload. | Eden has production key/firmware integration tied to its native core. | Lobo protects data but still needs the native crypto/key-consumption bridge. |
| Firmware | SAF source inspection, private-app installation, path-safe copying and ZIP extraction. | Eden has mature firmware/system integration. | Lobo currently performs source/installation management; Switch-specific firmware semantics are still incomplete. |
| Game scanning | Background scan, folder repository, stale-entry cleanup during scans, local cover detection. | Eden has mature title/application metadata extraction and game compatibility integration. | Lobo needs deeper NSP/XCI/NCA metadata extraction and richer artwork providers. |
| Vulkan / SPIR-V | Existing Vulkan presenter, pipeline/resource binding and SPIR-V tests remain untouched. | Eden's recent Vulkan work includes post-processing shaders on Android and extensive Vulkan maintenance; its current release also exposes Android Vulkan-worker controls. | Lobo has a good tested foundation but is not yet equivalent to Eden's production shader/render backend. citeturn0search2turn0search1turn0search10 |
| Frame pacing | Lobo separates runtime execution FPS from presentation and serializes Vulkan lifecycle around the render thread. | Eden has explicit Android frame-pacing/surface work aimed at CPU/GPU synchronization and latency. | Eden has more mature display cadence heuristics; Lobo's lifecycle safety is stronger than the previous Lobo baseline but the pacing algorithm itself remains simpler. citeturn0search5 |
| JIT / Dynarmic | Lobo has JIT backend, Fastmem/MMU/TLB and CPU tests; the standalone verification intentionally disables Dynarmic. | Eden uses Dynarmic as a central ARM dynamic recompiler; current Dynarmic advertises C++20, AArch64 and Android support. | The largest technical gap is still real Dynarmic integration and production JIT tuning. citeturn0search0turn0search1 |
| Fastmem / memory | Lobo has hardened Fastmem/MMU path and runtime tests. | Eden recently reduced page-table entry size and memory reservation pressure. | Lobo's fast path is functional/tested, but its memory model is much less mature and should be compared against Eden's newer page-table work. citeturn0search6 |
| Runtime orchestration | RuntimeCoordinator + NativeRuntimeHost + lifecycle controller + serialized runtime/graphics operations. | Eden's native core is substantially broader and more mature. | Lobo now has a clear ownership boundary; its runtime functionality is still far behind Eden in subsystem breadth. |
| GPU memory bandwidth | Existing Vulkan resource/pipeline tests remain green. | Eden's Vulkan maintenance specifically reduced unnecessary image copies and attachment loads to lower memory-bandwidth pressure. | Lobo needs comparable tiler/mobile bandwidth optimization work. citeturn0search10 |

### Bottom line

Lobo Gélido 57.25 now has a materially cleaner Android architecture than the previous Lobo baseline: UI code no longer owns SAF/persistence/key/firmware/library/profile mechanics, and the native runtime was not modified by this refactor. However, it would be technically incorrect to call the project “zero debt” or “Eden-equivalent” yet: the Android Gradle build still needs to be executed, Dynarmic is not enabled in the verified standalone build, the Vulkan backend lacks Eden's production depth, and game metadata/firmware semantics remain incomplete.
