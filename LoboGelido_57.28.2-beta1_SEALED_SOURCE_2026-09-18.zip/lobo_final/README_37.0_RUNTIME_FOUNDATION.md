# Lobo Gélido 37.0 — Runtime Foundation

## Objetivo
Esta versión avanza el núcleo real, no la interfaz: incorpora una arena contigua de memoria invitada para preparar fastmem/JIT y endurece la selección automática MultiCore.

## Cambios
- AddressSpace puede reservar una arena contigua de hasta 4 GiB (limitación deliberada para mantener el diseño móvil).
- El runtime reserva una arena de 16 MiB en `0x10000000` para su dominio invitado actual.
- Los accesos `host_ptr()` usan la arena contigua cuando la página está mapeada; fuera de ella se mantiene el camino por páginas.
- Las operaciones que cruzan páginas conservan el fallback comprobado por página.
- Se mantiene `write_epoch` para invalidación conservadora.
- MultiCore ya no marca como "launchable" un juego solo porque su plataforma sea reconocida. Esto evita anunciar compatibilidad de gameplay que todavía no existe.
- Prueba específica de fastmem y MMU.

## Validación
CTest: **24/24** pruebas pasadas.

## Estado honesto
La reserva fastmem es una base de runtime; todavía no equivale a fastmem de Dynarmic real porque el proveedor Dynarmic no está incluido en este paquete. Tampoco se implementa todavía un núcleo N64 jugable. La detección MultiCore permanece preparada, pero los backends adicionales deben implementarse antes de declarar gameplay.

## Próximo objetivo
- conectar la arena a callbacks reales de Dynarmic cuando la dependencia esté disponible;
- ampliar el runtime de memoria y permisos;
- comenzar el primer backend de plataforma real (N64) con CPU/RSP/RDP y loader apropiado;
- mantener la biblioteca automática sin selección manual de plataforma.
