# Benchmarks

Comparar Lobo Gélido contra cualquier referencia usando el mismo dispositivo, juego,
resolución, backend y configuración.

Registrar:
- frametime P50/P95/P99
- stutter count
- shader compilation stalls
- CPU time/frame
- GPU time/frame
- RAM
- temperatura
- battery drain
- boot/load time
- crash-free session duration

No declarar "más rápido" sin medición reproducible.
