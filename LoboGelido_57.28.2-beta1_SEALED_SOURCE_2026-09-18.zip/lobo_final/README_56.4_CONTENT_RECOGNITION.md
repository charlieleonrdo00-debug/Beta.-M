# Lobo Gélido 56.4 — Content Recognition + GPU Drivers

## Objetivo

1. Que el emulador **reconozca de verdad** las claves, el firmware y los juegos
   que el usuario selecciona (no solo guardar la URI).
2. Añadir un **gestor de controladores GPU** para que el usuario pueda
   instalar/seleccionar un paquete de driver y el emulador lo reconozca.

## Problema anterior

- `keysUri` / `firmwareUri` / `gamesFolderUri` se guardaban, pero:
  - No se validaba el contenido de las claves.
  - El firmware no se inspeccionaba.
  - La carpeta de juegos **nunca se escaneaba**: no se añadían `.nsp` / `.xci`
    a la biblioteca.
- No existía ninguna opción de controladores GPU.

## Qué hace 56.4

### Reconocimiento de contenido (`ContentRecognition.kt`)

| Tipo | Qué busca | Resultado en UI |
|------|-----------|-----------------|
| **Claves** | Nombre tipo `prod.keys` / `title.keys` + lectura del archivo | ✓ Configurado + nombre |
| **Firmware** | Carpeta (SAF tree) o archivo; cuenta elementos | ✓ Configurado + N elementos |
| **Juegos** | Escaneo recursivo de `.nsp`, `.xci`, `.nca`, `.nro`, `.nso`, `.nsz`, `.xcz` | ✓ N juego(s) + se añaden al catálogo |
| **Driver GPU** | Carpeta/paquete con pistas `adreno` / `mali` / `vulkan` / `.so` | ✓ Driver reconocido |

### Configuración inicial

Cada tarjeta muestra el **estado real** (reconocido o no) y el detalle
(nombre de archivo, cantidad de juegos, etc.).

Nueva tarjeta: **Controladores GPU** (opcional).

### Biblioteca

- Al elegir carpeta de juegos → escaneo automático y alta en `GameCatalogStore`.
- Botón **Rescanear carpeta de juegos**.
- Botón **Cambiar carpeta de juegos**.

### Gráficos / Vulkan

Nueva sección **Controladores GPU**:
- Seleccionar paquete/carpeta
- Ver estado de reconocimiento
- Quitar driver

### Sistema y almacenamiento

Estado resumido de Claves / Firmware / Juegos / Driver GPU + accesos directos.

## Legal

- No se incluyen ni se descargan firmware, claves, ROMs ni drivers propietarios.
- El usuario aporta su propio contenido desde el almacenamiento del dispositivo.

## Versión

- versionName: **56.4**
- versionCode: **5640**
