# Build

Requisitos:
- Android Studio reciente
- Android SDK 35+
- Android NDK 27+
- CMake 3.22+

La carpeta `core/` puede compilarse de forma independiente con CMake para ejecutar
las pruebas unitarias. La aplicación Android se integra encima de estas interfaces.

No se debe incorporar contenido propietario de terceros.
