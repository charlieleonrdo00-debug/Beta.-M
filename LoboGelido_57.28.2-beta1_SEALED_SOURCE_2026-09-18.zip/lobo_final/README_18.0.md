# Lobo Gélido 18.0

## Console Shell — Consumer Experience

18.0 is the consumer-facing shell milestone. The goal is not to imitate a generic emulator UI, but to make Lobo Gélido behave like a coherent virtual console while keeping its own visual identity.

### End-to-end flow

**Boot → Profile → Home → Library → Game Detail → Gameplay Preview → Launch → Quick Menu → Suspend → Resume**

### Architecture

- `ConsoleShellState.kt` — explicit route/state machine.
- `ConsoleUserStore.kt` — persistent console profiles.
- `GameSessionStore.kt` — session lifecycle and resume state.
- `GameCatalogStore.kt` — library/catalog persistence.
- `GameProfileStore.kt` — per-game configuration.
- `GamePreviewStore.kt` / `PreviewPlayer.kt` — user-owned gameplay previews.
- `ControllerSkinStore.kt` — Nintendo Switch-oriented touch skin catalog/import.
- `AppSettingsStore.kt` — centralized consumer settings.
- `MainActivity.kt` — Android composition root and renderer.

### Consumer design

- Fast boot presentation.
- Profile-aware home screen.
- Resume card for suspended sessions.
- Library-first navigation.
- Game detail as the launch decision surface.
- Preview before launch.
- Dedicated game-session surface.
- Quick menu without exposing implementation details.
- Suspend/resume state retained across UI navigation.
- Technical diagnostics remain outside the normal consumer flow.

### Runtime honesty

The shell is designed so a real emulator runtime can replace the placeholder game-session surface without redesigning the consumer navigation. The current build does **not** claim that the Switch runtime is fully implemented.

No firmware, keys, ROMs, or proprietary game assets are bundled.
