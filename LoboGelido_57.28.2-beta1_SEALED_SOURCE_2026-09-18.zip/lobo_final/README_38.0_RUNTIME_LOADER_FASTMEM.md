# Lobo Gélido 38.0 — Runtime / Fastmem / Loader

Esta versión continúa 37.0 con trabajo ejecutable, no solo documentación.

## Cambios
- Fastmem ahora usa una arena contigua real como backing de las páginas mapeadas; no existe una segunda copia silenciosa para páginas dentro del arena.
- `AddressSpace` conserva un conjunto explícito de páginas mapeadas para validar punteros rápidos.
- Añadida API `fastmem_contains()` y base de arena observable por backends JIT.
- Loader NRO/NSO: inspección de segmentos y carga de segmentos plaintext a `AddressSpace`.
- NCA sigue siendo solo inspección de contenedor; no se implementa descifrado ni DRM.
- Android CMake incluye el registro MultiCore actualizado.
- Android versionName/versionCode actualizados a 38.0.
- JNI deja de fabricar telemetría CPU/GPU sintética y muestra estado del runtime real.

## Validación
- CTest: 24/24.
- El test `fastmem` verifica que el puntero rápido y las lecturas escriben sobre la misma arena.
- El test `loader` crea un NRO sintético y comprueba inspección + carga.

## Próximo bloque
- Vulkan Android real: instancia, physical device, queue family, surface/swapchain y capacidades reales.
- Kernel/HLE/IPC ampliado.
- VFS/romfs y contenido instalado.
- HID/audio/video.
- Núcleos adicionales reales.
