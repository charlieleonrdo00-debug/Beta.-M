# Lobo Gélido 34.0 — Optimization Intelligence

Esta iteración profundiza las áreas que ya diferencian a Lobo Gélido: diagnóstico, optimización por dispositivo y políticas conservadoras de rendimiento.

## Mejoras
- AutoTuner expone resolución dinámica, FPS objetivo y confianza de la decisión.
- La política sigue siendo determinista y no inventa capacidades de GPU.
- La política térmica reduce agresivamente el objetivo a 30 FPS en presión alta.
- Los perfiles por juego reportan clase del dispositivo, ABI y recomendación legible.
- Se mantiene la separación entre recomendación y aplicación real del backend.

## Validación
- Tests nativos ampliados para AutoTuner.
- Android APK no compilado en este entorno por falta de SDK/Gradle Android.

## Alcance
Esto mejora las capas de optimización/diagnóstico; no sustituye la integración real de Dynarmic, Vulkan Android, HLE/IPC, loader, audio o NVDEC.
