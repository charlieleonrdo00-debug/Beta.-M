# Lobo Gélido 55.4 — Dynamic GPU Resource Binding

55.4 advances the clean-room Vulkan backend from dynamic pipelines to dynamic
resource binding. Guest-neutral GPU commands can now select a vertex-buffer
resource managed by the Vulkan resource backend, bind that real VkBuffer with a
command-local offset, and issue a draw against the currently selected pipeline.

Flow:

Guest GPU translator → command processor → pipeline ID + resource ID → Vulkan
resource backend → VkBuffer binding → descriptor set/pipeline layout → draw.

The existing internally-owned demonstration vertex buffer remains available as
a legacy API, but the command executor no longer uses it for guest-style
`BindVertexBuffer`/`Draw` execution.

No Nintendo firmware, keys, ROMs, or proprietary assets are included.
