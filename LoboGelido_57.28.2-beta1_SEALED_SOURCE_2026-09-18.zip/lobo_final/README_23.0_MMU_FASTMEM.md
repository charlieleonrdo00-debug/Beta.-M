# Lobo Gélido 23.0 — MMU + Fastmem

23.0 hardens the guest memory path.

- Expanded the software TLB from 64 to 256 entries.
- Interpreter 32/64-bit reads use translated host pointers when the access stays within a page.
- Interpreter writes retain AddressSpace write-epoch accounting, preserving exclusive-monitor invalidation.
- Permission checks remain in the MMU fast path.
- Cross-page accesses fall back to byte-wise checked accesses.

This is a real memory-path optimization, but it is **not yet a Switch-accurate MMU implementation**. ARMv8 page-table walking, ASID/TTBR semantics, stage-2 translation, and production fastmem fault handling remain future work.
