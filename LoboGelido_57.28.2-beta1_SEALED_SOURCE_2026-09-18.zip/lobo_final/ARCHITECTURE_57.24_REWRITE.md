# Lobo Gélido 57.24 — Architecture Rewrite / Hardening

## Objetivo

57.24 reorganiza los puntos de mayor riesgo de ciclo de vida sin sustituir CPU, MMU, RAM, Dynarmic, loader, IPC/HLE, filesystem ni el diseño visual de Android. La prioridad es que el código tenga propietarios claros, estados explícitos y fronteras de concurrencia verificables.

## Reglas de ownership

- `std::unique_ptr` es el único propietario de eventos del `Scheduler`.
- La priority queue contiene punteros no propietarios.
- `EventId` nunca vuelve a empezar en 1 después de `clear()`.
- Recursos nativos Android/Vulkan se cierran mediante una única ruta de teardown.
- Un FD recibido desde JNI se duplica; el host nativo solo cierra su copia.

## Concurrencia

`NativeRuntimeHost` es el único dueño de acceso JNI al runtime.

- `runtime_mutex_`: serializa selección de contenido, lifecycle, ejecución y métricas.
- `graphics_mutex_`: serializa initialize/draw/shutdown de Vulkan.
- El render thread no puede competir con `shutdownVulkan()`: `GameSurfaceView` detiene e interrumpe el hilo y espera su terminación antes del teardown.
- Input usa un `std::atomic<uint32_t>` y no requiere bloquear el hilo de render.

## Estados

El contrato de runtime sigue siendo:

`Cold -> Preparing -> Ready -> Running -> Paused -> Stopping/Stopped`

con `Recovering` y `Error` como estados de recuperación/fallo. Las transiciones continúan siendo ejecutadas por `RuntimeCoordinator`; el host solo garantiza exclusión mutua y lifetime.

## Scheduler

El scheduler sigue siendo determinista y single-threaded. Los cambios de 57.24 son de seguridad de ownership:

1. un único contenedor propietario (`owned_`);
2. `active_` solo registra handles activos;
3. cancelación no libera memoria mientras el evento siga en el heap;
4. callbacks pueden reentrar `cancel(id)` de forma segura;
5. `clear()` no recicla IDs.

## ThreadManager

Los wake callbacks ya no pueden quedar apuntando a un `ThreadManager` destruido: destructor y `clear()` cancelan primero los eventos de wake. Los IDs de threads tampoco se reciclan después de reset.

## Seguridad

- No se confía en la propiedad del FD entregado por Java.
- Se rechazan handles inválidos antes de entrar al runtime.
- Se evita use-after-free en callbacks y Vulkan.
- No se añade compatibilidad falsa: el loader mantiene sus límites reales.

## Próximas fronteras

El siguiente refactor estructural debe extraer `RuntimeSessionController`, separar `RuntimeCoordinator::prepare()` en servicios de preparación y mover la lógica de `MainActivity` a casos de uso/repositories. Estas capas deben introducirse incrementalmente para no romper la ejecución real ya cubierta por las pruebas.
