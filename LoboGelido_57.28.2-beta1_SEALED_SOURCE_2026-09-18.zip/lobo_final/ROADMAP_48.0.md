# Roadmap after 48.0

Next priority: Vulkan resource realization and descriptor-backed draw execution.

1. Vulkan buffer/image allocation abstraction.
2. Resource state/layout tracking.
3. Descriptor pool/layout/set creation where supported.
4. Connect GPU command processor resource IDs to Vulkan resources.
5. Real descriptor-backed graphics draw path.
6. Later: guest GPU command translation and shader translation.
