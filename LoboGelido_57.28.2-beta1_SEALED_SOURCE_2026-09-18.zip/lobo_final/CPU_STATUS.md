# CPU status — Core Hardening 10.0

This release hardens the CPU/memory boundary without claiming full Armv8-A coverage.

Implemented and tested in this release:
- architectural scalar register state and NZCV/FPCR/FPSR state from the previous baseline;
- expanded scalar AArch64 interpreter instruction set from 9.0;
- explicit exception types for instruction/data abort, undefined instruction, alignment, SVC and breakpoint;
- real software page-table mappings with permissions;
- 64-entry direct-mapped TLB cache with invalidation;
- atomic memory primitives using C++20 atomic_ref and acquire/release/seq-cst ordering;
- dedicated MMU regression test.

Still required for a production Switch CPU: complete Armv8-A decode coverage, FP/ASIMD/NEON, exclusive instruction decode and reservation semantics, system registers, precise exceptions/interrupts, multicore scheduling integration, fastmem, JIT and Android NCE.
