# Lobo Gélido 57.9.2 — Reference UI Rebuild

## Objetivo
Se reemplaza la capa visual anterior por una shell de consola compacta inspirada en la referencia entregada por el usuario.

## Cambios
- Eliminada la navegación inferior estilo Android; ahora existe un rail lateral compacto de consola.
- Eliminado el fondo atmosférico de pantalla completa con imagen y bloom.
- Eliminadas sombras/elevaciones exageradas de tarjetas y botones.
- Botones convertidos a controles planos compactos con borde fino.
- Paleta reducida a azul/cian oscuro, con magenta menos dominante.
- Inicio reconstruido con hero compacto, juegos recientes y acceso rápido.
- Biblioteca ya no duplica un segundo sidebar: usa el rail global y conserva búsqueda, filtros y cuadrícula.
- Pantalla de bienvenida/inicialización reconstruida para usar el mismo lenguaje visual.
- Se mantiene el logo de lobo exacto en launcher, arranque y shell.
- La biblioteca sigue siendo exclusivamente contenido real reconocido por SAF; no se agregaron juegos ficticios.

## Integridad de biblioteca
`GameCatalogStore.entries()` valida que cada URI exista, sea archivo legible y tenga una extensión de contenido soportada antes de mostrarlo.

## Limitación de validación
El entorno actual no pudo ejecutar Gradle porque la descarga de Gradle 8.13 requiere acceso de red y `services.gradle.org` no fue resoluble. La estructura Kotlin modificada fue verificada estáticamente (llaves/paréntesis balanceados).
