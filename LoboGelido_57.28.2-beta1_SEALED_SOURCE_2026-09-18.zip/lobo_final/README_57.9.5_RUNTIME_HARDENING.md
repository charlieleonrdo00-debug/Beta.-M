# Lobo Gélido 57.9.5 — Runtime hardening

This increment keeps the 57.9.4 UI/data-real baseline and fixes three runtime integration issues.

## Changes

- Android version synchronized to `57.9.5` / versionCode `5795`.
- Native runtime version string synchronized to `57.9.5`.
- SAF detached file-descriptor failure path now closes the original descriptor instead of duplicating and leaking it.
- Loader segments now carry explicit guest permissions (RX text, R read-only data, RW data).
- Content-backed sessions rebuild the MMU from the loaded segment map instead of leaving only the deterministic empty-runtime mapping active.
- A dedicated RW guest stack page is mapped in the existing fastmem arena.
- Loader regression test now verifies executable permissions are propagated.

## Intent

This is a correctness increment, not a compatibility claim. NRO/NSO plaintext loading remains deliberately limited: encrypted/compressed Switch content (NCA/NSP/XCI pipelines), relocations, filesystem services and the broader HLE surface are still separate work items.
