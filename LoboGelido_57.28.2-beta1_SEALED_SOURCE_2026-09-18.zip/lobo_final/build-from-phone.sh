#!/bin/sh
set -eu
echo "Sube este proyecto a un repositorio GitHub y ejecuta:"
echo "Actions -> Lobo Gelido - Android APK -> Run workflow"
