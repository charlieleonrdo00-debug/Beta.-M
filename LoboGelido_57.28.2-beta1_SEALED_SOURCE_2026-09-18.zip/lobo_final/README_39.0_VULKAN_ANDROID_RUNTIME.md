# Lobo Gélido 39.0 — Vulkan Android Runtime Foundation

## Implementado
- Android Vulkan instance creation using the NDK Vulkan loader.
- Android Surface creation from `android.view.Surface` via `ANativeWindow`.
- Physical-device enumeration and deterministic selection of a queue supporting graphics + compute.
- Logical-device creation and graphics queue acquisition.
- Swapchain extension is requested when an Android surface is supplied.
- Present-support validation for the selected queue family.
- Native lifecycle: initialize/shutdown/diagnostics through `RuntimeBridge`.
- Host builds keep a safe stub so the native test suite remains platform-independent.

## Honest scope
This is a real Vulkan device/surface foundation, not yet a complete renderer. It does not fabricate swapchain images, render passes, command buffers, shader pipelines, or frame presentation. Those are the next GPU-runtime layer.

## Validation
Host CTest: 24/24 passed.
Android APK was not produced in this environment because the Android SDK/Gradle toolchain is not installed here.
