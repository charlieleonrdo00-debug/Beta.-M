# Lobo Gélido 15.0

## Evolución de la experiencia antes de jugar

La versión 15.0 convierte la selección de un juego en una experiencia previa al lanzamiento. Desde Biblioteca, el usuario abre la ficha del título y encuentra primero una tarjeta **VISTA PREVIA / GAMEPLAY**. Si ya existe un vídeo asociado, se reproduce automáticamente en silencio y en bucle; si no existe, la interfaz ofrece **Añadir vídeo**.

### Flujo

`Biblioteca → seleccionar juego → ficha → vista previa → Ejecutar`

### Gestión del vídeo

- Selección mediante Android Storage Access Framework (`video/*`).
- URI persistente por juego.
- Cambiar o quitar vídeo desde la misma ficha.
- Reproducción nativa con `VideoView`.
- Bucle y audio silenciado para una navegación no intrusiva.
- No se distribuyen vídeos, juegos, firmware ni claves.

### Arquitectura UI

- `MainActivity`: shell y composición de pantallas.
- `GamePreviewStore`: persistencia de previews por juego.
- `GameDetail`: composición de metadata, preview y acciones de lanzamiento.
- `GameSession / QuickMenu`: flujo posterior al lanzamiento.
- `Telemetry / Diagnostics`: rendimiento y diagnóstico del runtime.

La separación de `GamePreviewStore` permite reemplazar el reproductor por una capa más avanzada posteriormente sin rediseñar la ficha.

## Estado de pruebas

Core C++: **11/11 pruebas pasan**.

APK Android: no generado en este entorno porque no hay Gradle Wrapper ni Gradle CLI disponible.
