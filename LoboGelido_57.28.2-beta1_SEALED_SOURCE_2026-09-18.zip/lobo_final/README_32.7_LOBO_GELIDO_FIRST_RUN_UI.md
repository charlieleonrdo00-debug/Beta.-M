# Lobo Gélido 32.7 — First Run UI Rebuild

## Objetivo
Se rediseñó la pantalla de primera instalación para que forme parte del lenguaje visual de Lobo Gélido, en lugar de parecer una pantalla genérica de configuración.

## Interfaz
- Cabecera con logo exacto de Lobo Gélido y marca del emulador.
- Hero de configuración inicial con fondo invernal y cristal oscuro.
- Bordes cyan/azul y acciones magenta/azul coherentes con el shell.
- Tarjetas grandes para Claves, Firmware, Escalado sin pérdidas y Juegos.
- Estado visible `Configurado` / `No configurado`.
- Iconos, flechas y tarjetas táctiles de gran tamaño.
- Acción `Saltar por ahora`.
- Acción `Ir a Ajustes`.
- Botones inferiores `Atrás` y `Siguiente`.
- Scroll vertical para pantallas pequeñas.

## Arquitectura
`MainActivity.showFirstRunSetup()` es ahora un renderer de primera ejecución basado en componentes reutilizables existentes (`logo`, `label`, `rounded`, `button`, `card`). Los datos siguen centralizados en `AppSettingsStore`.

Las selecciones de archivos/carpetas usan el Storage Access Framework de Android y conservan permisos persistentes URI cuando el proveedor lo permite. Android documenta `ACTION_OPEN_DOCUMENT` para archivos y `ACTION_OPEN_DOCUMENT_TREE` para directorios. La app no incluye claves, firmware ni juegos.

## Flujo
`Boot → FirstRunSetup → Home`

El usuario puede completar cualquier tarjeta, omitir la configuración y volver a ella desde `Ajustes → Configuración inicial / rutas`.

## Compatibilidad visual
El proyecto ya usa una ventana edge-to-edge para Android moderno. Android 15+ aplica edge-to-edge cuando la app apunta a API 35 o superior, por lo que los elementos inferiores deben respetar los insets en el siguiente ciclo de refinamiento de UI.

## Validación
- CMake Release: OK
- CTest: 20/20 pruebas pasadas
- APK Android: no compilado en este entorno por ausencia del SDK/Gradle Android completo.
