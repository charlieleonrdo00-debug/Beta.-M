# Lobo Gélido 32.4 — Ajustes Max

Esta iteración amplía el panel de ajustes para acercarlo a la cobertura de configuración actual de Eden y añadir opciones adicionales orientadas a Android, rendimiento y diagnóstico.

## Cambios
- Centro de ajustes rediseñado y organizado por categorías.
- Explicación `ⓘ` en cada opción avanzada.
- Indicador de nivel: Seguro / Avanzado / Experimental.
- CPU: multicore, Fastmem, JIT/Dynarmic, Block backend, precisión, afinidad, Android Performance Hints, prioridad y quantum.
- Gráficos/Vulkan: resolución 50–200%, escaladores, FPS, ASTC, NVDEC, Extended Dynamic State, pipeline workers, Fast GPU Time, GPU async, async presentation, shaders async, VSync, caches, anisotrópico y AA.
- Audio: backend, dispositivo, latencia, stretching, sincronización A/V y volúmenes.
- Android: pantalla completa, inmersivo, alta frecuencia, menú rápido, FPS, táctil, hápticos, mantener pantalla activa.
- Sistema/almacenamiento: idioma, región, zona horaria, energía, configuración por juego, rutas, caches y telemetría local.
- Red, usuario y depuración ampliados.
- Restablecimiento seguro de preferencias sin borrar juegos/partidas.

## Nota de implementación
Las opciones de UI se persisten localmente. Las que todavía dependen de un backend real se etiquetan por nivel y no se presentan como una capacidad ya implementada del renderer/core. El siguiente paso para convertirlas en acciones de runtime reales es conectar cada clave al backend CPU/MMU/Vulkan/audio Android correspondiente.

## Validación
- CMake/CTest host: **20/20 pruebas pasadas**.
- No se generó un APK Android en este entorno; el proyecto requiere Android SDK/NDK/Gradle para compilar el APK.

## Referencia técnica
La selección de categorías y varias opciones se contrastó con cambios públicos recientes de Eden, incluyendo su reorganización de CPU/gráficos, controles Android, workers de pipelines y opciones de GPU asíncrona. Eden sigue cambiando, por lo que esta lista se trata como una base de compatibilidad, no como una copia literal de su código.
