# Lobo Gélido — keep native entry points
-keep class com.lobogelido.RuntimeBridge { *; }
