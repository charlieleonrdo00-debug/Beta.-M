plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lobogelido"
    compileSdk = 36
    ndkVersion = "27.3.13750724"

    defaultConfig {
        applicationId = "com.lobogelido"
        minSdk = 29
        targetSdk = 36
        versionCode = 5729
        versionName = "57.28.2-beta1"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++20", "-fexceptions", "-frtti")
                arguments += listOf(
                    "-DANDROID_STL=c++_shared",
                    "-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON"
                )
            }
        }
    }

    // Beta signing (test-ready).
    // If you provide a real keystore via -PLOBO_KEYSTORE=... (or the LOBO_KEYSTORE
    // env var) the beta is signed with it; otherwise the release APK falls back to
    // the debug key so it is still installable for field testing out of the box.
    signingConfigs {
        create("beta") {
            val ksPath = (findProperty("LOBO_KEYSTORE") as String?) ?: System.getenv("LOBO_KEYSTORE")
            if (ksPath != null && file(ksPath).exists()) {
                storeFile = file(ksPath)
                storePassword = (findProperty("LOBO_KEYSTORE_PASSWORD") as String?) ?: System.getenv("LOBO_KEYSTORE_PASSWORD")
                keyAlias = (findProperty("LOBO_KEY_ALIAS") as String?) ?: System.getenv("LOBO_KEY_ALIAS")
                keyPassword = (findProperty("LOBO_KEY_PASSWORD") as String?) ?: System.getenv("LOBO_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Use the real beta keystore when configured, else the debug key so the
            // release APK installs on a test device without extra setup.
            val betaKs = (findProperty("LOBO_KEYSTORE") as String?) ?: System.getenv("LOBO_KEYSTORE")
            signingConfig = if (betaKs != null && file(betaKs).exists())
                signingConfigs.getByName("beta")
            else
                signingConfigs.getByName("debug")
        }
        debug {
            isMinifyEnabled = false
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    java {
        toolchain {
            languageVersion = JavaLanguageVersion.of(17)
        }
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    packaging {
        jniLibs {
            // 16 KB page-size compliance (Frente 4).
            // false => extractNativeLibs=false: the .so is stored UNCOMPRESSED and
            // page-aligned inside the APK and mapped directly by the loader. That is
            // what lets the 16 KB-aligned library (built with the -z max-page-size=16384
            // link flags in cpp/CMakeLists.txt) actually load on Android 15+ / 16 KB
            // devices, and it is required for Google Play's 16 KB target-API rule.
            // Legacy packaging (true) compresses and extracts the library to /data on
            // install, defeating direct page-aligned mapping. extractNativeLibs=false
            // works from API 23+, so it is safe at minSdk=29 and required for 16 KB.
            useLegacyPackaging = false
        }
    }

    buildFeatures {
        buildConfig = true
        // 57.28 debug proof path: native Vulkan clear/submit/present, no Canvas/Compose rendering.
        buildConfigField("boolean", "VULKAN_SMOKE_TEST", "true")
    }
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.2.20")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}
