#include "native_runtime_host.h"

#include <chrono>
#include <sstream>
#include <unistd.h>

namespace lg::android {

NativeRuntimeHost::~NativeRuntimeHost() {
    // Runtime teardown and graphics teardown are independently serialized.
    stop_session();
    shutdown_vulkan();
}

void NativeRuntimeHost::close_owned_fd_locked() noexcept {
    if (content_fd_ >= 0) {
        ::close(content_fd_);
        content_fd_ = -1;
    }
}

bool NativeRuntimeHost::select_content(const std::string& path) {
    std::lock_guard lock(runtime_mutex_);
    close_owned_fd_locked();
    content_ = path;
    return !content_.empty();
}

bool NativeRuntimeHost::select_content_fd(int fd) {
    if (fd < 0) return false;
    const int owned = ::dup(fd); // JNI caller keeps ownership of the original FD.
    if (owned < 0) return false;

    std::lock_guard lock(runtime_mutex_);
    close_owned_fd_locked();
    content_fd_ = owned;
    content_ = "/proc/self/fd/" + std::to_string(owned);
    return true;
}

std::string NativeRuntimeHost::selected_content() const {
    std::lock_guard lock(runtime_mutex_);
    return content_;
}

static const char* state_name(runtime::State state) noexcept {
    switch (state) {
        case runtime::State::Cold: return "CREATED";
        case runtime::State::Preparing: return "PREPARING";
        case runtime::State::Ready: return "READY";
        case runtime::State::Running: return "RUNNING";
        case runtime::State::Paused: return "PAUSED";
        case runtime::State::Recovering: return "RECOVERING";
        case runtime::State::Stopped: return "STOPPED";
        case runtime::State::Error: return "ERROR";
    }
    return "UNKNOWN";
}

std::string NativeRuntimeHost::session_state() const {
    std::lock_guard lock(runtime_mutex_);
    return state_name(runtime_.state());
}

bool NativeRuntimeHost::prepare_session() {
    std::lock_guard lock(runtime_mutex_);
    if (content_.empty()) return false;
    return runtime_.prepare(content_).ok();
}

bool NativeRuntimeHost::start_session() {
    std::lock_guard lock(runtime_mutex_);
    return runtime_.start().ok();
}

bool NativeRuntimeHost::pause_session() {
    std::lock_guard lock(runtime_mutex_);
    return runtime_.pause().ok();
}

bool NativeRuntimeHost::resume_session() {
    std::lock_guard lock(runtime_mutex_);
    return runtime_.resume().ok();
}

bool NativeRuntimeHost::stop_session() {
    std::lock_guard lock(runtime_mutex_);
    const bool ok = runtime_.stop().ok();
    close_owned_fd_locked();
    content_.clear();
    input_mask_.store(0, std::memory_order_release);
    return ok;
}

bool NativeRuntimeHost::run_frame() {
    std::lock_guard lock(runtime_mutex_);
    if (runtime_.state() != runtime::State::Running) return false;
    return runtime_.run_frame(runtime_.entry_point()).ok();
}

std::string NativeRuntimeHost::runtime_diagnostics() const {
    std::lock_guard lock(runtime_mutex_);
    return runtime_.diagnostics();
}

std::string NativeRuntimeHost::runtime_metrics() const {
    std::lock_guard lock(runtime_mutex_);
    const auto& m = runtime_.metrics();
    std::ostringstream s;
    s << "frames=" << m.frames
      << ";fps=" << m.fps
      << ";frame_ms=" << m.frame_time_ms
      << ";cpu_ms=" << (m.cpu_ns / 1e6)
      << ";faults=" << m.faults
      << ";recoveries=" << m.recoveries
      << ";scheduler_ticks=" << m.scheduler_ticks
      << ";input_mask=0x" << std::hex << input_mask_.load(std::memory_order_acquire) << std::dec;
    return s.str();
}

std::string NativeRuntimeHost::diagnostics() const {
    std::scoped_lock lock(runtime_mutex_, graphics_mutex_);
    const auto sec = std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::steady_clock::now() - start_time_).count();
    std::ostringstream s;
    s << "Estado: " << state_name(runtime_.state())
      << ";Uptime: " << sec << " s"
      << ";Contenido: " << (content_.empty() ? "ninguno" : "seleccionado")
      << ";Runtime: " << runtime_.diagnostics()
      << ";Vulkan: " << vulkan_.diagnostics()
      << ";Presenter: " << presenter_.diagnostics();
    return s.str();
}

void NativeRuntimeHost::submit_input(int action, bool pressed) noexcept {
    if (action < 0 || action >= 31) return;
    const uint32_t bit = 1u << static_cast<uint32_t>(action);
    if (pressed) input_mask_.fetch_or(bit, std::memory_order_release);
    else input_mask_.fetch_and(~bit, std::memory_order_release);
}

bool NativeRuntimeHost::initialize_vulkan(void* android_surface) {
    if (!android_surface) return false;
    std::lock_guard lock(graphics_mutex_);
    auto result = vulkan_.initialize(android_surface);
    if (!result.ok()) return false;
    auto presenter = presenter_.initialize(
        vulkan_.instance_handle(),
        vulkan_.physical_device_handle(),
        vulkan_.device_handle(),
        vulkan_.surface_handle(),
        vulkan_.graphics_queue_family(),
        vulkan_.graphics_queue_handle());
    if (!presenter.ok()) {
        vulkan_.shutdown();
        return false;
    }
    return true;
}

bool NativeRuntimeHost::draw_vulkan_frame() {
    std::lock_guard lock(graphics_mutex_);
    return presenter_.draw_frame().ok();
}

bool NativeRuntimeHost::draw_vulkan_clear_frame() {
    std::lock_guard lock(graphics_mutex_);
    return presenter_.draw_clear_frame().ok();
}

void NativeRuntimeHost::shutdown_vulkan() noexcept {
    std::lock_guard lock(graphics_mutex_);
    presenter_.shutdown();
    vulkan_.shutdown();
}

std::string NativeRuntimeHost::presenter_diagnostics() const {
    std::lock_guard lock(graphics_mutex_);
    return presenter_.diagnostics();
}

std::string NativeRuntimeHost::vulkan_diagnostics() const {
    std::lock_guard lock(graphics_mutex_);
    return vulkan_.diagnostics();
}

} // namespace lg::android
