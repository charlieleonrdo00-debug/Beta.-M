#include <jni.h>
#include <string>
#include <chrono>

#if defined(__ANDROID__)
#include <android/native_window_jni.h>
#endif

#include "native_runtime_host.h"

namespace {
const auto g_start = std::chrono::steady_clock::now();
lg::android::NativeRuntimeHost g_host;
}

extern "C" JNIEXPORT jstring JNICALL Java_com_lobogelido_RuntimeBridge_version(JNIEnv* env, jobject) {
    return env->NewStringUTF("Lobo Gélido 57.28 • Runtime Architecture • ARM64");
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_selectContent(JNIEnv* env, jobject, jstring path) {
    if (!env || !path) return JNI_FALSE;
    const char* raw = env->GetStringUTFChars(path, nullptr);
    if (!raw) return JNI_FALSE;
    const bool ok = g_host.select_content(raw);
    env->ReleaseStringUTFChars(path, raw);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_selectContentFd(JNIEnv*, jobject, jint fd) {
    return g_host.select_content_fd(fd) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL Java_com_lobogelido_RuntimeBridge_selectedContent(JNIEnv* env, jobject) {
    const auto value = g_host.selected_content();
    return env->NewStringUTF(value.c_str());
}

extern "C" JNIEXPORT jstring JNICALL Java_com_lobogelido_RuntimeBridge_sessionState(JNIEnv* env, jobject) {
    const auto value = g_host.session_state();
    return env->NewStringUTF(value.c_str());
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_prepareSession(JNIEnv*, jobject) {
    return g_host.prepare_session() ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_startSession(JNIEnv*, jobject) {
    return g_host.start_session() ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_pauseSession(JNIEnv*, jobject) {
    return g_host.pause_session() ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_resumeSession(JNIEnv*, jobject) {
    return g_host.resume_session() ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_stopSession(JNIEnv*, jobject) {
    return g_host.stop_session() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL Java_com_lobogelido_RuntimeBridge_runtimeDiagnostics(JNIEnv* env, jobject) {
    const auto value = g_host.runtime_diagnostics();
    return env->NewStringUTF(value.c_str());
}
extern "C" JNIEXPORT jstring JNICALL Java_com_lobogelido_RuntimeBridge_runtimeMetrics(JNIEnv* env, jobject) {
    const auto value = g_host.runtime_metrics();
    return env->NewStringUTF(value.c_str());
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_runRuntimeFrame(JNIEnv*, jobject) {
    return g_host.run_frame() ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL Java_com_lobogelido_RuntimeBridge_submitInput(JNIEnv*, jobject, jint action, jboolean pressed) {
    g_host.submit_input(action, pressed == JNI_TRUE);
}

extern "C" JNIEXPORT jstring JNICALL Java_com_lobogelido_RuntimeBridge_diagnostics(JNIEnv* env, jobject) {
    const auto value = g_host.diagnostics();
    return env->NewStringUTF(value.c_str());
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_initializeVulkan(JNIEnv* env, jobject, jobject surface) {
#if defined(__ANDROID__)
    if (!env || !surface) return JNI_FALSE;
    ANativeWindow* window = ANativeWindow_fromSurface(env, surface);
    if (!window) return JNI_FALSE;
    const bool ok = g_host.initialize_vulkan(window);
    ANativeWindow_release(window);
    return ok ? JNI_TRUE : JNI_FALSE;
#else
    (void)env; (void)surface;
    return JNI_FALSE;
#endif
}

extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_drawVulkanFrame(JNIEnv*, jobject) {
    return g_host.draw_vulkan_frame() ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_lobogelido_RuntimeBridge_drawVulkanClearFrame(JNIEnv*, jobject) {
    return g_host.draw_vulkan_clear_frame() ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jstring JNICALL Java_com_lobogelido_RuntimeBridge_presenterDiagnostics(JNIEnv* env, jobject) {
    const auto value = g_host.presenter_diagnostics();
    return env->NewStringUTF(value.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_com_lobogelido_RuntimeBridge_shutdownVulkan(JNIEnv*, jobject) {
    g_host.shutdown_vulkan();
}
extern "C" JNIEXPORT jstring JNICALL Java_com_lobogelido_RuntimeBridge_vulkanDiagnostics(JNIEnv* env, jobject) {
    const auto value = g_host.vulkan_diagnostics();
    return env->NewStringUTF(value.c_str());
}
