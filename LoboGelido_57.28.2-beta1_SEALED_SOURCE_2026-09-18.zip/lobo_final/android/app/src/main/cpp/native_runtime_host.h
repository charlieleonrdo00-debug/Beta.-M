#pragma once

#include <atomic>
#include <cstdint>
#include <chrono>
#include <mutex>
#include <string>

#include "runtime/runtime_coordinator.h"
#include "gpu/android_vulkan_context.h"
#include "gpu/vulkan_presenter.h"

namespace lg::android {

// Owns Android/native runtime resources and serializes JNI lifecycle calls.
// Runtime and presentation have independent locks so a Vulkan frame cannot
// race with Vulkan teardown, while CPU/runtime lifecycle remains isolated from
// presentation work.
class NativeRuntimeHost final {
public:
    NativeRuntimeHost() = default;
    ~NativeRuntimeHost();

    NativeRuntimeHost(const NativeRuntimeHost&) = delete;
    NativeRuntimeHost& operator=(const NativeRuntimeHost&) = delete;

    bool select_content(const std::string& path);
    bool select_content_fd(int fd);
    std::string selected_content() const;

    std::string session_state() const;
    bool prepare_session();
    bool start_session();
    bool pause_session();
    bool resume_session();
    bool stop_session();
    bool run_frame();

    std::string runtime_diagnostics() const;
    std::string runtime_metrics() const;
    std::string diagnostics() const;

    void submit_input(int action, bool pressed) noexcept;

    bool initialize_vulkan(void* android_surface);
    bool draw_vulkan_frame();
    bool draw_vulkan_clear_frame();
    void shutdown_vulkan() noexcept;
    std::string presenter_diagnostics() const;
    std::string vulkan_diagnostics() const;

private:
    void close_owned_fd_locked() noexcept;

    mutable std::mutex runtime_mutex_;
    mutable std::mutex graphics_mutex_;
    std::string content_;
    int content_fd_{-1};
    std::atomic<uint32_t> input_mask_{0};

    runtime::RuntimeCoordinator runtime_;
    gpu::AndroidVulkanContext vulkan_;
    gpu::VulkanPresenter presenter_;
    const std::chrono::steady_clock::time_point start_time_{std::chrono::steady_clock::now()};
};

} // namespace lg::android
