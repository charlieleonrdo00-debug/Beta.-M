package com.lobogelido

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Lobo Gélido visual shell — screens aligned to the visual reference.
 *
 * Panel 1: Inicio / Instalación (welcome)
 * Home hub + recent games helpers for MainActivity.
 */
class LoboConsoleHomeRenderer(private val activity: Activity) {
    private val bg = LoboTheme.bg
    private val panel = LoboTheme.panel
    private val panel2 = LoboTheme.panel2
    private val cyan = LoboTheme.cyan
    private val blue = LoboTheme.blue
    private val text = LoboTheme.text
    private val muted = LoboTheme.muted
    private val line = LoboTheme.line
    private val lineSoft = LoboTheme.lineSoft
    private val green = LoboTheme.green

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = text, bold: Boolean = false) =
        TextView(activity).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun rounded(fill: Int, stroke: Int = line, radius: Int = 16) =
        GradientDrawable().apply {
            setColor(fill)
            setStroke(dp(1), stroke)
            cornerRadius = dp(radius).toFloat()
        }

    private fun image(resource: Int, scale: ImageView.ScaleType = ImageView.ScaleType.CENTER_CROP) =
        ImageView(activity).apply {
            setImageResource(resource)
            this.scaleType = scale
        }

    private fun button(title: String, onClick: () -> Unit, primary: Boolean = false) =
        TextView(activity).apply {
            this.text = title
            textSize = 15f
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            setTextColor(Color.WHITE)
            background = rounded(
                if (primary) blue else panel2,
                if (primary) cyan else line,
                14
            )
            setPadding(dp(20), 0, dp(20), 0)
            setOnClickListener { onClick() }
        }

    /** Brief splash → onFinished in ~1s. */
    fun buildBoot(onFinished: () -> Unit): View {
        val root = FrameLayout(activity).apply { setBackgroundColor(bg) }
        val logo = image(R.drawable.lobo_logo_transparent, ImageView.ScaleType.CENTER_INSIDE).apply { alpha = 0f }
        root.addView(logo, FrameLayout.LayoutParams(dp(180), dp(180)).apply { gravity = Gravity.CENTER })
        logo.animate().alpha(1f).setDuration(300).start()

        var done = false
        fun finish() {
            if (done) return
            done = true
            root.animate().alpha(0f).setDuration(200).withEndAction(onFinished).start()
        }
        root.postDelayed({ finish() }, 1100L)
        return root
    }

    /**
     * Panel 1 — Pantalla de inicio / Instalación (visual reference).
     * Fondo atmosférico, lobo central, CTA Conectar y checklist de características.
     */
    fun buildWelcome(
        versionLabel: String,
        onConnect: () -> Unit,
        onLanguage: () -> Unit = {}
    ): View {
        // Reference startup: dark console surface, restrained cyan, real status text.
        val root = FrameLayout(activity).apply { setBackgroundColor(Color.rgb(3, 7, 13)) }
        val scroll = ScrollView(activity).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val column = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(24), dp(18), dp(20))
        }

        val brand = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), 0, dp(2), dp(10))
        }
        brand.addView(image(R.drawable.lobo_logo_transparent, ImageView.ScaleType.CENTER_INSIDE), LinearLayout.LayoutParams(dp(44), dp(44)))
        val brandCopy = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0) }
        brandCopy.addView(text("LOBO GÉLIDO", 15f, Color.WHITE, true))
        brand.addView(brandCopy, LinearLayout.LayoutParams(0, -2, 1f))
        brand.addView(text(versionLabel, 9f, muted))
        column.addView(brand, LinearLayout.LayoutParams(-1, -2))

        val panel = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(this@LoboConsoleHomeRenderer.panel, line, 12)
            setPadding(dp(16), dp(18), dp(16), dp(16))
        }
        panel.addView(image(R.drawable.lobo_logo_transparent, ImageView.ScaleType.CENTER_INSIDE), LinearLayout.LayoutParams(dp(154), dp(154)))
        panel.addView(text("LOBO GÉLIDO", 28f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        panel.addView(text("Tu consola virtual está lista", 11f, cyan, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(2))
        })
        panel.addView(text("Preparando el entorno para tus juegos.\nNo se muestran títulos que no existan en tu biblioteca.", 10.5f, muted).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setPadding(0, dp(6), 0, dp(12))
        })

        val status = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(6, 14, 24), lineSoft, 9)
            setPadding(dp(11), dp(9), dp(11), dp(9))
        }
        listOf("Cargando módulos del sistema", "Inicializando gráficos", "Verificando configuración", "Listo").forEachIndexed { i, item ->
            status.addView(text("${if (i == 3) "✓" else "•"}  $item", 9.5f, if (i == 3) green else muted, i == 3), LinearLayout.LayoutParams(-1, dp(24)))
        }
        panel.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        panel.addView(button("Continuar", onConnect, true), LinearLayout.LayoutParams(-1, dp(40)))
        panel.addView(text("🌐  Español", 9.5f, muted).apply {
            gravity = Gravity.CENTER
            setOnClickListener { onLanguage() }
            setPadding(0, dp(12), 0, 0)
        })
        column.addView(panel, LinearLayout.LayoutParams(-1, -2))
        column.addView(text("Rendimiento  ·  Estabilidad  ·  Precisión", 9f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        scroll.addView(column)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        return root
    }

    fun buildHome(
        userName: String,
        selectedGame: String,
        recentGames: List<GameEntry> = emptyList(),
        onLibrary: () -> Unit,
        onPerformance: () -> Unit,
        onDiagnostics: () -> Unit,
        onSettings: () -> Unit,
        onControls: () -> Unit,
        onSkins: () -> Unit,
        onProfiles: () -> Unit,
        onGame: (GameEntry) -> Unit
    ): View {
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }

        val titleRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }
        titleRow.addView(text("Inicio", 21f, text, true), LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(text("Sesión local · $userName", 9f, muted))
        root.addView(titleRow)

        // Hero: compact, information-dense, no oversized CTA.
        val hero = FrameLayout(activity).apply {
            background = rounded(panel, line, 12)
            clipToOutline = true
        }
        hero.addView(View(activity).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(10, 25, 42), Color.rgb(6, 15, 26))
            )
        }, FrameLayout.LayoutParams(-1, -1))
        hero.addView(image(R.drawable.lobo_logo_transparent, ImageView.ScaleType.CENTER_INSIDE).apply {
            alpha = 0.84f
        }, FrameLayout.LayoutParams(dp(112), dp(112)).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            rightMargin = dp(10)
        })
        val copy = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(118), dp(12))
        }
        copy.addView(text("LOBO GÉLIDO", 24f, Color.WHITE, true))
        copy.addView(text("Rendimiento · estabilidad · precisión", 10.5f, muted))
        copy.addView(button("▶  Abrir biblioteca", onLibrary, true), LinearLayout.LayoutParams(dp(164), dp(38)).apply { topMargin = dp(10) })
        hero.addView(copy, FrameLayout.LayoutParams(-1, -1))
        root.addView(hero, LinearLayout.LayoutParams(-1, dp(150)).apply { bottomMargin = dp(12) })

        val recentHeader = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        recentHeader.addView(text("Juegos recientes", 14f, text, true), LinearLayout.LayoutParams(0, -2, 1f))
        recentHeader.addView(text("Ver todos  ›", 10f, cyan, true).apply { setOnClickListener { onLibrary() } })
        root.addView(recentHeader, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })

        if (recentGames.isEmpty()) {
            val empty = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(panel2, line, 10)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            empty.addView(text("No hay juegos en la biblioteca", 12f, text, true))
            empty.addView(text("Los juegos mostrados aquí deben existir físicamente en el contenido reconocido.", 9.5f, muted).apply { setPadding(0, dp(4), 0, 0) })
            root.addView(empty, LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(12) })
        } else {
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
            recentGames.take(2).forEachIndexed { i, game ->
                val tile = gameTile(game.title, game.size, game.coverUri) { onGame(game) }
                val lp = LinearLayout.LayoutParams(0, dp(112), 1f)
                if (i > 0) lp.leftMargin = dp(8)
                row.addView(tile, lp)
            }
            root.addView(row, LinearLayout.LayoutParams(-1, dp(112)).apply { bottomMargin = dp(12) })
        }

        val section = text("Acceso rápido", 14f, text, true)
        root.addView(section, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        val quick = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            Triple("⌘", "Controles", onControls),
            Triple("◇", "Pieles", onSkins),
            Triple("♙", "Perfiles", onProfiles),
            Triple("⚙", "Ajustes", onSettings)
        ).forEachIndexed { index, item ->
            val cell = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = rounded(panel2, line, 10)
                setPadding(dp(3), dp(7), dp(3), dp(7))
                addView(text(item.first, 15f, cyan, true).apply { gravity = Gravity.CENTER })
                addView(text(item.second, 9f, muted).apply { gravity = Gravity.CENTER; maxLines = 1 })
                setOnClickListener { item.third() }
            }
            val lp = LinearLayout.LayoutParams(0, dp(62), 1f)
            if (index > 0) lp.leftMargin = dp(7)
            quick.addView(cell, lp)
        }
        root.addView(quick)
        return root
    }

    private fun gameTile(title: String, subtitle: String, coverUri: String?, action: () -> Unit): View {
        return FrameLayout(activity).apply {
            background = rounded(panel2, line, 14)
            clipToOutline = true
            if (!coverUri.isNullOrBlank()) {
                try {
                    addView(ImageView(activity).apply {
                        setImageURI(Uri.parse(coverUri))
                        scaleType = ImageView.ScaleType.CENTER_CROP
                    }, FrameLayout.LayoutParams(-1, -1))
                    addView(View(activity).apply {
                        background = GradientDrawable(
                            GradientDrawable.Orientation.TOP_BOTTOM,
                            intArrayOf(Color.TRANSPARENT, Color.argb(200, 2, 6, 12))
                        )
                    }, FrameLayout.LayoutParams(-1, -1))
                } catch (_: Exception) {
                    addView(View(activity).apply {
                        background = GradientDrawable(
                            GradientDrawable.Orientation.TOP_BOTTOM,
                            intArrayOf(Color.rgb(14, 32, 56), Color.rgb(6, 14, 26))
                        )
                    }, FrameLayout.LayoutParams(-1, -1))
                }
            } else {
                addView(View(activity).apply {
                    background = GradientDrawable(
                        GradientDrawable.Orientation.TOP_BOTTOM,
                        intArrayOf(Color.rgb(14, 32, 56), Color.rgb(6, 14, 26))
                    )
                }, FrameLayout.LayoutParams(-1, -1))
            }
            val c = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM
                setPadding(dp(12), dp(10), dp(10), dp(12))
            }
            c.addView(text(title, 13f, text, true))
            c.addView(text(subtitle, 10f, muted))
            addView(c, FrameLayout.LayoutParams(-1, -1))
            setOnClickListener { action() }
        }
}
}
