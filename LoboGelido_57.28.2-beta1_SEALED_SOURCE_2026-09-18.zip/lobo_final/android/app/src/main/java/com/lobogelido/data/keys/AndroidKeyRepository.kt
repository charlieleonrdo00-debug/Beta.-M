package com.lobogelido.data.keys

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.lobogelido.data.saf.AndroidSafRepository
import com.lobogelido.domain.keys.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.util.Base64

/** Stores user key material encrypted at rest; plaintext keys never enter logs or SharedPreferences. */
class AndroidKeyRepository(context: Context) : KeyManager, KeyFileParser, KeyValidator, SecureKeyStore {
    private val app = context.applicationContext
    private val saf = AndroidSafRepository(app)
    private val prefs = app.getSharedPreferences("lobo_keys_v2", Context.MODE_PRIVATE)
    private val keyAlias = "LoboGelido.Keys"
    private val encryptedKey = "encrypted_payload"
    private val ivKey = "encrypted_iv"
    private val maxBytes = 16L * 1024L * 1024L

    override fun inspect(source: KeySource): KeyInspection = parse(source).let { parsed ->
        KeyInspection(source, parsed.keys.map { it.type }.toSet(), parsed.keys.isNotEmpty(), parsed.errors)
    }

    override fun import(source: KeySource, options: KeyImportOptions): KeyImportResult {
        val parsed = parse(source)
        if (parsed.keys.isEmpty()) return KeyImportResult(false, 0, parsed.errors.ifEmpty { listOf("No se encontraron claves válidas.") })
        if (!options.replaceExisting && hasRequiredKeys()) return KeyImportResult(false, 0, listOf("Ya existen claves válidas; usa reemplazar para importarlas de nuevo."))
        val plaintext = readSourceBytes(source.id) ?: return KeyImportResult(false, 0, listOf("No se pudo leer el archivo de claves."))
        if (plaintext.size > maxBytes) return KeyImportResult(false, 0, listOf("El archivo de claves supera el límite permitido."))
        runCatching {
            storeEncrypted(plaintext)
            store(ValidatedKeys(parsed.keys))
        }.onFailure { return KeyImportResult(false, 0, listOf(it.message ?: "No se pudo proteger el archivo de claves.")) }
        return KeyImportResult(true, parsed.keys.size, parsed.errors)
    }

    override fun validate(): KeyValidationResult =
        validate(readStored(), KeyValidationContext(setOf(KeyType.PROD)))

    override fun getStatus(): KeyStoreStatus = KeyStoreStatus(
        availableTypes = readStored().keys.map { it.type }.toSet(),
        functional = hasRequiredKeys()
    )

    override fun remove(type: KeyType): KeyOperationResult {
        if (type == KeyType.PROD || type == KeyType.TITLE) {
            prefs.edit().remove(encryptedKey).remove(ivKey).apply()
            return KeyOperationResult(true)
        }
        return KeyOperationResult(false, "Las claves individuales no se almacenan separadas en el almacén cifrado.")
    }

    override fun parse(source: KeySource): ParsedKeyFile {
        val uri = runCatching { Uri.parse(source.id) }.getOrNull()
            ?: return ParsedKeyFile(source.id, emptyList(), listOf("URI de claves no válida."))
        val keys = mutableListOf<ParsedKey>()
        val errors = mutableListOf<String>()
        runCatching {
            saf.open(uri.toString())?.use { input ->
                BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8)).forEachLine { line ->
                    val value = line.trim()
                    if (value.isBlank() || value.startsWith('#')) return@forEachLine
                    val separator = value.indexOf('=')
                    if (separator <= 0 || separator == value.lastIndex) return@forEachLine
                    val name = value.substring(0, separator).trim().lowercase()
                    val secret = value.substring(separator + 1).trim()
                    if (name.isBlank() || secret.length < 8) return@forEachLine
                    val type = classifyKey(name)
                    keys += ParsedKey(type, name)
                }
            } ?: errors.add("No se pudo abrir el archivo de claves.")
        }.onFailure { errors.add("No se pudo leer el archivo de claves: ${it.message ?: "error de lectura"}") }
        return ParsedKeyFile(source.id, keys.distinctBy { it.type.name + ':' + it.identifier }, errors)
    }

    override fun validate(keys: ParsedKeyFile, context: KeyValidationContext): KeyValidationResult {
        val usable = keys.keys.map { it.type }.toSet()
        val missing = context.requiredTypes.filterNot { it in usable }.toSet()

        // prod.keys no suele nombrar cada entrada con "prod". La puerta base
        // solo comprueba que exista material de producción reconocible.
        // TITLE/DEVICE son material adicional y no deben bloquear la importación.
        val valid = keys.keys.any { it.type == KeyType.PROD } && missing.isEmpty() && keys.errors.isEmpty()
        return KeyValidationResult(valid, usable, missing, keys.errors)
    }

    private fun classifyKey(name: String): KeyType {
        val n = name.trim().lowercase()
        return when {
            n.startsWith("title_") ||
                n.startsWith("titlekek_") ||
                n.startsWith("title_key_") -> KeyType.TITLE

            n.contains("device") ||
                n.contains("console") -> KeyType.DEVICE

            n.startsWith("master_key_") ||
                n.startsWith("master_key") ||
                n.startsWith("package1_key_") ||
                n.startsWith("package2_key_") ||
                n.startsWith("key_area_key_") ||
                n.startsWith("key_area_") ||
                n.startsWith("sd_seed") ||
                n.startsWith("secure_boot") ||
                n.startsWith("ssl_") ||
                n.startsWith("save_mac") ||
                n.startsWith("bis_") ||
                n.startsWith("header_kek") ||
                n.startsWith("keyblob") ||
                n.startsWith("es_") ||
                n.startsWith("fs_") ||
                n.startsWith("fssl_") ||
                n.startsWith("mariko_") ||
                n.startsWith("prod_") -> KeyType.PROD

            else -> KeyType.OTHER
        }
    }

    override fun store(keys: ValidatedKeys) {
        require(keys.keys.isNotEmpty()) { "No se pueden almacenar cero claves." }
        prefs.edit()
            .putStringSet("types", keys.keys.map { it.type.name }.toSet())
            .putStringSet("identifiers", keys.keys.map { it.identifier }.toSet())
            .apply()
    }

    override fun hasRequiredKeys(): Boolean = validate().valid

    private fun readStored(): ParsedKeyFile {
        val payload = decryptStored()
        if (payload != null) return parseBytes("stored", payload)
        val types = prefs.getStringSet("types", emptySet()).orEmpty().mapNotNull { runCatching { KeyType.valueOf(it) }.getOrNull() }
        val identifiers = prefs.getStringSet("identifiers", emptySet()).orEmpty()
        val keys = types.map { type -> ParsedKey(type, identifiers.firstOrNull { it.startsWith(type.name.lowercase()) } ?: "stored_${type.name.lowercase()}") }
        return ParsedKeyFile("stored", keys, if (keys.isEmpty()) listOf("No hay claves protegidas.") else listOf("El material cifrado no pudo descifrarse."))
    }

    private fun parseBytes(id: String, bytes: ByteArray): ParsedKeyFile {
        val text = bytes.toString(StandardCharsets.UTF_8)
        val keys = mutableListOf<ParsedKey>()
        text.lineSequence().forEach { line ->
            val value = line.trim()
            if (value.isBlank() || value.startsWith('#')) return@forEach
            val separator = value.indexOf('=')
            if (separator <= 0 || separator == value.lastIndex) return@forEach
            val name = value.substring(0, separator).trim().lowercase()
            val secret = value.substring(separator + 1).trim()
            if (secret.length < 8) return@forEach
            val type = classifyKey(name)
            keys += ParsedKey(type, name)
        }
        return ParsedKeyFile(id, keys.distinctBy { it.type.name + ':' + it.identifier }, emptyList())
    }

    private fun readSourceBytes(uriString: String): ByteArray? = runCatching {
        saf.open(uriString)?.use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(32 * 1024)
            var total = 0L
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                require(total <= maxBytes) { "El archivo de claves supera el límite permitido." }
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        }
    }.getOrNull()

    private fun storeEncrypted(plain: ByteArray) {
        val key = getOrCreateSecretKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val encrypted = cipher.doFinal(plain)
        prefs.edit()
            .putString(encryptedKey, Base64.getEncoder().encodeToString(encrypted))
            .putString(ivKey, Base64.getEncoder().encodeToString(cipher.iv))
.apply()
    }

    private fun decryptStored(): ByteArray? = runCatching {
        val encrypted = prefs.getString(encryptedKey, null) ?: return null
        val iv = prefs.getString(ivKey, null) ?: return null
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, Base64.getDecoder().decode(iv)))
        cipher.doFinal(Base64.getDecoder().decode(encrypted))
    }.getOrNull()

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(keyAlias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setUserAuthenticationRequired(false)
            .build())
        return generator.generateKey()
    }
}
