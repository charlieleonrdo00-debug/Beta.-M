package com.lobogelido

import android.content.Context

/**
 * Local achievement system for Lobo Gélido.
 * Progress is stored on-device; no network and no proprietary content required.
 */
class AchievementStore(context: Context) {
    private val prefs = context.getSharedPreferences("lobo_achievements_v1", Context.MODE_PRIVATE)

    data class Achievement(
        val id: String,
        val title: String,
        val description: String,
        val icon: String,
        val category: Category
    )

    enum class Category { SETUP, LIBRARY, PLAY, SYSTEM, SPECIAL }

    data class Progress(
        val achievement: Achievement,
        val unlocked: Boolean,
        val unlockedAtEpoch: Long
    )

    companion object {
        val DEFINITIONS: List<Achievement> = listOf(
            Achievement("first_boot", "Primer aullido", "Abre Lobo Gélido por primera vez.", "🐺", Category.SETUP),
            Achievement("setup_complete", "Guardián listo", "Completa la configuración inicial.", "✓", Category.SETUP),
            Achievement("keys_set", "Llaves del reino", "Configura las claves del usuario.", "🔑", Category.SETUP),
            Achievement("firmware_set", "Firmware propio", "Configura el firmware del usuario.", "▣", Category.SETUP),
            Achievement("gpu_driver", "Forja gráfica", "Selecciona un paquete de driver GPU.", "⬢", Category.SETUP),
            Achievement("first_game", "Primer título", "Añade tu primer juego a la biblioteca.", "🎮", Category.LIBRARY),
            Achievement("library_5", "Coleccionista", "Ten al menos 5 juegos en la biblioteca.", "📚", Category.LIBRARY),
            Achievement("library_20", "Archivista", "Ten al menos 20 juegos en la biblioteca.", "🏛", Category.LIBRARY),
            Achievement("favorite_1", "Favorito marcado", "Marca un juego como favorito.", "★", Category.LIBRARY),
            Achievement("first_session", "En marcha", "Inicia una sesión de juego.", "▶", Category.PLAY),
            Achievement("sessions_10", "Veterano", "Inicia 10 sesiones de juego.", "⏱", Category.PLAY),
            Achievement("quick_menu", "Menú de batalla", "Abre el menú rápido durante una partida.", "☰", Category.PLAY),
            Achievement("profile_saved", "Estratega", "Guarda un perfil de juego personalizado.", "▤", Category.SYSTEM),
            Achievement("theme_changed", "Piel de hielo", "Cambia el tema visual.", "🎨", Category.SYSTEM),
            Achievement("diagnostics", "Ojo del lobo", "Abre el panel de diagnóstico.", "◉", Category.SYSTEM),
            Achievement("accessibility", "Acceso total", "Ajusta una opción de accesibilidad.", "♿", Category.SYSTEM),
            Achievement("all_setup", "Configuración total", "Claves, firmware y carpeta de juegos configurados.", "❄", Category.SPECIAL),
            Achievement("night_owl", "Lobo nocturno", "Usa la app entre las 00:00 y las 05:00.", "🌙", Category.SPECIAL)
        )
    }

    fun all(): List<Progress> = DEFINITIONS.map { a ->
        Progress(
            achievement = a,
            unlocked = isUnlocked(a.id),
            unlockedAtEpoch = unlockedAt(a.id)
        )
    }

    fun unlockedCount(): Int = DEFINITIONS.count { isUnlocked(it.id) }

    fun totalCount(): Int = DEFINITIONS.size

    fun isUnlocked(id: String): Boolean = prefs.getBoolean("u_$id", false)

    fun unlockedAt(id: String): Long = prefs.getLong("t_$id", 0L)

    /** Returns true if this call newly unlocked the achievement. */
    fun unlock(id: String): Boolean {
        if (DEFINITIONS.none { it.id == id }) return false
        if (isUnlocked(id)) return false
        prefs.edit()
            .putBoolean("u_$id", true)
            .putLong("t_$id", System.currentTimeMillis())
            .apply()
        return true
    }

    fun incrementSessionStarts(): Int {
        val n = prefs.getInt("session_starts", 0) + 1
        prefs.edit().putInt("session_starts", n).apply()
        return n
    }

    fun sessionStarts(): Int = prefs.getInt("session_starts", 0)

    fun markFirstBoot() = unlock("first_boot")
}
