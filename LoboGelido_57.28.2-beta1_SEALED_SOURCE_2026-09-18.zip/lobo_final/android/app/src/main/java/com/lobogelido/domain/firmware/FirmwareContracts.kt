package com.lobogelido.domain.firmware

/** Public contract for real firmware lifecycle operations. Implementations are supplied by infrastructure. */
interface FirmwareManager {
    fun inspect(source: FirmwareSource): FirmwareInspection
    fun validate(source: FirmwareSource, policy: FirmwareValidationPolicy): FirmwareValidationResult
    fun install(source: FirmwareSource, options: FirmwareInstallOptions): FirmwareInstallResult
    fun getInstalled(): InstalledFirmware?
    fun remove(version: FirmwareVersion): FirmwareOperationResult
}

interface FirmwareIntegrityVerifier {
    fun verifyHash(source: FirmwareSource, expected: ExpectedHash): IntegrityResult
    fun verifySignature(source: FirmwareSource, signature: FirmwareSignature, trustedKey: TrustedVerificationKey): IntegrityResult
}

interface FirmwareRepository {
    fun getInstalled(): InstalledFirmware?
    fun save(metadata: InstalledFirmware)
    fun remove(version: FirmwareVersion): FirmwareOperationResult
}

data class FirmwareSource(val id: String, val displayName: String, val sizeBytes: Long)
data class FirmwareVersion(val value: String)
data class FirmwareValidationPolicy(val requireExpectedHash: Boolean = true, val requireSignature: Boolean = false, val expectedHash: ExpectedHash? = null, val signature: FirmwareSignature? = null, val trustedKey: TrustedVerificationKey? = null)
data class FirmwareInstallOptions(val allowReplace: Boolean = false, val verifyAfterInstall: Boolean = true)
data class FirmwareArchive(val sourceId: String, val entries: List<String>, val totalBytes: Long)
data class FirmwareInspection(val source: FirmwareSource, val version: FirmwareVersion?, val archive: FirmwareArchive?, val errors: List<String>)
data class InstalledFirmware(val version: FirmwareVersion, val installId: String)
data class ExpectedHash(val algorithm: String, val hexDigest: String)
data class FirmwareSignature(val algorithm: String, val value: String)
data class TrustedVerificationKey(val id: String, val publicKeyBase64: String? = null)
data class IntegrityResult(val valid: Boolean, val method: String, val error: String? = null)
data class FirmwareValidationResult(val valid: Boolean, val integrity: IntegrityResult?, val errors: List<String>)
data class FirmwareInstallResult(val success: Boolean, val installed: InstalledFirmware?, val errors: List<String>)
data class FirmwareOperationResult(val success: Boolean, val error: String? = null)
