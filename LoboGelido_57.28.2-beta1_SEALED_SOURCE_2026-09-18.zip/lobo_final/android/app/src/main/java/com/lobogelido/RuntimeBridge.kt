package com.lobogelido

/**
 * Narrow Android boundary for the native runtime.
 * Keeping JNI declarations here prevents the Activity from becoming the
 * owner of native ABI details and makes lifecycle calls easier to test/mock.
 */
object RuntimeBridge {
    init { System.loadLibrary("lobogelido_android") }

    external fun version(): String
    external fun selectContent(path: String): Boolean
    external fun selectContentFd(fd: Int): Boolean
    external fun selectedContent(): String
    external fun diagnostics(): String
    external fun runtimeDiagnostics(): String
    external fun runtimeMetrics(): String
    external fun runRuntimeFrame(): Boolean
    external fun submitInput(action: Int, pressed: Boolean)
    external fun sessionState(): String
    external fun prepareSession(): Boolean
    external fun startSession(): Boolean
    external fun pauseSession(): Boolean
    external fun resumeSession(): Boolean
    external fun stopSession(): Boolean
    external fun initializeVulkan(surface: android.view.Surface): Boolean
    external fun drawVulkanFrame(): Boolean
    external fun drawVulkanClearFrame(): Boolean
    external fun presenterDiagnostics(): String
    external fun shutdownVulkan()
    external fun vulkanDiagnostics(): String
}
