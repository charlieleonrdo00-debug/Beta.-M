package com.lobogelido.domain.games

interface GameDiscovery {
    fun scan(folders: List<GameFolder>): GameScanResult
    fun scanFolder(folder: GameFolder): GameScanResult
    fun refresh(gameId: GameId): GameMetadata?
}

interface GameRepository {
    val gamesFlow: kotlinx.coroutines.flow.StateFlow<List<GameMetadata>>
    fun getAll(): List<GameMetadata>
    fun getById(id: GameId): GameMetadata?
    fun upsert(game: GameMetadata)
    fun remove(id: GameId)
    fun clearMissingEntries(existingSources: Set<GameSource>)
    fun setFavorite(id: GameId, favorite: Boolean)
    fun setPlayed(id: GameId, epochMillis: Long)
    fun setCompatibility(id: GameId, value: String)
    fun setVersion(id: GameId, value: String?)
}

interface ArtworkResolver { fun resolve(game: GameMetadata): ArtworkResolution }
interface GameFolderManager {
    fun addFolder(source: GameFolderSource): GameFolder
    fun removeFolder(folderId: GameFolderId)
    fun getFolders(): List<GameFolder>
    fun validateAccess(folder: GameFolder): FolderAccessResult
}

interface FileAccessProvider {
    fun open(source: GameSource): FileHandle
    fun list(folder: GameFolder): List<GameSource>
    fun exists(source: GameSource): Boolean
}

data class GameId(val value: String)
data class GameFolderId(val value: String)
data class GameSource(val id: String, val displayName: String, val path: String, val sizeBytes: Long)
data class GameFolder(val id: GameFolderId, val displayName: String, val sourceId: String)
data class GameFolderSource(val id: String, val displayName: String)

data class GameMetadata(
    val title: String,
    val titleId: GameId,
    val publisher: String?,
    val version: String?,
    val region: String?,
    val icon: Artwork?,
    val cover: Artwork?,
    val format: GameFormat,
    val sourcePath: String,
    val sizeBytes: Long = 0L,
    val modifiedEpoch: Long = 0L,
    val lastPlayedEpoch: Long = 0L,
    val favorite: Boolean = false,
    val compatibility: String = "No evaluada",
    val installed: Boolean = true
)

enum class GameFormat { NRO, NSO, NCA, NSP, XCI, NSZ, XCZ, UNKNOWN }
data class GameScanResult(val games: List<GameMetadata>, val skipped: List<GameSource>, val errors: List<String>)
data class Artwork(val id: String, val uri: String, val kind: ArtworkKind)
enum class ArtworkKind { ICON, COVER, BANNER }
data class ArtworkResolution(val artwork: Artwork?, val source: String?, val attemptedProviders: List<String>)
data class FileHandle(val id: String)
data class FolderAccessResult(val accessible: Boolean, val error: String? = null)
