package com.lobogelido.application.usecase

import android.os.Build
import com.lobogelido.domain.profiles.GameOptimizationInput
import com.lobogelido.domain.profiles.GamePlatformHint
import com.lobogelido.domain.profiles.GameProfile
import com.lobogelido.domain.profiles.ProfileRepository

class GetGameProfileUseCase(private val repository: ProfileRepository) {
    fun execute(gameId: String): GameProfile = repository.get(gameId)
}
class SaveGameProfileUseCase(private val repository: ProfileRepository) {
    fun execute(profile: GameProfile) = repository.save(profile)
}
class ResetGameProfileUseCase(private val repository: ProfileRepository) {
    fun execute(gameId: String) = repository.reset(gameId)
}

class OptimizeGameProfileUseCase(private val repository: ProfileRepository) {
    enum class DeviceTier { ENTRY, BALANCED, HIGH_END }
    data class OptimizationReport(
        val tier: DeviceTier, val cores: Int, val memoryMb: Long, val resolution: Int,
        val fps: Int, val graphics: String, val scaling: String, val confidence: Int,
        val deviceLabel: String, val abi: String, val recommendation: String
    )

    fun execute(game: GameOptimizationInput, cpuCores: Int, totalMemoryMb: Long): OptimizationReport {
        val normalizedCores = cpuCores.coerceAtLeast(1)
        val normalizedMemory = totalMemoryMb.coerceAtLeast(512L)
        val bias = when (game.platform) {
            GamePlatformHint.GBC, GamePlatformHint.GBA -> 5
            GamePlatformHint.GAMECUBE, GamePlatformHint.WII, GamePlatformHint.N3DS -> -5
            GamePlatformHint.OTHER -> 0
        }
        val tier = when {
            normalizedCores >= 8 && normalizedMemory >= 6144 -> DeviceTier.HIGH_END
            normalizedCores >= 6 && normalizedMemory >= 4096 -> DeviceTier.BALANCED
            else -> DeviceTier.ENTRY
        }
        val resolution = when (tier) { DeviceTier.HIGH_END -> 125; DeviceTier.BALANCED -> 100; DeviceTier.ENTRY -> 75 }
        val fps = if (tier == DeviceTier.ENTRY) 30 else 60
        val graphics = when (tier) { DeviceTier.HIGH_END -> "Alto"; DeviceTier.BALANCED -> "Equilibrado"; DeviceTier.ENTRY -> "Rendimiento" }
        val scaling = if (tier == DeviceTier.HIGH_END) "Lanczos" else "Inteligente"
        val confidence = (when (tier) { DeviceTier.HIGH_END -> 88; DeviceTier.BALANCED -> 78; DeviceTier.ENTRY -> 68 } + bias).coerceIn(50, 95)
        val label = when (tier) { DeviceTier.HIGH_END -> "Alto rendimiento"; DeviceTier.BALANCED -> "Equilibrado"; DeviceTier.ENTRY -> "Ahorro / compatibilidad" }
        val recommendation = when (tier) {
            DeviceTier.HIGH_END -> "Priorizar calidad; mantener cachés y JIT activos."
            DeviceTier.BALANCED -> "Priorizar estabilidad; 100% de resolución y 60 FPS."
            DeviceTier.ENTRY -> "Priorizar estabilidad térmica; 75% de resolución y 30 FPS."
        }
        repository.save(GameProfile(game.gameId, graphics, resolution, fps, true, scaling, "Alta", "Pro Controller", true, true))
        return OptimizationReport(tier, normalizedCores, normalizedMemory, resolution, fps, graphics, scaling, confidence, label, Build.SUPPORTED_ABIS.firstOrNull() ?: "desconocida", recommendation)
    }
}
