package com.lobogelido

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

/**
 * Lightweight motion system for fluid UI transitions.
 */
object LoboAnim {
    private val easeOut = DecelerateInterpolator(1.6f)
    private val overshoot = OvershootInterpolator(0.9f)

    fun fadeIn(view: View, duration: Long = 220L, delay: Long = 0L, fromY: Float = 16f) {
        view.alpha = 0f
        view.translationY = fromY
        view.animate()
            .alpha(1f)
            .translationY(0f)
            .setStartDelay(delay)
            .setDuration(duration)
            .setInterpolator(easeOut)
            .start()
    }

    fun fadeOut(view: View, duration: Long = 140L, end: (() -> Unit)? = null) {
        view.animate()
            .alpha(0f)
            .translationY(-8f)
            .setDuration(duration)
            .setInterpolator(easeOut)
            .withEndAction { end?.invoke() }
            .start()
    }

    fun press(view: View) {
        view.animate()
            .scaleX(0.96f).scaleY(0.96f)
            .setDuration(70L)
            .withEndAction {
                view.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(120L)
                    .setInterpolator(overshoot)
                    .start()
            }
            .start()
    }

    fun staggerChildren(parent: ViewGroup, startDelay: Long = 30L, step: Long = 35L) {
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i) ?: continue
            fadeIn(child, duration = 200L, delay = startDelay + i * step, fromY = 18f)
        }
    }

    fun pulseOnce(view: View) {
        val sx = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 1.04f, 1f)
        val sy = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 1.04f, 1f)
        AnimatorSet().apply {
            playTogether(sx, sy)
            duration = 280L
            interpolator = easeOut
            start()
        }
    }
}
