package com.lobogelido

import android.content.Context
import android.net.Uri

/**
 * Persistent mapping between a game identity and its optional gameplay preview.
 *
 * The preview is user-owned media selected through Android's Storage Access Framework.
 * No copyrighted video is bundled with Lobo Gélido.
 */
class GamePreviewStore(context: Context) {
    private val prefs = context.getSharedPreferences("lobo_game_previews", Context.MODE_PRIVATE)

    fun get(gameId: String): Uri? = prefs.getString(key(gameId), null)?.let(Uri::parse)

    fun set(gameId: String, uri: Uri) {
        prefs.edit().putString(key(gameId), uri.toString()).apply()
    }

    fun remove(gameId: String) {
        prefs.edit().remove(key(gameId)).apply()
    }

    private fun key(gameId: String): String = "preview_${gameId.trim().lowercase().hashCode()}"
}
