package com.lobogelido

import android.content.Context
import android.os.Build
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * GPU driver manager: detects the system driver, tracks installed alternative
 * packages, and can fetch open-source community driver packs the user chooses.
 *
 * Does not ship proprietary vendor blobs. Downloads are user-initiated only.
 */
object GpuDriverManager {
    private const val TAG = "GpuDriverManager"
    private const val PREFS = "lobo_gpu_drivers_v1"

    data class SystemGpuInfo(
        val title: String,
        val version: String,
        val vendor: String,
        val modelHint: String
    )

    data class InstalledDriver(
        val id: String,
        val name: String,
        val path: String,
        val source: String,
        val installedAt: Long
    )

    data class CatalogEntry(
        val id: String,
        val name: String,
        val description: String,
        /** Public page (GitHub / docs). Always safe to open in browser. */
        val infoUrl: String,
        /**
         * Optional direct zip URL. Only open-source / user-provided endpoints.
         * Null = user must use browser + Instalar.
         */
        val downloadUrl: String? = null
    )

    /** Community-oriented open-source oriented packs (Turnip / Freedreno family). */
    val CATALOG: List<CatalogEntry> = listOf(
        CatalogEntry(
            id = "turnip_generic",
            name = "Turnip (Mesa) genérico",
            description = "Drivers Vulkan open-source basados en Mesa Turnip para Adreno.",
            infoUrl = "https://docs.mesa3d.org/drivers/freedreno.html",
            downloadUrl = null
        ),
        CatalogEntry(
            id = "k11mch1",
            name = "AdrenoTools / K11MCH1",
            description = "Paquetes comunitarios de drivers Adreno para emuladores Android.",
            infoUrl = "https://github.com/K11MCH1/AdrenoToolsDrivers",
            downloadUrl = null
        ),
        CatalogEntry(
            id = "gamehub_adreno",
            name = "GameHub Adreno 8xx",
            description = "Paquete orientado a GPUs Adreno 8xx (si el usuario ya lo tiene).",
            infoUrl = "https://github.com/K11MCH1/AdrenoToolsDrivers",
            downloadUrl = null
        ),
        CatalogEntry(
            id = "kimchi_turnip",
            name = "KIMCHI Turnip",
            description = "Variante comunitaria Turnip; instálala desde archivo local.",
            infoUrl = "https://github.com/K11MCH1/AdrenoToolsDrivers",
            downloadUrl = null
        ),
        CatalogEntry(
            id = "freedreno",
            name = "Freedreno / Weab-Chan",
            description = "Línea Freedreno / paquetes comunitarios asociados.",
            infoUrl = "https://docs.mesa3d.org/drivers/freedreno.html",
            downloadUrl = null
        ),
        CatalogEntry(
            id = "whitebelyash",
            name = "Whitebelyash Turnip",
            description = "Paquete comunitario Turnip; usa + Instalar con el zip local.",
            infoUrl = "https://github.com/K11MCH1/AdrenoToolsDrivers",
            downloadUrl = null
        ),
        CatalogEntry(
            id = "mr_purple",
            name = "Mr. Purple Turnip",
            description = "Paquete comunitario; selecciónalo tras descargarlo.",
            infoUrl = "https://github.com/K11MCH1/AdrenoToolsDrivers",
            downloadUrl = null
        )
    )

    fun systemInfo(context: Context): SystemGpuInfo {
        val vulkan = prop("ro.hardware.vulkan")
            .ifBlank { prop("ro.hardware.egl") }
            .ifBlank { Build.HARDWARE }
        val board = Build.BOARD.orEmpty()
        val hardware = Build.HARDWARE.orEmpty()
        val vendor = when {
            vulkan.contains("adreno", true) || hardware.contains("qcom", true) ||
                board.contains("sm", true) -> "Qualcomm"
            vulkan.contains("mali", true) || hardware.contains("mali", true) -> "ARM Mali"
            vulkan.contains("powervr", true) || vulkan.contains("img", true) -> "Imagination"
            else -> Build.MANUFACTURER ?: "Sistema"
        }
        val model = when {
            vendor == "Qualcomm" -> {
                val g = prop("ro.hardware.vulkan").ifBlank { hardware }
                if (g.isNotBlank()) g else "Adreno"
            }
            else -> vulkan.ifBlank { hardware }.ifBlank { "GPU del sistema" }
        }
        val version = prop("ro.opengles.version").ifBlank {
            // Fall back to a readable build fingerprint fragment
            Build.DISPLAY?.take(24) ?: "—"
        }
        // Prefer GLES renderer if a previous session stored it
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val cachedRenderer = prefs.getString("gl_renderer", null)
        val cachedVersion = prefs.getString("gl_version", null)
        return SystemGpuInfo(
            title = "Controlador de la GPU del sistema",
            version = cachedVersion ?: version,
            vendor = if (cachedRenderer != null && cachedRenderer.contains("Adreno", true)) "Qualcomm"
            else if (cachedRenderer != null && cachedRenderer.contains("Mali", true)) "ARM Mali"
            else vendor,
            modelHint = cachedRenderer ?: model
        )
    }

    fun cacheGlStrings(context: Context, renderer: String?, version: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("gl_renderer", renderer)
            .putString("gl_version", version)
            .apply()
    }

    fun selectedId(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("selected_id", "system") ?: "system"

    fun select(context: Context, id: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("selected_id", id)
            .apply()
    }

    fun installed(context: Context): List<InstalledDriver> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString("installed_json", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                InstalledDriver(
                    id = o.optString("id"),
                    name = o.optString("name"),
                    path = o.optString("path"),
                    source = o.optString("source"),
                    installedAt = o.optLong("installedAt")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun addInstalled(context: Context, name: String, path: String, source: String): InstalledDriver {
        val id = "drv_${System.currentTimeMillis()}"
        val entry = InstalledDriver(id, name, path, source, System.currentTimeMillis())
        val list = installed(context).toMutableList()
        list.add(0, entry)
        saveInstalled(context, list)
        select(context, id)
        return entry
    }

    fun removeInstalled(context: Context, id: String) {
        val list = installed(context).filterNot { it.id == id }
        saveInstalled(context, list)
        if (selectedId(context) == id) select(context, "system")
        try {
            // Only delete files inside our drivers dir
            val dir = driversDir(context)
            listOfNotNull(
                installed(context).firstOrNull { it.id == id }?.path
            )
            // file may already be gone from list; clean orphan zips carefully
            dir.listFiles()?.forEach { f ->
                if (f.name.contains(id)) f.delete()
            }
        } catch (_: Exception) { }
    }

    private fun saveInstalled(context: Context, list: List<InstalledDriver>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject()
                .put("id", it.id)
                .put("name", it.name)
                .put("path", it.path)
                .put("source", it.source)
                .put("installedAt", it.installedAt))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("installed_json", arr.toString())
            .apply()
    }

    fun driversDir(context: Context): File =
        File(context.filesDir, "gpu_drivers").apply { mkdirs() }

    /**
     * Download a zip into app storage. Returns local file path or null.
     * Caller must run off the UI thread.
     */
    fun downloadToDrivers(
        context: Context,
        url: String,
        fileName: String,
        onProgress: ((Int) -> Unit)? = null
    ): File? {
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20000
                readTimeout = 60000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "LoboGelido/57.2")
            }
            if (conn.responseCode !in 200..299) {
                Log.w(TAG, "HTTP ${conn.responseCode} for $url")
                return null
            }
            val out = File(driversDir(context), fileName)
            conn.inputStream.use { input ->
                FileOutputStream(out).use { output ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    val length = conn.contentLengthLong
                    var n: Int
                    while (input.read(buf).also { n = it } >= 0) {
                        output.write(buf, 0, n)
                        total += n
                        if (length > 0 && onProgress != null) {
                            onProgress(((total * 100) / length).toInt().coerceIn(0, 100))
                        }
                    }
                }
            }
            out
        } catch (e: Exception) {
            Log.e(TAG, "download failed", e)
            null
        }
    }

    fun executor() = Executors.newSingleThreadExecutor()

    private fun prop(key: String): String = try {
        val c = Class.forName("android.os.SystemProperties")
        val m = c.getMethod("get", String::class.java)
        (m.invoke(null, key) as? String)?.trim().orEmpty()
    } catch (_: Exception) {
        ""
    }
}
