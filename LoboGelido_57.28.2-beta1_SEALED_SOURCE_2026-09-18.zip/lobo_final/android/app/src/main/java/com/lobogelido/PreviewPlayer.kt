package com.lobogelido

import android.content.Context
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView

/** Preview playback abstraction. Game detail does not depend on VideoView directly. */
interface PreviewPlayer {
    fun create(context: Context, uri: Uri, onError: () -> Unit): VideoView
}

class NativePreviewPlayer : PreviewPlayer {
    override fun create(context: Context, uri: Uri, onError: () -> Unit): VideoView = VideoView(context).apply {
        setVideoURI(uri)
        setMediaController(MediaController(context))
        setOnPreparedListener { mp -> mp.isLooping = true; mp.setVolume(0f, 0f); start() }
        setOnErrorListener { _, _, _ -> onError(); true }
    }
}
