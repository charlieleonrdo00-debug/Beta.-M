package com.lobogelido.domain.saf

interface SafPermissionRepository {
    fun persist(uri: String, write: Boolean = false): SafPermissionResult
    fun canRead(uri: String): Boolean
}

data class SafPermissionResult(val granted: Boolean, val uri: String, val error: String? = null)
