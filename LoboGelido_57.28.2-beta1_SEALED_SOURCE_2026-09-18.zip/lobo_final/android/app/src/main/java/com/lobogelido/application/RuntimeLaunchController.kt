package com.lobogelido.application

import android.content.Context
import android.net.Uri
import com.lobogelido.RuntimeBridgeFacade
import com.lobogelido.RuntimeBridgeFacadeImpl
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Owns SAF-to-native FD transfer and runtime session orchestration. */
class RuntimeLaunchController(context: Context, private val runtime: RuntimeBridgeFacade = RuntimeBridgeFacadeImpl) {
    private val resolver = context.applicationContext.contentResolver
    private val executor: ExecutorService = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "LoboRuntimeLaunch").apply { isDaemon = true }
    }

    enum class LaunchState { STARTED, FAILED }

    data class Result(
        val state: LaunchState,
        val message: String,
        val compatibility: String? = null
    )

    fun startAsync(gameId: String, selectedTitle: String, library: GameLibraryFacade, sessions: SessionFacade, onComplete: (Result) -> Unit) {
        executor.execute {
            val result = start(gameId, selectedTitle, library, sessions)
            onComplete(result)
        }
    }

    private fun start(gameId: String, selectedTitle: String, library: GameLibraryFacade, sessions: SessionFacade): Result {
        val entry = library.entries().firstOrNull { it.id == gameId || it.title == selectedTitle }
            ?: return Result(LaunchState.FAILED, "Ese juego ya no está disponible. La biblioteca se actualizó.")
        val uri = runCatching { Uri.parse(entry.uri) }.getOrNull()
            ?: return Result(LaunchState.FAILED, "No se pudo resolver el contenido del juego.")
        val descriptor = runCatching { resolver.openFileDescriptor(uri, "r") }.getOrNull()
            ?: return Result(LaunchState.FAILED, "No se pudo abrir el archivo del juego.")

        val fd = runCatching { descriptor.detachFd() }.getOrElse {
            descriptor.close()
            return Result(LaunchState.FAILED, "No se pudo entregar el archivo al runtime.")
        }
        if (!runtime.selectContentFd(fd)) {
            runCatching { android.system.Os.close(fd) }
            return Result(LaunchState.FAILED, "El runtime rechazó el contenido seleccionado.")
        }
        runCatching { android.system.Os.close(fd) }

        sessions.setPreparing(entry.title)
        if (!runtime.prepareSession()) {
            library.setCompatibility(entry.id, "No inició: el runtime rechazó el contenido")
            runCatching { runtime.stopSession() }
            sessions.suspend()
            return Result(LaunchState.FAILED, "El runtime no pudo preparar este contenido.")
        }
        if (!runtime.startSession()) {
            library.setCompatibility(entry.id, "No inició: error del runtime")
            sessions.suspend()
            return Result(LaunchState.FAILED, "El runtime no pudo iniciar esta sesión.")
        }

        library.setCompatibility(entry.id, "Inició correctamente en este dispositivo")
        library.markPlayed(entry.id)
        sessions.setRunning(entry.title)
        return Result(LaunchState.STARTED, "", "Inició correctamente en este dispositivo")
    }
}
