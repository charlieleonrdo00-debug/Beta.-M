package com.lobogelido

import android.content.Context

/** Durable consumer session state: enough for a console-like resume surface. */
class GameSessionStore(context: Context) {
    enum class State { IDLE, PREPARING, RUNNING, SUSPENDED }
    private val prefs = context.getSharedPreferences("lobo_session_v1", Context.MODE_PRIVATE)

    fun state(): State = runCatching { State.valueOf(prefs.getString("state", State.IDLE.name)!!) }.getOrDefault(State.IDLE)
    fun game(): String? = prefs.getString("game", null)
    fun startedAt(): Long = prefs.getLong("started", 0L)
    fun setPreparing(game: String) = prefs.edit().putString("game", game).putLong("started", System.currentTimeMillis()).putString("state", State.PREPARING.name).apply()
    fun setRunning(game: String) = prefs.edit().putString("game", game).putLong("started", System.currentTimeMillis()).putString("state", State.RUNNING.name).apply()
    fun suspend() = prefs.edit().putString("state", State.SUSPENDED.name).apply()
    fun clear() = prefs.edit().remove("game").remove("started").putString("state", State.IDLE.name).apply()
    fun hasResume(): Boolean = state() == State.SUSPENDED && !game().isNullOrBlank()
}
