package com.lobogelido.data.games

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.lobogelido.domain.games.*
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Android data source for game folders, metadata and library state. */
class AndroidGameRepository(context: Context) :
    GameDiscovery, GameRepository, GameFolderManager, FileAccessProvider, ArtworkResolver {

    private val app = context.applicationContext
    private val catalog = app.getSharedPreferences("lobo_catalog_v6", Context.MODE_PRIVATE)
    private val folders = app.getSharedPreferences("lobo_game_folders_v3", Context.MODE_PRIVATE)
    private val supported = setOf("nsp", "xci", "nca", "nro", "nso", "nsz", "xcz")
    private val imageExtensions = setOf("jpg", "jpeg", "png", "webp")
    private val genericIcon = Artwork(
        id = "generic:lobo-logo",
        uri = "android.resource://com.lobogelido/drawable/lobo_logo_transparent",
        kind = ArtworkKind.ICON
    )
    private val _gamesFlow = MutableStateFlow<List<GameMetadata>>(emptyList())
    override val gamesFlow: StateFlow<List<GameMetadata>> = _gamesFlow.asStateFlow()

    init {
        _gamesFlow.value = loadCatalog()
    }

    override fun scan(folders: List<GameFolder>): GameScanResult {
        val results = folders.map { scanFolder(it) }
        val games = results.flatMap { it.games }.distinctBy { it.sourcePath }
        clearMissingEntries(games.map { GameSource(it.titleId.value, it.title, it.sourcePath, it.sizeBytes) }.toSet())
        publishCatalog()
        return GameScanResult(games, results.flatMap { it.skipped }, results.flatMap { it.errors })
    }

    override fun scanFolder(folder: GameFolder): GameScanResult {
        val root = runCatching { DocumentFile.fromTreeUri(app, Uri.parse(folder.sourceId)) }.getOrNull()
            ?: return GameScanResult(emptyList(), emptyList(), listOf("Carpeta no accesible: ${folder.displayName}"))
        if (!root.isDirectory || !root.canRead()) {
            return GameScanResult(emptyList(), emptyList(), listOf("Sin permisos de lectura: ${folder.displayName}"))
        }

        val games = ArrayList<GameMetadata>()
        val skipped = ArrayList<GameSource>()
        walk(root, 0, games, skipped)
        games.forEach(::upsert)
        publishCatalog()
        return GameScanResult(games, skipped, emptyList())
    }

    private fun walk(directory: DocumentFile, depth: Int, games: MutableList<GameMetadata>, skipped: MutableList<GameSource>) {
        if (depth > 8) return
        val children = runCatching { directory.listFiles() }.getOrDefault(emptyArray())
        for (file in children) {
            if (file.isDirectory) {
                walk(file, depth + 1, games, skipped)
                continue
            }
            if (!file.isFile || !file.canRead()) continue
            val name = file.name.orEmpty()
            val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (extension !in supported) continue
            val path = file.uri.toString()
            val id = GameId("uri:$path")
            val persisted = persisted(id)
            val format = when (extension) {
                "nsp" -> GameFormat.NSP
                "xci" -> GameFormat.XCI
                "nca" -> GameFormat.NCA
                "nro" -> GameFormat.NRO
                "nso" -> GameFormat.NSO
                "nsz" -> GameFormat.NSZ
                "xcz" -> GameFormat.XCZ
                else -> GameFormat.UNKNOWN
            }
            val localCover = findCover(directory, name)
            games += GameMetadata(
                title = persisted.title ?: cleanTitle(name),
                titleId = id,
                publisher = persisted.publisher,
                version = persisted.version,
                region = persisted.region,
                icon = persisted.icon ?: genericIcon,
                cover = localCover ?: persisted.cover,
                format = format,
                sourcePath = path,
                sizeBytes = file.length().coerceAtLeast(0L),
                modifiedEpoch = file.lastModified().coerceAtLeast(0L),
                lastPlayedEpoch = persisted.lastPlayedEpoch,
                favorite = persisted.favorite,
                compatibility = persisted.compatibility,
                installed = true
            )
        }
    }

    private fun findCover(directory: DocumentFile, gameName: String): Artwork? {
        val base = gameName.substringBeforeLast('.').lowercase(Locale.ROOT)
        val candidates = setOf(base, "cover", "folder", "poster", "boxart", "thumb", "icon")
        return runCatching { directory.listFiles().asSequence() }
            .getOrDefault(emptySequence())
            .firstOrNull { f ->
                f.isFile && f.canRead() &&
                    f.name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT) in imageExtensions &&
                    f.name.orEmpty().substringBeforeLast('.').lowercase(Locale.ROOT) in candidates
            }?.let { Artwork("local:${it.uri}", it.uri.toString(), ArtworkKind.COVER) }
    }

    override fun refresh(gameId: GameId): GameMetadata? = getById(gameId)

    override fun getAll(): List<GameMetadata> =
        _gamesFlow.value.ifEmpty { loadCatalog() }.sortedBy { it.title.lowercase(Locale.ROOT) }

    override fun getById(id: GameId): GameMetadata? = findByPath(id.value.removePrefix("uri:"))

    override fun upsert(game: GameMetadata) {
        val key = key(game.sourcePath)
        val sources = catalog.getStringSet("sources", emptySet()).orEmpty().toMutableSet()
        sources += game.sourcePath
        catalog.edit()
            .putStringSet("sources", sources)
            .putString("title_$key", game.title)
            .putString("version_$key", game.version)
            .putString("publisher_$key", game.publisher)
            .putString("region_$key", game.region)
            .putString("cover_$key", game.cover?.uri)
            .putString("icon_$key", game.icon?.uri)
            .putLong("size_$key", game.sizeBytes)
            .putLong("modified_$key", game.modifiedEpoch)
            .putLong("recent_$key", game.lastPlayedEpoch)
            .putBoolean("fav_$key", game.favorite)
            .putString("compat_$key", game.compatibility)
            .putString("format_$key", game.format.name)
            .apply()
        publishCatalog()
    }

    override fun remove(id: GameId) {
        val path = id.value.removePrefix("uri:")
        val key = key(path)
        val sources = catalog.getStringSet("sources", emptySet()).orEmpty().filterNot { it == path }.toSet()
        catalog.edit().putStringSet("sources", sources).apply()
        catalog.edit().also { e ->
            listOf("title", "version", "publisher", "region", "cover", "icon", "size", "modified", "recent", "fav", "compat", "format")
                .forEach { e.remove("${it}_$key") }
        }.apply()
        publishCatalog()
    }

    override fun clearMissingEntries(existingSources: Set<GameSource>) {
        val valid = existingSources.map { it.path }.toSet()
        val current = catalog.getStringSet("sources", emptySet()).orEmpty()
        val stale = current - valid
        stale.forEach { path -> remove(GameId("uri:$path")) }
        publishCatalog()
    }

    override fun setFavorite(id: GameId, favorite: Boolean) {
        catalog.edit().putBoolean("fav_${key(id.value.removePrefix("uri:"))}", favorite).apply()
        publishCatalog()
    }

    override fun setPlayed(id: GameId, epochMillis: Long) {
        catalog.edit().putLong("recent_${key(id.value.removePrefix("uri:"))}", epochMillis.coerceAtLeast(0L)).apply()
        publishCatalog()
    }

    override fun setCompatibility(id: GameId, value: String) {
        catalog.edit().putString("compat_${key(id.value.removePrefix("uri:"))}", value.ifBlank { "No evaluada" }).apply()
        publishCatalog()
    }

    override fun setVersion(id: GameId, value: String?) {
        val editor = catalog.edit()
        val k = "version_${key(id.value.removePrefix("uri:"))}"
        if (value.isNullOrBlank()) editor.remove(k) else editor.putString(k, value)
        editor.apply()
        publishCatalog()
    }

    override fun addFolder(source: GameFolderSource): GameFolder {
        val id = source.id.trim()
        require(id.isNotEmpty()) { "La referencia SAF de la carpeta no puede estar vacía." }
        val current = folders.getStringSet("folders", emptySet()).orEmpty().toMutableSet()
        current += id
        folders.edit().putStringSet("folders", current).apply()
        return GameFolder(GameFolderId(id), source.displayName.ifBlank { "Juegos" }, id)
    }

    override fun removeFolder(folderId: GameFolderId) {
        folders.edit().putStringSet("folders", folders.getStringSet("folders", emptySet()).orEmpty() - folderId.value).apply()
    }

    override fun getFolders(): List<GameFolder> = folders.getStringSet("folders", emptySet()).orEmpty()
        .map { id -> GameFolder(GameFolderId(id), Uri.parse(id).lastPathSegment ?: "Juegos", id) }

    override fun validateAccess(folder: GameFolder): FolderAccessResult {
        val root = runCatching { DocumentFile.fromTreeUri(app, Uri.parse(folder.sourceId)) }.getOrNull()
        return if (root?.isDirectory == true && root.canRead()) FolderAccessResult(true)
        else FolderAccessResult(false, "Sin acceso de lectura a la carpeta.")
    }

    override fun open(source: GameSource): FileHandle = FileHandle(source.path)
    override fun list(folder: GameFolder): List<GameSource> = scanFolder(folder).games.map { GameSource(it.titleId.value, it.title, it.sourcePath, it.sizeBytes) }
    override fun exists(source: GameSource): Boolean = runCatching {
        DocumentFile.fromSingleUri(app, Uri.parse(source.path))?.let { it.exists() && it.isFile && it.canRead() } == true
    }.getOrDefault(false)

    override fun resolve(game: GameMetadata): ArtworkResolution = when {
        game.cover != null -> ArtworkResolution(game.cover, "local", listOf("local"))
        game.icon != null -> ArtworkResolution(game.icon, "local-icon", listOf("local", "icon"))
        else -> ArtworkResolution(null, null, listOf("local", "icon"))
    }

    private data class Persisted(
        val title: String?, val version: String?, val publisher: String?, val region: String?,
        val cover: Artwork?, val icon: Artwork?, val lastPlayedEpoch: Long, val favorite: Boolean,
        val compatibility: String
    )

    private fun persisted(id: GameId): Persisted {
        val k = key(id.value.removePrefix("uri:"))
        return Persisted(
            catalog.getString("title_$k", null), catalog.getString("version_$k", null),
            catalog.getString("publisher_$k", null), catalog.getString("region_$k", null),
            catalog.getString("cover_$k", null)?.let { Artwork("persisted-cover:$it", it, ArtworkKind.COVER) },
            catalog.getString("icon_$k", null)?.let { Artwork("persisted-icon:$it", it, ArtworkKind.ICON) },
            catalog.getLong("recent_$k", 0L), catalog.getBoolean("fav_$k", false),
            catalog.getString("compat_$k", "No evaluada") ?: "No evaluada"
        )
    }

    private fun findByPath(path: String): GameMetadata? {
        val sources = catalog.getStringSet("sources", emptySet()).orEmpty()
        if (path !in sources) return null
        val id = GameId("uri:$path")
        val p = persisted(id)
        val formatName = catalog.getString("format_${key(path)}", null) ?: path.substringAfterLast('.', "").uppercase(Locale.ROOT)
        val format = runCatching { GameFormat.valueOf(formatName) }.getOrDefault(GameFormat.UNKNOWN)
        return GameMetadata(
            title = p.title ?: cleanTitle(path.substringAfterLast('/')), titleId = id,
            publisher = p.publisher, version = p.version, region = p.region, icon = p.icon ?: genericIcon, cover = p.cover,
            format = format, sourcePath = path, sizeBytes = catalog.getLong("size_${key(path)}", 0L),
            modifiedEpoch = catalog.getLong("modified_${key(path)}", 0L), lastPlayedEpoch = p.lastPlayedEpoch,
            favorite = p.favorite, compatibility = p.compatibility, installed = true
        )
    }

    private fun loadCatalog(): List<GameMetadata> =
        catalog.getStringSet("sources", emptySet()).orEmpty()
            .mapNotNull(::findByPath)
            .sortedBy { it.title.lowercase(Locale.ROOT) }

    private fun publishCatalog() {
        _gamesFlow.value = loadCatalog()
    }

    private fun key(path: String): String = Integer.toUnsignedString(path.hashCode())
    private fun cleanTitle(name: String): String = name.substringBeforeLast('.')
        .replace(Regex("\\[.*?\\]"), "").replace(Regex("\\(.*?\\)"), "")
        .replace('_', ' ').replace(Regex("\\s+"), " ").trim().ifBlank { "Juego" }
}
