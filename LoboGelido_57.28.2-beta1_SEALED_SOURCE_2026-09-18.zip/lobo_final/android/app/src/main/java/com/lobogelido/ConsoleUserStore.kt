package com.lobogelido

import android.content.Context

/** Consumer-facing profile state. Keeps identity separate from emulator/runtime state. */
class ConsoleUserStore(context: Context) {
    private val prefs = context.getSharedPreferences("lobo_users_v1", Context.MODE_PRIVATE)

    data class User(val id: String, val name: String, val accent: Int, val active: Boolean)

    fun users(): List<User> = listOf(
        User("player1", prefs.getString("name_player1", "Jugador 1") ?: "Jugador 1", 0xFF30D2FF.toInt(), activeId() == "player1"),
        User("guest", "Invitado", 0xFFE048E0.toInt(), activeId() == "guest")
    )

    fun activeId(): String = prefs.getString("active", "player1") ?: "player1"
    fun active(): User = users().first { it.active }
    fun select(id: String) { prefs.edit().putString("active", id).apply() }
    fun renameActive(name: String) { prefs.edit().putString("name_${activeId()}", name.trim().ifBlank { "Jugador 1" }).apply() }
}
