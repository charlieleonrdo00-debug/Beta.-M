package com.lobogelido.domain.keys

/** Contract for importing and validating user-provided key material without exposing secrets to UI/logs. */
interface KeyManager {
    fun inspect(source: KeySource): KeyInspection
    fun import(source: KeySource, options: KeyImportOptions): KeyImportResult
    fun validate(): KeyValidationResult
    fun getStatus(): KeyStoreStatus
    fun remove(keyType: KeyType): KeyOperationResult
}

interface KeyFileParser {
    fun parse(source: KeySource): ParsedKeyFile
}

interface KeyValidator {
    fun validate(keys: ParsedKeyFile, context: KeyValidationContext): KeyValidationResult
}

interface SecureKeyStore {
    fun store(keys: ValidatedKeys)
    fun hasRequiredKeys(): Boolean
    fun getStatus(): KeyStoreStatus
    fun remove(type: KeyType): KeyOperationResult
}

enum class KeyType { PROD, TITLE, DEVICE, OTHER }
data class KeySource(val id: String, val displayName: String, val sizeBytes: Long)
data class KeyImportOptions(val replaceExisting: Boolean = false)
data class KeyInspection(val source: KeySource, val detectedTypes: Set<KeyType>, val parseable: Boolean, val errors: List<String>)
data class ParsedKey(val type: KeyType, val identifier: String)
data class ParsedKeyFile(val sourceId: String, val keys: List<ParsedKey>, val errors: List<String>)
data class KeyValidationContext(val requiredTypes: Set<KeyType>)
data class ValidatedKeys(val keys: List<ParsedKey>)
data class KeyValidationResult(val valid: Boolean, val usableTypes: Set<KeyType>, val missingTypes: Set<KeyType>, val errors: List<String>)
data class KeyImportResult(val success: Boolean, val importedCount: Int, val errors: List<String>)
data class KeyStoreStatus(val availableTypes: Set<KeyType>, val functional: Boolean)
data class KeyOperationResult(val success: Boolean, val error: String? = null)
