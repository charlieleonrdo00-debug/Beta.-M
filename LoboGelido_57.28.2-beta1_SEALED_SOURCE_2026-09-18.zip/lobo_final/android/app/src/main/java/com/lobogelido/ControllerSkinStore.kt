package com.lobogelido

import android.content.Context
import android.graphics.Color
import java.io.File

/** Persistent Nintendo Switch touch-controller skin catalog. */
data class ControllerSkin(
    val id: String,
    val name: String,
    val author: String,
    val description: String,
    val buttons: Int,
    val installed: Boolean = false,
    val source: String = "Lobo Gélido"
)

class ControllerSkinStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("lobo_controller_skins", Context.MODE_PRIVATE)
    private val root = File(context.filesDir, "controller_skins").apply { mkdirs() }

    fun catalog(): List<ControllerSkin> = listOf(
        ControllerSkin("joycon-neon", "Neon Joy-Con", "Lobo Gélido", "Azul hielo + rojo neón", 16),
        ControllerSkin("joycon-blue", "Ice Blue", "Lobo Gélido", "Joy-Con azul glacial", 16),
        ControllerSkin("joycon-red", "Arctic Red", "Lobo Gélido", "Joy-Con rojo ártico", 16),
        ControllerSkin("switch-gray", "Switch Gray", "Lobo Gélido", "Estilo gris clásico", 16),
        ControllerSkin("pro-ice", "Pro Controller Ice", "Lobo Gélido", "Control Pro en acabado hielo", 18),
        ControllerSkin("handheld-ice", "Handheld Frost", "Lobo Gélido", "Modo portátil compacto", 14),
        ControllerSkin("oled-white", "OLED White", "Lobo Gélido", "Joy-Con blanco OLED", 16),
        ControllerSkin("midnight", "Midnight", "Lobo Gélido", "Negro profundo + cyan", 16)
    ).map { it.copy(installed = isInstalled(it.id)) }

    fun imported(): List<ControllerSkin> = root.listFiles()?.filter { it.isDirectory }?.map { dir ->
        ControllerSkin(
            id = "imported_${dir.name}",
            name = dir.name.replace('_', ' '),
            author = "Importado",
            description = "Máscara personalizada para Nintendo Switch",
            buttons = dir.listFiles()?.count { it.extension.equals("png", true) } ?: 0,
            installed = true,
            source = "Usuario"
        )
    } ?: emptyList()

    fun all(): List<ControllerSkin> = catalog() + imported()

    fun isInstalled(id: String) = prefs.getBoolean("installed_$id", false)

    fun install(id: String) {
        prefs.edit().putBoolean("installed_$id", true).putString("active", id).apply()
    }

    fun uninstall(id: String) {
        prefs.edit().remove("installed_$id").apply()
    }

    fun active(): String = prefs.getString("active", "joycon-neon") ?: "joycon-neon"
    fun setActive(id: String) { prefs.edit().putString("active", id).apply() }

    fun importDirectory(name: String, files: List<Pair<String, ByteArray>>) {
        val safe = name.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "custom_skin" }
        val dir = File(root, safe).apply { mkdirs() }
        files.forEach { (filename, bytes) ->
            File(dir, filename.substringAfterLast('/')).writeBytes(bytes)
        }
        prefs.edit().putBoolean("installed_imported_$safe", true).putString("active", "imported_$safe").apply()
    }

    fun removeImported(id: String) {
        if (!id.startsWith("imported_")) return
        val name = id.removePrefix("imported_")
        File(root, name).deleteRecursively()
        prefs.edit().remove("installed_$id").apply()
    }

    fun accentFor(id: String): Int = when (id) {
        "joycon-red" -> Color.rgb(255, 70, 80)
        "joycon-blue", "pro-ice", "handheld-ice" -> Color.rgb(48, 210, 255)
        "joycon-neon" -> Color.rgb(224, 72, 224)
        "oled-white" -> Color.rgb(230, 240, 255)
        "midnight" -> Color.rgb(48, 210, 255)
        else -> Color.rgb(120, 150, 190)
    }
}
