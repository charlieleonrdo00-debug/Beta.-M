package com.lobogelido

import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/**
 * Single source of visual truth aligned to the official Lobo Gélido mockup.
 * Dark navy ice + cyan accents + crisp cards.
 */
object LoboTheme {
    // Surfaces
    val bg = Color.rgb(5, 11, 19)
    val bgDeep = Color.rgb(3, 7, 13)
    val panel = Color.rgb(8, 18, 30)
    val panel2 = Color.rgb(10, 22, 36)
    val panel3 = Color.rgb(12, 30, 48)
    val panelActive = Color.rgb(15, 39, 61)

    // Lines
    val line = Color.rgb(29, 61, 91)
    val lineSoft = Color.rgb(20, 43, 66)
    val lineCyan = Color.rgb(52, 120, 158)

    // Text
    val text = Color.rgb(241, 245, 249)
    val textSoft = Color.rgb(200, 214, 230)
    val muted = Color.rgb(137, 158, 178)

    // Accent colors
    val cyan = Color.rgb(70, 166, 216)
    val cyanBright = Color.rgb(108, 194, 230)
    val blue = Color.rgb(32, 105, 176)
    val blueDeep = Color.rgb(27, 91, 151)
    val magenta = Color.rgb(70, 166, 216)
    val green = Color.rgb(52, 211, 153)
    val greenSolid = Color.rgb(16, 185, 129)
    val warning = Color.rgb(251, 191, 36)
    val danger = Color.rgb(248, 113, 113)

    fun rounded(fill: Int, stroke: Int = line, radiusDp: Float, strokeWidthPx: Int = 1): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            setStroke(strokeWidthPx, stroke)
            cornerRadius = radiusDp
        }

    fun primaryButtonBg(radiusDp: Float): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(blue, blueDeep)
        ).apply {
            cornerRadius = radiusDp
            setStroke(1, cyanBright)
        }

    fun sidebarActiveBg(radiusDp: Float): GradientDrawable =
        rounded(panelActive, cyan, radiusDp)

    fun cardBg(radiusDp: Float, active: Boolean = false): GradientDrawable =
        rounded(if (active) panelActive else panel, if (active) cyan else line, radiusDp)
}
