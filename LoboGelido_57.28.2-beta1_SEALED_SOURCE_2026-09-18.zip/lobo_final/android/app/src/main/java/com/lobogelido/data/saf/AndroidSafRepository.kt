package com.lobogelido.data.saf

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.lobogelido.domain.saf.SafPermissionRepository
import com.lobogelido.domain.saf.SafPermissionResult

class AndroidSafRepository(context: Context) : SafPermissionRepository {
    private val app = context.applicationContext

    override fun persist(uri: String, write: Boolean): SafPermissionResult {
        val parsed = runCatching { Uri.parse(uri) }.getOrNull()
            ?: return SafPermissionResult(false, uri, "URI SAF no válida.")
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
            if (write) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0
        return runCatching {
            app.contentResolver.takePersistableUriPermission(parsed, flags)
            SafPermissionResult(true, uri)
        }.getOrElse { SafPermissionResult(false, uri, it.message ?: "No se pudo persistir el permiso SAF.") }
    }

    override fun canRead(uri: String): Boolean {
        val parsed = runCatching { Uri.parse(uri) }.getOrNull() ?: return false
        return runCatching {
            app.contentResolver.openInputStream(parsed)?.use { it.read() >= 0 } == true
        }.getOrDefault(false)
    }

    fun open(uri: String) = app.contentResolver.openInputStream(Uri.parse(uri))
    fun openFileDescriptor(uri: String) = app.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
}
