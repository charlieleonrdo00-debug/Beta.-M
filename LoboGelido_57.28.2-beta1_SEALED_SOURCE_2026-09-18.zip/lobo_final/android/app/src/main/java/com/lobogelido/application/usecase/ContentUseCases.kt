package com.lobogelido.application.usecase

import com.lobogelido.domain.firmware.*
import com.lobogelido.domain.keys.*
import com.lobogelido.domain.saf.SafPermissionResult

class PersistSafPermission(private val repository: com.lobogelido.domain.saf.SafPermissionRepository) {
    fun execute(uri: String, write: Boolean = false): SafPermissionResult = repository.persist(uri, write)
}

class ImportKeysUseCase(private val manager: KeyManager) {
    fun execute(uri: String, displayName: String, sizeBytes: Long = 0L, replace: Boolean = false): KeyImportResult =
        manager.import(KeySource(uri, displayName, sizeBytes), KeyImportOptions(replace))
}

class ValidateKeysUseCase(private val manager: KeyManager) { fun execute(): KeyValidationResult = manager.validate() }
class InspectKeysUseCase(private val manager: KeyManager) {
    fun execute(uri: String, displayName: String, sizeBytes: Long = 0L): KeyInspection =
        manager.inspect(KeySource(uri, displayName, sizeBytes))
}
class InstallFirmwareUseCase(private val manager: FirmwareManager) {
    fun execute(uri: String, displayName: String, sizeBytes: Long = 0L, replace: Boolean = false): FirmwareInstallResult =
        manager.install(FirmwareSource(uri, displayName, sizeBytes), FirmwareInstallOptions(replace, true))
}
class InspectFirmwareUseCase(private val manager: FirmwareManager) {
    fun execute(uri: String, displayName: String, sizeBytes: Long = 0L): FirmwareInspection =
        manager.inspect(FirmwareSource(uri, displayName, sizeBytes))
}
