package com.lobogelido

/** Converts the native diagnostics contract into UI-safe key/value data. */
data class DiagnosticsViewState(
    val status: String = "Sin datos",
    val advice: String = "No hay un diagnóstico real disponible todavía.",
    val metrics: List<Pair<String, String>> = emptyList(),
    val raw: String = ""
)

object DiagnosticsPresenter {
    fun parse(raw: String): DiagnosticsViewState {
        val parts = raw.split(';').filter { it.isNotBlank() }
        val status = parts.firstOrNull { it.startsWith("Estado:") }?.substringAfter(':')?.trim() ?: "Sin datos"
        val advice = parts.firstOrNull { it.startsWith("Consejo:") }?.substringAfter(':')?.trim()
            ?: "No hay un diagnóstico real disponible todavía."
        val metrics = parts.filterNot { it.startsWith("Estado:") || it.startsWith("Consejo:") }
            .mapNotNull { p -> p.split(':', limit = 2).takeIf { it.size == 2 }?.let { it[0].trim() to it[1].trim() } }
        return DiagnosticsViewState(status, advice, metrics, raw)
    }
}
