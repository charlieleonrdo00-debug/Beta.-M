package com.lobogelido

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.SurfaceHolder
import android.view.SurfaceView
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Real Android presentation surface.
 *
 * The Activity no longer paints a gradient/logo as the "game". Vulkan owns this
 * SurfaceView and presents through RuntimeBridge. If native runtime execution
 * fails, the view stops instead of inventing gameplay.
 */
class GameSurfaceView(
    context: Context,
    private val onRuntimeError: (String) -> Unit = {}
) : SurfaceView(context), SurfaceHolder.Callback {

    private val running = AtomicBoolean(false)
    private var renderThread: Thread? = null

    init {
        holder.addCallback(this)
        setBackgroundColor(Color.BLACK)
        isFocusable = true
    }

    @Synchronized
    override fun surfaceCreated(holder: SurfaceHolder) {
        stopRendering()
        val ok = try { RuntimeBridge.initializeVulkan(holder.surface) } catch (_: Throwable) { false }
        if (!ok) {
            onRuntimeError("No se pudo inicializar Vulkan en la superficie de juego.")
            return
        }
        running.set(true)
        renderThread = Thread({
            val frameNs = 1_000_000_000L / 60L
            while (running.get()) {
                val started = System.nanoTime()
                val runtimeOk: Boolean
                val presentOk: Boolean
                if (BuildConfig.VULKAN_SMOKE_TEST) {
                    runtimeOk = true
                    presentOk = try { RuntimeBridge.drawVulkanClearFrame() } catch (_: Throwable) { false }
                } else {
                    runtimeOk = try { RuntimeBridge.runRuntimeFrame() } catch (_: Throwable) { false }
                    presentOk = try { RuntimeBridge.drawVulkanFrame() } catch (_: Throwable) { false }
                }

                if (!runtimeOk || !presentOk) {
                    running.set(false)
                    val reason = if (!runtimeOk)
                        "El runtime detuvo la sesión: contenido no ejecutable o fallo de CPU."
                    else
                        "Vulkan no pudo presentar el frame."
                    post { onRuntimeError(reason) }
                    break
                }

                val remaining = frameNs - (System.nanoTime() - started)
                if (remaining > 0) {
                    try {
                        Thread.sleep(remaining / 1_000_000L, (remaining % 1_000_000L).toInt())
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
        }, "LoboGélido-Render").also {
            it.isDaemon = true
            it.start()
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        // VulkanPresenter recreates the swapchain on OUT_OF_DATE/SUBOPTIMAL.
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        stopRendering()
        try { RuntimeBridge.shutdownVulkan() } catch (_: Throwable) {}
    }

    @Synchronized
    fun stopRendering() {
        running.set(false)
        val thread = renderThread
        if (thread != null && thread !== Thread.currentThread()) {
            thread.interrupt()
            try {
                thread.join(2_000L)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
        renderThread = null
    }

    override fun onDetachedFromWindow() {
        stopRendering()
        super.onDetachedFromWindow()
    }
}

/**
 * Touch-only Switch-style input layer. It is deliberately separate from the
 * renderer so skins can change the appearance without changing input logic.
 *
 * Actions are a native input contract; the runtime can consume the same state
 * without the Activity knowing CPU/GPU implementation details.
 */
class SwitchTouchOverlay(context: Context) : android.view.View(context) {
    companion object {
        const val DPAD_UP = 0
        const val DPAD_DOWN = 1
        const val DPAD_LEFT = 2
        const val DPAD_RIGHT = 3
        const val A = 4
        const val B = 5
        const val X = 6
        const val Y = 7
        const val L = 8
        const val R = 9
        const val PLUS = 10
        const val MINUS = 11
        const val HOME = 12
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val activePointers = mutableMapOf<Int, Int>()
    private val pressed = mutableSetOf<Int>()

    override fun onDraw(c: android.graphics.Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val r = (w.coerceAtMost(h) * 0.045f).coerceAtLeast(22f)

        fun button(rect: RectF, label: String, action: Int) {
            fill.color = if (action in pressed) Color.argb(205, 35, 130, 235)
                else Color.argb(125, 5, 14, 27)
            c.drawRoundRect(rect, r * .35f, r * .35f, fill)
            fill.style = Paint.Style.STROKE
            fill.strokeWidth = 2f
            fill.color = Color.argb(150, 120, 205, 255)
            c.drawRoundRect(rect, r * .35f, r * .35f, fill)
            fill.style = Paint.Style.FILL
            text.textSize = r * .48f
            c.drawText(label, rect.centerX(), rect.centerY() - (text.ascent() + text.descent()) / 2, text)
        }

        // Left D-pad
        val cx = w * .18f
        val cy = h * .72f
        val d = r * 1.55f
        button(RectF(cx-d*.35f, cy-d, cx+d*.35f, cy-d*.28f), "▲", DPAD_UP)
        button(RectF(cx-d*.35f, cy+d*.28f, cx+d*.35f, cy+d), "▼", DPAD_DOWN)
        button(RectF(cx-d, cy-d*.35f, cx-d*.28f, cy+d*.35f), "◀", DPAD_LEFT)
        button(RectF(cx+d*.28f, cy-d*.35f, cx+d, cy+d*.35f), "▶", DPAD_RIGHT)

        // ABXY
        val bx = w * .82f
        val by = h * .70f
        button(RectF(bx-r*.7f, by-r*2.0f, bx+r*.7f, by-r*.6f), "X", X)
        button(RectF(bx-r*2.0f, by-r*.7f, bx-r*.6f, by+r*.7f), "Y", Y)
        button(RectF(bx+r*.6f, by-r*.7f, bx+r*2.0f, by+r*.7f), "A", A)
        button(RectF(bx-r*.7f, by+r*.6f, bx+r*.7f, by+r*2.0f), "B", B)

        // Shoulder/system controls
        val top = h * .12f
        button(RectF(w*.08f, top, w*.24f, top+r*.75f), "−", MINUS)
        button(RectF(w*.76f, top, w*.92f, top+r*.75f), "+", PLUS)
        button(RectF(w*.40f, top, w*.49f, top+r*.75f), "L", L)
        button(RectF(w*.51f, top, w*.60f, top+r*.75f), "R", R)
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN,
            android.view.MotionEvent.ACTION_POINTER_DOWN -> {
                val index = e.actionIndex
                val pointer = e.getPointerId(index)
                val action = hit(e.getX(index), e.getY(index))
                if (action >= 0) {
                    activePointers[pointer] = action
                    setPressed(action, true)
                }
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val pointer = e.getPointerId(i)
                    val old = activePointers[pointer]
                    val now = hit(e.getX(i), e.getY(i))
                    if (old != now) {
                        if (old != null) setPressed(old, false)
                        if (now >= 0) {
                            activePointers[pointer] = now
                            setPressed(now, true)
                        } else {
                            activePointers.remove(pointer)
                        }
                    }
                }
            }
            android.view.MotionEvent.ACTION_UP,
            android.view.MotionEvent.ACTION_POINTER_UP,
            android.view.MotionEvent.ACTION_CANCEL -> {
                val index = if (e.actionMasked == android.view.MotionEvent.ACTION_CANCEL) -1 else e.actionIndex
                if (index >= 0) {
                    val pointer = e.getPointerId(index)
                    activePointers.remove(pointer)?.let { setPressed(it, false) }
                } else {
                    activePointers.values.toList().forEach { setPressed(it, false) }
                    activePointers.clear()
                }
            }
        }
        return activePointers.isNotEmpty() || hit(e.x, e.y) >= 0
    }

    private fun setPressed(action: Int, down: Boolean) {
        if (down) pressed.add(action) else pressed.remove(action)
        val mapped = mapAction(action)
        try { RuntimeBridge.submitInput(mapped, down) } catch (_: Throwable) {}
        invalidate()
    }

    private fun mapAction(action: Int): Int {
        val game = context.getSharedPreferences("lobo_runtime", Context.MODE_PRIVATE).getString("selected_game", "") ?: ""
        if (game.isBlank()) return action
        val prefs = context.getSharedPreferences("lobo_settings", Context.MODE_PRIVATE)
        val names = arrayOf("A","B","X","Y","L","R","ZL","ZR","START","SELECT")
        val physical = when (action) {
            A -> "A"; B -> "B"; X -> "X"; Y -> "Y"; L -> "L"; R -> "R"; PLUS -> "+"; MINUS -> "−"
            else -> return action
        }
        val default = when (physical) { "+" -> "START"; "−" -> "SELECT"; else -> physical }
        val logical = prefs.getString("map_${game.hashCode()}_$physical", default) ?: default
        return when (logical) {
            "A" -> A; "B" -> B; "X" -> X; "Y" -> Y; "L" -> L; "R" -> R; "ZL" -> 13; "ZR" -> 14; "START" -> PLUS; "SELECT" -> MINUS
            else -> action
        }
    }

    private fun hit(x: Float, y: Float): Int {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = (w.coerceAtMost(h) * 0.045f).coerceAtLeast(22f)
        val cx = w * .18f
        val cy = h * .72f
        val d = r * 1.55f
        val regions = listOf(
            RectF(cx-d*.55f, cy-d*1.15f, cx+d*.55f, cy-d*.10f) to DPAD_UP,
            RectF(cx-d*.55f, cy+d*.10f, cx+d*.55f, cy+d*1.15f) to DPAD_DOWN,
            RectF(cx-d*1.15f, cy-d*.55f, cx-d*.10f, cy+d*.55f) to DPAD_LEFT,
            RectF(cx+d*.10f, cy-d*.55f, cx+d*1.15f, cy+d*.55f) to DPAD_RIGHT
        )
        val bx = w * .82f
        val by = h * .70f
        val buttons = listOf(
            RectF(bx-r*.9f, by-r*2.2f, bx+r*.9f, by-r*.45f) to X,
            RectF(bx-r*2.2f, by-r*.9f, bx-r*.45f, by+r*.9f) to Y,
            RectF(bx+r*.45f, by-r*.9f, bx+r*2.2f, by+r*.9f) to A,
            RectF(bx-r*.9f, by+r*.45f, bx+r*.9f, by+r*2.2f) to B,
            RectF(w*.08f, h*.12f, w*.24f, h*.12f+r*.85f) to MINUS,
            RectF(w*.76f, h*.12f, w*.92f, h*.12f+r*.85f) to PLUS,
            RectF(w*.40f, h*.12f, w*.49f, h*.12f+r*.85f) to L,
            RectF(w*.51f, h*.12f, w*.60f, h*.12f+r*.85f) to R
        )
        return (regions + buttons).firstOrNull { it.first.contains(x, y) }?.second ?: -1
    }

}
