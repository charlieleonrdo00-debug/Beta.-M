package com.lobogelido

/**
 * Central UI navigation state for the Lobo Gélido shell.
 *
 * Owns:
 * - current screen id
 * - explicit back stack
 * - whether the user is inside the Settings tree
 * - light presentation state (selected game, library filter/sort)
 *
 * MainActivity still renders; it must call [enter] when opening a screen
 * and [back] when the user presses Back / ‹.
 */
class UiStateManager {

    /** Screen ids — same names as MainActivity.Screen. */
    var screen: String = "HOME"
        private set

    private val stack = ArrayDeque<String>()

    /** True while browsing a page under Ajustes (not the hub itself). */
    var settingsChild: Boolean = false
        private set

    var selectedGame: String = ""
    var libraryFilter: LibraryFilter = LibraryFilter.ALL
    var librarySort: LibrarySort = LibrarySort.NAME

    private val settingsChildren = setOf(
        "GENERAL", "GRAPHICS", "AUDIO", "CONTROLS", "SYSTEM",
        "ACCESSIBILITY", "THEMES", "SKINS", "ABOUT", "ACHIEVEMENTS",
        "GPU_DRIVERS", "GPU_OBTAIN", "MULTIPLAYER", "FILE_MANAGER", "APPLETS",
        // PROFILES only when opened from settings
        "PROFILES"
    )

    /**
     * Enter a screen.
     * @param id screen id
     * @param fromSettings mark as settings child (Back → SETTINGS)
     * @param push push current onto back stack
     * @param game optional selected game title
     */
    fun enter(
        id: String,
        fromSettings: Boolean = false,
        push: Boolean = true,
        game: String? = null
    ) {
        if (game != null) selectedGame = game

        if (id == "SETTINGS" || id == "HOME" || id == "LIBRARY") {
            settingsChild = false
        } else if (fromSettings || id in settingsChildren && id != "PROFILES") {
            settingsChild = true
        } else if (id == "PROFILES") {
            // caller decides via fromSettings
            settingsChild = fromSettings
        }

        if (push && screen != id && screen != "BOOT") {
            if (stack.lastOrNull() != screen) stack.addLast(screen)
            while (stack.size > 24) stack.removeFirst()
        }
        screen = id
    }

    /** Replace screen without stacking (refresh). */
    fun replace(id: String, fromSettings: Boolean? = null, game: String? = null) {
        if (game != null) selectedGame = game
        if (fromSettings != null) settingsChild = fromSettings
        screen = id
    }

    /**
     * Pop navigation.
     * @return target screen id, or null if app should exit.
     */
    fun back(): String? {
        // Settings tree: always return to hub before leaving
        if (settingsChild && screen != "SETTINGS") {
            if (screen == "GPU_OBTAIN") {
                screen = "GPU_DRIVERS"
                settingsChild = true
                return "GPU_DRIVERS"
            }
            // Collapse any leftover settings pages on the stack
            while (stack.lastOrNull() in settingsChildren) stack.removeLast()
            settingsChild = false
            screen = "SETTINGS"
            return "SETTINGS"
        }

        if (stack.isNotEmpty()) {
            val prev = stack.removeLast()
            screen = prev
            settingsChild = prev in settingsChildren && prev != "SETTINGS"
            return prev
        }

        return when (screen) {
            "HOME", "BOOT" -> null
            "GAME" -> "QUICK_MENU".also { screen = it }
            "QUICK_MENU" -> "GAME".also { screen = it }
            "GAME_DETAIL" -> "LIBRARY".also { screen = it }
            "SETTINGS" -> "HOME".also { screen = it; settingsChild = false }
            "LIBRARY" -> "HOME".also { screen = it }
            else -> "HOME".also { screen = it; settingsChild = false }
        }
    }

    fun clearStack() = stack.clear()

    fun depth(): Int = stack.size

    fun snapshot(): String =
        "ui{screen=$screen child=$settingsChild depth=${stack.size} game=$selectedGame}"
}
