package com.lobogelido

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Lightweight Nintendo Switch controller thumbnail; no third-party assets required. */
class SwitchSkinPreviewView(context: Context) : View(context) {
    var skinId: String = "joycon-neon"
        set(value) { field = value; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat(); val cy = h / 2f
        val gap = w * .035f; val joyW = w * .25f; val joyH = h * .68f
        val left = RectF(w*.08f, cy-joyH/2, w*.08f+joyW, cy+joyH/2)
        val right = RectF(w*.67f, cy-joyH/2, w*.67f+joyW, cy+joyH/2)
        p.color = Color.rgb(7,14,24); c.drawRoundRect(RectF(w*.34f,cy-h*.22f,w*.66f,cy+h*.22f),h*.04f,h*.04f,p)
        p.color = Color.rgb(12,24,39); c.drawRoundRect(left, h*.08f,h*.08f,p); c.drawRoundRect(right,h*.08f,h*.08f,p)
        val accent = when(skinId) {
            "joycon-red", "oled-white" -> if (skinId=="joycon-red") Color.rgb(255,70,80) else Color.rgb(235,240,248)
            "joycon-blue", "pro-ice", "handheld-ice" -> Color.rgb(48,210,255)
            "joycon-neon" -> Color.rgb(224,72,224)
            "midnight" -> Color.rgb(48,210,255)
            else -> Color.rgb(115,145,180)
        }
        p.color = accent
        c.drawRoundRect(RectF(left.left,left.top,left.right, left.top+h*.08f),h*.03f,h*.03f,p)
        c.drawRoundRect(RectF(right.left,right.top,right.right, right.top+h*.08f),h*.03f,h*.03f,p)
        p.color = Color.WHITE
        c.drawCircle(left.centerX(), cy, h*.075f,p)
        p.color = Color.rgb(25,35,48); c.drawCircle(left.centerX(),cy,h*.055f,p)
        drawCross(c,left.centerX(),cy+h*.19f,h*.05f)
        drawButton(c,right.centerX()-h*.08f,cy-h*.03f,h*.035f,"A",Color.rgb(235,245,255))
        drawButton(c,right.centerX()+h*.08f,cy+h*.06f,h*.035f,"B",Color.rgb(235,245,255))
        drawButton(c,right.centerX()+h*.08f,cy-h*.12f,h*.035f,"X",Color.rgb(235,245,255))
        drawButton(c,right.centerX()-h*.08f,cy+h*.15f,h*.035f,"Y",Color.rgb(235,245,255))
        p.color = Color.argb(80,255,255,255); c.drawRect(w*.43f,cy-h*.05f,w*.57f,cy-h*.035f,p)
    }

    private fun drawCross(c: Canvas,x:Float,y:Float,r:Float){p.color=Color.rgb(40,55,70);c.drawRect(x-r*.28f,y-r,x+r*.28f,y+r,p);c.drawRect(x-r,y-r*.28f,x+r,y+r*.28f,p)}
    private fun drawButton(c:Canvas,x:Float,y:Float,r:Float,t:String,color:Int){p.color=Color.rgb(35,48,62);c.drawCircle(x,y,r*1.35f,p);p.color=color;c.drawCircle(x,y,r*.78f,p)}
}
