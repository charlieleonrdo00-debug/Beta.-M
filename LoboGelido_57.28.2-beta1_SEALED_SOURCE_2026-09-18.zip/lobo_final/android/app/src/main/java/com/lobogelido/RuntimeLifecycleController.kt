package com.lobogelido


/**
 * Owns the Android Activity -> native runtime lifecycle policy.
 *
 * MainActivity is deliberately unaware of the native state machine details.
 * Lifecycle callbacks only pause/resume an already running session; explicit
 * navigation and destruction are the only paths that stop it.
 */
class RuntimeLifecycleController(
    private val bridge: RuntimeBridgeFacade
) {
    private var pausedByLifecycle = false
    private var destroyed = false

    fun onActivityPause() {
        if (destroyed) return
        if (bridge.sessionState() == "RUNNING") {
            pausedByLifecycle = bridge.pauseSession()
        }
    }

    fun onActivityResume() {
        if (destroyed || !pausedByLifecycle) return
        if (bridge.sessionState() == "PAUSED") {
            if (bridge.resumeSession()) pausedByLifecycle = false
        } else {
            pausedByLifecycle = false
        }
    }

    fun stopForNavigation() {
        pausedByLifecycle = false
        if (!destroyed) bridge.stopSession()
    }

    fun destroy() {
        if (destroyed) return
        destroyed = true
        pausedByLifecycle = false
        bridge.stopSession()
    }
}

/** Small ABI-facing facade that makes lifecycle policy unit-testable. */
interface RuntimeBridgeFacade {
    fun sessionState(): String
    fun selectContentFd(fd: Int): Boolean
    fun prepareSession(): Boolean
    fun startSession(): Boolean
    fun pauseSession(): Boolean
    fun resumeSession(): Boolean
    fun stopSession(): Boolean
    fun runtimeMetrics(): String
    fun runtimeDiagnostics(): String
    fun vulkanDiagnostics(): String
    fun presenterDiagnostics(): String
    fun diagnostics(): String
}

/**
 * Defensive JNI boundary. Every native call is wrapped so a Throwable crossing
 * the JNI border (UnsatisfiedLinkError, a C++ exception surfaced as a Java
 * RuntimeException, or any Error) is contained here and turned into a safe
 * default instead of propagating up a UI/lifecycle/telemetry thread and
 * force-closing the process. Centralising it means the lifecycle controller,
 * the 250 ms telemetry poll, and the launch controller are all protected in one
 * place, with no native binding removed.
 */
object RuntimeBridgeFacadeImpl : RuntimeBridgeFacade {
    @Volatile private var lastKnownState: String = "COLD"
    private inline fun guardedString(fallback: String, block: () -> String): String =
        try { block() } catch (_: Throwable) { fallback }
    private inline fun guardedBool(block: () -> Boolean): Boolean =
        try { block() } catch (_: Throwable) { false }

    override fun sessionState(): String {
        val s = guardedString(lastKnownState) { RuntimeBridge.sessionState() }; lastKnownState = s; return s
    }
    override fun selectContentFd(fd: Int): Boolean = guardedBool { RuntimeBridge.selectContentFd(fd) }
    override fun prepareSession(): Boolean = guardedBool { RuntimeBridge.prepareSession() }
    override fun startSession(): Boolean = guardedBool { RuntimeBridge.startSession() }
    override fun pauseSession(): Boolean = guardedBool { RuntimeBridge.pauseSession() }
    override fun resumeSession(): Boolean = guardedBool { RuntimeBridge.resumeSession() }
    override fun stopSession(): Boolean = guardedBool { RuntimeBridge.stopSession() }
    override fun runtimeMetrics(): String = guardedString("") { RuntimeBridge.runtimeMetrics() }
    override fun runtimeDiagnostics(): String = guardedString("") { RuntimeBridge.runtimeDiagnostics() }
    override fun vulkanDiagnostics(): String = guardedString("") { RuntimeBridge.vulkanDiagnostics() }
    override fun presenterDiagnostics(): String = guardedString("") { RuntimeBridge.presenterDiagnostics() }
    override fun diagnostics(): String = guardedString("") { RuntimeBridge.diagnostics() }
}
