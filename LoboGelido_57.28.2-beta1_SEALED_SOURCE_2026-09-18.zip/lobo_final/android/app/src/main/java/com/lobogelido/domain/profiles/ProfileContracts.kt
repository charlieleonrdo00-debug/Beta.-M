package com.lobogelido.domain.profiles

interface ProfileRepository {
    fun get(gameId: String): GameProfile
    fun save(profile: GameProfile)
    fun reset(gameId: String)
}

enum class GamePlatformHint { GBC, GBA, GAMECUBE, WII, N3DS, OTHER }
data class GameOptimizationInput(val gameId: String, val platform: GamePlatformHint)

data class GameProfile(
    val gameId: String,
    val graphics: String = "Equilibrado",
    val resolution: Int = 100,
    val fpsLimit: Int = 60,
    val vsync: Boolean = true,
    val scaling: String = "Inteligente",
    val audio: String = "Alta",
    val controls: String = "Pro Controller",
    val shaderCache: Boolean = true,
    val jit: Boolean = false
)
