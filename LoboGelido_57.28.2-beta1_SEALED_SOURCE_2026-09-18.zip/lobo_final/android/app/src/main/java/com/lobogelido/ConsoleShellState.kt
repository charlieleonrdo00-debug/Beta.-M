package com.lobogelido

/** Pure state machine for the consumer shell. Runtime implementation can subscribe later. */
class ConsoleShellState {
    enum class Route { BOOT, HOME, LIBRARY, DETAIL, GAME, QUICK_MENU, SETTINGS }
    var route: Route = Route.BOOT
        private set
    var selectedGame: String? = null
        private set

    fun go(route: Route, game: String? = selectedGame) {
        this.route = route
        this.selectedGame = game
    }
}
