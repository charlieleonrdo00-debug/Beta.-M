package com.lobogelido

import com.lobogelido.application.*

import android.content.pm.ActivityInfo
import android.app.AlertDialog
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import android.text.InputType
import java.util.Locale
import java.lang.ref.WeakReference
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

/**
 * Lobo Gélido 57.25 — visual shell + game preview experience.
 *
 * UI architecture:
 *   AppShell -> ScreenState -> Screen renderer -> reusable components
 *   GameSession -> QuickMenu -> Performance/Diagnostics
 *   Settings -> global/device/game/session preferences
 *
 * The visual language intentionally follows the supplied Lobo Gélido references:
 * deep navy/black panels, restrained ice-blue/cyan accents, compact console rail,
 * and the user-supplied wolf mark. No decorative legacy bottom navigation.
 */
class MainActivity : AppCompatActivity() {
    private val runtimeLifecycle = RuntimeLifecycleController(RuntimeBridgeFacadeImpl)
    private val features by lazy { LoboApplicationGraph.get(applicationContext) }
    private val runtimeLaunch by lazy { RuntimeLaunchController(applicationContext) }

    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout
    private val pick = SafFacade.Request.GAME.code
    private val pickPreview = SafFacade.Request.PREVIEW.code
    private val pickSkinZip = SafFacade.Request.SKIN_ZIP.code
    private val pickSkinFolder = SafFacade.Request.SKIN_FOLDER.code
    private val pickKeys = SafFacade.Request.KEYS.code
    private val pickFirmware = SafFacade.Request.FIRMWARE.code
    private val pickGamesFolder = SafFacade.Request.GAMES_FOLDER.code
    private val pickGpuDriver = SafFacade.Request.GPU_DRIVER.code
    private val shellState = ConsoleShellState()
    private val ui = UiStateManager()
    private val previewPlayer: PreviewPlayer by lazy { NativePreviewPlayer() }
    private var libraryFilter = LibraryFilter.ALL
    private var librarySort = LibrarySort.NAME
    private var previewVideo: VideoView? = null
    private var gameSurface: GameSurfaceView? = null

    // Activity/surface lifecycle state. This state is deliberately kept outside
    // the visual hierarchy: it only coordinates the already-existing game
    // surface and native runtime.
    private val lifecycleLock = Any()
    @Volatile private var activityResumed = false
    @Volatile private var activityDestroyed = false
    @Volatile private var gameSurfaceAvailable = false
    private var runtimePausedByActivity = false
    private var observedSurface: GameSurfaceView? = null
    private val surfaceLifecycleCallback = object : android.view.SurfaceHolder.Callback {
        override fun surfaceCreated(holder: android.view.SurfaceHolder) {
            synchronized(lifecycleLock) {
                if (activityDestroyed) return
                gameSurfaceAvailable = true
                // GameSurfaceView owns the ANativeWindow/Vulkan presentation
                // lifecycle. MainActivity only records availability so it never
                // attempts to use a stale Surface after destruction.
            }
            reconcileRuntimeLifecycle()
        }

        override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) {
            synchronized(lifecycleLock) {
                if (!activityDestroyed) gameSurfaceAvailable = holder.surface?.isValid == true
            }
        }

        override fun surfaceDestroyed(holder: android.view.SurfaceHolder) {
            synchronized(lifecycleLock) {
                gameSurfaceAvailable = false
            }
            // GameSurfaceView.stopRendering() is responsible for joining its
            // render thread before its own Vulkan shutdown. Do not call native
            // Vulkan teardown from the Activity.
        }
    }

    // Palette — single source of visual truth (LoboTheme)
    private val bg get() = LoboTheme.bg
    private val panel get() = LoboTheme.panel
    private val panel2 get() = LoboTheme.panel2
    private val panel3 get() = LoboTheme.panel3
    private val line get() = LoboTheme.line
    private val lineSoft get() = LoboTheme.lineSoft
    private val text get() = LoboTheme.text
    private val muted get() = LoboTheme.muted
    private var cyan = LoboTheme.cyan
    private var blue = LoboTheme.blue
    private var magenta = LoboTheme.cyan
    private val green get() = LoboTheme.green
    private val warning get() = LoboTheme.warning
    private val danger get() = LoboTheme.danger
    private val handler = Handler(Looper.getMainLooper())
    private var perfTask: Runnable? = null
    private var bootWatchdog: Runnable? = null
    private var selectedGame: String = ""
    private val consoleHomeRenderer by lazy { LoboConsoleHomeRenderer(this) }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        // Record any uncaught crash so the next diagnostic export carries it.
        // Idempotent, guarded, and chains to the platform handler.
        LoboCrashReporter.install(this)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        applyTheme()
        configureSystemBars()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                navigateBack()
            }
        })
        showShell()
        grantAchievement("first_boot")
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        if (hour in 0..4) grantAchievement("night_owl")
        showBoot()
    }

    private fun configureSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
    }

    /** Unlock achievement and toast once when newly earned. */
    private fun grantAchievement(id: String) {
        if (features.achievements.unlock(id)) {
            val title = features.achievements.definitions().firstOrNull { it.id == id }?.title ?: id
            toast("🏆 Logro: $title")
        }
    }

    private fun evaluateCompoundAchievements() {
        val n = features.library.entries().size
        if (n >= 1) grantAchievement("first_game")
        if (n >= 5) grantAchievement("library_5")
        if (n >= 20) grantAchievement("library_20")
        val keys = features.setup.recognizeKeys(features.settings.keysUri).configured
        val fw = features.setup.recognizeFirmware(features.settings.firmwareUri).configured
        val games = features.settings.lastGamesFound > 0
        if (keys) grantAchievement("keys_set")
        if (fw) grantAchievement("firmware_set")
        if (features.settings.gpuDriverUri != null) grantAchievement("gpu_driver")
        if (keys && fw && games) grantAchievement("all_setup")
    }

    private fun showAchievements() {
        goScreen(Screen.ACHIEVEMENTS, fromSettings = true)
        clear("Logros", "Progreso local de Lobo Gélido.")
        topBar("Logros")
        nav.visibility = View.VISIBLE

        val unlocked = features.achievements.unlockedCount()
        val total = features.achievements.totalCount()
        val hero = card(14)
        hero.addView(label("🏆  Logros", 18f, text, true))
        hero.addView(label("$unlocked / $total desbloqueados", 14f, cyan, true).apply {
            setPadding(0, dp(6), 0, 0)
        })
        // Progress bar
        val rowFill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(Color.rgb(20, 32, 48), line, 8)
        }
        val pct = if (total == 0) 0 else (unlocked * 100 / total)
        rowFill.addView(View(this).apply {
            background = GradientDrawable().apply {
                setColor(cyan)
                cornerRadius = dp(8).toFloat()
            }
        }, LinearLayout.LayoutParams(0, dp(10), pct.coerceAtLeast(1).toFloat()))
        if (pct < 100) {
            rowFill.addView(View(this), LinearLayout.LayoutParams(0, dp(10), (100 - pct).toFloat()))
        }
        hero.addView(rowFill, lp(-1, dp(10)).apply { topMargin = dp(12) })
        add(hero, margin = 8)

        // Group by category
        val groups = listOf(
            "SETUP" to "Configuración",
            "LIBRARY" to "Biblioteca",
            "PLAY" to "Juego",
            "SYSTEM" to "Sistema",
            "SPECIAL" to "Especiales"
        )
        val progress = features.achievements.all()
        groups.forEach { (category, title) ->
            val items = progress.filter { it.achievement.category.name == category }
            if (items.isEmpty()) return@forEach
            val section = card(12)
            section.addView(label(title, 14f, cyan, true))
            items.forEach { p ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(8), 0, dp(8))
                    alpha = if (p.unlocked) 1f else 0.55f
                }
                row.addView(label(p.achievement.icon, 20f, text), lp(dp(36), -2))
                val col = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(8), 0, 0, 0)
                }
                col.addView(label(p.achievement.title, 13f, text, true))
                col.addView(label(p.achievement.description, 11f, muted))
                if (p.unlocked && p.unlockedAtEpoch > 0) {
                    val whenStr = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
                        .format(java.util.Date(p.unlockedAtEpoch))
                    col.addView(label("Desbloqueado · $whenStr", 10f, green))
                }
                row.addView(col, lp(0, -2, 1f))
                row.addView(label(if (p.unlocked) "✓" else "○", 16f, if (p.unlocked) green else muted, true))
                section.addView(row)
            }
            add(section, margin = 6)
        }
    }

    /**
     * Precise back stack:
     * - Stay inside Settings until user leaves the Settings hub.
     * - Sub-pages return to their parent, not to Home/Library.
     */
    private fun navigateBack() {
        when (val target = ui.back()) {
            null -> finish()
            "HOME", "BOOT" -> showHome()
            "LIBRARY" -> showLibrary()
            "GAME_DETAIL" -> showGameDetail()
            "GAME" -> showGameRuntime()
            "QUICK_MENU" -> showQuickMenu()
            "PERFORMANCE" -> showPerformance()
            "DIAGNOSTICS" -> showDiagnostics()
            "SETTINGS" -> showSettings()
            "GENERAL" -> showGeneral()
            "GRAPHICS" -> showGraphics()
            "AUDIO" -> showAudio()
            "CONTROLS" -> showControls()
            "SYSTEM" -> showSystem()
            "ACCESSIBILITY" -> showAccessibility()
            "THEMES" -> showThemes()
            "SKINS" -> showSkins()
            "PROFILES" -> showProfiles()
            "ABOUT" -> showAbout()
            "ACHIEVEMENTS" -> showAchievements()
            "GPU_DRIVERS" -> showGpuDriverManager()
            "GPU_OBTAIN" -> showGpuDriverObtain()
            else -> showHome()
        }
    }


    override fun onPause() {
        synchronized(lifecycleLock) {
            if (activityDestroyed) return
            activityResumed = false
        }

        // Pause the guest execution state, not the runtime object. This keeps
        // RAM mappings, MMU state and the JIT cache/context alive across a
        // normal Android background transition.
        runtimeLifecycle.onActivityPause()
        synchronized(lifecycleLock) {
            runtimePausedByActivity = features.runtime.state() == "PAUSED"
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        synchronized(lifecycleLock) {
            if (activityDestroyed) return
            activityResumed = true
        }
        reconcileRuntimeLifecycle()
    }

    /**
     * Reconciles Activity lifecycle with the existing native session.
     *
     * The Activity never creates/destroys an ANativeWindow and never tears
     * Vulkan down directly. Surface ownership remains in GameSurfaceView ->
     * RuntimeBridge -> NativeRuntimeHost. This prevents a stale Surface from
     * being used after surfaceDestroyed().
     */
    private fun reconcileRuntimeLifecycle() {
        val shouldResume = synchronized(lifecycleLock) {
            !activityDestroyed && activityResumed && gameSurfaceAvailable && runtimePausedByActivity
        }
        if (!shouldResume) return

        if (features.runtime.state() == "PAUSED") {
            runtimeLifecycle.onActivityResume()
            if (features.runtime.state() == "RUNNING") {
                synchronized(lifecycleLock) {
                    runtimePausedByActivity = false
                }
            }
        }
    }

    override fun onDestroy() {
        synchronized(lifecycleLock) {
            if (activityDestroyed) return
            activityDestroyed = true
            activityResumed = false
            gameSurfaceAvailable = false
            runtimePausedByActivity = false
        }

        perfTask?.let(handler::removeCallbacks)
        bootWatchdog?.let(handler::removeCallbacks)
        previewVideo?.stopPlayback()
        previewVideo = null

        // Destruction order is intentional:
        // 1) stop Java render thread and wait for it;
        // 2) GameSurfaceView tears down its Vulkan surface safely;
        // 3) only then stop the native runtime.
        gameSurface?.let { surface ->
            surface.holder.removeCallback(surfaceLifecycleCallback)
            surface.stopRendering()
        }
        observedSurface?.holder?.removeCallback(surfaceLifecycleCallback)
        observedSurface = null
        gameSurface = null
        runtimeLifecycle.destroy()
        super.onDestroy()
    }

    private enum class Screen { HOME, BOOT, LIBRARY, GAME, GAME_DETAIL, PERFORMANCE, DIAGNOSTICS, SETTINGS, GENERAL, GRAPHICS, AUDIO, CONTROLS, SYSTEM, ACCESSIBILITY, THEMES, SKINS, PROFILES, MULTIPLAYER, FILE_MANAGER, APPLETS, QUICK_MENU, ABOUT, ACHIEVEMENTS, GPU_DRIVERS, GPU_OBTAIN }
    private var currentScreen = Screen.HOME
    /** True when browsing a page under Ajustes (so Back returns to Ajustes, not Home). */
    private var settingsChild = false // kept in sync with ui.settingsChild

    private fun goScreen(s: Screen, fromSettings: Boolean = false, push: Boolean = true, game: String? = null) {
        currentScreen = s
        settingsChild = when {
            s == Screen.SETTINGS || s == Screen.HOME || s == Screen.LIBRARY ||
                s == Screen.GAME || s == Screen.QUICK_MENU || s == Screen.GAME_DETAIL ||
                s == Screen.PERFORMANCE || s == Screen.DIAGNOSTICS || s == Screen.BOOT -> false
            s == Screen.PROFILES -> fromSettings
            fromSettings -> true
            else -> settingsChild // keep if already in tree
        }
        // Auto-mark known settings children
        if (s in setOf(
                Screen.GENERAL, Screen.GRAPHICS, Screen.AUDIO, Screen.CONTROLS,
                Screen.SYSTEM, Screen.ACCESSIBILITY, Screen.THEMES, Screen.SKINS,
                Screen.ABOUT, Screen.ACHIEVEMENTS, Screen.GPU_DRIVERS, Screen.GPU_OBTAIN
            )
        ) settingsChild = true
        ui.enter(s.name, fromSettings = settingsChild, push = push, game = game)
    }

    private fun showBoot() {
        goScreen(Screen.HOME, push = false)
        shellState.go(ConsoleShellState.Route.BOOT)
        clear()
        val boot = consoleHomeRenderer.buildBoot {
            if (isFinishing) return@buildBoot
            showWelcome()
        }
        add(boot, -1)
        // Red de seguridad: si por cualquier razón la animación/hilo de arranque
        // no llama a showWelcome(), forzamos el avance para que el usuario nunca
        // quede atrapado en el logo.
        val watchdog = Runnable {
            if (!isFinishing && shellState.route == ConsoleShellState.Route.BOOT) showWelcome()
        }
        bootWatchdog = watchdog
        handler.postDelayed(watchdog, 4000L)
    }

    /** Panel 1 — Pantalla de inicio / Instalación. */
    private fun showWelcome() {
        bootWatchdog?.let { handler.removeCallbacks(it) }
        bootWatchdog = null
        goScreen(Screen.HOME, push = false)
        shellState.go(ConsoleShellState.Route.BOOT)
        clear()
        nav.visibility = View.GONE
        val welcome = consoleHomeRenderer.buildWelcome(
            versionLabel = "v57.25",
            onConnect = {
                nav.visibility = View.VISIBLE
                if (!features.settings.firstRunCompleted) showFirstRunSetup() else showLibrary()
            },
            onLanguage = { toast("Idioma: Español") }
        )
        content.addView(welcome, lp(-1, -1))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int = -1, h: Int = -2, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun label(s: String, size: Float, color: Int = text, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size * (features.settings.textScale / 100f); setTextColor(color); setPadding(dp(2), dp(2), dp(2), dp(2))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(color: Int, stroke: Int = line, radius: Int = 18) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }

    private fun card(padding: Int = 12) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
        background = rounded(panel, line, 12)
        elevation = 0f
        translationZ = 0f
        clipToOutline = true
    }

    private fun button(title: String, action: () -> Unit, hot: Boolean = false) = TextView(this).apply {
        text = title; textSize = 13f; gravity = Gravity.CENTER; isAllCaps = false
        setTextColor(if (hot) Color.WHITE else this@MainActivity.text)
        typeface = if (hot) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setPadding(dp(14), 0, dp(14), 0)
        setOnClickListener { LoboAnim.press(this); action() }
        background = rounded(if (hot) blue else panel2, if (hot) cyan else line, 10)
        minHeight = dp(40)
    }

    private fun add(v: View, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, margin: Int = 0) {
        content.addView(v, lp(-1, h).apply { setMargins(0, dp(margin), 0, 0) })
        // Fluid enter for each block added to the content column
        LoboAnim.fadeIn(v, duration = 200L, delay = (content.childCount * 18L).coerceAtMost(120L), fromY = 14f)
    }

    private fun logo(size: Int = 52) = ImageView(this).apply {
        setImageResource(R.drawable.lobo_logo_transparent)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setBackgroundColor(Color.TRANSPARENT)
    }

    private fun showShell() {
        val root = FrameLayout(this)
        root.setBackgroundColor(bg)

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bg)
        }
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))

        // Single console rail used by every normal screen. This is the reference
        // navigation: one left rail, no bottom navigation and no duplicate menus.
        nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = rounded(Color.rgb(4, 12, 21), lineSoft, 0)
        }

        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(2), dp(4), dp(2), dp(12))
        }
        brand.addView(logo(42), lp(-1, dp(44)))
        brand.addView(label("LOBO GÉLIDO", 10f, text, true).apply { gravity = Gravity.CENTER })
        brand.addView(label("SWITCH", 7.5f, cyan, true).apply { gravity = Gravity.CENTER })
        nav.addView(brand, lp(-1, dp(86)))

        data class RailItem(val icon: String, val title: String, val route: String, val action: () -> Unit)
        val items = listOf(
            RailItem("⌂", "Inicio", "HOME") { showHome() },
            RailItem("▦", "Biblioteca", "LIBRARY") { showLibrary() },
            RailItem("◌", "Rendimiento", "PERFORMANCE") { showPerformance() },
            RailItem("◉", "Diagnóstico", "DIAGNOSTICS") { showDiagnostics() },
            RailItem("♙", "Perfiles", "PROFILES") { showProfiles() },
            RailItem("⚙", "Ajustes", "SETTINGS") { showSettings() }
        )
        items.forEach { item ->
            val b = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), 0, dp(6), 0)
                isClickable = true
                isFocusable = true
                tag = item.route
                setOnClickListener { item.action() }
            }
            b.addView(label(item.icon, 15f, cyan, true).apply { gravity = Gravity.CENTER }, lp(dp(28), dp(44)))
            b.addView(label(item.title, 10.5f, muted), lp(0, dp(44), 1f))
            nav.addView(b, lp(-1, dp(44)).apply { bottomMargin = dp(3) })
        }
        nav.addView(View(this), lp(-1, 0, 1f))
        nav.addView(label("v57.25", 7.5f, muted).apply { gravity = Gravity.CENTER })
        shell.addView(nav, lp(dp(126), -1))

        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        shell.addView(main, lp(0, -1, 1f))

        // La navegación lateral es la única cabecera de la aplicación.
        // No se añade una segunda barra superior ni otro botón de Ajustes.
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(12))
            clipChildren = false
            clipToPadding = false
        }
        scroll.addView(content, ScrollView.LayoutParams(-1, -1))
        main.addView(scroll, lp(-1, 0, 1f))
        setContentView(root)
    }

    private fun clear(title: String = "", subtitle: String = "") {
        perfTask?.let(handler::removeCallbacks); perfTask = null
        previewVideo?.stopPlayback(); previewVideo = null
        content.animate().cancel()
        content.removeAllViews()
        content.alpha = 1f
        content.translationY = 0f
        if (title.isNotBlank()) {
            add(label(title, 26f, text, true))
            if (subtitle.isNotBlank()) add(label(subtitle, 12f, muted), margin = 2)
        }
        // Content column fades in as a whole for a fluid screen change
        LoboAnim.fadeIn(content, duration = 180L, delay = 0L, fromY = 10f)
    }

    private fun topBar(title: String, back: Boolean = true, onBack: (() -> Unit)? = null) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (back) {
            row.addView(button("‹", { (onBack ?: { navigateBack() }).invoke() }, false).apply {
                textSize = 22f; minHeight = dp(42); minWidth = dp(48)
            }, lp(dp(50), dp(44)))
        }
        row.addView(label(title, 22f, text, true), lp(0, -2, 1f).apply { leftMargin = dp(8) })
        row.addView(logo(40), lp(dp(42), dp(42)))
        add(row, margin = 4)
    }

    private fun showHome(){
        currentScreen=Screen.HOME
        shellState.go(ConsoleShellState.Route.HOME)
        clear()
        nav.visibility = View.VISIBLE
        val user = features.users.active()
        syncRealLibrary()
        val recent = features.library.filtered(LibraryFilter.ALL, "", LibrarySort.RECENT).take(2)
        val home = consoleHomeRenderer.buildHome(
            userName = user.name,
            selectedGame = selectedGame,
            recentGames = recent,
            onLibrary = ::showLibrary,
            onPerformance = ::showPerformance,
            onDiagnostics = ::showDiagnostics,
            onSettings = ::showSettings,
            onControls = ::showControls,
            onSkins = ::showSkins,
            onProfiles = ::showProfiles,
            onGame = { game ->
                selectedGame = game.title
                showGameDetail()
            }
        )
        content.addView(home, lp(-1, -2))
    }

    /**
     * Panel 2 — Biblioteca: sidebar + título + chips + rejilla de carátulas.
     * Logo oficial en cabecera.
     */
    private fun showLibrary() {
        syncRealLibrary()
        goScreen(Screen.LIBRARY)
        shellState.go(ConsoleShellState.Route.LIBRARY)
        clear()
        nav.visibility = View.VISIBLE

        // Brand header
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(10))
        }
        brand.addView(logo(42), lp(dp(42), dp(42)))
        val brandText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        brandText.addView(label("LOBO GÉLIDO", 16f, text, true))
        brandText.addView(label("Biblioteca · ${features.library.entries().size} títulos", 11f, muted))
        brand.addView(brandText, lp(0, -2, 1f))
        brand.addView(button("＋", { pickGame() }, true).apply {
            minWidth = dp(44); textSize = 18f
        }, lp(dp(46), dp(46)))
        add(brand)

        // The global console rail already provides navigation. Keep this screen focused
        // on the library itself; no nested/duplicated sidebar.
        // The outer shell already owns the only vertical ScrollView. Keeping the
        // library content directly inside it avoids a weighted child inside a
        // wrap-content parent, which can measure the game grid at zero height.
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        main.addView(label("Biblioteca", 22f, text, true))

        // Filter chips: Todos / Instalados / Favoritos
        val filters = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(6))
        }
        listOf(
            LibraryFilter.ALL to "Todos",
            LibraryFilter.INSTALLED to "Instalados",
            LibraryFilter.FAVORITES to "★ Favoritos"
        ).forEach { (filter, title) ->
            val active = libraryFilter == filter
            val chip = TextView(this).apply {
                text = title
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (active) Color.WHITE else muted)
                background = rounded(if (active) blue else panel2, if (active) cyan else line, 12)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener {
                    libraryFilter = filter
                    showLibrary()
                }
            }
            filters.addView(chip, lp(-2, -2).apply {
                if (filters.childCount > 0) leftMargin = dp(6)
            })
        }
        main.addView(filters)

        val search = EditText(this).apply {
            hint = "Buscar juegos…"
            setHintTextColor(muted)
            setTextColor(this@MainActivity.text)
            textSize = 14f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            background = rounded(panel2, line, 14)
            setPadding(dp(14), 0, dp(14), 0)
            minHeight = dp(44)
        }
        main.addView(search, lp(-1, dp(44)).apply { bottomMargin = dp(8) })

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            tag = "library_list"
        }
        main.addView(list, lp(-1, -2))

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderLibrary(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        content.addView(main, lp(-1, -2))

        renderLibrary("")

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        tools.addView(button("↻  Rescanear", { rescanGamesLibrary() }, false), lp(0, dp(44), 1f))
        tools.addView(button("📁  Carpeta", { pickGamesDirectory() }, false), lp(0, dp(44), 1f).apply { leftMargin = dp(8) })
        add(tools)
    }

    /** Renders a 2-column cover grid using the library's real artwork. */
    private fun renderLibrary(query: String) {
        val list = content.findViewWithTag<LinearLayout>("library_list") ?: return
        list.removeAllViews()
        val games = features.library.filtered(libraryFilter, query, librarySort)
        if (games.isEmpty()) {
            val empty = card(18)
            empty.addView(label("Biblioteca vacía", 17f, text, true))
            empty.addView(label(
                if (query.isNotBlank()) "No hay resultados para \"$query\"."
                else "Aún no hay juegos instalados. Añade un .nsp/.xci o elige una carpeta.",
                12f, muted
            ))
            empty.addView(button("＋  Añadir juego", { pickGame() }, true), lp(-1, dp(48)).apply { topMargin = dp(12) })
            empty.addView(button("📁  Carpeta de juegos", { pickGamesDirectory() }, false), lp(-1, dp(46)).apply { topMargin = dp(6) })
            list.addView(empty)
            return
        }

        var row: LinearLayout? = null
        games.forEachIndexed { index, game ->
            if (index % 2 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                list.addView(row, lp(-1, -2).apply { bottomMargin = dp(10) })
            }
            val tile = FrameLayout(this).apply {
                background = rounded(panel2, line, 14)
                clipToOutline = true
                minimumHeight = dp(160)
            }
            val cover = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                if (!game.coverUri.isNullOrBlank()) {
                    try {
                        setImageURI(Uri.parse(game.coverUri))
                    } catch (_: Exception) {
                        setBackgroundColor(Color.rgb(5, 12, 20))
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                    }
                } else {
                    setBackgroundColor(Color.rgb(5, 12, 20))
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                }
            }
            tile.addView(cover, FrameLayout.LayoutParams(-1, -1))
            if (game.coverUri.isNullOrBlank()) {
                tile.addView(label("CARÁTULA NO DISPONIBLE", 8f, muted, true).apply {
                    gravity = Gravity.CENTER
                    textAlignment = View.TEXT_ALIGNMENT_CENTER
                }, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER })
            }
            tile.addView(View(this).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(Color.TRANSPARENT, Color.argb(210, 2, 6, 12))
                )
            }, FrameLayout.LayoutParams(-1, -1))
            val caption = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM
                setPadding(dp(10), dp(8), dp(10), dp(10))
            }
            caption.addView(label(game.title, 12f, text, true))
            caption.addView(label(game.size, 10f, muted))
            tile.addView(caption, FrameLayout.LayoutParams(-1, -1))
            tile.setOnClickListener {
                selectedGame = game.title
                showGameDetail()
            }
            val cellLp = LinearLayout.LayoutParams(0, dp(170), 1f)
            if (index % 2 == 1) cellLp.leftMargin = dp(10)
            row?.addView(tile, cellLp)
            LoboAnim.fadeIn(tile, duration = 220L, delay = (index * 40L).coerceAtMost(280L), fromY = 20f)
        }
        // Odd last item: spacer so single tile doesn't stretch full width awkwardly
        if (games.size % 2 == 1) {
            row?.addView(View(this), LinearLayout.LayoutParams(0, dp(170), 1f).apply { leftMargin = dp(10) })
        }
        // Force a fresh measure/layout after replacing the complete grid. This is
        // important after SAF synchronization because the StateFlow may update
        // while the library ScrollView is already attached to the window.
        list.requestLayout()
        list.invalidate()
    }

    /** Synchronizes the visible catalog through the application layer. */
    private fun syncRealLibrary() {
        val folder = features.settings.gamesFolderUri ?: return
        val activityRef = WeakReference(this)
        features.library.syncAsync(folder) {
            activityRef.get()?.let { activity ->
                activity.runOnUiThread {
                    if (!activity.isFinishing && activity.currentScreen == Screen.LIBRARY) {
                        activity.showLibrary()
                    }
                }
            }
        }
    }

    private fun pickGame() { features.saf.requestForCode(pick)?.let { launchSafPicker(it) } }
    private fun showGameDetail(){
        currentScreen=Screen.GAME_DETAIL; shellState.go(ConsoleShellState.Route.DETAIL, selectedGame); clear();topBar("Detalle de juego")

        // La vista previa es parte de la decisión de lanzamiento: primero se ve el juego,
        // después se ejecuta. El vídeo se reproduce en silencio y en bucle cuando existe.
        val previewCard = card(10)
        previewCard.background = rounded(Color.rgb(2,10,19), cyan, 20)
        val previewTitle = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        previewTitle.addView(label("▶  VISTA PREVIA", 16f, cyan, true), lp(0, -2, 1f))
        previewTitle.addView(label("GAMEPLAY", 10f, muted, true))
        previewCard.addView(previewTitle)

        val savedPreview = features.previews.get(selectedGame)
        if (savedPreview != null) {
            val video = previewPlayer.create(this, savedPreview) { toast("No se pudo reproducir la vista previa") }.apply {
                background = rounded(Color.BLACK, line, 14)
            }
            previewVideo = video
            previewCard.addView(video, lp(-1, dp(230)).apply { topMargin = dp(8) })
            previewCard.addView(label("Vista previa del juego · audio silenciado", 10f, muted).apply {
                setPadding(dp(4), dp(6), dp(4), 0)
            })
        } else {
            val empty = FrameLayout(this).apply {
                background = rounded(Color.rgb(1,7,14), lineSoft, 14)
                minimumHeight = dp(230)
            }
            empty.addView(label("Vista previa no configurada", 17f, text, true).apply {
                gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(-1, -2).apply { topMargin = dp(70) })
            empty.addView(label("No existe una vista previa local para este juego. Puedes añadir una grabación propia.", 11f, muted).apply {
                gravity = Gravity.CENTER
                setGravity(Gravity.CENTER)
            }, FrameLayout.LayoutParams(-1, -2).apply { topMargin = dp(105); leftMargin = dp(20); rightMargin = dp(20) })
            previewCard.addView(empty, lp(-1, dp(230)).apply { topMargin = dp(8) })
        }

        val previewActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        previewActions.addView(button("▣  ${if (savedPreview == null) "Añadir vídeo" else "Cambiar vídeo"}", { pickPreviewVideo() }), lp(0, dp(46), 1f).apply { topMargin = dp(8) })
        if (savedPreview != null) {
            previewActions.addView(button("Quitar", { features.previews.remove(selectedGame); showGameDetail() }), lp(dp(90), dp(46)).apply { leftMargin = dp(8); topMargin = dp(8) })
        }
        previewCard.addView(previewActions)
        add(previewCard, margin=8)

        val entry = features.library.entries().firstOrNull { it.title == selectedGame }
        if (entry == null) {
            toast("El juego ya no existe en la biblioteca.")
            showLibrary()
            return
        }

        val hero = FrameLayout(this).apply {
            background = rounded(Color.rgb(2, 9, 18), line, 16)
            clipToOutline = true
        }
        entry.coverUri?.let { cover ->
            try {
                hero.addView(ImageView(this).apply {
                    setImageURI(Uri.parse(cover))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }, FrameLayout.LayoutParams(-1, -1))
            } catch (_: Exception) {}
        } ?: run {
            hero.addView(label("CARÁTULA NO DISPONIBLE", 11f, muted, true).apply {
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
            }, FrameLayout.LayoutParams(-1, -1))
        }
        val shade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(225, 0, 0, 0))
            )
        }
        hero.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        overlay.addView(label(entry.title, 22f, text, true))
        overlay.addView(label("${entry.platform.name}  •  ${entry.size}", 11f, muted))
        overlay.addView(label(
            if (entry.lastPlayedEpoch > 0L) "Jugado anteriormente" else "Aún no iniciado",
            11f, muted
        ))
        hero.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        add(hero, dp(245))

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,dp(10),0,0)}
        actions.addView(button("▶  Jugar",{startSelectedGame()},true),lp(0,dp(52),1f))
        actions.addView(button("⚙  Configurar",{showProfiles()}),lp(0,dp(52),1f).apply{leftMargin=dp(8)})
        actions.addView(button("▣  Ver detalles",{showAbout()}),lp(0,dp(52),1f).apply{leftMargin=dp(8)})
        add(actions)

        val info=card()
        info.addView(label("Información",18f,text,true))
        listOf(
            "Archivo" to (Uri.parse(entry.uri ?: "").lastPathSegment ?: "—"),
            "Tamaño real" to entry.size,
            "Formato" to entry.format,
            "Plataforma" to entry.platform.name,
            "Versión" to entry.version,
            "Compatibilidad" to entry.compatibility,
            "Estado del archivo" to if (entry.installed) "Archivo legible" else "No disponible",
            "Perfil activo" to (features.profiles.get(entry.id)?.graphics ?: "Predeterminado")
        ).forEach { r ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(label(r.first,13f,muted),lp(0,dp(38),1f))
            row.addView(label(r.second,13f,text,true))
            info.addView(row)
        }
        add(info,margin=10)
    }

    private fun startSelectedGame() {
        val activityRef = WeakReference(this)
        runtimeLaunch.startAsync(selectedGame, selectedGame, features.library, features.sessions) { result ->
            activityRef.get()?.let { activity ->
                activity.runOnUiThread {
                    if (activity.isFinishing) return@runOnUiThread
                    when (result.state) {
                        RuntimeLaunchController.LaunchState.FAILED -> {
                            result.compatibility?.let { compatibility ->
                                activity.features.library.entries().firstOrNull { entry -> entry.title == activity.selectedGame }?.let { entry ->
                                    activity.features.library.setCompatibility(entry.id, compatibility)
                                }
                            }
                            activity.toast(result.message)
                            if (result.message.startsWith("Ese juego")) activity.showLibrary()
                        }
                        RuntimeLaunchController.LaunchState.STARTED -> {
                            activity.shellState.go(ConsoleShellState.Route.GAME, activity.selectedGame)
                            activity.grantAchievement("first_session")
                            val sessionCount = activity.features.achievements.incrementSessionStarts()
                            if (sessionCount >= 10) activity.grantAchievement("sessions_10")
                            activity.showGameRuntime()
                        }
                    }
                }
            }
        }
    }

    /**
     * Game play surface. No gradient, cover, logo or fabricated gameplay is
     * painted here: Vulkan owns the pixels and the native runtime owns execution.
     */
    private fun showGameRuntime() {
        features.sessions.setRuntimeSelectedGame(selectedGame)
        goScreen(Screen.GAME, game = selectedGame)
        shellState.go(ConsoleShellState.Route.GAME, selectedGame)
        clear()
        nav.visibility = View.GONE
        perfTask?.let(handler::removeCallbacks)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            minimumHeight = dp(620)
        }

        val surface = GameSurfaceView(this) { reason ->
            toast(reason)
            runtimeLifecycle.stopForNavigation()
            features.sessions.suspend()
            nav.visibility = View.VISIBLE
            showLibrary()
        }
        gameSurface = surface
        observedSurface?.holder?.removeCallback(surfaceLifecycleCallback)
        observedSurface = surface
        surface.holder.addCallback(surfaceLifecycleCallback)
        synchronized(lifecycleLock) {
            gameSurfaceAvailable = surface.holder.surface?.isValid == true
        }
        root.addView(surface, FrameLayout.LayoutParams(-1, -1))

        // Console-style, restrained overlays. They never substitute for the
        // rendered game image.
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(185, 0, 0, 0), Color.TRANSPARENT)
            )
        }
        top.addView(label("LOBO GÉLIDO", 12f, text, true), lp(0, -2, 1f))
        top.addView(label(java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date()), 12f, muted))
        root.addView(top, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.TOP })

        val status = label("Runtime: ${features.runtime.state()}", 10f, cyan, true).apply {
            setBackgroundColor(Color.argb(155, 0, 0, 0))
            setPadding(dp(10), dp(7), dp(10), dp(7))
        }
        root.addView(status, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.TOP or Gravity.START
            topMargin = dp(52)
            leftMargin = dp(12)
        })

        val hud = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.argb(170, 5, 12, 23), line, 12)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        fun hudLine(name: String, value: String) {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(label(name, 9f, muted), lp(0, -2, 1f))
            row.addView(label(value, 9f, text, true))
            hud.addView(row)
        }
        hud.addView(label("RUNTIME", 9f, cyan, true))
        hudLine("Sesión", features.runtime.state())
        hudLine("Vulkan", features.runtime.vulkanDiagnostics().substringBefore(";"))
        root.addView(hud, FrameLayout.LayoutParams(dp(176), -2).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = dp(52)
            rightMargin = dp(10)
        })

        val controls = SwitchTouchOverlay(this)
        controls.alpha = 0.92f
        root.addView(controls, FrameLayout.LayoutParams(-1, -1))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(Color.argb(200, 0, 0, 0), Color.TRANSPARENT)
            )
        }
        bottom.addView(button("☰  Menú rápido", { showQuickMenu() }, true), lp(0, dp(46), 1f))
        bottom.addView(button("⏸", {
            if (features.runtime.pause()) {
                features.sessions.suspend()
                nav.visibility = View.VISIBLE
                showLibrary()
            }
        }, false), lp(dp(58), dp(46)).apply { leftMargin = dp(8) })
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.BOTTOM })

        add(root, dp(620))
        features.sessions.setRunning(selectedGame)

        perfTask = object : Runnable {
            override fun run() {
                if (currentScreen != Screen.GAME) return
                status.text = "Runtime: ${features.runtime.state()}"
                hud.removeAllViews()
                hud.addView(label("RUNTIME", 9f, cyan, true))
                hudLine("Sesión", features.runtime.state())
                hudLine("Vulkan", features.runtime.vulkanDiagnostics().substringBefore(";"))
                hudLine("Present", features.runtime.presenterDiagnostics().substringBefore(";"))
                handler.postDelayed(this, 1000)
            }
        }.also { handler.post(it) }
    }

    private fun pickPreviewVideo() { features.saf.requestForCode(pickPreview)?.let { launchSafPicker(it) } }

    /** Panel 4 — Menú rápido durante el juego. */
    private fun showQuickMenu() {
        goScreen(Screen.QUICK_MENU, game = selectedGame)
        shellState.go(ConsoleShellState.Route.QUICK_MENU, selectedGame)
        grantAchievement("quick_menu")
        clear()
        nav.visibility = View.GONE

        val root = card(14)
        root.background = rounded(Color.rgb(6, 14, 28), cyan, 18)

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(logo(40), lp(dp(40), dp(40)))
        head.addView(label("LOBO GÉLIDO", 16f, text, true), lp(0, -2, 1f).apply { leftMargin = dp(8) })
        val clock = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        head.addView(label(clock, 11f, muted))
        root.addView(head)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
        }

        // Primary: Continuar
        body.addView(
            button("▶  Continuar", {
                nav.visibility = View.GONE
                showGameRuntime()
            }, true),
            lp(-1, dp(50)).apply { bottomMargin = dp(8) }
        )

        listOf(
            "⌘  Ajustes del juego" to { nav.visibility = View.VISIBLE; showProfiles() },
            "⚙  Ajustes gráficos" to { nav.visibility = View.VISIBLE; showGraphics() },
            "🎮  Controles" to { nav.visibility = View.VISIBLE; showControls() }
        ).forEach { (title, action) ->
            body.addView(button(title, action, false), lp(-1, dp(46)).apply { bottomMargin = dp(6) })
        }

        // Only show measurements actually returned by the native runtime.
        val stats = card(12)
        stats.addView(label(if (selectedGame.isBlank()) "Sesión" else selectedGame, 14f, text, true))
        stats.addView(label(features.runtime.metrics(), 10f, muted).apply { setPadding(0, dp(8), 0, 0) })
        stats.addView(label(features.runtime.presenterDiagnostics(), 10f, muted))
        body.addView(stats, lp(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })

        body.addView(button("⇥  Salir a la biblioteca", {
            features.runtime.pause()
            features.sessions.suspend()
            nav.visibility = View.VISIBLE
            showLibrary()
        }, false), lp(-1, dp(48)))

        root.addView(body)
        add(root, margin = 12)
    }

    /** Panel 6 — Diagnóstico / Rendimiento. */
    private fun showPerformance() {
        goScreen(Screen.PERFORMANCE)
        clear("Rendimiento", "Estado del sistema, FPS y recursos.")
        nav.visibility = View.VISIBLE

        // Tabs: Rendimiento | Diagnóstico | Telemetría
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.addView(button("Rendimiento", { showPerformance() }, true), lp(0, dp(42), 1f))
        tabs.addView(button("Diagnóstico", { showDiagnostics() }, false), lp(0, dp(42), 1f).apply { leftMargin = dp(6) })
        tabs.addView(button("Telemetría", { showDiagnostics() }, false), lp(0, dp(42), 1f).apply { leftMargin = dp(6) })
        add(tabs, margin = 8)

        // Status card
        val status = card(14)
        status.addView(label("Estado del sistema", 15f, text, true))
        val runtimeState = features.runtime.state()
        status.addView(label("●  $runtimeState", 18f, if (runtimeState == "RUNNING") green else warning, true).apply { setPadding(0, dp(6), 0, 0) })
        status.addView(label(features.runtime.runtimeDiagnostics(), 10f, muted))
        add(status, margin = 8)

        // FPS + wolf card
        val fpsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val fpsCard = card(12)
        fpsCard.addView(label("FPS", 11f, muted))
        fpsCard.addView(label(features.runtime.metrics(), 10f, text, true))
        fpsCard.addView(label("Mediciones producidas por el runtime nativo.", 11f, muted))
        fpsRow.addView(fpsCard, lp(0, -2, 1f))
        val wolfCard = card(12)
        wolfCard.gravity = Gravity.CENTER
        wolfCard.addView(logo(72), lp(dp(72), dp(72)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        wolfCard.addView(label("Sesión activa", 11f, cyan, true).apply { gravity = Gravity.CENTER })
        fpsRow.addView(wolfCard, lp(0, -2, 1f).apply { leftMargin = dp(8) })
        add(fpsRow, margin = 8)

        // Sparkline graph matching the diagnostics layout
        val graphCard = card(12)
        graphCard.addView(label("Telemetría en vivo", 13f, cyan, true))
        graphCard.addView(
            label("El gráfico aparecerá cuando existan muestras reales del runtime.", 11f, muted),
            lp(-1, dp(48)).apply { topMargin = dp(8) }
        )
        add(graphCard, margin = 8)

        // Resource bars CPU / GPU / RAM / VRAM (full-width proportional)
        fun barRow(name: String, pct: Int, color: Int) {
            val c = card(10)
            val head = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            head.addView(label(name, 13f, text, true), lp(0, -2, 1f))
            head.addView(label("$pct%", 13f, color, true))
            c.addView(head)
            // Weight-based fill so it always matches card width
            val rowFill = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                background = rounded(Color.rgb(20, 32, 48), line, 8)
            }
            val fill = View(this).apply {
                background = GradientDrawable().apply {
                    setColor(color)
                    cornerRadius = dp(8).toFloat()
                }
            }
            val empty = View(this)
            val w = pct.coerceIn(1, 100).toFloat()
            rowFill.addView(fill, LinearLayout.LayoutParams(0, dp(12), w))
            rowFill.addView(empty, LinearLayout.LayoutParams(0, dp(12), (100 - pct).coerceAtLeast(0).toFloat()))
            c.addView(rowFill, lp(-1, dp(12)).apply { topMargin = dp(8) })
            add(c, margin = 6)
        }
        val resources = card(10)
        resources.addView(label("Recursos", 13f, text, true))
        resources.addView(label(features.runtime.vulkanDiagnostics(), 10f, muted).apply { setPadding(0, dp(8), 0, 0) })
        resources.addView(label(features.runtime.presenterDiagnostics(), 10f, muted))
        add(resources, margin = 6)

        // Frame analysis
        val frame = card(12)
        frame.addView(label("Análisis del frame", 14f, text, true))
        listOf(
            "Runtime" to features.runtime.metrics(),
            "Vulkan" to features.runtime.vulkanDiagnostics(),
            "Presentación" to features.runtime.presenterDiagnostics()
        ).forEach { (k, v) ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(4), 0, dp(4))
            }
            r.addView(label(k, 12f, muted), lp(0, -2, 1f))
            r.addView(label(v, 12f, text, true))
            frame.addView(r)
        }
        add(frame, margin = 8)

        val smartOn = features.settings.getLegacyBoolean("smart_scale", true)
        add(button(
            if (smartOn) "✓  Escalado inteligente activo" else "⚡  Activar escalado inteligente",
            {
                features.settings.setLegacyBoolean("smart_scale", !smartOn)
                showPerformance()
            },
            true
        ), dp(50), 8)

        perfTask?.let(handler::removeCallbacks)
        perfTask = object : Runnable {
            override fun run() {
                handler.postDelayed(this, 1500)
            }
        }.also { handler.post(it) }
    }

    /** Panel 7 — Diagnóstico avanzado / recomendaciones. */
    private fun showDiagnostics() {
        goScreen(Screen.DIAGNOSTICS)
        clear("Diagnóstico", "Análisis y recomendaciones.")
        nav.visibility = View.VISIBLE
        grantAchievement("diagnostics")

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.addView(button("Rendimiento", { showPerformance() }, false), lp(0, dp(42), 1f))
        tabs.addView(button("Diagnóstico", { showDiagnostics() }, true), lp(0, dp(42), 1f).apply { leftMargin = dp(6) })
        add(tabs, margin = 8)

        val state = DiagnosticsPresenter.parse(features.runtime.diagnostics())
        val healthy = state.status.contains("Óptimo", true) || state.status.contains("Optimal", true)

        // Warning / OK banner
        val banner = card(14)
        if (healthy) {
            banner.addView(label("●  Estado óptimo", 16f, green, true))
            banner.addView(label(state.advice.ifBlank { "No se detectan cuellos de botella." }, 12f, muted))
        } else {
            banner.addView(label("⚠  Atención", 16f, warning, true))
            banner.addView(label(state.advice.ifBlank { "Revisa resolución y escalado si la GPU está al límite." }, 12f, muted))
            banner.addView(label("Recomendación: reduce la resolución interna un nivel o activa el TSR.", 12f, cyan).apply {
                setPadding(0, dp(8), 0, 0)
            })
        }
        add(banner, margin = 8)

        // Frame budget breakdown
        val budget = card(12)
        budget.addView(label("Frame Budget", 14f, text, true))
        listOf(
            "Runtime" to features.runtime.metrics(),
            "Vulkan" to features.runtime.vulkanDiagnostics(),
            "Presentación" to features.runtime.presenterDiagnostics()
        ).forEach { (k, v) ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(5), 0, dp(5))
            }
            r.addView(label(k, 12f, muted), lp(0, -2, 1f))
            r.addView(label(v, 12f, text, true))
            budget.addView(r)
        }
        add(budget, margin = 8)

        // Metrics from runtime
        val metrics = card(12)
        metrics.addView(label("Telemetría del runtime", 14f, text, true))
        if (state.metrics.isEmpty()) {
            metrics.addView(label("Sin muestras del runtime. Inicia un juego para obtener telemetría real.", 11f, muted))
        } else {
            state.metrics.forEach { (k, v) ->
                val r = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(4), 0, dp(4))
                }
                r.addView(label(k, 12f, muted), lp(0, -2, 1f))
                r.addView(label(v, 12f, text, true))
                metrics.addView(r)
            }
        }
        add(metrics, margin = 8)

        add(button("↻  Actualizar", { showDiagnostics() }, true), dp(48), 8)
        add(button("▣  Copiar diagnóstico", {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Lobo Gélido diagnóstico", state.raw))
            toast("Diagnóstico copiado")
        }, false), dp(46), 6)
        add(button("⬇  Guardar diagnóstico en Descargas", { saveDiagnosticToDownloads() }, true), dp(46), 6)
        add(button("…  Exportar y elegir ubicación", { launchDiagnosticExport() }, false), dp(46), 6)
        add(label("El ZIP incluye estado del runtime, Vulkan, dispositivo, logcat y el último crash. No incluye llaves, firmware ni juegos.", 10.5f, muted), margin = 4)
    }

    // -- Diagnostic bundle export -------------------------------------------------
    // Lets the user save a ZIP of everything the emulator knows about itself so it
    // can be handed over for offline debugging. Uses SAF ACTION_CREATE_DOCUMENT
    // (a real "save" dialog) — no FileProvider/manifest change required.
    private val reqDiagExport = 909

    /** One-tap save straight into the phone's Downloads/LoboGelido folder. */
    private fun saveDiagnosticToDownloads() {
        toast("Generando diagnóstico…")
        val ref = WeakReference(this)
        val extra = runCatching { diagnosticExtraSections() }.getOrDefault(emptyMap())
        Thread({
            val result = runCatching { DiagnosticsExporter.saveToDownloads(applicationContext, extra) }
                .getOrElse { DiagnosticsExporter.SaveResult(false, it.message ?: "error") }
            ref.get()?.runOnUiThread {
                toast(if (result.ok) "Guardado en ${result.location}" else "No se pudo guardar: ${result.location}")
            }
        }, "LoboDiagDownloads").apply { isDaemon = true }.start()
    }

    private fun launchDiagnosticExport() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, DiagnosticsExporter.suggestedFileName())
        }
        try {
            startActivityForResult(intent, reqDiagExport)
        } catch (_: android.content.ActivityNotFoundException) {
            toast("No hay un explorador de archivos disponible para guardar el ZIP.")
        } catch (_: Throwable) {
            toast("No se pudo abrir el diálogo para guardar el diagnóstico.")
        }
    }

    /** Redacted, app-side sections added to the bundle. Never includes secrets. */
    private fun diagnosticExtraSections(): Map<String, String> {
        val out = linkedMapOf<String, String>()
        out["settings.txt"] = runCatching {
            val s = features.settings
            buildString {
                appendLine("== Ajustes (redactado) ==")
                appendLine("theme            = ${s.theme}")
                appendLine("text_scale       = ${s.textScale}")
                appendLine("reduce_motion    = ${s.reduceMotion}")
                appendLine("touch_controls   = ${s.touchControls}")
                appendLine("developer_mode   = ${s.developerMode}")
                appendLine("lossless_scaling  = ${s.losslessScaling}")
                appendLine("first_run_done   = ${s.firstRunCompleted}")
                appendLine()
                appendLine("== Estado de recursos (solo estado, sin bytes) ==")
                appendLine("keys_configured     = ${!s.keysUri.isNullOrBlank()} (${s.lastKeysLabel.ifBlank { "sin etiqueta" }})")
                appendLine("firmware_configured = ${!s.firmwareUri.isNullOrBlank()} (${s.lastFirmwareLabel.ifBlank { "sin etiqueta" }})")
                appendLine("games_folder_set    = ${!s.gamesFolderUri.isNullOrBlank()}")
                appendLine("gpu_driver          = ${s.lastGpuDriverLabel.ifBlank { "por defecto" }}")
                appendLine("last_games_found    = ${s.lastGamesFound}")
            }
        }.getOrElse { "Ajustes no disponibles: ${it.message}" }

        out["session.txt"] = runCatching {
            buildString {
                appendLine("== Sesión ==")
                appendLine("selected_game    = ${selectedGame.ifBlank { "ninguno" }}")
                appendLine("runtime_state    = ${features.runtime.state()}")
            }
        }.getOrElse { "Sesión no disponible: ${it.message}" }
        return out
    }

    private fun writeDiagnosticBundle(uri: Uri) {
        val ref = WeakReference(this)
        val extra = runCatching { diagnosticExtraSections() }.getOrDefault(emptyMap())
        Thread({
            val bytes = runCatching { DiagnosticsExporter.build(applicationContext, extra) }
                .getOrDefault(ByteArray(0))
            val ok = runCatching {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) } != null && bytes.isNotEmpty()
            }.getOrDefault(false)
            ref.get()?.runOnUiThread {
                toast(if (ok) "Diagnóstico exportado (${bytes.size / 1024} KB)" else "No se pudo escribir el ZIP de diagnóstico")
            }
        }, "LoboDiagExport").apply { isDaemon = true }.start()
    }

    private data class AdvancedSetting(val id:String,val title:String,val description:String,val type:String="toggle",val options:List<String> = emptyList(),val default:String="off",val level:String="Seguro")

    private fun showFirstRunSetup() {
        currentScreen = Screen.SETTINGS
        clear()

        // First-run screen deliberately uses the Lobo Gélido visual language:
        // deep ice background, restrained blue/cyan outlines and actions.
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(12))
        }

        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        brand.addView(logo(58), lp(dp(58), dp(58)))
        val brandText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0) }
        brandText.addView(label("LOBO GÉLIDO", 20f, text, true))
        brandText.addView(label("EMULADOR DE SWITCH  •  CONFIGURACIÓN INICIAL", 8.5f, cyan, true))
        brand.addView(brandText, lp(0, -2, 1f))
        brand.addView(label("●", 10f, green, true))
        root.addView(brand, lp(-1, dp(66)))

        val hero = FrameLayout(this).apply {
            background = rounded(Color.argb(220, 3, 13, 27), cyan, 22)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        val winter = ImageView(this).apply {
            setImageResource(R.drawable.lobo_winter)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.30f
        }
        hero.addView(winter, FrameLayout.LayoutParams(-1, -1))
        val heroShade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.argb(245, 3, 10, 20), Color.argb(90, 3, 10, 20))
            )
        }
        hero.addView(heroShade, FrameLayout.LayoutParams(-1, -1))
        val heroText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heroText.addView(label("Configuración inicial", 27f, text, true))
        heroText.addView(label("Prepara Lobo Gélido para que encuentre tus juegos y aplique la mejor configuración posible.", 12f, muted))
        heroText.addView(label("Puedes instalar cada componente ahora o saltarlo y hacerlo después desde Ajustes.", 11f, cyan).apply { setPadding(0, dp(8), 0, 0) })
        hero.addView(heroText, FrameLayout.LayoutParams(-1, -2))
        root.addView(hero, lp(-1, dp(156)).apply { bottomMargin = dp(10) })

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun setupCard(icon: String, title: String, description: String, configured: Boolean, action: () -> Unit) {
            val shell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = rounded(Color.rgb(5, 20, 38), if (configured) green else Color.rgb(15, 142, 220), 22)
                elevation = dp(3).toFloat()
            }

            val iconBox = TextView(this).apply {
                text = icon
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    colors = intArrayOf(Color.rgb(10, 73, 125), Color.rgb(4, 26, 50))
                    cornerRadius = dp(17).toFloat()
                    setStroke(dp(2), if (configured) green else cyan)
                }
            }
            shell.addView(iconBox, lp(dp(72), dp(72)))

            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), 0, dp(6), 0) }
            info.addView(label(title, 18f, text, true))
            info.addView(label(description, 11f, muted))
            info.addView(label(if (configured) "✓ Configurado" else "● No configurado", 10.5f, if (configured) green else warning, true).apply { setPadding(0, dp(7), 0, 0) })
            shell.addView(info, lp(0, -2, 1f))

            val arrow = TextView(this).apply {
                text = "›"
                textSize = 35f
                gravity = Gravity.CENTER
                setTextColor(if (configured) green else cyan)
            }
            shell.addView(arrow, lp(dp(42), dp(60)))
            shell.setOnClickListener { action() }
            list.addView(shell, lp(-1, dp(96)).apply { bottomMargin = dp(9) })
        }

        val keysRec = features.setup.recognizeKeys(features.settings.keysUri)
        val fwRec = features.setup.recognizeFirmware(features.settings.firmwareUri)
        val gamesRec = SetupController.GamesScan(features.settings.gamesFolderUri != null, features.settings.lastGamesFound, if (features.settings.gamesFolderUri != null) "${features.settings.lastGamesFound} juego(s) en la última sincronización" else "Selecciona la carpeta de juegos")
        val gpuRec = features.setup.recognizeGpuDriver(features.settings.gpuDriverUri)

        fun statusLine(configured: Boolean, label: String, detail: String): String =
            if (configured) "✓ ${label.removePrefix("✓ ").trim()} — $detail" else "● ${label.removePrefix("● ").trim()} — $detail"

        setupCard(
            "🔑", "Claves",
            "Configura las claves personales (prod.keys / title.keys) necesarias para contenido compatible.\n${statusLine(keysRec.configured, keysRec.label, keysRec.detail)}",
            keysRec.configured
        ) { pickKeysFile() }

        setupCard(
            "▣", "Firmware",
            "Selecciona el firmware obtenido de tu propia consola.\n${statusLine(fwRec.configured, fwRec.label, fwRec.detail)}",
            fwRec.configured
        ) { pickFirmwareSource() }

        setupCard(
            "◈", "Escalado sin pérdidas",
            "Elige cómo quieres procesar y mejorar la imagen del emulador.\nActual: ${features.settings.losslessScaling}",
            features.settings.losslessScaling != "Auto"
        ) {
            val options = arrayOf("Auto", "Pixel Perfect", "Bilineal", "Lanczos", "Desactivado")
            AlertDialog.Builder(this)
                .setTitle("◈  Escalado sin pérdidas")
                .setSingleChoiceItems(options, options.indexOf(features.settings.losslessScaling).coerceAtLeast(0)) { dialog, which ->
                    features.settings.losslessScaling = options[which]
                    dialog.dismiss()
                    showFirstRunSetup()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }

        setupCard(
            "🎮", "Juegos",
            "Selecciona la carpeta donde están tus juegos (.nsp / .xci / …).\n${statusLine(gamesRec.configured, if (gamesRec.configured) "✓ Configurado" else "● No configurado", gamesRec.detail)}",
            gamesRec.configured
        ) { pickGamesDirectory() }

        setupCard(
            "⬢", "Controladores GPU",
            "Gestor de controladores: sistema, instalar zip o obtener paquetes comunitarios.\n${statusLine(gpuRec.configured, gpuRec.label, gpuRec.detail)}",
            gpuRec.configured
        ) { showGpuDriverManager() }

        val skip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(10), dp(10))
            background = rounded(Color.rgb(4, 15, 29), cyan, 18)
        }
        val skipInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        skipInfo.addView(label("Saltar por ahora", 15f, text, true))
        skipInfo.addView(label("Podrás configurar todo más tarde desde Ajustes → Configuración inicial.", 10.5f, muted))
        skip.addView(skipInfo, lp(0, -2, 1f))
        skip.addView(button("⚙  Ir a Ajustes", { showSettings() }, false).apply { minWidth = dp(132); minHeight = dp(44) }, lp(dp(145), dp(46)))
        list.addView(skip, lp(-1, dp(78)).apply { topMargin = dp(2); bottomMargin = dp(10) })

        scroll.addView(list, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, lp(-1, 0, 1f))

        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        footer.addView(button("‹  Atrás", {
            features.settings.firstRunCompleted = true
            showHome()
        }, false), lp(0, dp(52), 1f))
        footer.addView(button("🐺  Siguiente", {
            features.settings.firstRunCompleted = true
            grantAchievement("setup_complete")
            evaluateCompoundAchievements()
            showLibrary()
        }, true), lp(0, dp(52), 1f).apply { leftMargin = dp(8) })
        root.addView(footer, lp(-1, dp(58)).apply { topMargin = dp(8) })

        content.addView(root, lp(-1, -1))
    }

    private fun pickKeysFile() { features.saf.requestForCode(pickKeys)?.let { launchSafPicker(it) } }

    private fun pickFirmwareSource() { features.saf.requestForCode(pickFirmware)?.let { launchSafPicker(it) } }

    private fun pickGamesDirectory() { features.saf.requestForCode(pickGamesFolder)?.let { launchSafPicker(it) } }

    private fun pickGpuDriverPackage() { features.saf.requestForCode(pickGpuDriver)?.let { launchSafPicker(it) } }

    /** Gestor de controladores de la GPU (UI tipo captura). */
    private fun showGpuDriverManager() {
        goScreen(Screen.GPU_DRIVERS, fromSettings = true)
        clear("Gestor de controladores", "GPU del sistema e instalaciones alternativas.")
        topBar("Gestor de controladores de la GPU")
        nav.visibility = View.VISIBLE

        val sys = features.gpuDrivers.systemInfo()
        val selected = features.gpuDrivers.selectedId()

        // Intro card (screenshot 1)
        val intro = card(16)
        val introRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        introRow.addView(label("🔧", 28f, magenta), lp(dp(40), -2))
        val introCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, 0, 0)
        }
        introCol.addView(label("Gestor de controladores de la GPU", 16f, text, true))
        introCol.addView(label(
            "Instale los controladores alternativos para obtener un posible mejor rendimiento o precisión.",
            12f, muted
        ).apply { setPadding(0, dp(6), 0, 0) })
        introCol.addView(label("Controlador de la GPU del sistema", 13f, magenta, true).apply {
            setPadding(0, dp(10), 0, 0)
        })
        introRow.addView(introCol, lp(0, -2, 1f))
        intro.addView(introRow)
        add(intro, margin = 8)

        // System driver row (screenshot 2)
        val sysCard = card(14)
        sysCard.background = rounded(
            if (selected == "system") Color.rgb(12, 28, 48) else panel,
            if (selected == "system") magenta else line,
            14
        )
        val sysRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        sysRow.addView(label(if (selected == "system") "◉" else "○", 18f, if (selected == "system") magenta else muted), lp(dp(28), -2))
        val sysInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sysInfo.addView(label(sys.title, 14f, text, true))
        sysInfo.addView(label(sys.version, 12f, muted))
        sysInfo.addView(label(sys.vendor, 12f, muted))
        if (sys.modelHint.isNotBlank()) {
            sysInfo.addView(label(sys.modelHint, 11f, cyan).apply { setPadding(0, dp(2), 0, 0) })
        }
        sysRow.addView(sysInfo, lp(0, -2, 1f))
        sysCard.addView(sysRow)
        sysCard.setOnClickListener {
            features.gpuDrivers.select("system")
            features.settings.gpuDriverUri = null
            toast("Usando controlador del sistema")
            showGpuDriverManager()
        }
        add(sysCard, margin = 8)

        // Installed alternative drivers
        val installed = features.gpuDrivers.installed()
        if (installed.isNotEmpty()) {
            val listCard = card(12)
            listCard.addView(label("Controladores instalados", 14f, text, true))
            installed.forEach { drv ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(8), 0, dp(8))
                }
                val active = selected == drv.id
                row.addView(label(if (active) "◉" else "○", 18f, if (active) magenta else muted), lp(dp(28), -2))
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                col.addView(label(drv.name, 13f, text, true))
                col.addView(label(drv.source, 11f, muted))
                row.addView(col, lp(0, -2, 1f))
                row.addView(button("✕", {
                    features.gpuDrivers.removeInstalled(drv.id)
                    if (features.settings.gpuDriverUri == drv.path) features.settings.gpuDriverUri = null
                    showGpuDriverManager()
                }, false).apply { minWidth = dp(40) })
                row.setOnClickListener {
                    features.gpuDrivers.select(drv.id)
                    features.settings.gpuDriverUri = drv.path
                    features.settings.lastGpuDriverLabel = drv.name
                    grantAchievement("gpu_driver")
                    toast("Activo: ${drv.name}")
                    showGpuDriverManager()
                }
                listCard.addView(row)
            }
            add(listCard, margin = 8)
        }

        // Footer: Obtener + Instalar (screenshot 2)
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        footer.addView(button("↓  Obtener", { showGpuDriverObtain() }, true).apply {
            setBackgroundColor(magenta)
        }, lp(0, dp(52), 1f))
        footer.addView(button("＋  Instalar", { pickGpuDriverPackage() }, true).apply {
            setBackgroundColor(magenta)
        }, lp(0, dp(52), 1f).apply { leftMargin = dp(10) })
        add(footer, margin = 12)
    }

    /** Catálogo para obtener controladores (screenshot 3). */
    private fun showGpuDriverObtain() {
        goScreen(Screen.GPU_OBTAIN, fromSettings = true)
        clear("Obtener controladores", "Paquetes comunitarios open-source.")
        topBar("Obtener controladores de la GPU")
        nav.visibility = View.VISIBLE

        val sys = features.gpuDrivers.systemInfo()
        val head = card(12)
        val r1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        r1.addView(label("Modelo de la GPU", 12f, muted), lp(0, -2, 1f))
        r1.addView(label(sys.modelHint.ifBlank { sys.vendor }, 12f, magenta, true).apply {
            background = rounded(Color.rgb(40, 10, 30), magenta, 12)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        })
        head.addView(r1)
        val r2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        r2.addView(label("Controlador recomendado:", 12f, muted), lp(0, -2, 1f))
        r2.addView(label(
            if (sys.vendor.contains("Qualcomm", true)) "Turnip / Adreno" else "Paquete del sistema",
            12f, magenta, true
        ).apply {
            background = rounded(Color.rgb(40, 10, 30), magenta, 12)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        })
        head.addView(r2)
        add(head, margin = 8)

        add(label(
            "Los paquetes se obtienen de fuentes comunitarias (Mesa / GitHub). " +
                "Lobo Gélido no incluye drivers propietarios. Tras descargar el .zip, use Instalar.",
            11f, muted
        ), margin = 6)

        features.gpuDrivers.catalog().forEach { entry ->
            val card = card(12)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(label(entry.name, 14f, text, true))
            col.addView(label(entry.description, 11f, muted))
            row.addView(col, lp(0, -2, 1f))
            row.addView(label("▾", 16f, muted))
            card.addView(row)

            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(0, dp(10), 0, 0)
            }
            actions.addView(button("🌐  Abrir página de descarga", {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(entry.infoUrl)))
                } catch (_: Exception) {
                    toast("No se pudo abrir el enlace")
                }
            }, true), lp(-1, dp(46)))
            if (entry.downloadUrl != null) {
                actions.addView(button("↓  Descargar en la app", {
                    toast("Descargando…")
                    features.gpuDrivers.executor().execute {
                        val file = features.gpuDrivers.downloadToDrivers(
                            entry.downloadUrl, "${entry.id}.zip"
                        )
                        runOnUiThread {
                            if (file != null) {
                                val inst = features.gpuDrivers.addInstalled(
                                    entry.name, file.absolutePath, "Descarga · ${entry.name}"
                                )
                                features.settings.gpuDriverUri = inst.path
                                features.settings.lastGpuDriverLabel = inst.name
                                grantAchievement("gpu_driver")
                                toast("Instalado: ${entry.name}")
                                showGpuDriverManager()
                            } else {
                                toast("Descarga fallida. Usa la página web + Instalar.")
                            }
                        }
                    }
                }, false), lp(-1, dp(46)).apply { topMargin = dp(6) })
            } else {
                actions.addView(button("＋  Ya lo tengo · Instalar zip", {
                    pickGpuDriverPackage()
                }, false), lp(-1, dp(46)).apply { topMargin = dp(6) })
            }
            card.addView(actions)
            card.setOnClickListener {
                actions.visibility =
                    if (actions.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
            add(card, margin = 6)
        }

        add(button("‹  Volver al gestor", { showGpuDriverManager() }, false), dp(48), 10)
    }

    private fun rescanGamesLibrary() {
        val folder = features.settings.gamesFolderUri ?: return
        val activityRef = WeakReference(this)
        features.library.syncAsync(folder) { result ->
            activityRef.get()?.runOnUiThread {
                features.settings.lastGamesFound = result.count
                toast(if (result.count == 0) "Carpeta enlazada · 0 juegos detectados" else "Biblioteca actualizada · ${result.count} juego(s) reconocidos")
                evaluateCompoundAchievements()
                if (result.configured) showLibrary() else if (features.settings.firstRunCompleted) showSystem() else showFirstRunSetup()
            }
        }
    }


    /** Panel 9 — Ajustes (reference: menú de categorías + panel derecho). */
    private fun showSettings() {
        goScreen(Screen.SETTINGS)
        clear("Ajustes", "Centro de configuración de Lobo Gélido.")
        nav.visibility = View.VISIBLE

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(10))
        }
        header.addView(logo(36), lp(dp(36), dp(36)))
        header.addView(label("Ajustes", 20f, text, true), lp(0, -2, 1f).apply { leftMargin = dp(10) })
        add(header)

        // Primary categories as full-width rows
        fun cat(title: String, subtitle: String, action: () -> Unit, active: Boolean = false) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(if (active) Color.rgb(12, 28, 48) else panel, if (active) cyan else line, 14)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setOnClickListener { action() }
            }
            val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            textCol.addView(label(title, 14f, if (active) cyan else text, true))
            textCol.addView(label(subtitle, 11f, muted))
            row.addView(textCol, lp(0, -2, 1f))
            row.addView(label("›", 20f, muted, true))
            content.addView(row, lp(-1, -2).apply { bottomMargin = dp(8) })
        }
        cat("General", "Tema, idioma y energía", ::showGeneral, true)
        cat("Gráficos", "Resolución, escalado, Vulkan", ::showGraphics)
        cat("Controladores GPU", "Gestor, obtener e instalar", ::showGpuDriverManager)
        cat("Audio", "Backend, latencia y volumen", ::showAudio)
        cat("Controles", "Mapeo y pieles", ::showControls)
        cat("Sistema", "Almacenamiento y rutas", ::showSystem)
        cat("Temas", "Identidad visual", ::showThemes)
        cat("Accesibilidad", "Texto, contraste y gestos", ::showAccessibility)
        cat("Perfiles", "Perfiles por juego", { settingsChild = true; showProfiles() })
        cat("Multijugador", "Configuración de red y sesiones locales", ::showMultiplayer)
        cat("Gestor de archivos", "Explorar archivos con acceso concedido", ::showFileManager)
        cat("Applets", "Componentes auxiliares del entorno", ::showApplets)
        cat("Logros", "Progreso y desbloqueos", ::showAchievements)
        cat("Diagnóstico", "Telemetría y depuración", ::showDebugSettings)
        cat("Acerca de", "Versión y arquitectura", ::showAbout)

        // Quick toggles panel
        val quick = card(12)
        quick.addView(label("Accesos rápidos", 14f, text, true))
        settingInline(quick, "Escalado inteligente", "smart_scale", true)
        settingInline(quick, "Mostrar FPS", "fps_overlay", false)
        settingInline(quick, "Frame pacing", "pacing", true)
        add(quick, margin = 8)

        add(button("↺  Restablecer todos los ajustes", {
            AlertDialog.Builder(this)
                .setTitle("Restablecer ajustes")
                .setMessage("Se borrarán preferencias locales. Los juegos no se eliminan.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Restablecer") { _, _ ->
                    features.settings.clearLegacy()
                    features.settings.reset()
                    showSettings()
                }.show()
        }, false), dp(48), 8)
    }

    private fun infoSetting(title:String,description:String,level:String="Seguro"){
        android.app.AlertDialog.Builder(this).setTitle("ⓘ  $title").setMessage("$description\n\nNivel: $level").setPositiveButton("Entendido",null).show()
    }
    private fun advancedToggle(c:LinearLayout,s:AdvancedSetting){
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val left=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        left.addView(label(s.title,14f,text,true));left.addView(label("${s.description}  •  ${s.level}",10f,muted));row.addView(left,lp(0,dp(62),1f))
        row.addView(button("ⓘ",{infoSetting(s.title,s.description,s.level)},false).apply{minWidth=dp(42)})
        row.addView(Switch(this).apply{isChecked=features.settings.getLegacyBoolean("adv_${s.id}",s.default=="on");setOnCheckedChangeListener{_,v->features.settings.setLegacyBoolean("adv_${s.id}",v)}})
        c.addView(row)
    }
    private fun advancedChoice(c:LinearLayout,s:AdvancedSetting){
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};val left=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};left.addView(label(s.title,14f,text,true));left.addView(label("${s.description}  •  ${s.level}",10f,muted));row.addView(left,lp(0,dp(62),1f));row.addView(button("ⓘ",{infoSetting(s.title,s.description,s.level)},false).apply{minWidth=dp(42)})
        val saved=features.settings.getLegacyString("adv_${s.id}",s.default)?:s.default
        row.addView(button("$saved ▾",{android.app.AlertDialog.Builder(this).setTitle(s.title).setSingleChoiceItems(s.options.toTypedArray(),s.options.indexOf(saved).coerceAtLeast(0)){d,w->features.settings.setLegacyString("adv_${s.id}",s.options[w]);d.dismiss();when(currentScreen){Screen.GRAPHICS->showGraphics();Screen.AUDIO->showAudio();else->showSettings()}}.setNegativeButton("Cancelar",null).show()},false),lp(dp(170),dp(46)));c.addView(row)
    }

    private fun showDebugSettings(){currentScreen=Screen.DIAGNOSTICS;settingsChild=true;ui.enter("DEBUG", fromSettings=true);clear();topBar("Diagnóstico y depuración");val c=card();listOf(AdvancedSetting("dbg_logs","Logs detallados","Aumenta la información registrada para localizar problemas.",default="off",level="Avanzado"),AdvancedSetting("dbg_gpu","GPU logging","Registra eventos relevantes del backend gráfico.",default="off",level="Experimental"),AdvancedSetting("dbg_cpu","CPU tracing","Registra actividad del backend CPU; puede reducir rendimiento.",default="off",level="Experimental"),AdvancedSetting("dbg_mmu","MMU diagnostics","Registra fallos y traducciones de memoria para depuración.",default="off",level="Experimental"),AdvancedSetting("dbg_scheduler","Scheduler metrics","Muestra decisiones, quantum, yields y preempciones.",default="on",level="Avanzado"),AdvancedSetting("dbg_shaders","Shader dump","Guarda información de shaders para análisis.",default="off",level="Experimental")).forEach{advancedToggle(c,it)};add(c,margin=10);add(button("Abrir diagnóstico en vivo",::showDiagnostics),dp(48),8)}

    private fun showGeneral() {
        goScreen(Screen.GENERAL, fromSettings = true)
        clear("General", "Tema, idioma, energía y comportamiento.")
        topBar("General")
        nav.visibility = View.VISIBLE

        val c = card(14)
        c.addView(label("Preferencias", 15f, text, true))
        listOf("Tema" to "Oscuro", "Idioma" to "Español", "Modo de energía" to "Equilibrado").forEach {
            rowSelect(c, it.first, it.second)
        }
        listOf(
            "Notificaciones" to "notify",
            "Auto guardar" to "autosave",
            "Mostrar FPS" to "fps_overlay",
            "Modo desarrollador" to "developer"
        ).forEachIndexed { i, pair ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(label(pair.first, 14f, text), lp(0, dp(48), 1f))
            row.addView(Switch(this).apply {
                isChecked = features.settings.getLegacyBoolean(pair.second, i < 3)
                setOnCheckedChangeListener { _, v -> features.settings.setLegacyBoolean(pair.second, v) }
            })
            c.addView(row)
        }
        c.addView(button("Restablecer configuración", {
            features.settings.clearLegacy()
            showGeneral()
        }, false), lp(-1, dp(46)).apply { topMargin = dp(10) })
        add(c, margin = 10)
    }

    private fun rowSelect(c:LinearLayout,name:String,value:String){val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};row.addView(label(name,14f,text,true),lp(0,dp(48),1f));row.addView(label(value+"  ▾",13f,muted).apply{background=rounded(panel2,line,12);setPadding(dp(12),dp(10),dp(12),dp(10))});c.addView(row)}

    /** Panel 5 — Ajustes (configuración avanzada / Gráficos). */
    private fun showGraphics() {
        goScreen(Screen.GRAPHICS, fromSettings = true)
        clear("Gráficos", "Resolución, escalado, FPS y Vulkan.")
        topBar("Gráficos")
        nav.visibility = View.VISIBLE

        // Sub tabs Básico / Avanzado
        val sub = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sub.addView(button("Básico", { /* already basic section */ }, true), lp(0, dp(40), 1f))
        sub.addView(button("Avanzado", { toast("Desplázate a las opciones avanzadas") }, false), lp(0, dp(40), 1f).apply { leftMargin = dp(6) })
        add(sub, margin = 6)

        val p = features.profiles.get(selectedGame)
        val c = card(14)
        c.addView(label("Ajustes gráficos", 15f, text, true))
        choiceRow(c, "Preset gráfico", p.graphics, listOf("Máximo", "Equilibrado", "Rendimiento")) { v ->
            features.profiles.save(p.copy(graphics = v)); showGraphics()
        }
        choiceRow(c, "Resolución interna", "${p.resolution}%",
            listOf("50%", "60%", "75%", "80%", "90%", "100%", "125%", "150%", "200%")) { v ->
            features.profiles.save(p.copy(resolution = v.removeSuffix("%").toInt())); showGraphics()
        }
        choiceRow(c, "Escalado", p.scaling,
            listOf("Desactivado", "FSR", "Bicúbico", "Lanczos", "Spline-1", "Mitchell", "MMPX", "Inteligente")) { v ->
            features.profiles.save(p.copy(scaling = v)); showGraphics()
        }
        choiceRow(c, "Límite de FPS", if (p.fpsLimit == 0) "Sin límite" else p.fpsLimit.toString(),
            listOf("Sin límite", "30", "40", "45", "60", "72", "90", "120", "144")) { v ->
            features.profiles.save(p.copy(fpsLimit = if (v == "Sin límite") 0 else v.toInt())); showGraphics()
        }
        advancedChoice(c,AdvancedSetting("gfx_api","API gráfica","Selecciona el backend gráfico disponible.",options=listOf("Vulkan","Automático"),default="Vulkan"))
        advancedChoice(c,AdvancedSetting("gfx_astc","ASTC Decode","Elige dónde se decodifican texturas ASTC.",options=listOf("GPU","CPU","Automático"),default="GPU",level="Avanzado"))
        advancedChoice(c,AdvancedSetting("gfx_nvdec","NVDEC","Ruta de decodificación de vídeo cuando el backend la soporte.",options=listOf("GPU","CPU","Automático"),default="GPU",level="Avanzado"))
        advancedChoice(c,AdvancedSetting("gfx_dynamic","Extended Dynamic State","Controla la variante de estado dinámico de Vulkan.",options=listOf("Automático","1","2","Desactivado"),default="Automático",level="Avanzado"))
        advancedChoice(c,AdvancedSetting("gfx_workers","Pipeline workers","Número de hilos usados para trabajo de pipelines; demasiados pueden aumentar temperatura/contención.",options=listOf("Automático","1","2","3","4","5","6","7","8"),default="Automático",level="Avanzado"))
        advancedChoice(c,AdvancedSetting("gfx_gpu_time","Fast GPU Time","Reduce el coste de estimar el tiempo de GPU; puede afectar a la precisión.",options=listOf("Desactivado","128","256","512","Automático"),default="256",level="Avanzado"))
        listOf(AdvancedSetting("gfx_async","GPU asíncrona","Desacopla parte del trabajo de GPU para buscar más rendimiento; puede introducir glitches.",default="off",level="Experimental"),AdvancedSetting("gfx_async_present","Presentación Vulkan asíncrona","Usa trabajo auxiliar para presentación/sincronización Vulkan; puede mejorar rendimiento con riesgo de inestabilidad.",default="off",level="Experimental"),AdvancedSetting("gfx_shader_async","Compilación de shaders asíncrona","Compila shaders durante la ejecución para reducir bloqueos.",default="on",level="Avanzado"),AdvancedSetting("gfx_vsync","VSync","Sincroniza la presentación con la pantalla para reducir tearing.",default="on"),AdvancedSetting("gfx_aniso","Filtrado anisotrópico","Mejora la nitidez de texturas vistas en ángulo.",default="on"),AdvancedSetting("gfx_pipeline_cache","Caché de pipelines","Guarda pipelines compilados para acelerar lanzamientos posteriores.",default="on"),AdvancedSetting("gfx_shader_cache","Caché de shaders","Conserva shaders compilados para evitar recompilarlos.",default="on")).forEach{advancedToggle(c,it)}
        choiceRow(c,"Filtro de texturas","Anisotrópico 16x",listOf("Bilineal","Anisotrópico 2x","Anisotrópico 4x","Anisotrópico 8x","Anisotrópico 16x")){v->features.settings.setLegacyString("adv_gfx_texture_filter",v);showGraphics()}
        choiceRow(c,"Anti-aliasing","Desactivado",listOf("Desactivado","FXAA","TAA","MSAA 2x","MSAA 4x")){v->features.settings.setLegacyString("adv_gfx_aa",v);showGraphics()}
        sliderRow(c,"Brillo",50,"graphics_brightness")
        c.addView(label("Perfil: $selectedGame",10f,muted).apply{setPadding(0,dp(10),0,0)});add(c,margin=10)

        // GPU driver manager
        val gpuRec = features.setup.recognizeGpuDriver(features.settings.gpuDriverUri)
        val gpuCard = card()
        gpuCard.addView(label("⬢  Controladores GPU", 17f, text, true))
        gpuCard.addView(label(
            "Instala o selecciona un paquete de driver GPU del dispositivo. " +
                "El emulador lo reconocerá y lo mostrará en el estado del sistema. " +
                "No se descargan drivers propietarios automáticamente.",
            11f, muted
        ))
        gpuCard.addView(label(
            if (gpuRec.configured) "Estado: ${gpuRec.label} — ${gpuRec.detail}"
            else "Estado: No configurado",
            12f, if (gpuRec.configured) green else warning, true
        ).apply { setPadding(0, dp(8), 0, 0) })
        gpuCard.addView(button("🔧  Abrir gestor de controladores", { showGpuDriverManager() }, true), lp(-1, dp(48)).apply { topMargin = dp(10) })
        if (gpuRec.configured) {
            gpuCard.addView(button("✕  Quitar driver activo", {
                features.settings.gpuDriverUri = null
                features.settings.lastGpuDriverLabel = ""
                features.gpuDrivers.select("system")
                toast("Driver GPU eliminado")
                showGraphics()
            }, false), lp(-1, dp(46)).apply { topMargin = dp(6) })
        }
        add(gpuCard, margin = 10)

        // Mockup footer: Restablecer + Aplicar
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        footer.addView(button("Restablecer", {
            features.profiles.reset(selectedGame)
            toast("Gráficos restablecidos")
            showGraphics()
        }, false), lp(0, dp(50), 1f))
        footer.addView(button("Aplicar", {
            features.profiles.save(features.profiles.get(selectedGame))
            grantAchievement("profile_saved")
            toast("Configuración aplicada")
        }, true), lp(0, dp(50), 1f).apply { leftMargin = dp(8) })
        add(footer, margin = 10)
    }

    private fun showAudio(){goScreen(Screen.AUDIO, fromSettings = true);clear();topBar("Audio");val c=card();
        advancedChoice(c,AdvancedSetting("audio_backend","Backend de audio","Motor utilizado para producir audio.",options=listOf("Automático","SDL3","OpenSL ES"),default="Automático"))
        advancedChoice(c,AdvancedSetting("audio_device","Dispositivo","Selecciona la salida de audio disponible.",options=listOf("Predeterminado","Altavoz","Auriculares","Bluetooth"),default="Predeterminado"))
        advancedChoice(c,AdvancedSetting("audio_latency","Latencia","Equilibrio entre respuesta rápida y estabilidad.",options=listOf("Automática","Baja","Media","Alta"),default="Automática"))
        advancedToggle(c,AdvancedSetting("audio_stretch","Audio stretching","Mantiene el audio continuo cuando el ritmo de emulación fluctúa.",default="on"))
        advancedToggle(c,AdvancedSetting("audio_sync","Sincronización A/V","Mantiene audio y vídeo coordinados.",default="on"))
        advancedToggle(c,AdvancedSetting("audio_muted_focus","Silenciar en segundo plano","Silencia el juego al perder el foco.",default="off"))
        sliderRow(c,"Volumen maestro",80,"audio_master");sliderRow(c,"Volumen de efectos",80,"audio_effects");sliderRow(c,"Volumen de música",70,"audio_music");add(c,margin=10)
    }

    private fun showControls(){
        goScreen(Screen.CONTROLS, fromSettings = true);clear();topBar("Controles")
        val c=card();c.addView(label("🎮 Control total por juego",17f,text,true));c.addView(label("El mapeo se guarda de forma independiente para $selectedGame.",11f,muted))
        val p=features.profiles.get(selectedGame)
        choiceRow(c,"Perfil de control",p.controls,listOf("Pro Controller","Joy-Con","Portátil","Táctil","Personalizado")){v->features.profiles.save(p.copy(controls=v));showControls()}
        val activeSkin = features.skins.active()
        c.addView(label("Piel de controles: ${features.skins.all().firstOrNull{it.id==activeSkin}?.name ?: activeSkin}", 12f, cyan, true))
        c.addView(button("◉  Personalizar pieles", { showSkins() }), lp(-1, dp(46)).apply { topMargin=dp(8) })
        val mappings=linkedMapOf("A" to "A","B" to "B","X" to "X","Y" to "Y","L" to "L","R" to "R","ZL" to "ZL","ZR" to "ZR","+" to "START","−" to "SELECT")
        c.addView(label("Mapa de botones",14f,cyan,true).apply{setPadding(0,dp(10),0,dp(4))})
        mappings.forEach { (physical,logical) ->
            val key="map_${selectedGame.hashCode()}_$physical";val saved=features.settings.getLegacyString(key,logical)?:logical
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(label(physical,14f,text,true),lp(dp(56),dp(44)));row.addView(label("→",14f,muted),lp(dp(32),dp(44)));row.addView(button(saved,{android.app.AlertDialog.Builder(this).setTitle("Asignar $physical").setItems(arrayOf("A","B","X","Y","L","R","ZL","ZR","START","SELECT")){_,w->val v=arrayOf("A","B","X","Y","L","R","ZL","ZR","START","SELECT")[w];features.settings.setLegacyString(key,v);showControls()}.setNegativeButton("Cancelar",null).show()},false),lp(0,dp(42),1f));c.addView(row)
        }
        sliderRow(c,"Sensibilidad de sticks",75,"stick_sensitivity");sliderRow(c,"Zona muerta",8,"stick_deadzone")
        c.addView(button("Restablecer mapeo",{mappings.keys.forEach{features.settings.remove("map_${selectedGame.hashCode()}_$it")};showControls()}),lp(-1,dp(46)).apply{topMargin=dp(10)})
        add(c,margin=10)
    }

    private fun choiceRow(
        c: LinearLayout,
        title: String,
        value: String,
        options: List<String>,
        onSelected: (String) -> Unit
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(label(title, 13f, text, true), lp(0, dp(48), 1f))
        row.addView(button("$value ▾", {
            val current = options.indexOf(value).coerceAtLeast(0)
            android.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(options.toTypedArray(), current) { dialog, which ->
                    onSelected(options[which])
                    dialog.dismiss()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }, false), lp(dp(190), dp(44)))
        c.addView(row)
    }

    private fun sliderRow(c:LinearLayout,title:String,value:Int,key:String?=null){
        val initial=key?.let{features.settings.getInt(it,value)}?:value
        val valueLabel=label("$title                                      $initial%",13f,text).apply{setPadding(0,dp(10),0,dp(2))}
        c.addView(valueLabel)
        c.addView(SeekBar(this).apply{progress=initial;max=100;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(bar:SeekBar?,progress:Int,fromUser:Boolean){valueLabel.text="$title                                      $progress%";if(fromUser&&key!=null)features.settings.setInt(key,progress)}
            override fun onStartTrackingTouch(bar:SeekBar?){ }
            override fun onStopTrackingTouch(bar:SeekBar?){ }
        })})
    }
    private fun showSystem(){goScreen(Screen.SYSTEM, fromSettings = true);clear();topBar("Sistema y almacenamiento");val c=card();
        advancedChoice(c,AdvancedSetting("sys_language","Idioma","Idioma de la interfaz y mensajes.",options=listOf("Español","English","Português","Français","Deutsch"),default="Español"));advancedChoice(c,AdvancedSetting("sys_region","Región","Preferencia regional del entorno emulado.",options=listOf("Automática","América","Europa","Asia","Oceanía"),default="Automática"));advancedChoice(c,AdvancedSetting("sys_timezone","Zona horaria","Zona horaria usada por el entorno emulado.",options=listOf("Automática","UTC","Local"),default="Automática"));advancedChoice(c,AdvancedSetting("sys_power","Modo de energía","Prioriza duración de batería o rendimiento.",options=listOf("Equilibrado","Rendimiento","Ahorro"),default="Equilibrado"));
        listOf(AdvancedSetting("sys_autosave","Guardar configuración automáticamente","Persiste cambios de ajustes al modificarlos.",default="on"),AdvancedSetting("sys_game_config","Configuración por juego","Permite sobrescribir valores globales para un juego.",default="on"),AdvancedSetting("sys_custom_paths","Rutas personalizadas","Permite elegir directorios de juegos/datos cuando Android conceda acceso.",default="on"),AdvancedSetting("sys_shader_cache","Caché de shaders","Mantiene datos de shaders entre sesiones.",default="on"),AdvancedSetting("sys_pipeline_cache","Caché de pipelines","Mantiene pipelines compilados entre sesiones.",default="on"),AdvancedSetting("sys_telemetry","Telemetría local","Muestra métricas internas; no implica envío de datos a terceros.",default="on")).forEach{advancedToggle(c,it)}
        c.addView(button("🧹 Limpiar caché de shaders",{clearNamedCache("shaders");toast("Caché de shaders limpiada")},false),lp(-1,dp(46)).apply{topMargin=dp(8)})
        c.addView(button("🧹 Limpiar caché de pipelines",{clearNamedCache("pipelines");toast("Caché de pipelines limpiada")},false),lp(-1,dp(46)).apply{topMargin=dp(8)})
        c.addView(label("La configuración inicial solo aparece durante la primera instalación. Después, usa las opciones individuales de este apartado.", 11f, muted).apply {
            setPadding(0, dp(10), 0, dp(4))
        })
        c.addView(button("↻ Rescanear biblioteca de juegos",{rescanGamesLibrary()},false),lp(-1,dp(46)).apply{topMargin=dp(8)})
        c.addView(button("📁 Carpeta de juegos",{pickGamesDirectory()},false),lp(-1,dp(46)).apply{topMargin=dp(8)})
        c.addView(button("🔑 Seleccionar claves",{pickKeysFile()},false),lp(-1,dp(46)).apply{topMargin=dp(8)})
        c.addView(button("▣ Seleccionar firmware",{pickFirmwareSource()},false),lp(-1,dp(46)).apply{topMargin=dp(8)})
        c.addView(button("⬢ Controladores GPU",{showGpuDriverManager()},false),lp(-1,dp(46)).apply{topMargin=dp(8)})
        add(c,margin=10)

        val status = card()
        status.addView(label("Estado de contenido", 16f, text, true))
        val keysRec = features.setup.recognizeKeys(features.settings.keysUri)
        val fwRec = features.setup.recognizeFirmware(features.settings.firmwareUri)
        val gamesRec = SetupController.GamesScan(features.settings.gamesFolderUri != null, features.settings.lastGamesFound, if (features.settings.gamesFolderUri != null) "${features.settings.lastGamesFound} juego(s) en la última sincronización" else "Selecciona la carpeta de juegos")
        val gpuRec = features.setup.recognizeGpuDriver(features.settings.gpuDriverUri)
        val contentStatuses = listOf(
            Triple("Claves", keysRec.configured, keysRec.detail),
            Triple("Firmware", fwRec.configured, fwRec.detail),
            Triple("Juegos", gamesRec.configured, gamesRec.detail),
            Triple("Driver GPU", gpuRec.configured, gpuRec.detail)
        )
        contentStatuses.forEach { (name, configured, detail) ->
            status.addView(label(
                "$name: ${if (configured) "✓ $detail" else "● No configurado"}",
                12f, if (configured) green else warning
            ).apply { setPadding(0, dp(4), 0, 0) })
        }
        add(status, margin = 10)
    }

    /** Panel 12 — Accesibilidad y extras. */
    private fun showAccessibility() {
        goScreen(Screen.ACCESSIBILITY, fromSettings = true)
        clear("Accesibilidad", "Texto, color, gestos y feedback.")
        topBar("Accesibilidad")
        nav.visibility = View.VISIBLE
        grantAchievement("accessibility")

        val c = card(14)
        c.addView(label("Acceso universal", 16f, text, true))
        c.addView(label("Estos ajustes se aplican a toda la interfaz.", 11f, muted))
        choiceRow(c, "Tamaño de texto", "${features.settings.textScale}%",
            listOf("80%", "90%", "100%", "110%", "125%", "140%", "160%")) {
            features.settings.textScale = it.removeSuffix("%").toInt()
            showAccessibility()
        }
        choiceRow(c, "Contraste", if (features.settings.highContrast) "Alto" else "Normal",
            listOf("Normal", "Alto")) {
            features.settings.highContrast = it == "Alto"
            showAccessibility()
        }
        choiceRow(c, "Asistencia de color", features.settings.colorAssist,
            listOf("Desactivado", "Deuteranopía", "Protanopía", "Tritanopía")) {
            features.settings.colorAssist = it
            showAccessibility()
        }
        listOf(
            "Navegación por gestos" to features.settings.gestures,
            "Vibración" to features.settings.vibration,
            "Sonidos de interfaz" to features.settings.uiSounds,
            "Reducir movimiento" to features.settings.reduceMotion
        ).forEach { (name, checked) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(label(name, 14f, text), lp(0, dp(48), 1f))
            row.addView(Switch(this).apply {
                isChecked = checked
                setOnCheckedChangeListener { _, v ->
                    when (name) {
                        "Navegación por gestos" -> features.settings.gestures = v
                        "Vibración" -> features.settings.vibration = v
                        "Sonidos de interfaz" -> features.settings.uiSounds = v
                        "Reducir movimiento" -> features.settings.reduceMotion = v
                    }
                }
            })
            c.addView(row)
        }
        c.addView(label("La navegación y el texto respetan el tamaño seleccionado.", 11f, cyan).apply {
            setPadding(0, dp(8), 0, 0)
        })
        add(c, margin = 10)
    }

    /** Panel 10 — Identidad visual / Temas. */
    private fun showThemes() {
        goScreen(Screen.THEMES, fromSettings = true)
        clear("Temas", "Identidad visual de Lobo Gélido.")
        nav.visibility = View.VISIBLE

        val hero = card(16)
        hero.gravity = Gravity.CENTER_HORIZONTAL
        hero.addView(logo(120), lp(dp(120), dp(120)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        hero.addView(label("LOBO GÉLIDO", 20f, text, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
        hero.addView(label("Identidad visual · Temas", 12f, cyan, true).apply { gravity = Gravity.CENTER })
        add(hero, margin = 10)

        val current = features.settings.theme
        ThemePresets.all().forEach { theme ->
            val active = theme.id == current
            val tile = card(12)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(logo(48), lp(dp(48), dp(48)))
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, 0, 0)
            }
            info.addView(label(theme.name, 15f, text, true))
            info.addView(label(theme.description, 11f, muted))
            row.addView(info, lp(0, -2, 1f))
            row.addView(label(if (active) "✓" else "○", 18f, if (active) green else muted, true))
            tile.addView(row)
            tile.setOnClickListener {
                features.settings.theme = theme.id
                applyTheme()
                grantAchievement("theme_changed")
                showShell()
                showThemes()
            }
            add(tile, margin = 6)
        }
        add(button("Aplicar tema actual", {
            applyTheme(); showShell(); showThemes()
        }, true), dp(50), 8)
        add(button("Restaurar Hielo", {
            features.settings.theme = ThemePresets.ICE
            applyTheme(); showShell(); showThemes()
        }, false), dp(46), 6)
    }

    private fun applyTheme(){
        when(features.settings.theme){
            ThemePresets.NEBULA->{cyan=Color.rgb(224,72,224);blue=Color.rgb(110,91,255);magenta=Color.rgb(48,210,255)}
            ThemePresets.AURORA->{cyan=Color.rgb(0,245,212);blue=Color.rgb(39,174,96);magenta=Color.rgb(224,72,224)}
            else->{cyan=Color.rgb(70,166,216);blue=Color.rgb(32,105,176);magenta=Color.rgb(70,166,216)}
        }
    }

    private fun showSkins(){
        goScreen(Screen.SKINS, fromSettings = true); clear("Pieles", "Máscaras de controlador personalizadas para Nintendo Switch.")
        topBar("Pieles")

        val intro=card(14)
        intro.addView(label("Máscaras de controlador personalizadas",18f,text,true))
        intro.addView(label("Importa una carpeta o un .zip de imágenes ic_controller_*.png. Los paquetes de máscaras compatibles se pueden adaptar a Nintendo Switch.",12f,muted))
        intro.addView(button("Importar carpeta de máscaras…",{pickSkinFolder()},true),lp(-1,dp(48)).apply{topMargin=dp(10)})
        intro.addView(button("Importar skin .zip…",{pickSkinZip()},false),lp(-1,dp(48)).apply{topMargin=dp(6)})
        val hide=features.settings.getLegacyBoolean("hide_skin_catalog",false)
        val hideRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        hideRow.addView(label("Ocultar máscaras descargables",14f,text,true),lp(0,dp(48),1f))
        hideRow.addView(Switch(this).apply{isChecked=hide;setOnCheckedChangeListener{_,v->features.settings.setLegacyBoolean("hide_skin_catalog",v);showSkins()}})
        intro.addView(hideRow)
        add(intro,margin=8)

        val active=features.skins.active()
        val activeCard=card(12)
        activeCard.addView(label("Piel activa",14f,cyan,true))
        activeCard.addView(label(features.skins.all().firstOrNull{it.id==active}?.name ?: "Predeterminada",16f,text,true))
        activeCard.addView(label("Se aplicará a los controles táctiles de Lobo Gélido.",10f,muted))
        add(activeCard,margin=8)

        if(!features.settings.getLegacyBoolean("hide_skin_catalog",false)){
            val title=label("Catálogo de máscaras",18f,text,true);add(title,margin=10)
            features.skins.catalog().forEach{skin->addSkinRow(skin)}
        }
        val imported=features.skins.imported()
        if(imported.isNotEmpty()){
            add(label("Mis máscaras importadas",18f,text,true),margin=12)
            imported.forEach{addSkinRow(it)}
        }
    }

    private fun addSkinRow(skin:ControllerSkin){
        val row=card(8)
        val horizontal=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val preview=SwitchSkinPreviewView(this).apply{skinId=skin.id;setBackgroundColor(Color.rgb(2,8,16))}
        horizontal.addView(preview,lp(dp(154),dp(112)))
        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(6),0)}
        info.addView(label(skin.name,16f,text,true))
        info.addView(label(skin.author,12f,muted))
        info.addView(label("${skin.source}  ·  ${skin.buttons} controles",10f,muted))
        info.addView(label(skin.description,10f,muted))
        horizontal.addView(info,lp(0,-2,1f))
        val action=button(if(features.skins.active()==skin.id) "✓ Activa" else "Obtener",{
            features.skins.install(skin.id); toast("Piel obtenida: ${skin.name}"); showSkins()
        },features.skins.active()==skin.id)
        horizontal.addView(action,lp(dp(102),dp(48)))
        row.addView(horizontal)
        if(skin.source=="Usuario") row.addView(button("Eliminar máscara",{features.skins.removeImported(skin.id);showSkins()},false),lp(-1,dp(42)).apply{topMargin=dp(7)})
        add(row,margin=7)
    }

    private fun pickSkinZip() { features.saf.requestForCode(pickSkinZip)?.let { launchSafPicker(it) } }

    private fun pickSkinFolder() { features.saf.requestForCode(pickSkinFolder)?.let { launchSafPicker(it) } }

    private fun importSkinZip(uri: Uri) {
        val count = features.skins.importZip(uri)
        if (count == 0) { toast("No se encontraron ic_controller_*.png en el ZIP"); return }
        toast("Máscara importada: $count imágenes")
        showSkins()
    }

    private fun importSkinFolder(uri: Uri) {
        val document = runCatching { androidx.documentfile.provider.DocumentFile.fromTreeUri(this, uri) }.getOrNull()
        if (document == null || !document.isDirectory) {
            toast("No se pudo acceder a la carpeta seleccionada")
            return
        }
        val files = document.listFiles().asSequence()
            .filter { it.isFile && it.name?.lowercase(Locale.ROOT)?.endsWith(".png") == true }
            .filter { it.name?.substringAfterLast('/')?.startsWith("ic_controller_", ignoreCase = true) == true }
            .mapNotNull { file ->
                val name = file.name ?: return@mapNotNull null
                val bytes = runCatching { contentResolver.openInputStream(file.uri)?.use { it.readBytes() } }.getOrNull()
                bytes?.let { name to it }
            }
            .toList()
        if (files.isEmpty()) {
            toast("No se encontraron ic_controller_*.png en la carpeta")
            return
        }
        val folderName = document.name?.ifBlank { "custom_skin" } ?: "custom_skin"
        features.skins.importDirectory(folderName, files)
        toast("Máscara importada: ${files.size} imágenes")
        showSkins()
    }

    /** Panel 8 — Perfiles de juego (reference: lista con toggle). */
    private fun showProfiles() {
        goScreen(Screen.PROFILES, fromSettings = settingsChild)
        clear("Perfiles", "Perfiles de consola y por juego.")
        topBar("Perfiles de juego")
        nav.visibility = View.VISIBLE

        // Layer tabs
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Global", "Dispositivo", "Juego", "Sesión").forEachIndexed { i, s ->
            tabs.addView(
                button(if (i == 2) "✓ $s" else s, { toast("Capa $s") }, i == 2),
                lp(0, dp(42), 1f).apply { if (i > 0) leftMargin = dp(6) }
            )
        }
        add(tabs, margin = 8)

        // Console user profiles
        val users = card(12)
        users.addView(label("Perfil de consola", 15f, text, true))
        features.users.users().forEach { u ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            row.addView(label(if (u.active) "●" else "○", 14f, if (u.active) green else muted), lp(dp(24), -2))
            row.addView(label(u.name, 14f, text, true), lp(0, -2, 1f))
            row.addView(Switch(this).apply {
                isChecked = u.active
                setOnCheckedChangeListener { _, _ ->
                    features.users.select(u.id)
                    showProfiles()
                }
            })
            users.addView(row)
        }
        users.addView(button("✎  Cambiar nombre", {
            val input = EditText(this).apply {
                setText(features.users.active().name)
                setTextColor(this@MainActivity.text)
                setSingleLine(true)
            }
            AlertDialog.Builder(this)
                .setTitle("Nombre del perfil")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar") { _, _ ->
                    features.users.renameActive(input.text.toString())
                    showProfiles()
                }.show()
        }, false), lp(-1, dp(44)).apply { topMargin = dp(8) })
        add(users, margin = 8)

        // Per-game profiles from library
        val games = features.library.entries()
        val list = card(12)
        list.addView(label("Perfiles por juego", 15f, text, true))
        if (games.isEmpty()) {
            list.addView(label("No hay juegos. Añade títulos en la biblioteca.", 12f, muted))
        } else {
            games.take(12).forEach { game ->
                val p = features.profiles.get(game.title)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(8), 0, dp(8))
                }
                val thumb = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = rounded(panel2, line, 10)
                    clipToOutline = true
                    if (!game.coverUri.isNullOrBlank()) {
                        try { setImageURI(Uri.parse(game.coverUri)) } catch (_: Exception) {}
                    } else {
                        setBackgroundColor(Color.rgb(5, 12, 20))
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                    }
                }
                row.addView(thumb, lp(dp(44), dp(44)))
                val info = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10), 0, 0, 0)
                }
                info.addView(label(game.title, 13f, text, true))
                info.addView(label("${p.graphics} · ${p.resolution}% · ${p.fpsLimit} FPS", 10f, muted))
                row.addView(info, lp(0, -2, 1f))
                row.addView(Switch(this).apply {
                    isChecked = true
                    setOnCheckedChangeListener { _, _ -> toast("Perfil ${game.title}") }
                })
                row.setOnClickListener {
                    selectedGame = game.title
                    showGraphics()
                }
                list.addView(row)
            }
        }
        list.addView(button("＋  Crear perfil", {
            if (selectedGame.isNotBlank()) {
                features.profiles.save(features.profiles.get(selectedGame))
                toast("Perfil guardado")
            } else toast("Selecciona un juego primero")
        }, true), lp(-1, dp(48)).apply { topMargin = dp(10) })
        add(list, margin = 8)
    }

    private fun clearNamedCache(name: String) {
        val dir = java.io.File(cacheDir, name)
        if (dir.exists()) dir.deleteRecursively()
        dir.mkdirs()
    }

    private fun showMultiplayer() {
        currentScreen = Screen.MULTIPLAYER
        settingsChild = true
        ui.enter("MULTIPLAYER", fromSettings = true)
        clear()
        topBar("Multijugador")
        val c = card(14)
        c.addView(label("Sesiones y conectividad", 16f, text, true))
        advancedToggle(c, AdvancedSetting("multi_local", "Multijugador local", "Habilita la configuración local para sesiones compatibles.", default="on"))
        advancedToggle(c, AdvancedSetting("multi_online", "Servicios en línea", "Guarda la preferencia de servicios en línea; no crea soporte de red inexistente.", default="off", level="Avanzado"))
        advancedToggle(c, AdvancedSetting("multi_discovery", "Descubrimiento local", "Permite que la interfaz prepare sesiones LAN cuando exista un backend compatible.", default="off", level="Avanzado"))
        advancedChoice(c, AdvancedSetting("multi_port", "Puerto local", "Puerto usado por un backend de red cuando esté disponible.", options=listOf("Automático", "24872", "24873", "24874"), default="Automático", level="Avanzado"))
        c.addView(button("↻  Restablecer multijugador", { listOf("multi_local","multi_online","multi_discovery","multi_port").forEach { features.settings.remove("adv_$it") }; showMultiplayer() }, false), lp(-1, dp(46)).apply { topMargin = dp(8) })
        add(c, margin = 10)
    }

    private fun showFileManager() {
        currentScreen = Screen.FILE_MANAGER
        settingsChild = true
        ui.enter("FILE_MANAGER", fromSettings = true)
        clear()
        topBar("Gestor de archivos Lobo Gélido")
        val root = card(12)
        val folder = features.settings.gamesFolderUri
        root.addView(label("Carpeta de juegos", 15f, text, true))
        root.addView(label(folder?.let { features.library.displayName(Uri.parse(it)) } ?: "No configurada", 11f, muted))
        root.addView(button("📁  Abrir carpeta de juegos", { pickGamesDirectory() }, true), lp(-1, dp(46)).apply { topMargin = dp(8) })
        root.addView(button("↻  Actualizar contenido", { rescanGamesLibrary() }, false), lp(-1, dp(46)).apply { topMargin = dp(6) })
        add(root, margin = 10)
        val list = card(12)
        list.addView(label("Archivos reconocidos", 15f, text, true))
        if (folder.isNullOrBlank()) {
            list.addView(label("Concede acceso a una carpeta para explorarla.", 12f, muted))
        } else {
            val cachedCount = features.settings.lastGamesFound
            list.addView(label("$cachedCount juego(s) en la última sincronización", 11f, if (cachedCount > 0) green else warning))
            features.library.entries().take(50).forEach { g ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
                row.addView(label("▣", 18f, cyan), lp(dp(30), -2))
                row.addView(label(g.title, 12f, text, true), lp(0, -2, 1f))
                row.addView(label(g.size, 10f, muted))
                row.setOnClickListener { selectedGame = g.title; toast("Archivo seleccionado: ${g.title}") }
                list.addView(row)
            }
            if (features.library.entries().isEmpty()) list.addView(label("No se encontraron contenedores compatibles.", 12f, muted))
        }
        add(list, margin = 10)
    }

    private fun showApplets() {
        currentScreen = Screen.APPLETS
        settingsChild = true
        ui.enter("APPLETS", fromSettings = true)
        clear()
        topBar("Applets")
        val c = card(14)
        c.addView(label("Componentes auxiliares", 16f, text, true))
        listOf(
            AdvancedSetting("applet_home", "Home menu", "Preferencia del componente de menú principal.", default="on"),
            AdvancedSetting("applet_keyboard", "Teclado", "Permite preparar el teclado virtual cuando una interfaz compatible lo solicite.", default="on"),
            AdvancedSetting("applet_web", "Navegador", "Controla la disponibilidad declarativa del applet de navegador.", default="off"),
            AdvancedSetting("applet_error", "Pantalla de errores", "Muestra información de diagnóstico cuando un componente informa un error.", default="on")
        ).forEach { advancedToggle(c, it) }
        c.addView(button("ⓘ  Estado de applets", { infoSetting("Applets", "Estas preferencias controlan la capa de configuración del entorno. Un applet solo se ejecuta cuando existe un backend compatible.", "Runtime") }, true), lp(-1, dp(46)).apply { topMargin = dp(8) })
        add(c, margin = 10)
    }

    private fun showAbout() {
        goScreen(Screen.ABOUT, fromSettings = true)
        clear("Lobo Gélido", "Identidad y arquitectura.")
        val a = card(14)
        a.addView(logo(140), lp(-1, dp(150)))
        a.addView(label("LOBO GÉLIDO 57.5", 22f, text, true).apply { gravity = Gravity.CENTER })
        a.addView(label("Rendimiento · Estabilidad · Precisión", 12f, cyan, true).apply { gravity = Gravity.CENTER })
        add(a, margin = 10)
        val b = card(12)
        b.addView(label("Arquitectura", 15f, text, true))
        b.addView(label(
            "Shell → Pantallas → Runtime\nTelemetría → Diagnóstico\nCPU / GPU / Audio / Input",
            12f, muted
        ))
        add(b, margin = 8)
        val c = card(12)
        c.addView(label("Contenido", 15f, text, true))
        c.addView(label(
            "No incluye firmware, claves ni juegos. Usa contenido propio del usuario.",
            12f, muted
        ))
        add(c, margin = 8)
    }

    private fun launchSafPicker(request: SafFacade.Request) {
        val spec = features.saf.picker(request)
        val action = if (spec.directory) Intent.ACTION_OPEN_DOCUMENT_TREE else Intent.ACTION_OPEN_DOCUMENT
        val intent = Intent(action).apply {
            if (!spec.directory) { addCategory(Intent.CATEGORY_OPENABLE); type = spec.mimeType }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            if (spec.grantWrite) addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        startActivityForResult(intent, request.code)
    }

    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        // Diagnostic export uses ACTION_CREATE_DOCUMENT, so its code is not a
        // SafFacade.Request. Handle it before the picker dispatch below.
        if (requestCode == reqDiagExport) { writeDiagnosticBundle(uri); return }
        when (features.saf.requestForCode(requestCode)) {
            SafFacade.Request.KEYS -> {
                val activityRef = WeakReference(this)
                features.setup.selectKeysAsync(uri.toString()) { rec ->
                    activityRef.get()?.runOnUiThread {
                        toast(if (rec.configured) "Claves reconocidas: ${rec.detail}" else "Archivo de claves rechazado: ${rec.detail}")
                        evaluateCompoundAchievements()
                        if (features.settings.firstRunCompleted) showSystem() else showFirstRunSetup()
                    }
                }
            }
            SafFacade.Request.FIRMWARE -> {
                val activityRef = WeakReference(this)
                features.setup.selectFirmwareAsync(uri.toString()) { rec ->
                    activityRef.get()?.runOnUiThread {
                        toast(if (rec.configured) "Firmware reconocido: ${rec.detail}" else "Firmware rechazado: ${rec.detail}")
                        evaluateCompoundAchievements()
                        if (features.settings.firstRunCompleted) showSystem() else showFirstRunSetup()
                    }
                }
            }
            SafFacade.Request.GAMES_FOLDER -> {
                val activityRef = WeakReference(this)
                features.setup.selectGamesFolderAsync(uri.toString()) { rec ->
                    activityRef.get()?.runOnUiThread {
                        toast(if (rec.count > 0) "Juegos reconocidos: ${rec.count}" else "Carpeta guardada · 0 juegos compatibles detectados")
                        evaluateCompoundAchievements()
                        if (features.settings.firstRunCompleted) showSystem() else showFirstRunSetup()
                    }
                }
            }
            SafFacade.Request.GPU_DRIVER -> {
                val rec = features.setup.selectGpuDriver(uri.toString())
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Driver instalado"
                features.gpuDrivers.addInstalled(name, uri.toString(), "Instalación local")
                grantAchievement("gpu_driver")
                toast(if (rec.configured) "Driver GPU reconocido: ${rec.detail}" else "Paquete de driver guardado")
                evaluateCompoundAchievements()
                showGpuDriverManager()
            }
            SafFacade.Request.PREVIEW -> {
                features.previews.set(selectedGame, uri)
                showGameDetail()
            }
            SafFacade.Request.SKIN_ZIP -> {
                importSkinZip(uri)
            }
            SafFacade.Request.SKIN_FOLDER -> {
                importSkinFolder(uri)
            }
            SafFacade.Request.GAME -> {
                val name = features.library.addSingle(uri)
                toast("Juego añadido: $name")
                showLibrary()
            }
            null -> Unit
        }
    }

}
