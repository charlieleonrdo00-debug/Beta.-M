package com.lobogelido.application

import android.content.Context
import com.lobogelido.*
import com.lobogelido.application.usecase.AddGameFolderUseCase
import com.lobogelido.application.usecase.ImportKeysUseCase
import com.lobogelido.application.usecase.InstallFirmwareUseCase
import com.lobogelido.application.usecase.InspectFirmwareUseCase
import com.lobogelido.application.usecase.InspectKeysUseCase
import com.lobogelido.application.usecase.PersistSafPermission
import com.lobogelido.application.usecase.RemoveGameFolderUseCase
import com.lobogelido.application.usecase.ScanGamesUseCase
import com.lobogelido.application.usecase.ValidateKeysUseCase
import com.lobogelido.data.firmware.AndroidFirmwareRepository
import com.lobogelido.data.games.AndroidGameRepository
import com.lobogelido.data.keys.AndroidKeyRepository
import com.lobogelido.data.profiles.AndroidProfileRepository
import com.lobogelido.data.saf.AndroidSafRepository
import com.lobogelido.data.settings.AndroidSettingsRepository
import com.lobogelido.domain.firmware.*
import com.lobogelido.domain.games.*
import com.lobogelido.domain.keys.*
import com.lobogelido.domain.profiles.GameOptimizationInput
import com.lobogelido.domain.profiles.GamePlatformHint
import com.lobogelido.domain.profiles.GameProfile
import com.lobogelido.domain.profiles.ProfileRepository
import com.lobogelido.domain.saf.SafPermissionResult
import com.lobogelido.domain.settings.SettingsRepository
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Composition root. Only object construction and UI-facing application gateways live here.
 * Android framework access is contained by Data implementations.
 */
class LoboApplicationGraph private constructor(context: Context) {
    private val app = context.applicationContext
    private val settingsRepository: SettingsRepository = AndroidSettingsRepository(app)
    private val safRepository = AndroidSafRepository(app)
    private val keyRepository = AndroidKeyRepository(app)
    private val firmwareRepository = AndroidFirmwareRepository(app)
    private val gameRepository = AndroidGameRepository(app)
    private val profileRepository: ProfileRepository = AndroidProfileRepository(app)

    private val inspectKeys = InspectKeysUseCase(keyRepository)
    private val importKeys = ImportKeysUseCase(keyRepository)
    private val validateKeys = ValidateKeysUseCase(keyRepository)
    private val inspectFirmware = InspectFirmwareUseCase(firmwareRepository)
    private val installFirmware = InstallFirmwareUseCase(firmwareRepository)
    private val scanGames = ScanGamesUseCase(gameRepository)
    private val addGameFolder = AddGameFolderUseCase(gameRepository)
    private val removeGameFolder = RemoveGameFolderUseCase(gameRepository)
    private val persistSafPermission = PersistSafPermission(safRepository)

    val settings = SettingsFacade(settingsRepository)
    val library = GameLibraryFacade(gameRepository)
    val profiles = ProfileFacade(profileRepository)
    val setup = SetupController(
        settings, library, inspectKeys, importKeys, validateKeys,
        inspectFirmware, installFirmware, scanGames, addGameFolder, removeGameFolder,
        persistSafPermission
    )
    val saf = SafFacade(persistSafPermission)
    val previews = PreviewFacade(app)
    val skins = SkinFacade(app)
    val users = UserFacade(app)
    val sessions = SessionFacade(app)
    val achievements = AchievementFacade(app)
    val gpuDrivers = GpuDriverFacade(app)
    val runtime = RuntimeControlFacade()

    companion object {
        @Volatile private var instance: LoboApplicationGraph? = null
        fun get(context: Context): LoboApplicationGraph = instance ?: synchronized(this) {
            instance ?: LoboApplicationGraph(context).also { instance = it }
        }
    }
}

class SettingsFacade(private val repo: SettingsRepository) {
    private val read = ReadSetting(repo)
    private val write = WriteSetting(repo)
    var theme: String get() = read.string("theme", ThemePresets.ICE) ?: ThemePresets.ICE; set(v) = write.string("theme", v)
    var textScale: Int get() = read.int("text_scale", 100); set(v) = write.int("text_scale", v.coerceIn(80, 160))
    var highContrast: Boolean get() = read.bool("high_contrast", true); set(v) = write.bool("high_contrast", v)
    var colorAssist: String get() = read.string("color_assist", "Desactivado") ?: "Desactivado"; set(v) = write.string("color_assist", v)
    var reduceMotion: Boolean get() = read.bool("reduce_motion", false); set(v) = write.bool("reduce_motion", v)
    var touchControls: Boolean get() = read.bool("touch", true); set(v) = write.bool("touch", v)
    var developerMode: Boolean get() = read.bool("developer", false); set(v) = write.bool("developer", v)
    var gestures: Boolean get() = read.bool("gestures", true); set(v) = write.bool("gestures", v)
    var vibration: Boolean get() = read.bool("vibration", true); set(v) = write.bool("vibration", v)
    var uiSounds: Boolean get() = read.bool("ui_sounds", true); set(v) = write.bool("ui_sounds", v)
    val animationsEnabled: Boolean get() = !reduceMotion
    var firstRunCompleted: Boolean get() = read.bool("first_run_completed", false); set(v) = write.bool("first_run_completed", v)
    var keysUri: String? get() = read.string("keys_uri"); set(v) = write.string("keys_uri", v)
    var firmwareUri: String? get() = read.string("firmware_uri"); set(v) = write.string("firmware_uri", v)
    var gamesFolderUri: String? get() = read.string("games_folder_uri"); set(v) = write.string("games_folder_uri", v)
    var gpuDriverUri: String? get() = read.string("gpu_driver_uri"); set(v) = write.string("gpu_driver_uri", v)
    var losslessScaling: String get() = read.string("lossless_scaling", "Auto") ?: "Auto"; set(v) = write.string("lossless_scaling", v)
    var lastGamesFound: Int get() = read.int("last_games_found", 0); set(v) = write.int("last_games_found", v.coerceAtLeast(0))
    var lastKeysLabel: String get() = read.string("last_keys_label", "") ?: ""; set(v) = write.string("last_keys_label", v)
    var lastFirmwareLabel: String get() = read.string("last_firmware_label", "") ?: ""; set(v) = write.string("last_firmware_label", v)
    var lastGpuDriverLabel: String get() = read.string("last_gpu_driver_label", "") ?: ""; set(v) = write.string("last_gpu_driver_label", v)
    fun getInt(k: String, d: Int) = read.int(k, d)
    fun setInt(k: String, v: Int) = write.int(k, v)
    fun getBoolean(k: String, d: Boolean) = read.bool(k, d)
    fun setBoolean(k: String, v: Boolean) = write.bool(k, v)
    fun getString(k: String, d: String? = null) = read.string(k, d)
    fun setString(k: String, v: String?) = write.string(k, v)
    fun remove(k: String) = write.remove(k)
    fun clearAll() = repo.clear()
    fun reset() = repo.clear()
    fun getLegacyInt(k: String, d: Int) = getInt(k, d)
    fun setLegacyInt(k: String, v: Int) = setInt(k, v)
    fun getLegacyBoolean(k: String, d: Boolean) = getBoolean(k, d)
    fun setLegacyBoolean(k: String, v: Boolean) = setBoolean(k, v)
    fun getLegacyString(k: String, d: String? = null) = getString(k, d)
    fun setLegacyString(k: String, v: String?) = setString(k, v)
    fun clearLegacy() = clearAll()
}

class GameLibraryFacade(private val repository: AndroidGameRepository) {
    val gamesFlow: kotlinx.coroutines.flow.StateFlow<List<GameMetadata>> = repository.gamesFlow
    private val scanExecutor: ExecutorService = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "LoboLibraryScan").apply { isDaemon = true } }
    fun syncAsync(folder: String, onComplete: (SyncResult) -> Unit) { scanExecutor.execute { val result = syncResult(folder); onComplete(result) } }
    fun entries(): List<GameEntry> = gamesFlow.value.map(::toUiEntry)
    fun filtered(filter: LibraryFilter, query: String, sort: LibrarySort): List<GameEntry> {
        val q = query.trim().lowercase()
        val filtered = entries().filter { game ->
            (q.isEmpty() || game.title.lowercase().contains(q) || game.tags.any { it.lowercase().contains(q) }) &&
                when (filter) { LibraryFilter.ALL -> true; LibraryFilter.INSTALLED -> game.installed; LibraryFilter.FAVORITES -> game.favorite }
        }
        return when (sort) {
            LibrarySort.NAME -> filtered.sortedBy { it.title.lowercase() }
            LibrarySort.RECENT -> filtered.sortedByDescending { it.lastPlayedEpoch }
            LibrarySort.SIZE -> filtered.sortedByDescending { gameSize(game = it) }
        }
    }
    fun add(uri: android.net.Uri, coverUri: android.net.Uri? = null, displayTitle: String? = null, sizeLabel: String? = null) {
        val existing = repository.getById(GameId("uri:$uri"))
        val source = GameSource("uri:$uri", displayTitle ?: uri.lastPathSegment.orEmpty(), uri.toString(), parseSize(sizeLabel))
        val metadata = existing?.copy(
            title = displayTitle ?: existing.title,
            cover = coverUri?.let { Artwork("manual:$it", it.toString(), ArtworkKind.COVER) } ?: existing.cover,
            sizeBytes = source.sizeBytes
        ) ?: GameMetadata(
            title = source.displayName, titleId = GameId(source.id), publisher = null, version = null,
            region = null, icon = null, cover = coverUri?.let { Artwork("manual:$it", it.toString(), ArtworkKind.COVER) },
            format = formatFrom(source.displayName), sourcePath = source.path, sizeBytes = source.sizeBytes
        )
        repository.upsert(metadata)
    }
    fun enrichCover(id: String, uri: android.net.Uri?) { if (uri != null) repository.getById(GameId("uri:${id.removePrefix("uri:")}"))?.let { repository.upsert(it.copy(cover = Artwork("manual:$uri", uri.toString(), ArtworkKind.COVER))) } }
    fun setCompatibility(id: String, value: String) = repository.setCompatibility(GameId("uri:${id.removePrefix("uri:")}"), value)
    fun setVersion(id: String, value: String?) = repository.setVersion(GameId("uri:${id.removePrefix("uri:")}"), value)
    fun remove(uri: String) = repository.remove(GameId("uri:${uri.removePrefix("uri:")}"))
    fun toggleFavorite(id: String): Boolean { val game = repository.getById(GameId("uri:${id.removePrefix("uri:")}")) ?: return false; val next = !game.favorite; repository.setFavorite(game.titleId, next); return next }
    fun markPlayed(id: String) = repository.setPlayed(GameId("uri:${id.removePrefix("uri:")}"), System.currentTimeMillis())
    fun syncResult(folder: String, onChanged: (() -> Unit)? = null): SyncResult {
        val parsed = android.net.Uri.parse(folder)
        val source = GameFolder(GameFolderId(folder), parsed.lastPathSegment ?: "Juegos", folder)
        val result = ScanGamesUseCase(repository).executeAll(listOf(source))
        onChanged?.invoke()
        return SyncResult(result.errors.isEmpty(), result.games.size, "${source.displayName} · ${result.games.size} juego(s)")
    }
    fun syncFromFolder(folder: String, onChanged: (() -> Unit)? = null) = syncResult(folder, onChanged).count
    fun addSingle(uri: android.net.Uri): String { add(uri); return uri.lastPathSegment?.substringAfterLast('/') ?: "Juego" }
    fun displayName(uri: android.net.Uri?): String = uri?.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')?.ifBlank { "Juego" } ?: "Juego"
    data class SyncResult(val configured: Boolean, val count: Int, val detail: String)

    private fun toUiEntry(game: GameMetadata): GameEntry = GameEntry(
        id = game.titleId.value.removePrefix("uri:"), title = game.title, uri = game.sourcePath,
        coverUri = game.cover?.uri, installed = game.installed, favorite = game.favorite,
        size = GameFileMetadata.sizeLabel(game.sizeBytes), version = game.version ?: "No disponible",
        lastPlayedEpoch = game.lastPlayedEpoch, tags = setOf("Instalado", game.format.name),
        platform = PlatformDetector.detect(android.net.Uri.parse(game.sourcePath), game.title).platform,
        format = game.format.name, modifiedEpoch = game.modifiedEpoch, compatibility = game.compatibility
    )
    private fun gameSize(game: GameEntry) = parseSize(game.size)
    private fun parseSize(label: String?): Long { if (label.isNullOrBlank()) return 0L; val n = label.replace(',', '.').filter { it.isDigit() || it == '.' }.toDoubleOrNull() ?: return 0L; return when { label.contains("GB", true) -> (n * 1024 * 1024 * 1024).toLong(); label.contains("MB", true) -> (n * 1024 * 1024).toLong(); label.contains("KB", true) -> (n * 1024).toLong(); else -> n.toLong() } }
    private fun formatFrom(name: String): GameFormat = when (name.substringAfterLast('.', "").lowercase()) { "nsp" -> GameFormat.NSP; "xci" -> GameFormat.XCI; "nca" -> GameFormat.NCA; "nro" -> GameFormat.NRO; "nso" -> GameFormat.NSO; "nsz" -> GameFormat.NSZ; "xcz" -> GameFormat.XCZ; else -> GameFormat.UNKNOWN }
}

class ProfileFacade(private val repository: ProfileRepository) {
    private val get = GetGameProfileUseCase(repository); private val save = SaveGameProfileUseCase(repository); private val reset = ResetGameProfileUseCase(repository)
    private val optimize = OptimizeGameProfileUseCase(repository)
    fun get(id: String): GameProfile = get.execute(id)
    fun save(profile: GameProfile) = save.execute(profile)
    fun reset(id: String) = reset.execute(id)
    fun optimizeForDevice(game: GameEntry, cores: Int, memoryMb: Long) = optimize.execute(
        GameOptimizationInput(game.id, when (game.platform) {
            GamePlatform.GBC -> GamePlatformHint.GBC; GamePlatform.GBA -> GamePlatformHint.GBA
            GamePlatform.GAMECUBE -> GamePlatformHint.GAMECUBE; GamePlatform.WII -> GamePlatformHint.WII
            GamePlatform.N3DS -> GamePlatformHint.N3DS; else -> GamePlatformHint.OTHER
        }), cores, memoryMb
    )
}

class SetupController(
    private val settings: SettingsFacade,
    private val library: GameLibraryFacade,
    private val inspectKeys: InspectKeysUseCase,
    private val importKeys: ImportKeysUseCase,
    private val validateKeys: ValidateKeysUseCase,
    private val inspectFirmware: InspectFirmwareUseCase,
    private val installFirmware: InstallFirmwareUseCase,
    private val scanGames: ScanGamesUseCase,
    private val addFolder: AddGameFolderUseCase,
    private val removeFolder: RemoveGameFolderUseCase,
    private val persistSaf: PersistSafPermission
) {
    private val scanExecutorForSetup: ExecutorService = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "LoboSetupScan").apply { isDaemon = true } }
    data class Recognition(val configured: Boolean, val label: String, val detail: String)
    data class GamesScan(val configured: Boolean, val count: Int, val detail: String)

    fun recognizeKeys(uri: String?): Recognition {
        if (uri.isNullOrBlank()) return Recognition(false, "No configurado", "Selecciona un archivo de claves")
        val label = settings.lastKeysLabel
        return Recognition(settings.keysUri == uri && label.isNotBlank() && !label.contains("revisión", true), "✓ Configurado", label.ifBlank { "Claves pendientes de validación" })
    }
    fun recognizeFirmware(uri: String?): Recognition {
        if (uri.isNullOrBlank()) return Recognition(false, "No configurado", "Selecciona una fuente de firmware")
        val label = settings.lastFirmwareLabel
        return Recognition(settings.firmwareUri == uri && label.isNotBlank() && !label.contains("no válido", true), "✓ Configurado", label.ifBlank { "Firmware pendiente de validación" })
    }
    fun recognizeGpuDriver(uri: String?): Recognition = if (uri.isNullOrBlank()) Recognition(false, "No configurado", "Opcional: selecciona un paquete de driver GPU") else Recognition(true, "✓ Driver reconocido", uri.substringAfterLast('/'))
    fun scanGames(folder: String?): GamesScan {
        if (folder.isNullOrBlank()) return GamesScan(false, 0, "Selecciona la carpeta de juegos")
        val source = GameFolder(GameFolderId(folder), folder.substringAfterLast('/').ifBlank { "Juegos" }, folder)
        val result = scanGames.execute(source)
        return GamesScan(result.errors.isEmpty(), result.games.size, "${source.displayName} · ${result.games.size} juego(s)")
    }
    fun selectKeys(uri: String): Recognition {
        val permission = persistSaf.execute(uri)
        if (!permission.granted) return Recognition(false, "No configurado", permission.error ?: "No se pudo acceder al archivo.")
        val name = uri.substringAfterLast('/').ifBlank { "keys" }
        val imported = importKeys.execute(uri, name)
        val validation = validateKeys.execute()
        val ok = imported.success && validation.valid
        val out = Recognition(ok, if (ok) "✓ Configurado" else "● Revisión requerida", if (ok) "${imported.importedCount} claves importadas" else (validation.errors + imported.errors).distinct().joinToString("; ").ifBlank { "Faltan claves requeridas." })
        if (ok) settings.keysUri = uri
        settings.lastKeysLabel = out.detail
        return out
    }
    fun selectKeysAsync(uri: String, onComplete: (Recognition) -> Unit) { scanExecutorForSetup.execute { onComplete(selectKeys(uri)) } }

    fun selectFirmware(uri: String): Recognition {
        val permission = persistSaf.execute(uri, true)
        if (!permission.granted) return Recognition(false, "No configurado", permission.error ?: "No se pudo acceder al firmware.")
        val name = uri.substringAfterLast('/').ifBlank { "firmware" }
        val result = installFirmware.execute(uri, name)
        val out = Recognition(result.success, if (result.success) "✓ Configurado" else "● No válido", result.errors.firstOrNull() ?: result.installed?.version?.value.orEmpty())
        if (result.success) settings.firmwareUri = uri
        settings.lastFirmwareLabel = out.detail
        return out
    }
    fun selectFirmwareAsync(uri: String, onComplete: (Recognition) -> Unit) { scanExecutorForSetup.execute { onComplete(selectFirmware(uri)) } }

    fun selectGamesFolder(uri: String): GamesScan {
        val permission = persistSaf.execute(uri, true)
        if (!permission.granted) return GamesScan(false, 0, permission.error ?: "No se pudo acceder a la carpeta.")
        val folder = addFolder.execute(GameFolderSource(uri, uri.substringAfterLast('/').ifBlank { "Juegos" }))
        settings.gamesFolderUri = folder.sourceId
        val result = scanGames.executeAll(listOf(folder))
        settings.lastGamesFound = result.games.size
        return GamesScan(result.errors.isEmpty(), result.games.size, "${folder.displayName} · ${result.games.size} juego(s)")
    }
    fun selectGamesFolderAsync(uri: String, onComplete: (GamesScan) -> Unit) {
        scanExecutorForSetup.execute { onComplete(selectGamesFolder(uri)) }
    }
    fun selectGpuDriver(uri: String): Recognition { settings.gpuDriverUri = uri; val result = recognizeGpuDriver(uri); settings.lastGpuDriverLabel = result.detail; return result }
}

class SafFacade(private val persist: PersistSafPermission) {
    enum class Request(val code: Int, val tree: Boolean, val mime: String) {
        GAME(401, false, "*/*"), PREVIEW(402, false, "video/*"), SKIN_ZIP(403, false, "application/zip"),
        SKIN_FOLDER(404, true, "*/*"), KEYS(405, false, "*/*"), FIRMWARE(406, true, "*/*"), GAMES_FOLDER(407, true, "*/*"), GPU_DRIVER(408, false, "*/*")
    }
    fun requestForCode(code: Int) = Request.entries.firstOrNull { it.code == code }
    fun persistPermission(uri: String, write: Boolean = false): SafPermissionResult = persist.execute(uri, write)
    fun picker(request: Request): PickerSpec = PickerSpec(request.tree, request.mime, request.tree)
    data class PickerSpec(val directory: Boolean, val mimeType: String, val grantWrite: Boolean)
}

class PreviewFacade(context: Context) { private val store = GamePreviewStore(context); fun get(id: String) = store.get(id); fun set(id: String, uri: android.net.Uri) = store.set(id, uri); fun remove(id: String) = store.remove(id) }
class SkinFacade(private val context: Context) {
    private val store = ControllerSkinStore(context)
    fun catalog() = store.catalog(); fun imported() = store.imported(); fun all() = store.all(); fun active() = store.active(); fun install(id: String) = store.install(id); fun removeImported(id: String) = store.removeImported(id); fun importDirectory(n: String, f: List<Pair<String, ByteArray>>) = store.importDirectory(n, f)
    fun importZip(uri: android.net.Uri): Int = context.contentResolver.openInputStream(uri)?.use { input -> java.util.zip.ZipInputStream(input).use { zip -> val files = mutableListOf<Pair<String, ByteArray>>(); var entry = zip.nextEntry; while (entry != null) { if (!entry.isDirectory && entry.name.lowercase().endsWith(".png") && entry.name.substringAfterLast('/').startsWith("ic_controller_")) files += entry.name to zip.readBytes(); entry = zip.nextEntry }; if (files.isNotEmpty()) store.importDirectory(uri.lastPathSegment?.substringAfterLast(':')?.substringBeforeLast('.') ?: "skin", files); files.size } } ?: 0
}
class UserFacade(context: Context) { private val store = ConsoleUserStore(context); fun users() = store.users(); fun active() = store.active(); fun select(id: String) = store.select(id); fun renameActive(n: String) = store.renameActive(n) }
class SessionFacade(context: Context) { private val store = GameSessionStore(context); private val prefs = context.applicationContext.getSharedPreferences("lobo_runtime", Context.MODE_PRIVATE); fun state() = store.state(); fun game() = store.game(); fun setPreparing(g: String) = store.setPreparing(g); fun setRunning(g: String) = store.setRunning(g); fun suspend() = store.suspend(); fun clear() = store.clear(); fun setRuntimeSelectedGame(g: String) = prefs.edit().putString("selected_game", g).apply() }
class AchievementFacade(context: Context) { private val store = AchievementStore(context); fun unlock(id: String) = store.unlock(id); fun definitions() = AchievementStore.DEFINITIONS; fun all() = store.all(); fun unlockedCount() = store.unlockedCount(); fun totalCount() = store.totalCount(); fun incrementSessionStarts() = store.incrementSessionStarts() }
class GpuDriverFacade(private val context: Context) { fun systemInfo() = GpuDriverManager.systemInfo(context); fun selectedId() = GpuDriverManager.selectedId(context); fun select(id: String) = GpuDriverManager.select(context, id); fun installed() = GpuDriverManager.installed(context); fun removeInstalled(id: String) = GpuDriverManager.removeInstalled(context, id); fun addInstalled(n: String, p: String, s: String) = GpuDriverManager.addInstalled(context, n, p, s); fun catalog() = GpuDriverManager.CATALOG; fun executor() = GpuDriverManager.executor(); fun downloadToDrivers(u: String, f: String, onProgress: ((Int) -> Unit)? = null) = GpuDriverManager.downloadToDrivers(context, u, f, onProgress) }


class RuntimeControlFacade(private val bridge: RuntimeBridgeFacade = RuntimeBridgeFacadeImpl) {
    private val snapshot = java.util.concurrent.atomic.AtomicReference(RuntimeSnapshot("COLD", "", "", "", ""))
    private val executor = java.util.concurrent.Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "LoboRuntimeTelemetry").apply { isDaemon = true }
    }
    init {
        executor.scheduleWithFixedDelay({ refresh() }, 0L, 250L, java.util.concurrent.TimeUnit.MILLISECONDS)
    }
    fun state(): String = snapshot.get().state
    fun pause(): Boolean = bridge.pauseSession()
    fun resume(): Boolean = bridge.resumeSession()
    fun metrics(): String = snapshot.get().metrics
    fun runtimeDiagnostics(): String = snapshot.get().runtime
    fun vulkanDiagnostics(): String = snapshot.get().vulkan
    fun presenterDiagnostics(): String = snapshot.get().presenter
    fun diagnostics(): String = snapshot.get().diagnostics
    private fun refresh() {
        // Defense-in-depth: this runs every 250 ms on a background thread from app
        // start. An escaping Throwable would silently cancel the scheduled task
        // (telemetry frozen) or, if native, take the process down. The bridge
        // already guards each call; wrap the whole tick so the poller never dies.
        try {
            snapshot.set(RuntimeSnapshot(bridge.sessionState(), bridge.runtimeMetrics(), bridge.runtimeDiagnostics(), bridge.vulkanDiagnostics(), bridge.presenterDiagnostics(), bridge.diagnostics()))
        } catch (_: Throwable) {
            // keep last good snapshot; next tick retries
        }
    }
    private data class RuntimeSnapshot(val state: String, val metrics: String, val runtime: String, val vulkan: String, val presenter: String, val diagnostics: String = "")
}
