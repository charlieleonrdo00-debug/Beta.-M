package com.lobogelido.application.usecase
import com.lobogelido.domain.settings.SettingsRepository
class ReadSetting(private val repo:SettingsRepository){fun string(key:String,default:String?=null)=repo.getString(key,default);fun int(key:String,default:Int=0)=repo.getInt(key,default);fun bool(key:String,default:Boolean=false)=repo.getBoolean(key,default)}
class WriteSetting(private val repo:SettingsRepository){fun string(key:String,value:String?){repo.putString(key,value)};fun int(key:String,value:Int){repo.putInt(key,value)};fun bool(key:String,value:Boolean){repo.putBoolean(key,value)};fun remove(key:String){repo.remove(key)}}
