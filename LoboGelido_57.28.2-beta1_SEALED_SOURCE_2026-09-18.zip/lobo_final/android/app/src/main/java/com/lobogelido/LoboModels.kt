package com.lobogelido


/** Shared UI/domain models. Kept free of Activity code so screens can evolve independently. */
data class GameEntry(
    val id: String,
    val title: String,
    val uri: String? = null,
    val coverUri: String? = null,
    val installed: Boolean = false,
    val favorite: Boolean = false,
    val size: String = "—",
    val version: String = "—",
    val lastPlayedEpoch: Long = 0L,
    val tags: Set<String> = emptySet(),
    val platform: GamePlatform = GamePlatform.AUTO,
    val format: String = "—",
    val modifiedEpoch: Long = 0L,
    val compatibility: String = "No evaluada"
)

enum class LibraryFilter { ALL, INSTALLED, FAVORITES }
enum class LibrarySort { NAME, RECENT, SIZE }

data class GameProfile(
    val gameId: String,
    val graphics: String = "Equilibrado",
    val resolution: Int = 100,
    val fpsLimit: Int = 60,
    val vsync: Boolean = true,
    val scaling: String = "Inteligente",
    val audio: String = "Alta",
    val controls: String = "Pro Controller",
    val shaderCache: Boolean = true,
    val jit: Boolean = false
)


data class ThemePreset(
    val id: String,
    val name: String,
    val accent: Int,
    val secondary: Int,
    val description: String
)

object ThemePresets {
    const val ICE = "ice"
    const val NEBULA = "nebula"
    const val AURORA = "aurora"

    fun all(): List<ThemePreset> = listOf(
        ThemePreset(ICE, "Hielo", 0xFF30D2FF.toInt(), 0xFF1C8BFF.toInt(), "Cyan glacial + azul profundo"),
        ThemePreset(NEBULA, "Nébula", 0xFFE048E0.toInt(), 0xFF6E5BFF.toInt(), "Magenta orbital + violeta"),
        ThemePreset(AURORA, "Aurora", 0xFF00F5D4.toInt(), 0xFF27AE60.toInt(), "Turquesa aurora + verde")
    )
}
