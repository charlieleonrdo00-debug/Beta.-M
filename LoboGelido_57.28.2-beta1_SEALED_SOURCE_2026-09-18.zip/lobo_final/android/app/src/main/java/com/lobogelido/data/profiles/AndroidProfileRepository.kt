package com.lobogelido.data.profiles

import android.content.Context
import com.lobogelido.domain.profiles.GameProfile
import com.lobogelido.domain.profiles.ProfileRepository

class AndroidProfileRepository(context: Context) : ProfileRepository {
    private val prefs = context.applicationContext.getSharedPreferences("lobo_profiles_v3", Context.MODE_PRIVATE)
    private fun key(id: String, field: String) = "${Integer.toUnsignedString(id.hashCode())}_$field"

    override fun get(gameId: String): GameProfile = GameProfile(
        gameId = gameId,
        graphics = prefs.getString(key(gameId, "graphics"), "Equilibrado") ?: "Equilibrado",
        resolution = prefs.getInt(key(gameId, "resolution"), 100).coerceIn(25, 200),
        fpsLimit = prefs.getInt(key(gameId, "fps"), 60).coerceAtLeast(0),
        vsync = prefs.getBoolean(key(gameId, "vsync"), true),
        scaling = prefs.getString(key(gameId, "scaling"), "Inteligente") ?: "Inteligente",
        audio = prefs.getString(key(gameId, "audio"), "Alta") ?: "Alta",
        controls = prefs.getString(key(gameId, "controls"), "Pro Controller") ?: "Pro Controller",
        shaderCache = prefs.getBoolean(key(gameId, "shader"), true),
        jit = prefs.getBoolean(key(gameId, "jit"), false)
    )

    override fun save(profile: GameProfile) {
        prefs.edit()
            .putString(key(profile.gameId, "graphics"), profile.graphics)
            .putInt(key(profile.gameId, "resolution"), profile.resolution.coerceIn(25, 200))
            .putInt(key(profile.gameId, "fps"), profile.fpsLimit.coerceAtLeast(0))
            .putBoolean(key(profile.gameId, "vsync"), profile.vsync)
            .putString(key(profile.gameId, "scaling"), profile.scaling)
            .putString(key(profile.gameId, "audio"), profile.audio)
            .putString(key(profile.gameId, "controls"), profile.controls)
            .putBoolean(key(profile.gameId, "shader"), profile.shaderCache)
            .putBoolean(key(profile.gameId, "jit"), profile.jit)
            .apply()
    }

    override fun reset(gameId: String) {
        prefs.edit().also { e ->
            listOf("graphics", "resolution", "fps", "vsync", "scaling", "audio", "controls", "shader", "jit")
                .forEach { e.remove(key(gameId, it)) }
        }.apply()
    }
}
