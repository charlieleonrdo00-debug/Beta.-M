package com.lobogelido

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Persists the last uncaught exception so the NEXT diagnostic export carries the
 * crash that ended the previous run.
 *
 * It CHAINS to the platform's previous handler, so Android still shows its own
 * "app stopped" dialog and the process still terminates normally — this only
 * records, it does not swallow the crash. Installation is idempotent and can
 * never itself crash the app (all work is guarded).
 */
object LoboCrashReporter {

    private const val FILE_NAME = "last_crash.txt"
    @Volatile private var installed = false

    fun crashFile(context: Context): File = File(context.applicationContext.filesDir, FILE_NAME)

    /** Install once, as early as possible (e.g. MainActivity.onCreate). */
    fun install(context: Context) {
        if (installed) return
        installed = true
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching { record(appContext, thread, throwable) }
            // Always hand back to the platform handler so behaviour is unchanged.
            previous?.uncaughtException(thread, throwable)
        }
    }

    private fun record(context: Context, thread: Thread, throwable: Throwable) {
        val when_ = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val trace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()

        // Best-effort snapshot of native state AT crash time. Nested guard: if the
        // crash is itself native and the bridge is unusable, we skip it silently.
        val nativeState = runCatching { RuntimeBridge.sessionState() }.getOrDefault("<n/d>")
        val nativeDiag = runCatching { RuntimeBridge.diagnostics() }.getOrDefault("<n/d>")

        val body = buildString {
            appendLine("== Último crash ==")
            appendLine("timestamp     = $when_")
            appendLine("thread        = ${thread.name}")
            appendLine("exception     = ${throwable.javaClass.name}: ${throwable.message}")
            appendLine("session_state = $nativeState")
            appendLine("native_diag   = $nativeDiag")
            appendLine()
            appendLine("[stacktrace]")
            append(trace)
        }
        runCatching { crashFile(context).writeText(body) }
    }
}
