package com.lobogelido.application.usecase

import com.lobogelido.domain.games.GameDiscovery
import com.lobogelido.domain.games.GameFolder
import com.lobogelido.domain.games.GameFolderId
import com.lobogelido.domain.games.GameFolderManager
import com.lobogelido.domain.games.GameFolderSource
import com.lobogelido.domain.games.GameScanResult

class ScanGamesUseCase(private val discovery: GameDiscovery) {
    fun execute(folders: List<GameFolder>): GameScanResult =
        runCatching { discovery.scan(folders) }
            .getOrElse {
                GameScanResult(
                    emptyList(),
                    emptyList(),
                    listOf("No se pudo escanear la biblioteca: ${it.message ?: "error desconocido"}")
                )
            }

    fun execute(folder: GameFolder): GameScanResult =
        runCatching { discovery.scanFolder(folder) }
            .getOrElse {
                GameScanResult(
                    emptyList(),
                    emptyList(),
                    listOf("No se pudo escanear ${folder.displayName}: ${it.message ?: "error desconocido"}")
                )
            }

    fun executeAll(folders: List<GameFolder>): GameScanResult = execute(folders)
}

class AddGameFolderUseCase(private val manager: GameFolderManager) {
    fun execute(source: GameFolderSource): GameFolder = manager.addFolder(source)
}

class RemoveGameFolderUseCase(private val manager: GameFolderManager) {
    fun execute(id: GameFolderId) = manager.removeFolder(id)
}
