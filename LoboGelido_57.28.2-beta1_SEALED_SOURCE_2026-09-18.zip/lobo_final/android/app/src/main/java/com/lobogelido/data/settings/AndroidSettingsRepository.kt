package com.lobogelido.data.settings

import android.content.Context
import com.lobogelido.domain.settings.SettingsRepository

class AndroidSettingsRepository(context: Context) : SettingsRepository {
    private val preferences = context.applicationContext
        .getSharedPreferences("lobo_settings_v3", Context.MODE_PRIVATE)

    override fun getString(key: String, default: String?): String? =
        preferences.getString(key, default)

    override fun putString(key: String, value: String?) {
        preferences.edit().putString(key, value).apply()
    }

    override fun getInt(key: String, default: Int): Int =
        preferences.getInt(key, default)

    override fun putInt(key: String, value: Int) {
        preferences.edit().putInt(key, value).apply()
    }

    override fun getBoolean(key: String, default: Boolean): Boolean =
        preferences.getBoolean(key, default)

    override fun putBoolean(key: String, value: Boolean) {
        preferences.edit().putBoolean(key, value).apply()
    }

    override fun remove(key: String) {
        preferences.edit().remove(key).apply()
    }

    override fun clear() {
        preferences.edit().clear().apply()
    }
}
