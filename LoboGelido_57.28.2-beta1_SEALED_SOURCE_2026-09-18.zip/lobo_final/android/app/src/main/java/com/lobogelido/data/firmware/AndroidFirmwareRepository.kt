package com.lobogelido.data.firmware

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.lobogelido.domain.firmware.*
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Locale

class AndroidFirmwareRepository(context: Context) : FirmwareManager, FirmwareRepository {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("lobo_firmware_v2", Context.MODE_PRIVATE)
    private val root = File(app.filesDir, "firmware")
    private val hints = setOf("firmware", "nand", "system", "package1", "package2", "boot0", "boot1")

    override fun inspect(source: FirmwareSource): FirmwareInspection {
        val uri = runCatching { Uri.parse(source.id) }.getOrNull()
            ?: return FirmwareInspection(source, null, null, listOf("URI de firmware no válida."))
        val doc = runCatching { DocumentFile.fromTreeUri(app, uri) ?: DocumentFile.fromSingleUri(app, uri) }.getOrNull()
            ?: return FirmwareInspection(source, null, null, listOf("No se pudo acceder a la fuente de firmware."))
        val entries = if (doc.isDirectory) collectNames(doc, 0) else listOfNotNull(doc.name)
        val total = if (doc.isDirectory) entries.sumOf { 1L } else doc.length().coerceAtLeast(0L)
        val recognized = entries.any { name -> hints.any { hint -> name.lowercase(Locale.ROOT).contains(hint) } } || entries.size >= 4
        return FirmwareInspection(source, FirmwareVersion(source.displayName).takeIf { recognized }, FirmwareArchive(source.id, entries, total), if (recognized) emptyList() else listOf("La fuente no contiene una estructura reconocible de firmware."))
    }

    override fun validate(source: FirmwareSource, policy: FirmwareValidationPolicy): FirmwareValidationResult {
        val inspection = inspect(source)
        if (inspection.version == null) return FirmwareValidationResult(false, null, inspection.errors)
        if (policy.requireExpectedHash) {
            val expected = policy.expectedHash ?: return FirmwareValidationResult(false, null, listOf("La política exige un hash esperado, pero no se proporcionó."))
            val integrity = AndroidFirmwareIntegrityVerifier(app).verifyHash(source, expected)
            if (!integrity.valid) return FirmwareValidationResult(false, integrity, listOf(integrity.error ?: "La verificación de integridad falló."))
            return FirmwareValidationResult(true, integrity, emptyList())
        }
        if (policy.requireSignature) {
            val signature = policy.signature ?: return FirmwareValidationResult(false, null, listOf("La política exige una firma, pero no se proporcionó."))
            val trusted = policy.trustedKey ?: return FirmwareValidationResult(false, null, listOf("La política exige una clave de confianza, pero no se proporcionó."))
            val integrity = AndroidFirmwareIntegrityVerifier(app).verifySignature(source, signature, trusted)
            if (!integrity.valid) return FirmwareValidationResult(false, integrity, listOf(integrity.error ?: "La verificación de firma falló."))
            return FirmwareValidationResult(true, integrity, emptyList())
        }
        return FirmwareValidationResult(true, null, emptyList())
    }

    override fun install(source: FirmwareSource, options: FirmwareInstallOptions): FirmwareInstallResult {
        val validation = validate(source, FirmwareValidationPolicy(requireExpectedHash = false))
        if (!validation.valid) return FirmwareInstallResult(false, null, validation.errors)
        val destination = File(root, safeDirectoryName(source.displayName, source.id))
        if (destination.exists() && !options.allowReplace) return FirmwareInstallResult(false, null, listOf("Ya existe un firmware instalado para esta fuente."))
        runCatching {
            if (destination.exists()) destination.deleteRecursively()
            destination.mkdirs()
            val uri = Uri.parse(source.id)
            val doc = DocumentFile.fromTreeUri(app, uri) ?: DocumentFile.fromSingleUri(app, uri)
                ?: error("Fuente SAF no accesible.")
            if (doc.isDirectory) copyTree(doc, destination)
            else copySingle(doc, destination)
        }.onFailure { return FirmwareInstallResult(false, null, listOf(it.message ?: "Error durante la instalación del firmware.")) }

        val installed = InstalledFirmware(FirmwareVersion(source.displayName), destination.absolutePath)
        prefs.edit().putString("version", installed.version.value).putString("id", installed.installId).apply()
        return FirmwareInstallResult(true, installed, emptyList())
    }

    override fun getInstalled(): InstalledFirmware? = prefs.getString("version", null)?.let { version ->
        val id = prefs.getString("id", null).orEmpty()
        InstalledFirmware(FirmwareVersion(version), id)
    }

    override fun remove(version: FirmwareVersion): FirmwareOperationResult {
        val installed = getInstalled() ?: return FirmwareOperationResult(false, "No hay firmware instalado.")
        if (installed.version.value != version.value) {
            return FirmwareOperationResult(false, "La versión indicada no está instalada.")
        }
        val deletion = runCatching {
            val target = File(installed.installId)
            if (target.exists() && !target.deleteRecursively()) {
                error("No se pudo eliminar el firmware instalado.")
            }
        }
        if (deletion.isFailure) {
            return FirmwareOperationResult(false, deletion.exceptionOrNull()?.message ?: "No se pudo eliminar el firmware.")
        }
        prefs.edit().clear().apply()
        return FirmwareOperationResult(true)
    }

    override fun save(metadata: InstalledFirmware) {
        prefs.edit().putString("version", metadata.version.value).putString("id", metadata.installId).apply()
    }

    private fun collectNames(directory: DocumentFile, depth: Int): List<String> {
        if (depth > 8) return emptyList()
        return runCatching { directory.listFiles().toList() }.getOrDefault(emptyList()).flatMap { child ->
            if (child.isDirectory) collectNames(child, depth + 1) else listOfNotNull(child.name)
        }
    }

    private fun copyTree(source: DocumentFile, destination: File) {
        runCatching { source.listFiles().toList() }.getOrDefault(emptyList()).forEach { child ->
            val name = safeFileName(child.name ?: "entry")
            val target = File(destination, name)
            if (child.isDirectory) { target.mkdirs(); copyTree(child, target) }
            else copySingle(child, target.parentFile ?: destination, target.name)
        }
    }

    private fun copySingle(source: DocumentFile, destination: File, outputName: String = safeFileName(source.name ?: "firmware.bin")) {
        destination.mkdirs()
        val target = File(destination, outputName)
        app.contentResolver.openInputStream(source.uri)?.use { input -> FileOutputStream(target).use { output -> input.copyTo(output, 64 * 1024) } }
            ?: error("No se pudo leer ${source.name ?: "el archivo"}.")
    }

    private fun safeFileName(name: String): String = name.replace(Regex("[\\x00-\\x1F\\x7F/\\\\:]"), "_").take(240).ifBlank { "entry" }
    private fun safeDirectoryName(name: String, id: String): String = "${safeFileName(name)}_${Integer.toUnsignedString(id.hashCode())}"
}

class AndroidFirmwareIntegrityVerifier(private val context: Context) : FirmwareIntegrityVerifier {
    override fun verifyHash(source: FirmwareSource, expected: ExpectedHash): IntegrityResult {
        val algorithm = expected.algorithm.trim().uppercase(Locale.ROOT)
        val jca = when (algorithm) {
            "SHA256", "SHA-256" -> "SHA-256"
            "SHA1", "SHA-1" -> "SHA-1"
            "MD5" -> "MD5"
            else -> return IntegrityResult(false, expected.algorithm, "Algoritmo de hash no soportado: ${expected.algorithm}")
        }
        val uri = Uri.parse(source.id)
        val doc = runCatching { DocumentFile.fromSingleUri(context, uri) }.getOrNull()
            ?: return IntegrityResult(false, expected.algorithm, "No se pudo resolver la fuente SAF.")
        if (!doc.isFile) return IntegrityResult(false, expected.algorithm, "La verificación de hash requiere un archivo, no una carpeta SAF.")
        val actual = runCatching {
            val digest = MessageDigest.getInstance(jca)
            context.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (count > 0) digest.update(buffer, 0, count)
                }
            } ?: error("No se pudo abrir la fuente SAF.")
            digest.digest().joinToString("") { byte -> "%02x".format(byte) }
        }.getOrElse { return IntegrityResult(false, expected.algorithm, it.message ?: "No se pudo calcular el hash.") }
        val valid = actual.equals(expected.hexDigest.trim(), ignoreCase = true)
        return IntegrityResult(valid, expected.algorithm, if (valid) null else "El hash calculado no coincide con el esperado.")
    }

    override fun verifySignature(source: FirmwareSource, signature: FirmwareSignature, trustedKey: TrustedVerificationKey): IntegrityResult {
        val keyData = trustedKey.publicKeyBase64 ?: return IntegrityResult(false, signature.algorithm, "No hay una clave pública de confianza asociada a ${trustedKey.id}.")
        return runCatching {
            val keyBytes = java.util.Base64.getDecoder().decode(keyData)
            val keySpec = java.security.spec.X509EncodedKeySpec(keyBytes)
            val publicKey = java.security.KeyFactory.getInstance("EC").generatePublic(keySpec)
            val verifier = java.security.Signature.getInstance(signature.algorithm)
            verifier.initVerify(publicKey)
            val uri = Uri.parse(source.id)
            val doc = DocumentFile.fromSingleUri(context, uri) ?: error("No se pudo resolver la fuente SAF.")
            if (!doc.isFile) error("La firma requiere un archivo plano.")
            context.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) { val count = input.read(buffer); if (count < 0) break; if (count > 0) verifier.update(buffer, 0, count) }
            } ?: error("No se pudo abrir la fuente SAF.")
            val signatureBytes = java.util.Base64.getDecoder().decode(signature.value)
            val valid = verifier.verify(signatureBytes)
            IntegrityResult(valid, signature.algorithm, if (valid) null else "La firma no coincide con la fuente.")
        }.getOrElse { IntegrityResult(false, signature.algorithm, it.message ?: "No se pudo verificar la firma.") }
    }
}

