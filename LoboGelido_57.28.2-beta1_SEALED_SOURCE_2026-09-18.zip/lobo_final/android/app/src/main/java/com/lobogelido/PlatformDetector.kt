package com.lobogelido

import android.net.Uri
import java.util.Locale

enum class GamePlatform(val id: String, val internalName: String) {
    AUTO("auto", "Detección automática"),
    GBC("gbc", "Game Boy Color"),
    GBA("gba", "Game Boy Advance"),
    N64("n64", "Nintendo 64"),
    NDS("nds", "Nintendo DS"),
    GAMECUBE("gc", "GameCube"),
    WII("wii", "Wii"),
    N3DS("3ds", "Nintendo 3DS"),
    SWITCH("switch", "Nintendo Switch")
}

data class PlatformDetection(val platform: GamePlatform, val confidence: Int, val reason: String)

/** User-facing platform is deliberately hidden: detection only chooses the internal core. */
object PlatformDetector {
    fun detect(uri: Uri?, title: String = ""): PlatformDetection {
        val value = listOf(uri?.lastPathSegment.orEmpty(), uri?.toString().orEmpty(), title)
            .joinToString(" ").lowercase(Locale.ROOT)
        val ext = value.substringAfterLast('.', "")
        return when (ext) {
            "gb", "gbc" -> PlatformDetection(GamePlatform.GBC, 96, "Extensión de cartucho")
            "gba" -> PlatformDetection(GamePlatform.GBA, 96, "Extensión de cartucho")
            "z64", "n64", "v64" -> PlatformDetection(GamePlatform.N64, 96, "Extensión de cartucho")
            "nds" -> PlatformDetection(GamePlatform.NDS, 96, "Extensión de cartucho")
            "3ds", "cci", "cia", "cxi" -> PlatformDetection(GamePlatform.N3DS, 92, "Contenedor portátil")
            "rvz" -> PlatformDetection(GamePlatform.WII, 95, "Contenedor RVZ")
            "gcm", "gcz" -> PlatformDetection(GamePlatform.GAMECUBE, 92, "Imagen óptica")
            "iso" -> when {
                "wii" in value -> PlatformDetection(GamePlatform.WII, 80, "Pista de plataforma en nombre")
                "gamecube" in value || "gc" in value -> PlatformDetection(GamePlatform.GAMECUBE, 80, "Pista de plataforma en nombre")
                else -> PlatformDetection(GamePlatform.AUTO, 20, "ISO requiere inspección de cabecera")
            }
            "nro", "nso", "nca", "xci", "nsp" -> PlatformDetection(GamePlatform.SWITCH, 97, "Contenido de Switch")
            else -> PlatformDetection(GamePlatform.AUTO, 0, "Sin señal suficiente; inspección del loader")
        }
    }
}
