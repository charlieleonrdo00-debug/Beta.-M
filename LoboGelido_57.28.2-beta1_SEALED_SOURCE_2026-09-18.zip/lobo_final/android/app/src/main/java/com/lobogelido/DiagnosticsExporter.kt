package com.lobogelido

import android.app.ActivityManager
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * In-app diagnostic bundle exporter.
 *
 * Produces a single ZIP that captures everything the emulator knows about
 * ITSELF at a point in time — native runtime/Vulkan/presenter diagnostics,
 * device and build metadata, a tail of logcat, and the last recorded crash —
 * so the user can hand it over for offline debugging.
 *
 * PRIVACY / SAFETY BOUNDARY (deliberate):
 *   - The bundle NEVER contains encryption keys, firmware images, or game ROMs.
 *     Only *status* is exported (configured yes/no, validation label, sizes),
 *     never the secret/copyrighted bytes.
 *   - Persistable SAF URIs are truncated to their authority + last segment so a
 *     full private tree path is not leaked verbatim.
 *
 * ROBUSTNESS: every section is wrapped independently. A failure collecting one
 * datum degrades that section to an error line; it never aborts the export and
 * never throws into the caller. This mirrors the try/catch(Throwable) discipline
 * already applied on the render/input JNI hot paths.
 */
object DiagnosticsExporter {

    private val stamp: String
        get() = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())

    /** Suggested filename for the SAF "create document" dialog. */
    fun suggestedFileName(): String = "lobogelido-diagnostico-$stamp.zip"

    /** Result of a direct save, with a human-readable location or error. */
    data class SaveResult(val ok: Boolean, val location: String)

    /**
     * Save the bundle DIRECTLY into the phone's public Downloads collection
     * (Downloads/LoboGelido/…) with no file picker, using MediaStore. On API 29+
     * (minSdk here is 35) this needs no storage permission. Never throws.
     */
    fun saveToDownloads(context: Context, extra: Map<String, String> = emptyMap()): SaveResult {
        val bytes = build(context, extra) // never throws
        if (bytes.isEmpty()) return SaveResult(false, "No se pudo generar el diagnóstico.")
        val name = suggestedFileName()
        return runCatching {
            val resolver = context.contentResolver
            val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LoboGelido")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(collection, values)
                ?: return@runCatching SaveResult(false, "El sistema rechazó la escritura en Descargas.")
            val wrote = resolver.openOutputStream(uri)?.use { it.write(bytes); true } ?: false
            if (!wrote) {
                runCatching { resolver.delete(uri, null, null) }
                return@runCatching SaveResult(false, "No se pudo abrir el destino en Descargas.")
            }
            // Publish (clear the pending flag) so the file becomes visible.
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            runCatching { resolver.update(uri, values, null, null) }
            SaveResult(true, "Descargas/LoboGelido/$name")
        }.getOrElse { SaveResult(false, "No se pudo guardar en Descargas: ${it.message}") }
    }

    /**
     * Build the ZIP entirely in memory and return its bytes. Never throws:
     * on catastrophic failure it returns a minimal ZIP describing the failure.
     *
     * @param extra domain sections the Activity supplies (already redacted),
     *              keyed by file name -> text content.
     */
    fun build(context: Context, extra: Map<String, String> = emptyMap()): ByteArray {
        val sections = linkedMapOf<String, String>()
        sections["README.txt"] = readme()
        sections["device.txt"] = safe { deviceInfo(context) }
        sections["app.txt"] = safe { appInfo() }
        sections["runtime_native.txt"] = safe { nativeRuntime() }
        sections["logcat.txt"] = safe { logcatTail() }
        sections["crash_last.txt"] = safe { lastCrash(context) }
        // Activity-supplied, already-redacted domain sections (settings, session,
        // keys/firmware status). Added last so they cannot break the core dump.
        for ((name, body) in extra) {
            val clean = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            sections[clean] = body
        }
        return zip(sections)
    }

    // ---- section collectors ---------------------------------------------------

    private fun readme(): String = buildString {
        appendLine("Lobo Gélido — paquete de diagnóstico")
        appendLine("Generado: $stamp")
        appendLine()
        appendLine("Contiene: metadatos de dispositivo/app, diagnóstico del runtime")
        appendLine("nativo (CPU/Vulkan/presenter), cola de logcat y última traza de crash.")
        appendLine()
        appendLine("NO contiene: llaves de cifrado, firmware ni ROMs de juegos.")
        appendLine("Solo se exporta el ESTADO (configurado sí/no, etiquetas), nunca")
        appendLine("los bytes secretos o con copyright.")
    }

    private fun deviceInfo(context: Context): String = buildString {
        appendLine("== Dispositivo ==")
        appendLine("manufacturer = ${Build.MANUFACTURER}")
        appendLine("model        = ${Build.MODEL}")
        appendLine("device       = ${Build.DEVICE}")
        appendLine("board        = ${Build.BOARD}")
        appendLine("hardware     = ${Build.HARDWARE}")
        appendLine("soc          = ${socLabel()}")
        appendLine("android_sdk  = ${Build.VERSION.SDK_INT}")
        appendLine("android_rel  = ${Build.VERSION.RELEASE}")
        appendLine("abis         = ${Build.SUPPORTED_ABIS.joinToString()}")
        runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            appendLine("mem_total    = ${mi.totalMem / (1024 * 1024)} MB")
            appendLine("mem_avail    = ${mi.availMem / (1024 * 1024)} MB")
            appendLine("mem_low      = ${mi.lowMemory}")
            appendLine("large_heap   = ${am.memoryClass} MB (class), ${am.largeMemoryClass} MB (large)")
        }
        runCatching {
            val dm = context.resources.displayMetrics
            appendLine("display      = ${dm.widthPixels}x${dm.heightPixels} @ ${dm.densityDpi}dpi (x${dm.density})")
        }
    }

    private fun socLabel(): String = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            "${Build.SOC_MANUFACTURER} / ${Build.SOC_MODEL}"
        } else "n/d (SDK<31)"
    }.getOrDefault("n/d")

    private fun appInfo(): String = buildString {
        appendLine("== Aplicación ==")
        // BuildConfig is generated in this package; guard each field so a build
        // that omits one still exports the rest.
        appendLine("version_name    = ${runCatching { BuildConfig.VERSION_NAME }.getOrDefault("?")}")
        appendLine("version_code    = ${runCatching { BuildConfig.VERSION_CODE }.getOrDefault("?")}")
        appendLine("application_id  = ${runCatching { BuildConfig.APPLICATION_ID }.getOrDefault("?")}")
        appendLine("build_type      = ${runCatching { BuildConfig.BUILD_TYPE }.getOrDefault("?")}")
        appendLine("vulkan_smoke    = ${runCatching { BuildConfig.VULKAN_SMOKE_TEST }.getOrDefault("?")}")
    }

    private fun nativeRuntime(): String = buildString {
        appendLine("== Runtime nativo (JNI) ==")
        // Each JNI call is independently guarded: if the .so is missing a symbol
        // or the native side throws, we record that instead of failing the dump.
        appendLine("version              = ${jni { RuntimeBridge.version() }}")
        appendLine("session_state        = ${jni { RuntimeBridge.sessionState() }}")
        appendLine("selected_content     = ${jni { RuntimeBridge.selectedContent() }}")
        appendLine()
        appendLine("[diagnostics]");        appendLine(jni { RuntimeBridge.diagnostics() })
        appendLine("[runtime_diagnostics]"); appendLine(jni { RuntimeBridge.runtimeDiagnostics() })
        appendLine("[runtime_metrics]");     appendLine(jni { RuntimeBridge.runtimeMetrics() })
        appendLine("[vulkan_diagnostics]");  appendLine(jni { RuntimeBridge.vulkanDiagnostics() })
        appendLine("[presenter_diagnostics]");appendLine(jni { RuntimeBridge.presenterDiagnostics() })
    }

    private fun logcatTail(): String = runCatching {
        // Best effort: on modern Android an app can read only its own log buffer.
        val process = ProcessBuilder(
            listOf("logcat", "-d", "-v", "time", "-t", "1500")
        ).redirectErrorStream(true).start()
        val out = process.inputStream.bufferedReader().use { it.readText() }
        process.destroy()
        if (out.isBlank()) "logcat vacío o no accesible en este dispositivo." else out
    }.getOrElse { "logcat no disponible: ${it.message}" }

    private fun lastCrash(context: Context): String = runCatching {
        val f = LoboCrashReporter.crashFile(context)
        if (f.exists() && f.length() > 0) f.readText() else "Sin crash registrado desde la última instalación."
    }.getOrElse { "No se pudo leer el registro de crash: ${it.message}" }

    // ---- helpers --------------------------------------------------------------

    private inline fun safe(block: () -> String): String =
        try { block() } catch (t: Throwable) { "Sección no disponible: ${t.message}" }

    private inline fun jni(block: () -> String): String =
        try { block() } catch (t: Throwable) { "<no disponible: ${t.javaClass.simpleName}: ${t.message}>" }

    private fun zip(sections: Map<String, String>): ByteArray {
        val bos = ByteArrayOutputStream()
        try {
            ZipOutputStream(bos).use { zos ->
                for ((name, body) in sections) {
                    zos.putNextEntry(ZipEntry(name))
                    zos.write(body.toByteArray(Charsets.UTF_8))
                    zos.closeEntry()
                }
            }
        } catch (t: Throwable) {
            // Last-resort minimal archive so the caller always gets a valid ZIP.
            return runCatching {
                val fb = ByteArrayOutputStream()
                ZipOutputStream(fb).use { z ->
                    z.putNextEntry(ZipEntry("error.txt"))
                    z.write(("Fallo al construir el paquete: ${t.message}").toByteArray())
                    z.closeEntry()
                }
                fb.toByteArray()
            }.getOrDefault(ByteArray(0))
        }
        return bos.toByteArray()
    }
}
