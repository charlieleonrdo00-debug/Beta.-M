package com.lobogelido

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.util.Locale

/**
 * Facts that can be read from the user's actual game file without inventing
 * title/version/compatibility information. Anything unavailable is explicitly
 * reported as unknown.
 */
data class GameFileMetadata(
    val format: String,
    val sizeBytes: Long,
    val modifiedEpoch: Long,
    val readable: Boolean,
    val header: String
) {
    companion object {
        private val supported = setOf("nsp", "xci", "nca", "nro", "nso", "nsz", "xcz")

        fun read(context: Context, uri: Uri): GameFileMetadata? {
            val doc = try { DocumentFile.fromSingleUri(context, uri) } catch (_: Throwable) { null }
            if (doc == null || !doc.exists() || !doc.isFile) return null
            val name = doc.name.orEmpty()
            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext !in supported) return null
            var readable = false
            var header = ""
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val b = ByteArray(4)
                    val n = input.read(b)
                    readable = n > 0
                    if (n == 4) header = b.joinToString("") { "%02X".format(it) }
                }
            } catch (_: Throwable) {}
            return GameFileMetadata(
                format = ext.uppercase(Locale.ROOT),
                sizeBytes = doc.length().coerceAtLeast(0L),
                modifiedEpoch = doc.lastModified().coerceAtLeast(0L),
                readable = readable,
                header = header
            )
        }

        fun sizeLabel(bytes: Long): String = when {
            bytes <= 0L -> "Desconocido"
            bytes < 1024L * 1024L -> "${bytes / 1024} KB"
            bytes < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
            else -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
        }
    }
}

