#!/usr/bin/env bash
set -euo pipefail

# Lobo Gélido Android build bootstrap.
# AGP 8.13.x requires Gradle 8.13.x. Do not use a system Gradle 9.x here.
GRADLE_VERSION="8.13"
CACHE_DIR="${XDG_CACHE_HOME:-$HOME/.cache}/lobo-gelido/gradle-${GRADLE_VERSION}"
GRADLE_BIN="$CACHE_DIR/gradle-${GRADLE_VERSION}/bin/gradle"
ZIP="$CACHE_DIR/gradle-${GRADLE_VERSION}-bin.zip"

if [[ ! -x "$GRADLE_BIN" ]]; then
  mkdir -p "$CACHE_DIR"
  echo "Downloading Gradle ${GRADLE_VERSION}..."
  curl -fL --retry 3 --retry-delay 2 \
    "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" \
    -o "$ZIP"
  rm -rf "$CACHE_DIR/gradle-${GRADLE_VERSION}"
  unzip -q "$ZIP" -d "$CACHE_DIR"
fi

# AGP 8.13 is documented for JDK 17. Fail early with a useful message instead
# of producing a long, misleading plugin error.
JAVA_MAJOR="$(java -version 2>&1 | sed -n 's/.*version "\([0-9][0-9]*\).*/\1/p' | head -1)"
if [[ "${JAVA_MAJOR:-0}" != "17" ]]; then
  echo "ERROR: Lobo Gélido requires JDK 17 for the AGP 8.13 build." >&2
  echo "Current Java: ${JAVA_MAJOR:-unknown}" >&2
  exit 2
fi

exec "$GRADLE_BIN" --no-daemon --stacktrace assembleDebug "$@"
