# Lobo Gélido 31.0 — CPU Fast Path & Runtime Selection

## Objetivo

31.0 convierte la capa CPU/runtime en una ruta más determinista y eficiente antes de activar el backend Dynarmic real en un entorno Android/NDK con su árbol fuente disponible.

## Cambios

- `BackendKind` reemplaza la selección frágil de backends por comparación de nombres.
- `BackendManager` selecciona JIT → Block → Interpreter usando capacidades reales.
- El runtime deja de depender de que el backend JIT se llame exactamente `"JIT"`; Dynarmic puede exponer su nombre real.
- `RuntimeCoordinator::stop()` invalida JIT, limpia caché de decodificación e invalida el BlockBackend antes de reutilizar memoria.
- Se añadieron rutas rápidas `memcpy` para lecturas de 32/64 bits dentro de página en `AddressSpace`.
- Se añadió una prueba de reutilización completa de sesión para detectar estado de CPU/cachés que sobreviva a `stop()`.
- La suite sigue ejecutándose con C++20 y sin extensiones del compilador.

## Validación

- Release: 19/19 pruebas pasan.
- ASan + UBSan + leak detection: 19/19 pruebas pasan.

## Dynarmic

El adaptador real permanece opcional. El árbol de Dynarmic debe proporcionarse mediante:

```text
-DLOBOGELIDO_ENABLE_DYNARMIC=ON
-DLOBOGELIDO_DYNARMIC_SOURCE_DIR=/ruta/al/arbol/dynarmic
```

No se incluye código propietario ni firmware/keys/ROMs.

Dynarmic declara soporte para C++20, Android y host AArch64, y permite un sistema de memoria proporcionado por el emulador. La integración de Lobo Gélido conserva esa separación para poder evolucionar MMU/Fastmem sin acoplar el núcleo a una implementación concreta.
