#include "timer_manager.h"
namespace lg::system {
TimerManager::TimerId TimerManager::create(Scheduler::Tick delay, Scheduler::Tick period){
    const auto id=next_id_++; timers_[id]=Timer{delay,period,true,false}; return id;
}
bool TimerManager::cancel(TimerId id){auto it=timers_.find(id);if(it==timers_.end())return false;it->second.armed=false;return true;}
bool TimerManager::armed(TimerId id)const noexcept{auto it=timers_.find(id);return it!=timers_.end()&&it->second.armed;}
bool TimerManager::expired(TimerId id)const noexcept{auto it=timers_.find(id);return it!=timers_.end()&&it->second.fired;}
Scheduler::Tick TimerManager::deadline(TimerId id)const noexcept{auto it=timers_.find(id);return it==timers_.end()?0:it->second.deadline;}
void TimerManager::pump(Scheduler::Tick now){for(auto&[id,t]:timers_)if(t.armed&&now>=t.deadline){t.fired=true;if(t.period)t.deadline=now+t.period;else t.armed=false;}}
}

void lg::system::TimerManager::clear() noexcept { timers_.clear(); next_id_=1; }
