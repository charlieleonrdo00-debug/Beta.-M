#pragma once
#include <cstdint>
#include <unordered_map>
#include "../cpu/interpreter.h"
#include "thread_manager.h"
namespace lg::system {
class GuestThreadContextManager {
public:
    cpu::CpuState* create(ThreadManager::ThreadId id, uint64_t pc, uint64_t sp=0);
    cpu::CpuState* get(ThreadManager::ThreadId id) noexcept;
    const cpu::CpuState* get(ThreadManager::ThreadId id) const noexcept;
    bool destroy(ThreadManager::ThreadId id);
    void clear() noexcept;
    size_t size() const noexcept { return contexts_.size(); }
private:
    std::unordered_map<ThreadManager::ThreadId,cpu::CpuState> contexts_;
};
}
