#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>
#include <unordered_set>

namespace lg::system {

class CapabilityManager {
public:
    using ProcessId = uint64_t;
    using CapabilityId = uint32_t;

    bool grant(ProcessId process, std::string capability);
    bool revoke(ProcessId process, const std::string& capability) noexcept;
    bool has(ProcessId process, const std::string& capability) const noexcept;
    void clear(ProcessId process) noexcept;
    void clear_all() noexcept;
    size_t count(ProcessId process) const noexcept;

private:
    std::unordered_map<ProcessId, std::unordered_set<std::string>> grants_;
};

} // namespace lg::system
