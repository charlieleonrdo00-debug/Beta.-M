#pragma once
#include "scheduler.h"
#include "thread_manager.h"
#include "synchronization.h"
#include "service_registry.h"
#include "ipc_manager.h"
#include "timer_manager.h"
#include "guest_thread_context.h"
#include "process_manager.h"
#include "capability_manager.h"
#include "../core/result.h"
#include <utility>
namespace lg::system {
class Kernel {
public:
    Kernel():threads_(scheduler_){}
    Scheduler& scheduler() noexcept{return scheduler_;}
    ThreadManager& threads() noexcept{return threads_;}
    const ThreadManager& threads() const noexcept{return threads_;}
    SyncManager& sync() noexcept{return sync_;}
    ServiceRegistry& services() noexcept{return services_;}
    IpcManager& ipc() noexcept{return ipc_;}
    TimerManager& timers() noexcept{return timers_;}
    GuestThreadContextManager& contexts() noexcept{return contexts_;}
    ProcessManager& processes() noexcept{return processes_;}
    const ProcessManager& processes() const noexcept{return processes_;}
    CapabilityManager& capabilities() noexcept{return capabilities_;}
    const CapabilityManager& capabilities() const noexcept{return capabilities_;}
    IpcEndpoint* connect_service(ProcessManager::ProcessId process, const std::string& name) const noexcept {
        return services_.find_authorized(name, process, capabilities_);
    }
    IpcManager::ChannelId connect_service_channel(ProcessManager::ProcessId process, const std::string& name) noexcept {
        if (!services_.find_authorized(name, process, capabilities_)) return 0;
        const auto* required = services_.required_capability(name);
        return ipc_.create_authorized_channel(process, name, required ? *required : std::string{});
    }
    bool send_service(IpcManager::ChannelId channel, ProcessManager::ProcessId process, IpcMessage message) noexcept {
        const auto* caps = &capabilities_;
        return ipc_.send_authorized(channel, process, std::move(message), threads_, *caps);
    }
    bool receive_service(IpcManager::ChannelId channel, ProcessManager::ProcessId process, IpcMessage& out, ThreadManager::ThreadId waiter = 0) noexcept {
        return ipc_.receive_authorized(channel, process, out, waiter, threads_, capabilities_);
    }
    core::Result<IpcMessage> dispatch_service(IpcManager::ChannelId channel, ProcessManager::ProcessId process, const IpcMessage& request) const noexcept {
        if (!ipc_.channel_authorized(channel, process, capabilities_)) return core::Result<IpcMessage>::Error("unauthorized IPC channel");
        const auto* service = ipc_.channel_service(channel);
        if (!service) return core::Result<IpcMessage>::Error("invalid IPC service channel");
        auto* endpoint = services_.find_authorized(*service, process, capabilities_);
        if (!endpoint) return core::Result<IpcMessage>::Error("invalid IPC service channel");
        return endpoint->dispatch(request);
    }
    bool destroy_process(ProcessManager::ProcessId process) noexcept {
        if (!processes_.destroy(process)) return false;
        capabilities_.clear(process);
        ipc_.close_process(process);
        return true;
    }
    void reset() noexcept { contexts_.clear(); capabilities_.clear_all(); processes_.clear(); timers_.clear(); ipc_.clear(); sync_.clear(); services_.clear(); threads_.clear(); scheduler_.clear(); }
private:
    Scheduler scheduler_;
    ThreadManager threads_;
    SyncManager sync_;
    ServiceRegistry services_;
    IpcManager ipc_;
    TimerManager timers_;
    GuestThreadContextManager contexts_;
    ProcessManager processes_;
    CapabilityManager capabilities_;
};
}
