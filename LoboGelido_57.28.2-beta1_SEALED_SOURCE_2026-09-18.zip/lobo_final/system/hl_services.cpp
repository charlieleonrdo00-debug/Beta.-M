#include "hl_services.h"
#include <cstring>
#include <limits>
namespace lg::system {
core::Result<IpcMessage> SystemService::dispatch(const IpcMessage& r){
    IpcMessage out; out.command_id=r.command_id;
    if(r.command_id==0){out.payload.resize(sizeof(uint64_t));const auto t=scheduler_.now();std::memcpy(out.payload.data(),&t,sizeof(t));return core::Result<IpcMessage>::Ok(std::move(out));}
    if(r.command_id==1){const char name[]="LoboGelido-HLE";out.payload.assign(name,name+sizeof(name)-1);return core::Result<IpcMessage>::Ok(std::move(out));}
    if(r.command_id==2){const char name[]="LoboGelido-SystemService-v1";out.payload.assign(name,name+sizeof(name)-1);return core::Result<IpcMessage>::Ok(std::move(out));}
    return core::Result<IpcMessage>::Error("unknown system service command");
}
std::unique_ptr<IpcEndpoint> make_system_service(Scheduler& s){return std::make_unique<SystemService>(s);}
}
