#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>

namespace lg::system {

class ProcessManager {
public:
    using ProcessId = uint64_t;
    struct Process {
        ProcessId id{};
        std::string name;
        std::string executable_path;
        uint64_t entry_point{};
        uint64_t image_base{};
        uint64_t image_size{};
        uint32_t segment_count{};
        bool running{};
        bool initialized{};
    };

    ProcessId create(std::string name, std::string executable_path,
                     uint64_t entry_point, uint64_t image_base,
                     uint64_t image_size, uint32_t segment_count);
    bool mark_initialized(ProcessId id) noexcept;
    bool start(ProcessId id) noexcept;
    bool stop(ProcessId id) noexcept;
    bool destroy(ProcessId id) noexcept;
    const Process* get(ProcessId id) const noexcept;
    const Process* current() const noexcept;
    void clear() noexcept;
    size_t size() const noexcept { return processes_.size(); }

private:
    std::unordered_map<ProcessId, Process> processes_;
    ProcessId next_id_{1};
    ProcessId current_id_{};
};

} // namespace lg::system
