#include "thread_manager.h"
#include <algorithm>
#include <limits>

namespace lg::system {

ThreadManager::ThreadManager(Scheduler& scheduler) : scheduler_(scheduler) {}

ThreadManager::~ThreadManager() {
    // Scheduler callbacks must never outlive their ThreadManager owner.
    for (auto& [id, thread] : threads_) {
        (void)id;
        if (thread.wake_event) scheduler_.cancel(thread.wake_event);
        thread.wake_event = 0;
    }
    ready_queue_.clear();
    ready_index_.clear();
}

uint64_t ThreadManager::priority_weight(uint8_t priority) noexcept {
    return 1ull + static_cast<uint64_t>(priority);
}

uint64_t ThreadManager::saturating_add(uint64_t a, uint64_t b) noexcept {
    return b > std::numeric_limits<uint64_t>::max() - a
        ? std::numeric_limits<uint64_t>::max() : a + b;
}

uint64_t ThreadManager::saturating_mul(uint64_t a, uint64_t b) noexcept {
    if (a == 0 || b == 0) return 0;
    return a > std::numeric_limits<uint64_t>::max() / b
        ? std::numeric_limits<uint64_t>::max() : a * b;
}

void ThreadManager::ready_insert(Thread& thread) {
    thread.info.state = ThreadState::Ready;
    if (thread.info.ready_since_tick == 0) thread.info.ready_since_tick = scheduler_.now();
    ready_remove(thread);
    auto [it, inserted] = ready_queue_.insert(ReadyKey{
        thread.info.priority,
        thread.info.deadline_tick != 0,
        thread.info.deadline_tick,
        thread.info.vruntime,
        ready_sequence_++,
        thread.info.id});
    (void)inserted;
    ready_index_[thread.info.id] = it;
}

void ThreadManager::ready_remove(Thread& thread) {
    auto it = ready_index_.find(thread.info.id);
    if (it == ready_index_.end()) return;
    ready_queue_.erase(it->second);
    ready_index_.erase(it);
}

ThreadManager::ThreadId ThreadManager::create(std::string name, uint8_t priority, Entry entry) {
    if (!entry) return 0;
    Thread t{};
    t.info.id = next_id_++;
    if (t.info.id == 0) t.info.id = next_id_++;
    t.info.name = std::move(name);
    t.info.priority = priority;
    t.info.base_priority = priority;
    t.info.state = ThreadState::Ready;
    t.info.last_run_tick = scheduler_.now();
    t.info.ready_since_tick = scheduler_.now();
    t.entry = std::move(entry);
    const auto id = t.info.id;
    auto [it, inserted] = threads_.emplace(id, std::move(t));
    if (!inserted) return 0;
    ready_insert(it->second);
    return id;
}

bool ThreadManager::make_ready(ThreadId id) {
    auto it = threads_.find(id);
    if (it == threads_.end() || it->second.info.state == ThreadState::Terminated) return false;
    if (it->second.info.state == ThreadState::Ready) return true;
    if (it->second.wake_event) {
        scheduler_.cancel(it->second.wake_event);
        it->second.wake_event = 0;
    }
    it->second.info.wake_tick = 0;
    it->second.info.last_run_tick = scheduler_.now();
    it->second.info.ready_since_tick = scheduler_.now();
    ++it->second.info.wakeups;
    ready_insert(it->second);
    return true;
}

bool ThreadManager::sleep(ThreadId id, Scheduler::Tick ticks) {
    auto it = threads_.find(id);
    if (it == threads_.end() || it->second.info.state == ThreadState::Terminated) return false;
    if (it->second.info.state == ThreadState::Ready) ready_remove(it->second);
    if (it->second.wake_event) scheduler_.cancel(it->second.wake_event);
    if (current_ == id) current_ = 0;

    const auto now = scheduler_.now();
    const auto deadline = ticks > std::numeric_limits<Scheduler::Tick>::max() - now
        ? std::numeric_limits<Scheduler::Tick>::max() : now + ticks;
    it->second.info.state = ThreadState::Sleeping;
    it->second.info.wake_tick = deadline;
    it->second.info.ready_since_tick = 0;
    it->second.wake_event = scheduler_.schedule(deadline, [this, id] {
        auto x = threads_.find(id);
        if (x != threads_.end() && x->second.info.state == ThreadState::Sleeping) {
            x->second.wake_event = 0;
            x->second.info.wake_tick = 0;
            x->second.info.last_run_tick = scheduler_.now();
            x->second.info.ready_since_tick = scheduler_.now();
            ++x->second.info.wakeups;
            ready_insert(x->second);
        }
    }, 220);
    return it->second.wake_event != 0;
}

bool ThreadManager::block(ThreadId id) {
    auto it = threads_.find(id);
    if (it == threads_.end() || it->second.info.state == ThreadState::Terminated) return false;
    if (it->second.info.state == ThreadState::Ready) ready_remove(it->second);
    if (it->second.wake_event) scheduler_.cancel(it->second.wake_event);
    it->second.wake_event = 0;
    it->second.info.state = ThreadState::Blocked;
    it->second.info.wake_tick = 0;
    it->second.info.ready_since_tick = 0;
    if (current_ == id) current_ = 0;
    return true;
}

bool ThreadManager::unblock(ThreadId id) { return make_ready(id); }

bool ThreadManager::terminate(ThreadId id) {
    auto it = threads_.find(id);
    if (it == threads_.end()) return false;
    if (it->second.info.state == ThreadState::Ready) ready_remove(it->second);
    if (it->second.wake_event) scheduler_.cancel(it->second.wake_event);
    it->second.wake_event = 0;
    it->second.info.state = ThreadState::Terminated;
    it->second.info.wake_tick = 0;
    it->second.info.ready_since_tick = 0;
    if (current_ == id) current_ = 0;
    return true;
}

bool ThreadManager::yield(ThreadId id) {
    auto it = threads_.find(id);
    if (it == threads_.end() || it->second.info.state != ThreadState::Running) return false;
    ++it->second.info.yields;
    ++yields_;
    it->second.info.state = ThreadState::Ready;
    it->second.info.ready_since_tick = scheduler_.now();
    current_ = 0;
    ready_insert(it->second);
    return true;
}

bool ThreadManager::preempt_current() {
    if (!current_) return false;
    auto it = threads_.find(current_);
    if (it == threads_.end() || it->second.info.state != ThreadState::Running) {
        current_ = 0;
        return false;
    }
    ++it->second.info.preemptions;
    ++preemptions_;
    it->second.info.state = ThreadState::Ready;
    it->second.info.ready_since_tick = scheduler_.now();
    current_ = 0;
    ready_insert(it->second);
    return true;
}

bool ThreadManager::set_priority(ThreadId id, uint8_t priority) {
    auto it = threads_.find(id);
    if (it == threads_.end()) return false;
    const bool ready = it->second.info.state == ThreadState::Ready;
    if (ready) ready_remove(it->second);
    it->second.info.priority = priority;
    it->second.info.base_priority = priority;
    if (ready) ready_insert(it->second);
    return true;
}

bool ThreadManager::set_affinity(ThreadId id, uint64_t affinity_mask) {
    auto it = threads_.find(id);
    if (it == threads_.end() || affinity_mask == 0) return false;
    it->second.info.affinity_mask = affinity_mask;
    return true;
}

bool ThreadManager::set_deadline(ThreadId id, uint64_t deadline_tick) {
    auto it = threads_.find(id);
    if (it == threads_.end()) return false;
    const bool ready = it->second.info.state == ThreadState::Ready;
    if (ready) ready_remove(it->second);
    it->second.info.deadline_tick = deadline_tick;
    if (ready) ready_insert(it->second);
    return true;
}

const ThreadInfo* ThreadManager::info(ThreadId id) const noexcept {
    auto it = threads_.find(id);
    return it == threads_.end() ? nullptr : &it->second.info;
}

ThreadManager::ThreadId ThreadManager::schedule_next() {
    ++scheduler_decisions_;
    if (ready_queue_.empty()) return 0;
    const auto id = ready_queue_.begin()->id;
    auto it = threads_.find(id);
    if (it == threads_.end() || it->second.info.state != ThreadState::Ready) return 0;
    return id;
}

uint64_t ThreadManager::recommended_quantum(ThreadId id, uint64_t base_quantum) const noexcept {
    auto it = threads_.find(id);
    if (it == threads_.end()) return std::max<uint64_t>(1, base_quantum);
    // Higher priorities get shorter decision intervals, while low-priority
    // work gets a longer batch to reduce scheduler overhead. Deterministic and
    // bounded so it cannot turn into an unbounded host-side timeslice.
    const uint64_t factor = 256ull - static_cast<uint64_t>(it->second.info.priority);
    const uint64_t scaled = (saturating_mul(base_quantum, factor) + 127ull) / 128ull;
    return std::clamp<uint64_t>(scaled, 8, 256);
}

bool ThreadManager::dispatch_next(uint64_t quantum_ticks) {
    const auto id = schedule_next();
    if (!id) return false;
    auto it = threads_.find(id);
    if (it == threads_.end()) return false;

    if (current_ && current_ != id) {
        auto old = threads_.find(current_);
        if (old != threads_.end() && old->second.info.state == ThreadState::Running) {
            ++old->second.info.preemptions;
            ++preemptions_;
            old->second.info.state = ThreadState::Ready;
            old->second.info.ready_since_tick = scheduler_.now();
            ready_insert(old->second);
        }
    }

    ready_remove(it->second);
    current_ = id;
    it->second.info.state = ThreadState::Running;
    it->second.info.ready_since_tick = 0;
    ++context_switches_;
    ++it->second.info.switches;
    ++it->second.info.quanta;
    it->second.info.last_run_tick = scheduler_.now();

    reported_ticks_ = 0;
    active_quantum_ = recommended_quantum(id, std::max<uint64_t>(1, quantum_ticks));
    const auto before = scheduler_.now();
    it->second.entry(id);

    const auto after = scheduler_.now();
    const auto elapsed = after >= before ? after - before : 0;
    const auto consumed = reported_ticks_ ? reported_ticks_ : std::max<uint64_t>(quantum_ticks, elapsed);
    last_dispatch_ticks_ = std::max<uint64_t>(1, consumed);
    it->second.info.cpu_ticks = saturating_add(it->second.info.cpu_ticks, consumed);
    const auto weighted = (saturating_mul(consumed, 256ull) / priority_weight(it->second.info.priority));
    it->second.info.vruntime = saturating_add(it->second.info.vruntime, std::max<uint64_t>(1, weighted));
    total_cpu_ticks_ = saturating_add(total_cpu_ticks_, consumed);
    account_wait_for_ready_threads(consumed);

    if (it->second.info.state == ThreadState::Running) {
        it->second.info.state = ThreadState::Ready;
        it->second.info.wait_ticks = 0;
        it->second.info.ready_since_tick = scheduler_.now();
        ready_insert(it->second);
        if (ready_queue_.size() > 1) ++fairness_rotations_;
        current_ = 0;
    } else if (it->second.info.state == ThreadState::Ready) {
        it->second.info.wait_ticks = 0;
        it->second.info.ready_since_tick = scheduler_.now();
        ready_insert(it->second);
        current_ = 0;
    }
    return true;
}

void ThreadManager::account_wait_for_ready_threads(uint64_t elapsed) {
    if (!elapsed) return;
    for (const auto& key : ready_queue_) {
        auto it = threads_.find(key.id);
        if (it != threads_.end()) it->second.info.wait_ticks = saturating_add(it->second.info.wait_ticks, elapsed);
    }
}

void ThreadManager::clear() noexcept {
    for (auto& [id, thread] : threads_) {
        (void)id;
        if (thread.wake_event) scheduler_.cancel(thread.wake_event);
        thread.wake_event = 0;
    }
    ready_queue_.clear();
    ready_index_.clear();
    threads_.clear();
    current_ = 0;
    ready_sequence_ = 1;
    context_switches_ = 0;
    total_cpu_ticks_ = 0;
    scheduler_decisions_ = 0;
    fairness_rotations_ = 0;
    preemptions_ = 0;
    yields_ = 0;
    last_dispatch_ticks_ = 1;
    reported_ticks_ = 0;
    active_quantum_ = 1;
}

} // namespace lg::system
