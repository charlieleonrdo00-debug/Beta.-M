#include "capability_manager.h"
#include <utility>

namespace lg::system {

bool CapabilityManager::grant(ProcessId process, std::string capability) {
    if (process == 0 || capability.empty() || capability.size() > 128) return false;
    return grants_[process].insert(std::move(capability)).second;
}

bool CapabilityManager::revoke(ProcessId process, const std::string& capability) noexcept {
    auto it = grants_.find(process);
    if (it == grants_.end()) return false;
    const bool removed = it->second.erase(capability) != 0;
    if (it->second.empty()) grants_.erase(it);
    return removed;
}

bool CapabilityManager::has(ProcessId process, const std::string& capability) const noexcept {
    auto it = grants_.find(process);
    return it != grants_.end() && it->second.find(capability) != it->second.end();
}

void CapabilityManager::clear(ProcessId process) noexcept { grants_.erase(process); }
void CapabilityManager::clear_all() noexcept { grants_.clear(); }
size_t CapabilityManager::count(ProcessId process) const noexcept {
    auto it = grants_.find(process);
    return it == grants_.end() ? 0 : it->second.size();
}

} // namespace lg::system
