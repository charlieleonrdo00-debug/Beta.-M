#include "service_registry.h"
#include <algorithm>

namespace lg::system {

bool ServiceRegistry::register_service(std::string name, std::unique_ptr<IpcEndpoint> endpoint,
                                        std::string required_capability) {
    if (name.empty() || !endpoint || required_capability.size() > 128) return false;
    if (!required_capability.empty() && required_capability.find('\0') != std::string::npos) return false;
    return services_.emplace(std::move(name), Service{std::move(endpoint), std::move(required_capability)}).second;
}

IpcEndpoint* ServiceRegistry::find(const std::string& name) const noexcept {
    auto it = services_.find(name);
    return it == services_.end() ? nullptr : it->second.endpoint.get();
}

std::vector<std::string> ServiceRegistry::names() const {
    std::vector<std::string> result;
    result.reserve(services_.size());
    for (const auto& [name, endpoint] : services_) {
        (void)endpoint;
        result.push_back(name);
    }
    std::sort(result.begin(), result.end());
    return result;
}

IpcEndpoint* ServiceRegistry::find_authorized(const std::string& name,
                                               CapabilityManager::ProcessId process,
                                               const CapabilityManager& capabilities) const noexcept {
    const auto it = services_.find(name);
    if (it == services_.end() || process == 0) return nullptr;
    if (!it->second.required_capability.empty() &&
        !capabilities.has(process, it->second.required_capability)) return nullptr;
    return it->second.endpoint.get();
}

const std::string* ServiceRegistry::required_capability(const std::string& name) const noexcept {
    const auto it = services_.find(name);
    return it == services_.end() ? nullptr : &it->second.required_capability;
}

} // namespace lg::system

void lg::system::ServiceRegistry::clear() noexcept { services_.clear(); }
