#pragma once
#include <memory>
#include "ipc.h"
#include "service_registry.h"
#include "scheduler.h"
namespace lg::system {
class SystemService final : public IpcEndpoint {
public:
    explicit SystemService(Scheduler& scheduler):scheduler_(scheduler){}
    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;
private:
    Scheduler& scheduler_;
};
std::unique_ptr<IpcEndpoint> make_system_service(Scheduler& scheduler);
}
