#pragma once
#include <cstdint>
#include <deque>
#include <unordered_map>
#include "thread_manager.h"
namespace lg::system {
class SyncManager {
public:
    using ObjectId=uint64_t;
    ObjectId create_event(bool signaled=false);
    ObjectId create_semaphore(uint32_t count, uint32_t max_count);
    bool signal(ObjectId id, ThreadManager& threads);
    bool reset(ObjectId id);
    bool wait(ObjectId id, ThreadManager::ThreadId thread, ThreadManager& threads);
    bool release(ObjectId id, ThreadManager& threads, uint32_t amount=1);
    bool exists(ObjectId id) const noexcept;
    void clear() noexcept;
private:
    enum class Type{Event,Semaphore}; struct Obj{Type type;bool signaled{};uint32_t count{},max_count{};std::deque<ThreadManager::ThreadId> waiters;};
    std::unordered_map<ObjectId,Obj> objects_; ObjectId next_id_{1};
};
}
