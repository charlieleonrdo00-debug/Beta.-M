#include "scheduler.h"

#include <algorithm>
#include <limits>
#include <utility>

namespace lg::system {

Scheduler::EventId Scheduler::allocate_id() {
    // IDs are never reset/reused during the lifetime of a Scheduler. This
    // prevents stale handles from accidentally targeting a future event.
    if (next_id_ == 0) return 0;
    const EventId id = next_id_++;
    if (next_id_ == 0) next_id_ = 0; // exhausted; subsequent calls fail safely.
    if (owned_.find(id) != owned_.end()) return 0;
    return id;
}

Scheduler::EventId Scheduler::schedule_impl(Tick tick, Tick period, Task task,
                                             Priority priority) {
    if (!task || next_id_ == 0) return 0;
    if (tick < now_) tick = now_;

    const EventId id = allocate_id();
    if (!id) return 0;

    auto event = std::make_unique<Event>();
    event->id = id;
    event->tick = tick;
    event->period = period;
    event->priority = priority;
    event->sequence = next_sequence_++;
    event->task = std::move(task);

    Event* raw = event.get();
    owned_.emplace(id, std::move(event));
    active_.insert(id);
    events_.push(raw);
    ++stats_.scheduled;
    stats_.queue_peak = std::max<uint64_t>(stats_.queue_peak, events_.size());
    return id;
}

Scheduler::EventId Scheduler::schedule(Tick tick, Task task, Priority priority) {
    return schedule_impl(tick, 0, std::move(task), priority);
}

Scheduler::EventId Scheduler::schedule_after(Tick delay, Task task, Priority priority) {
    const Tick target = (delay > std::numeric_limits<Tick>::max() - now_)
                            ? std::numeric_limits<Tick>::max()
                            : now_ + delay;
    return schedule_impl(target, 0, std::move(task), priority);
}

Scheduler::EventId Scheduler::schedule_periodic(Tick first_tick, Tick period,
                                                 Task task, Priority priority) {
    if (period == 0) return 0;
    return schedule_impl(first_tick, period, std::move(task), priority);
}

bool Scheduler::cancel(EventId id) {
    auto it = owned_.find(id);
    if (it == owned_.end() || active_.find(id) == active_.end()) return false;
    it->second->cancelled = true;
    active_.erase(id);
    ++stats_.cancelled;
    return true;
}

bool Scheduler::contains(EventId id) const {
    return active_.find(id) != active_.end();
}

void Scheduler::retire(Event* event) {
    if (!event) return;
    active_.erase(event->id);
    owned_.erase(event->id); // single owning container; heap only stores non-owning pointers.
}

uint64_t Scheduler::prune_cancelled() {
    uint64_t pruned = 0;
    while (!events_.empty()) {
        Event* event = events_.top();
        if (!event->cancelled) break;
        events_.pop();
        ++pruned;
        ++stats_.stale_pruned;
        retire(event);
    }
    return pruned;
}

Scheduler::RunStats Scheduler::run_until(Tick tick, uint64_t event_budget) {
    RunStats result{};
    ++stats_.runs;
    if (tick < now_ || event_budget == 0) return result;

    while (true) {
        prune_cancelled();
        if (events_.empty() || events_.top()->tick > tick) break;
        if (result.executed >= event_budget) {
            result.budget_exhausted = true;
            ++stats_.deferred;
            break;
        }

        Event* event = events_.top();
        events_.pop();
        if (event->cancelled || active_.find(event->id) == active_.end()) {
            ++result.cancelled;
            retire(event);
            continue;
        }

        now_ = event->tick;
        const Tick scheduled_tick = event->tick;
        const Tick period = event->period;
        Task task = std::move(event->task);
        const EventId id = event->id;

        // One-shot events are removed from the active set before user code
        // executes, so re-entrant cancel(id) is deterministic and harmless.
        if (period == 0) active_.erase(id);

        if (task) {
            task();
            ++result.executed;
            ++stats_.executed;
        }

        const bool still_active = active_.find(id) != active_.end();
        if (period != 0 && !event->cancelled && still_active) {
            if (period > std::numeric_limits<Tick>::max() - scheduled_tick) {
                active_.erase(id);
                event->cancelled = true;
                retire(event);
                continue;
            }
            event->tick = scheduled_tick + period;
            event->sequence = next_sequence_++;
            event->task = std::move(task);
            events_.push(event);
            stats_.queue_peak = std::max<uint64_t>(stats_.queue_peak, events_.size());
        } else {
            retire(event);
        }
    }

    now_ = tick;
    return result;
}

Scheduler::RunStats Scheduler::run_for(Tick delta, uint64_t event_budget) {
    const Tick target = (delta > std::numeric_limits<Tick>::max() - now_)
                            ? std::numeric_limits<Tick>::max()
                            : now_ + delta;
    return run_until(target, event_budget);
}

Scheduler::Tick Scheduler::next_deadline() noexcept {
    prune_cancelled();
    if (events_.empty()) return 0;
    return events_.top()->tick;
}

void Scheduler::clear() {
    while (!events_.empty()) events_.pop();
    active_.clear();
    owned_.clear();
    now_ = 0;
    // Do not reset next_id_: stale EventIds must never become valid again.
    next_sequence_ = 0;
    stats_ = {};
}

} // namespace lg::system
