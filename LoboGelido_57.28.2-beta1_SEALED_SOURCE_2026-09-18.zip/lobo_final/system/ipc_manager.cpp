#include "ipc_manager.h"
#include <algorithm>
#include <limits>

namespace lg::system {

IpcManager::ChannelId IpcManager::create_channel() {
    const auto id = next_id_++;
    if (id == 0) return 0;
    channels_.emplace(id, Channel{});
    return id;
}

IpcManager::ChannelId IpcManager::create_authorized_channel(ProcessId owner, std::string service, std::string required_capability) {
    if (!owner || service.empty() || service.size() > 128 || required_capability.size() > 128) return 0;
    if (service.find('\0') != std::string::npos || required_capability.find('\0') != std::string::npos) return 0;
    const auto id = next_id_++;
    if (!id) return 0;
    Channel channel{};
    channel.owner = owner;
    channel.service = std::move(service);
    channel.required_capability = std::move(required_capability);
    channels_.emplace(id, std::move(channel));
    return id;
}

bool IpcManager::channel_authorized(ChannelId id, ProcessId caller, const CapabilityManager& capabilities) const noexcept {
    if (!caller) return false;
    auto it = channels_.find(id);
    if (it == channels_.end() || !it->second.owner || it->second.owner != caller) return false;
    const auto& cap = it->second.required_capability;
    return cap.empty() || capabilities.has(caller, cap);
}

bool IpcManager::send(ChannelId id, IpcMessage message, ThreadManager& threads) {
    if (message.payload.size() > IpcMessage::kMaxPayloadSize) return false;
    auto it = channels_.find(id);
    if (it == channels_.end() || it->second.owner) return false;
    it->second.queue.push_back(std::move(message));
    while (!it->second.waiters.empty()) {
        const auto tid = it->second.waiters.front();
        it->second.waiters.pop_front();
        if (threads.unblock(tid)) break;
    }
    return true;
}

bool IpcManager::receive(ChannelId id, IpcMessage& out, ThreadManager::ThreadId waiter, ThreadManager& threads) {
    auto it = channels_.find(id);
    if (it == channels_.end() || it->second.owner) return false;
    if (it->second.queue.empty()) {
        if (waiter) {
            const auto duplicate = std::find(it->second.waiters.begin(), it->second.waiters.end(), waiter);
            if (duplicate == it->second.waiters.end()) { it->second.waiters.push_back(waiter); threads.block(waiter); }
        }
        return false;
    }
    out = std::move(it->second.queue.front()); it->second.queue.pop_front(); return true;
}

bool IpcManager::send_authorized(ChannelId id, ProcessId caller, IpcMessage message, ThreadManager& threads, const CapabilityManager& capabilities) {
    if (!channel_authorized(id, caller, capabilities) || message.payload.size() > IpcMessage::kMaxPayloadSize) return false;
    auto it = channels_.find(id);
    it->second.queue.push_back(std::move(message));
    while (!it->second.waiters.empty()) { const auto tid=it->second.waiters.front(); it->second.waiters.pop_front(); if (threads.unblock(tid)) break; }
    return true;
}

bool IpcManager::receive_authorized(ChannelId id, ProcessId caller, IpcMessage& out, ThreadManager::ThreadId waiter, ThreadManager& threads, const CapabilityManager& capabilities) {
    if (!channel_authorized(id, caller, capabilities)) return false;
    auto it = channels_.find(id);
    if (it->second.queue.empty()) {
        if (waiter) { const auto duplicate=std::find(it->second.waiters.begin(),it->second.waiters.end(),waiter); if (duplicate==it->second.waiters.end()) { it->second.waiters.push_back(waiter); threads.block(waiter); } }
        return false;
    }
    out=std::move(it->second.queue.front()); it->second.queue.pop_front(); return true;
}

const std::string* IpcManager::channel_service(ChannelId id) const noexcept {
    auto it = channels_.find(id);
    return it == channels_.end() ? nullptr : &it->second.service;
}

size_t IpcManager::pending(ChannelId id) const noexcept { auto it=channels_.find(id); return it==channels_.end()?0:it->second.queue.size(); }
size_t IpcManager::waiter_count(ChannelId id) const noexcept { auto it=channels_.find(id); return it==channels_.end()?0:it->second.waiters.size(); }
size_t IpcManager::close_process(ProcessId owner) noexcept {
    if (!owner) return 0;
    size_t removed = 0;
    for (auto it = channels_.begin(); it != channels_.end();) {
        if (it->second.owner == owner) {
            it = channels_.erase(it);
            ++removed;
        } else {
            ++it;
        }
    }
    return removed;
}

void IpcManager::clear() noexcept {
    channels_.clear();
    // IDs are opaque handles. Never recycle them across a kernel reset: an old
    // handle must not accidentally refer to a newly-created channel.
}

}
