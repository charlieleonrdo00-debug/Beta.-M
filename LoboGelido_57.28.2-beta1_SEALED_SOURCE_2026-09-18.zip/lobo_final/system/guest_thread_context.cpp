#include "guest_thread_context.h"
namespace lg::system {
cpu::CpuState* GuestThreadContextManager::create(ThreadManager::ThreadId id, uint64_t pc, uint64_t sp) {
    if (!id) return nullptr;
    auto [it, inserted] = contexts_.try_emplace(id);
    if (inserted) {
        it->second.pc = pc;
        it->second.sp = sp;
    } else {
        // Reusing a thread ID must never retain architectural state from a
        // previous guest lifetime.
        it->second.reset();
        it->second.pc = pc;
        it->second.sp = sp;
    }
    return &it->second;
}
cpu::CpuState* GuestThreadContextManager::get(ThreadManager::ThreadId id)noexcept{auto it=contexts_.find(id);return it==contexts_.end()?nullptr:&it->second;}
const cpu::CpuState* GuestThreadContextManager::get(ThreadManager::ThreadId id)const noexcept{auto it=contexts_.find(id);return it==contexts_.end()?nullptr:&it->second;}
bool GuestThreadContextManager::destroy(ThreadManager::ThreadId id){return contexts_.erase(id)!=0;}
}

void lg::system::GuestThreadContextManager::clear() noexcept { contexts_.clear(); }
