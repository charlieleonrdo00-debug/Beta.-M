#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include "ipc.h"

namespace lg::system {

class FileSystemService final : public IpcEndpoint {
public:
    static constexpr uint32_t kOpen = 0;
    static constexpr uint32_t kRead = 1;
    static constexpr uint32_t kWrite = 2;
    static constexpr uint32_t kClose = 3;
    static constexpr uint32_t kList = 4;

    core::Result<IpcMessage> dispatch(const IpcMessage& request) override;

    bool seed_file(std::string path, std::vector<uint8_t> data);
    size_t file_count() const noexcept { return files_.size(); }

private:
    struct Handle { std::string path; size_t offset{}; };
    static bool normalize_path(const std::string& path, std::string& out);
    core::Result<IpcMessage> open(const IpcMessage& request);
    core::Result<IpcMessage> read(const IpcMessage& request);
    core::Result<IpcMessage> write(const IpcMessage& request);
    core::Result<IpcMessage> close(const IpcMessage& request);
    core::Result<IpcMessage> list(const IpcMessage& request);

    std::unordered_map<std::string, std::vector<uint8_t>> files_;
    std::unordered_map<uint32_t, Handle> handles_;
    uint32_t next_handle_{1};
};

std::unique_ptr<IpcEndpoint> make_filesystem_service();

} // namespace lg::system
