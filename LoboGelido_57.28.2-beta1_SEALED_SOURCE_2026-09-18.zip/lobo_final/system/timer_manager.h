#pragma once
#include <cstdint>
#include <unordered_map>
#include "scheduler.h"

namespace lg::system {
class TimerManager {
public:
    using TimerId = uint64_t;
    TimerId create(Scheduler::Tick delay, Scheduler::Tick period = 0);
    bool cancel(TimerId id);
    bool armed(TimerId id) const noexcept;
    bool expired(TimerId id) const noexcept;
    Scheduler::Tick deadline(TimerId id) const noexcept;
    void pump(Scheduler::Tick now);
    void clear() noexcept;
private:
    struct Timer { Scheduler::Tick deadline{}; Scheduler::Tick period{}; bool armed{}; bool fired{}; };
    std::unordered_map<TimerId, Timer> timers_;
    TimerId next_id_{1};
};
}
