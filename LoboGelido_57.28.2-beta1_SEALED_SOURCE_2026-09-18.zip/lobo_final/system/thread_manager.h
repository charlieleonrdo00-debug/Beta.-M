#pragma once
#include <cstdint>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include "scheduler.h"

namespace lg::system {

enum class ThreadState : uint8_t { Created, Ready, Running, Sleeping, Blocked, Terminated };

struct ThreadInfo {
    uint64_t id{};
    std::string name;
    uint8_t priority{};
    uint8_t base_priority{};
    ThreadState state{ThreadState::Created};
    uint64_t wake_tick{};
    uint64_t deadline_tick{};
    uint64_t affinity_mask{~0ull};
    uint64_t quanta{};
    uint64_t switches{};
    uint64_t preemptions{};
    uint64_t yields{};
    uint64_t wakeups{};
    uint64_t cpu_ticks{};
    uint64_t wait_ticks{};
    uint64_t vruntime{};
    uint64_t last_run_tick{};
    uint64_t ready_since_tick{};
};

class ThreadManager {
public:
    using ThreadId = uint64_t;
    using Entry = std::function<void(ThreadId)>;

    explicit ThreadManager(Scheduler& scheduler);
    ~ThreadManager();
    ThreadManager(const ThreadManager&) = delete;
    ThreadManager& operator=(const ThreadManager&) = delete;
    ThreadId create(std::string name, uint8_t priority, Entry entry);
    bool make_ready(ThreadId id);
    bool sleep(ThreadId id, Scheduler::Tick ticks);
    bool block(ThreadId id);
    bool unblock(ThreadId id);
    bool terminate(ThreadId id);
    bool yield(ThreadId id);
    bool preempt_current();
    bool set_priority(ThreadId id, uint8_t priority);
    bool set_affinity(ThreadId id, uint64_t affinity_mask);
    bool set_deadline(ThreadId id, uint64_t deadline_tick);
    ThreadId current() const noexcept { return current_; }
    const ThreadInfo* info(ThreadId id) const noexcept;
    size_t size() const noexcept { return threads_.size(); }

    // Deterministic guest scheduler:
    //   1) higher guest priority wins;
    //   2) an explicit deadline wins within the same priority;
    //   3) least vruntime wins for fairness;
    //   4) ready sequence and id make ties reproducible.
    ThreadId schedule_next();
    bool dispatch_next(uint64_t quantum_ticks = 1);

    uint64_t recommended_quantum(ThreadId id, uint64_t base_quantum = 64) const noexcept;
    uint64_t context_switches() const noexcept { return context_switches_; }
    uint64_t runnable_count() const noexcept { return ready_queue_.size(); }
    uint64_t total_cpu_ticks() const noexcept { return total_cpu_ticks_; }
    uint64_t scheduler_decisions() const noexcept { return scheduler_decisions_; }
    uint64_t fairness_rotations() const noexcept { return fairness_rotations_; }
    uint64_t last_dispatch_ticks() const noexcept { return last_dispatch_ticks_; }
    uint64_t preemptions() const noexcept { return preemptions_; }
    uint64_t yields() const noexcept { return yields_; }
    uint64_t active_quantum() const noexcept { return active_quantum_; }
    void report_current_consumed_ticks(uint64_t ticks) noexcept {
        if (current_) reported_ticks_ = ticks;
    }
    void clear() noexcept;

private:
    struct Thread { ThreadInfo info; Entry entry; Scheduler::EventId wake_event{}; };
    struct ReadyKey {
        uint8_t priority{};
        bool has_deadline{};
        uint64_t deadline_tick{};
        uint64_t vruntime{};
        uint64_t ready_sequence{};
        ThreadId id{};
    };
    struct ReadyCompare {
        bool operator()(const ReadyKey& a, const ReadyKey& b) const noexcept {
            if (a.priority != b.priority) return a.priority > b.priority;
            // Deadlines are an ordering hint, never an excuse for permanent
            // starvation: fairness is evaluated before deadline preference.
            if (a.vruntime != b.vruntime) return a.vruntime < b.vruntime;
            if (a.has_deadline != b.has_deadline) return a.has_deadline > b.has_deadline;
            if (a.has_deadline && a.deadline_tick != b.deadline_tick)
                return a.deadline_tick < b.deadline_tick;
            if (a.ready_sequence != b.ready_sequence) return a.ready_sequence < b.ready_sequence;
            return a.id < b.id;
        }
    };

    void ready_insert(Thread& thread);
    void ready_remove(Thread& thread);
    void account_wait_for_ready_threads(uint64_t elapsed);
    static uint64_t priority_weight(uint8_t priority) noexcept;
    static uint64_t saturating_add(uint64_t a, uint64_t b) noexcept;
    static uint64_t saturating_mul(uint64_t a, uint64_t b) noexcept;

    Scheduler& scheduler_;
    std::map<ThreadId, Thread> threads_;
    std::set<ReadyKey, ReadyCompare> ready_queue_;
    std::unordered_map<ThreadId, std::set<ReadyKey, ReadyCompare>::iterator> ready_index_;
    ThreadId next_id_{1};
    ThreadId current_{};
    uint64_t ready_sequence_{1};
    uint64_t context_switches_{};
    uint64_t total_cpu_ticks_{};
    uint64_t scheduler_decisions_{};
    uint64_t fairness_rotations_{};
    uint64_t preemptions_{};
    uint64_t yields_{};
    uint64_t last_dispatch_ticks_{1};
    uint64_t reported_ticks_{};
    uint64_t active_quantum_{1};
};

} // namespace lg::system
