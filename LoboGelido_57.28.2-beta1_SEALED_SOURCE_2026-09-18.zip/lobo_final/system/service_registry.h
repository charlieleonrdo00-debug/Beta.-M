#pragma once
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include "ipc.h"
#include "capability_manager.h"

namespace lg::system {

class ServiceRegistry {
public:
    bool register_service(std::string name, std::unique_ptr<IpcEndpoint> endpoint,
                          std::string required_capability = {});
    IpcEndpoint* find(const std::string& name) const noexcept;
    IpcEndpoint* find_authorized(const std::string& name, CapabilityManager::ProcessId process,
                                 const CapabilityManager& capabilities) const noexcept;
    const std::string* required_capability(const std::string& name) const noexcept;
    void clear() noexcept;
    size_t size() const noexcept { return services_.size(); }
    bool contains(const std::string& name) const noexcept { return find(name) != nullptr; }
    std::vector<std::string> names() const;
private:
    struct Service {
        std::unique_ptr<IpcEndpoint> endpoint;
        std::string required_capability;
    };
    std::unordered_map<std::string, Service> services_;
};

} // namespace lg::system
