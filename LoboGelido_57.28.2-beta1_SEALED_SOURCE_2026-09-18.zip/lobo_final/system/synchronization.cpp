#include "synchronization.h"
namespace lg::system {
SyncManager::ObjectId SyncManager::create_event(bool s){auto id=next_id_++;objects_.emplace(id,Obj{Type::Event,s,0,0,{}});return id;}
SyncManager::ObjectId SyncManager::create_semaphore(uint32_t c,uint32_t m){if(m==0||c>m)return 0;auto id=next_id_++;objects_.emplace(id,Obj{Type::Semaphore,false,c,m,{}});return id;}
bool SyncManager::exists(ObjectId id)const noexcept{return objects_.count(id)!=0;}
bool SyncManager::signal(ObjectId id,ThreadManager& tm){auto it=objects_.find(id);if(it==objects_.end()||it->second.type!=Type::Event)return false;it->second.signaled=true;if(!it->second.waiters.empty()){auto tid=it->second.waiters.front();it->second.waiters.pop_front();tm.unblock(tid);it->second.signaled=false;}return true;}
bool SyncManager::reset(ObjectId id){auto it=objects_.find(id);if(it==objects_.end()||it->second.type!=Type::Event)return false;it->second.signaled=false;return true;}
bool SyncManager::wait(ObjectId id,ThreadManager::ThreadId tid,ThreadManager& tm){auto it=objects_.find(id);if(it==objects_.end())return false;auto&o=it->second;if(o.type==Type::Event){if(o.signaled){o.signaled=false;return true;}o.waiters.push_back(tid);return tm.block(tid);}if(o.count){--o.count;return true;}o.waiters.push_back(tid);return tm.block(tid);}
bool SyncManager::release(ObjectId id,ThreadManager& tm,uint32_t amount){auto it=objects_.find(id);if(it==objects_.end()||it->second.type!=Type::Semaphore||amount==0)return false;auto&o=it->second;if(amount>o.max_count-o.count)return false;while(amount&& !o.waiters.empty()){auto tid=o.waiters.front();o.waiters.pop_front();tm.unblock(tid);--amount;}o.count+=amount;return true;}
} // namespace lg::system

void lg::system::SyncManager::clear() noexcept { objects_.clear(); next_id_=1; }
