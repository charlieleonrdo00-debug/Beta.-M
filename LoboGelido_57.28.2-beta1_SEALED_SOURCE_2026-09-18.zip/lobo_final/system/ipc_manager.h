#pragma once
#include <cstdint>
#include <deque>
#include <string>
#include <unordered_map>
#include "ipc.h"
#include "thread_manager.h"
#include "capability_manager.h"

namespace lg::system {
class IpcManager {
public:
    using ChannelId=uint64_t;
    using ProcessId=CapabilityManager::ProcessId;
    ChannelId create_channel();
    ChannelId create_authorized_channel(ProcessId owner, std::string service, std::string required_capability);
    bool send(ChannelId id, IpcMessage message, ThreadManager& threads);
    bool receive(ChannelId id, IpcMessage& out, ThreadManager::ThreadId waiter, ThreadManager& threads);
    bool send_authorized(ChannelId id, ProcessId caller, IpcMessage message, ThreadManager& threads, const CapabilityManager& capabilities);
    bool receive_authorized(ChannelId id, ProcessId caller, IpcMessage& out, ThreadManager::ThreadId waiter, ThreadManager& threads, const CapabilityManager& capabilities);
    bool channel_authorized(ChannelId id, ProcessId caller, const CapabilityManager& capabilities) const noexcept;
    const std::string* channel_service(ChannelId id) const noexcept;
    size_t pending(ChannelId id) const noexcept;
    size_t waiter_count(ChannelId id) const noexcept;
    size_t close_process(ProcessId owner) noexcept;
    void clear() noexcept;
private:
    struct Channel {
        ProcessId owner{};
        std::string service;
        std::string required_capability;
        std::deque<IpcMessage> queue;
        std::deque<ThreadManager::ThreadId> waiters;
    };
    std::unordered_map<ChannelId,Channel> channels_; ChannelId next_id_{1};
};
}
