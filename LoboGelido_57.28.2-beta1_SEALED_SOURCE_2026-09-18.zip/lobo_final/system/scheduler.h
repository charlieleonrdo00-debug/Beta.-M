#pragma once

#include <cstdint>
#include <functional>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <vector>

namespace lg::system {

// Deterministic guest-time event scheduler.
// It is intentionally single-threaded: ordering is part of the emulator's
// observable behavior, while host threads may feed work through schedule().
class Scheduler {
public:
    using Tick = uint64_t;
    using EventId = uint64_t;
    using Task = std::function<void()>;
    using Priority = uint8_t;

    struct RunStats {
        uint64_t executed{};
        uint64_t cancelled{};
        uint64_t deferred{};
        bool budget_exhausted{};
    };

    struct Stats {
        uint64_t scheduled{};
        uint64_t executed{};
        uint64_t cancelled{};
        uint64_t deferred{};
        uint64_t queue_peak{};
        uint64_t stale_pruned{};
        uint64_t runs{};
    };

    // Lower tick wins. For equal ticks, higher priority wins. Finally the
    // monotonically increasing sequence makes execution fully deterministic.
    EventId schedule(Tick tick, Task task, Priority priority = 0);
    EventId schedule_after(Tick delay, Task task, Priority priority = 0);
    EventId schedule_periodic(Tick first_tick, Tick period, Task task,
                              Priority priority = 0);

    bool cancel(EventId id);
    bool contains(EventId id) const;

    // Executes every due event through 'tick'. The optional budget prevents
    // a broken zero-delay producer from monopolizing the emulator thread.
    RunStats run_until(Tick tick, uint64_t event_budget = 1'000'000);
    RunStats run_for(Tick delta, uint64_t event_budget = 1'000'000);

    Tick now() const noexcept { return now_; }
    bool empty() const noexcept { return events_.empty(); }
    size_t pending() const noexcept { return active_.size(); }
    Tick next_deadline() noexcept;
    const Stats& stats() const noexcept { return stats_; }

    // Drops cancelled/stale heap entries without executing user code.
    uint64_t prune_cancelled();
    void clear();

private:
    struct Event {
        EventId id{};
        Tick tick{};
        Tick period{};
        Priority priority{};
        uint64_t sequence{};
        Task task;
        bool cancelled{};
    };

    struct Compare {
        bool operator()(const Event* a, const Event* b) const noexcept {
            if (a->tick != b->tick) return a->tick > b->tick;
            if (a->priority != b->priority) return a->priority < b->priority;
            return a->sequence > b->sequence;
        }
    };

    EventId schedule_impl(Tick tick, Tick period, Task task, Priority priority);
    EventId allocate_id();
    void retire(Event* event);

    std::priority_queue<Event*, std::vector<Event*>, Compare> events_;
    std::unordered_set<EventId> active_;
    std::unordered_map<EventId, std::unique_ptr<Event>> owned_;
    Tick now_{};
    EventId next_id_{1};
    uint64_t next_sequence_{};
    Stats stats_{};
};

} // namespace lg::system
