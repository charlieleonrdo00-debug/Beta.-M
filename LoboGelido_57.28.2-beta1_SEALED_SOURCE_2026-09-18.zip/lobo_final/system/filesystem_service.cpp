#include "filesystem_service.h"
#include <algorithm>
#include <cstring>
#include <limits>
#include <string_view>

namespace lg::system {
namespace {
constexpr size_t kMaxIo = 256 * 1024;
constexpr uint32_t kInvalidHandle = 0;

IpcMessage response(uint32_t command, std::vector<uint8_t> payload = {}) {
    IpcMessage out; out.command_id = command; out.payload = std::move(payload); return out;
}
std::vector<uint8_t> u32(uint32_t v) { std::vector<uint8_t> p(4); std::memcpy(p.data(), &v, 4); return p; }
uint32_t read_u32(const std::vector<uint8_t>& p, size_t off) { uint32_t v{}; std::memcpy(&v, p.data()+off, 4); return v; }
}

bool FileSystemService::normalize_path(const std::string& path, std::string& out) {
    if (path.empty() || path.front() != '/') return false;
    out.clear();
    out.reserve(path.size());
    size_t i = 0;
    while (i < path.size()) {
        while (i < path.size() && path[i] == '/') ++i;
        const size_t begin = i;
        while (i < path.size() && path[i] != '/') ++i;
        if (begin == i) continue;
        const std::string_view part(path.data() + begin, i - begin);
        if (part == ".") continue;
        if (part == "..") return false;
        if (part.find('\\') != std::string_view::npos) return false;
        out.push_back('/'); out.append(part);
    }
    if (out.empty()) out = "/";
    return true;
}

bool FileSystemService::seed_file(std::string path, std::vector<uint8_t> data) {
    std::string normalized;
    if (!normalize_path(path, normalized) || data.size() > kMaxIo) return false;
    files_[normalized] = std::move(data);
    return true;
}

core::Result<IpcMessage> FileSystemService::open(const IpcMessage& r) {
    const std::string path(r.payload.begin(), r.payload.end());
    std::string normalized;
    if (!normalize_path(path, normalized)) return core::Result<IpcMessage>::Error("invalid path");
    if (files_.find(normalized) == files_.end()) return core::Result<IpcMessage>::Error("file not found");
    if (next_handle_ == kInvalidHandle) return core::Result<IpcMessage>::Error("handle exhaustion");
    const uint32_t h = next_handle_++;
    handles_.emplace(h, Handle{normalized, 0});
    return core::Result<IpcMessage>::Ok(response(r.command_id, u32(h)));
}

core::Result<IpcMessage> FileSystemService::read(const IpcMessage& r) {
    if (r.payload.size() != 8) return core::Result<IpcMessage>::Error("read requires handle and size");
    const uint32_t h = read_u32(r.payload, 0); const uint32_t requested = read_u32(r.payload, 4);
    if (requested > kMaxIo) return core::Result<IpcMessage>::Error("read too large");
    auto hit = handles_.find(h); if (hit == handles_.end()) return core::Result<IpcMessage>::Error("invalid handle");
    auto fit = files_.find(hit->second.path); if (fit == files_.end()) return core::Result<IpcMessage>::Error("file missing");
    const auto& data = fit->second;
    if (hit->second.offset > data.size()) return core::Result<IpcMessage>::Error("invalid offset");
    const size_t count = std::min<size_t>(requested, data.size() - hit->second.offset);
    std::vector<uint8_t> out(data.begin()+static_cast<std::ptrdiff_t>(hit->second.offset), data.begin()+static_cast<std::ptrdiff_t>(hit->second.offset+count));
    hit->second.offset += count;
    return core::Result<IpcMessage>::Ok(response(r.command_id, std::move(out)));
}

core::Result<IpcMessage> FileSystemService::write(const IpcMessage& r) {
    if (r.payload.size() < 4) return core::Result<IpcMessage>::Error("write requires handle");
    const uint32_t h = read_u32(r.payload, 0);
    if (r.payload.size() - 4 > kMaxIo) return core::Result<IpcMessage>::Error("write too large");
    auto hit = handles_.find(h); if (hit == handles_.end()) return core::Result<IpcMessage>::Error("invalid handle");
    auto fit = files_.find(hit->second.path); if (fit == files_.end()) return core::Result<IpcMessage>::Error("file missing");
    const size_t count = r.payload.size() - 4;
    if (hit->second.offset > kMaxIo || count > kMaxIo - hit->second.offset) return core::Result<IpcMessage>::Error("file size limit");
    if (hit->second.offset + count > fit->second.size()) fit->second.resize(hit->second.offset + count);
    std::copy(r.payload.begin()+4, r.payload.end(), fit->second.begin()+static_cast<std::ptrdiff_t>(hit->second.offset));
    hit->second.offset += count;
    return core::Result<IpcMessage>::Ok(response(r.command_id, u32(static_cast<uint32_t>(count))));
}

core::Result<IpcMessage> FileSystemService::close(const IpcMessage& r) {
    if (r.payload.size() != 4) return core::Result<IpcMessage>::Error("close requires handle");
    const uint32_t h = read_u32(r.payload, 0);
    if (handles_.erase(h) != 1) return core::Result<IpcMessage>::Error("invalid handle");
    return core::Result<IpcMessage>::Ok(response(r.command_id));
}

core::Result<IpcMessage> FileSystemService::list(const IpcMessage& r) {
    if (!r.payload.empty()) return core::Result<IpcMessage>::Error("list takes no payload");
    std::vector<std::string> names; names.reserve(files_.size());
    for (const auto& [path, data] : files_) { (void)data; names.push_back(path); }
    std::sort(names.begin(), names.end());
    std::vector<uint8_t> out;
    for (const auto& name : names) {
        if (name.size() > std::numeric_limits<uint16_t>::max() || out.size() + 2 + name.size() > IpcMessage::kMaxPayloadSize) return core::Result<IpcMessage>::Error("listing too large");
        const uint16_t n = static_cast<uint16_t>(name.size()); const auto* p = reinterpret_cast<const uint8_t*>(&n);
        out.insert(out.end(), p, p+2); out.insert(out.end(), name.begin(), name.end());
    }
    return core::Result<IpcMessage>::Ok(response(r.command_id, std::move(out)));
}

core::Result<IpcMessage> FileSystemService::dispatch(const IpcMessage& r) {
    if (r.payload.size() > IpcMessage::kMaxPayloadSize) return core::Result<IpcMessage>::Error("IPC payload too large");
    switch (r.command_id) {
        case kOpen: return open(r); case kRead: return read(r); case kWrite: return write(r); case kClose: return close(r); case kList: return list(r);
        default: return core::Result<IpcMessage>::Error("unknown filesystem command");
    }
}

std::unique_ptr<IpcEndpoint> make_filesystem_service() { return std::make_unique<FileSystemService>(); }
} // namespace lg::system
