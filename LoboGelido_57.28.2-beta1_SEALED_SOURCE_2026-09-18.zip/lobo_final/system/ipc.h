#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>
#include "../core/result.h"

namespace lg::system {

struct IpcMessage {
    static constexpr size_t kMaxPayloadSize = 1024 * 1024;
    uint32_t command_id{};
    std::vector<uint8_t> payload;
};

class IpcEndpoint {
public:
    virtual ~IpcEndpoint() = default;
    virtual core::Result<IpcMessage> dispatch(const IpcMessage& request) = 0;
};

} // namespace lg::system
