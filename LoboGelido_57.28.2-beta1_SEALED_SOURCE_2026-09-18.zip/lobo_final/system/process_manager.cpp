#include "process_manager.h"
#include <limits>
#include <utility>

namespace lg::system {

ProcessManager::ProcessId ProcessManager::create(std::string name, std::string executable_path,
                                                  uint64_t entry_point, uint64_t image_base,
                                                  uint64_t image_size, uint32_t segment_count) {
    if (name.empty() || executable_path.empty() || !entry_point || !image_size || !segment_count)
        return 0;
    if (next_id_ == 0 || next_id_ == std::numeric_limits<ProcessId>::max()) return 0;
    const ProcessId id = next_id_++;
    processes_.emplace(id, Process{id, std::move(name), std::move(executable_path),
                                   entry_point, image_base, image_size, segment_count, false, false});
    return id;
}

bool ProcessManager::mark_initialized(ProcessId id) noexcept {
    auto it = processes_.find(id);
    if (it == processes_.end() || it->second.initialized) return false;
    it->second.initialized = true;
    return true;
}

bool ProcessManager::start(ProcessId id) noexcept {
    auto it = processes_.find(id);
    if (it == processes_.end()) return false;
    if (current_id_ && current_id_ != id) return false;
    if (it->second.running) return false;
    it->second.running = true;
    current_id_ = id;
    return true;
}

bool ProcessManager::stop(ProcessId id) noexcept {
    auto it = processes_.find(id);
    if (it == processes_.end()) return false;
    it->second.running = false;
    if (current_id_ == id) current_id_ = 0;
    return true;
}

bool ProcessManager::destroy(ProcessId id) noexcept {
    if (current_id_ == id) return false;
    return processes_.erase(id) == 1;
}

const ProcessManager::Process* ProcessManager::get(ProcessId id) const noexcept {
    auto it = processes_.find(id);
    return it == processes_.end() ? nullptr : &it->second;
}

const ProcessManager::Process* ProcessManager::current() const noexcept {
    return current_id_ ? get(current_id_) : nullptr;
}

void ProcessManager::clear() noexcept {
    processes_.clear();
    next_id_ = 1;
    current_id_ = 0;
}

} // namespace lg::system
