#include "frame_pacing.h"
#include <thread>

namespace lg::performance {

FramePacing::FramePacing(double target_fps)
    : budget_(std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::duration<double>(1.0 / target_fps))) {}

void FramePacing::begin_frame() {
    frame_start_ = std::chrono::steady_clock::now();
}

void FramePacing::end_frame() {
    const auto elapsed = std::chrono::steady_clock::now() - frame_start_;
    if (elapsed < budget_) std::this_thread::sleep_for(budget_ - elapsed);
}

} // namespace lg::performance
