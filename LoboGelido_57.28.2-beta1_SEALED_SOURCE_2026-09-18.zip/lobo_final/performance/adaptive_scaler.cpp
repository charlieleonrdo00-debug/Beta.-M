#include "adaptive_scaler.h"
#include <algorithm>

namespace lg::performance {

AdaptiveScaler::AdaptiveScaler(AdaptiveScaleConfig config) : config_(config) {
    config_.target_fps = std::clamp(config_.target_fps, 30, 120);
    config_.min_scale = std::clamp(config_.min_scale, 50, 100);
    config_.max_scale = std::clamp(config_.max_scale, config_.min_scale, 100);
    state_.scale = config_.max_scale;
}

void AdaptiveScaler::set_enabled(bool enabled) noexcept {
    config_.enabled = enabled;
    if (!enabled) reset();
}

bool AdaptiveScaler::enabled() const noexcept { return config_.enabled; }

void AdaptiveScaler::reset() noexcept {
    state_ = {};
    state_.scale = config_.max_scale;
}

int AdaptiveScaler::update(double frame_ms, double gpu_ms, int thermal_level) noexcept {
    state_.last_frame_ms = frame_ms;
    if (!config_.enabled || frame_ms <= 0.0) return state_.scale;

    const double budget = 1000.0 / static_cast<double>(config_.target_fps);
    const bool overloaded = frame_ms > budget * 1.08 || gpu_ms > budget * 0.95 || thermal_level >= 3;
    const bool healthy = frame_ms < budget * 0.92 && gpu_ms > 0.0 && gpu_ms < budget * 0.72 && thermal_level < 2;

    if (overloaded) {
        state_.stable_frames = 0;
        // Small steps avoid visible resolution pumping and preserve frame pacing.
        state_.scale = std::max(config_.min_scale, state_.scale - 5);
    } else if (healthy) {
        ++state_.stable_frames;
        // Require a sustained healthy window before increasing quality.
        if (state_.stable_frames >= 45) {
            state_.scale = std::min(config_.max_scale, state_.scale + 2);
            state_.stable_frames = 0;
        }
    } else {
        state_.stable_frames = 0;
    }
    return state_.scale;
}

} // namespace lg::performance
