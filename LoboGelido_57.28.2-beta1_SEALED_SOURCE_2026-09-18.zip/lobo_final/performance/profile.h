#pragma once
#include <cstdint>

namespace lg::performance {

struct DeviceProfile {
    uint64_t gpu_vendor{};
    uint64_t gpu_device{};
    bool vulkan{};
    bool nce{};
    uint32_t memory_mb{};
};

struct GameProfile {
    uint32_t resolution_scale{100};
    bool async_shader_compile{true};
    bool aggressive_pacing{true};
};

} // namespace lg::performance
