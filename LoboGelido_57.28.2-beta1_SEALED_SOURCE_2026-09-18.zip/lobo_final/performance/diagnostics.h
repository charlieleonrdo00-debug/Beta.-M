#pragma once
#include <array>
#include <cstdint>
#include <string>

namespace lg::performance {

enum class Bottleneck : uint8_t { Optimal, Cpu, Gpu, Thermal, Shader, Memory, Presentation };

struct DiagnosticsSnapshot {
    double cpu_ms{};
    double gpu_ms{};
    double present_ms{};
    double frame_ms{};
    double fps{};
    double jitter_ms{};
    double cpu_util{};
    double gpu_util{};
    uint32_t samples{};
    int thermal_level{};
    uint32_t shader_pending{};
    uint32_t shader_cache_hits{};
    uint32_t shader_cache_misses{};
    int adaptive_scale{100};
    bool adaptive_enabled{};
    bool jit_enabled{};
    bool vulkan_ready{};
    uint32_t tlb_entries{64};
    Bottleneck bottleneck{Bottleneck::Optimal};
};

class DiagnosticsCore {
public:
    static constexpr size_t kHistory = 120;
    void record(double cpu_ms, double gpu_ms, double present_ms, int thermal_level = 0,
                uint32_t shader_pending = 0, uint32_t cache_hits = 0, uint32_t cache_misses = 0) noexcept;
    void set_runtime(bool jit_enabled, bool vulkan_ready, int adaptive_scale, bool adaptive_enabled) noexcept;
    DiagnosticsSnapshot snapshot(double target_fps = 60.0) const noexcept;
    std::string summary(double target_fps = 60.0) const;

private:
    struct Sample { double cpu{}, gpu{}, present{}, frame{}; int thermal{}; };
    std::array<Sample, kHistory> history_{};
    size_t count_{};
    size_t cursor_{};
    bool jit_enabled_{};
    bool vulkan_ready_{};
    int adaptive_scale_{100};
    bool adaptive_enabled_{};
    uint32_t shader_pending_{};
    uint32_t shader_hits_{};
    uint32_t shader_misses_{};
};

const char* bottleneck_name(Bottleneck b) noexcept;
const char* advisor_text(Bottleneck b) noexcept;

} // namespace lg::performance
