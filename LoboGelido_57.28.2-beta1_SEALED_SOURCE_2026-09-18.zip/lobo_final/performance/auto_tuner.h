#pragma once
#include <cstdint>

namespace lg::performance {

struct Telemetry {
    double cpu_ms{};
    double gpu_ms{};
    double frame_ms{};
    int thermal_level{};
};

struct Policy {
    int resolution_scale{100};
    bool async_shaders{true};
    bool gpu_async{true};
    bool async_present{true};
    int pipeline_workers{4};
    bool dynamic_resolution{false};
    int target_fps{60};
    int confidence{70};
};

/**
 * Conservative, deterministic device/runtime policy.
 * It only reacts to sustained pressure; it never invents GPU capabilities.
 */
class AutoTuner {
public:
    Policy update(const Telemetry& t) const noexcept;
};

} // namespace lg::performance
