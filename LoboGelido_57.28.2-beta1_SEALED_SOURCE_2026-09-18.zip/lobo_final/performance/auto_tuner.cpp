#include "auto_tuner.h"

namespace lg::performance {

Policy AutoTuner::update(const Telemetry& t) const noexcept {
    Policy p{};
    const bool gpu_bound = t.gpu_ms > 0.0 && t.gpu_ms >= t.cpu_ms * 1.10;
    const bool cpu_bound = t.cpu_ms > 0.0 && t.cpu_ms >= t.gpu_ms * 1.10;

    // Start from stable Android-friendly defaults.  Lower resolution only when
    // frame pacing or thermal pressure makes it useful.
    if (t.frame_ms > 16.8) p.resolution_scale = 95;
    if (t.frame_ms > 21.0 || t.thermal_level >= 3) p.resolution_scale = 85;
    if (t.frame_ms > 27.0 || t.thermal_level >= 4) p.resolution_scale = 75;

    // Dynamic resolution is deliberately opt-in by policy: it becomes useful
    // only when the frame budget is demonstrably missed. This avoids visible
    // oscillation on devices that hover around 60 FPS.
    p.dynamic_resolution = t.frame_ms > 18.0 || t.thermal_level >= 3;
    p.target_fps = (t.thermal_level >= 4 || t.frame_ms > 28.0) ? 30 : 60;

    const bool has_timing = t.frame_ms > 0.0;
    p.confidence = has_timing ? 82 : 55;
    if (gpu_bound || cpu_bound) p.confidence += 6;
    if (t.thermal_level >= 3) p.confidence += 4;
    if (p.confidence > 96) p.confidence = 96;

    // GPU pressure benefits from fewer pipeline workers; CPU pressure benefits
    // from keeping shader work asynchronous.  This is policy only: the real
    // renderer must expose these capabilities before applying them.
    if (gpu_bound || t.thermal_level >= 3) {
        p.pipeline_workers = 4;
        p.gpu_async = t.thermal_level < 4;
        p.async_present = t.thermal_level < 4;
    } else if (cpu_bound) {
        p.pipeline_workers = 5;
        p.gpu_async = true;
        p.async_present = true;
    }

    if (t.thermal_level >= 4) p.async_shaders = false;
    return p;
}

} // namespace lg::performance
