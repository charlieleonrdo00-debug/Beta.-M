#include "performance/diagnostics.h"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>

namespace lg::performance {

void DiagnosticsCore::record(double cpu_ms, double gpu_ms, double present_ms, int thermal_level,
                             uint32_t shader_pending, uint32_t cache_hits, uint32_t cache_misses) noexcept {
    const double frame = std::max({cpu_ms, gpu_ms, present_ms, 0.001});
    history_[cursor_] = {cpu_ms, gpu_ms, present_ms, frame, thermal_level};
    cursor_ = (cursor_ + 1) % kHistory;
    count_ = std::min(count_ + 1, kHistory);
    shader_pending_ = shader_pending;
    shader_hits_ = cache_hits;
    shader_misses_ = cache_misses;
}

void DiagnosticsCore::set_runtime(bool jit_enabled, bool vulkan_ready, int adaptive_scale, bool adaptive_enabled) noexcept {
    jit_enabled_ = jit_enabled; vulkan_ready_ = vulkan_ready;
    adaptive_scale_ = std::clamp(adaptive_scale, 1, 100); adaptive_enabled_ = adaptive_enabled;
}

DiagnosticsSnapshot DiagnosticsCore::snapshot(double target_fps) const noexcept {
    DiagnosticsSnapshot out{}; out.samples = static_cast<uint32_t>(count_);
    out.jit_enabled = jit_enabled_; out.vulkan_ready = vulkan_ready_;
    out.adaptive_scale = adaptive_scale_; out.adaptive_enabled = adaptive_enabled_;
    out.shader_pending = shader_pending_; out.shader_cache_hits = shader_hits_; out.shader_cache_misses = shader_misses_;
    if (!count_) return out;
    double cpu=0,gpu=0,present=0,frame=0,mean=0; int thermal=0;
    for(size_t i=0;i<count_;++i){ const auto& s=history_[i]; cpu+=s.cpu; gpu+=s.gpu; present+=s.present; frame+=s.frame; mean+=s.frame; thermal=std::max(thermal,s.thermal); }
    cpu/=count_; gpu/=count_; present/=count_; frame/=count_; mean/=count_; out.cpu_ms=cpu; out.gpu_ms=gpu; out.present_ms=present; out.frame_ms=frame;
    double variance=0; for(size_t i=0;i<count_;++i){double d=history_[i].frame-mean; variance+=d*d;} out.jitter_ms=std::sqrt(variance/count_);
    out.fps=1000.0/frame; const double budget=1000.0/target_fps; out.cpu_util=cpu/budget*100.0; out.gpu_util=gpu/budget*100.0; out.thermal_level=thermal;
    if(thermal>=3) out.bottleneck=Bottleneck::Thermal;
    else if(shader_pending_>0) out.bottleneck=Bottleneck::Shader;
    else if(gpu>cpu*1.15 && gpu>budget*0.70) out.bottleneck=Bottleneck::Gpu;
    else if(cpu>gpu*1.15 && cpu>budget*0.85) out.bottleneck=Bottleneck::Cpu;
    else if(present>budget*0.25) out.bottleneck=Bottleneck::Presentation;
    else if(frame>budget*1.08) out.bottleneck=Bottleneck::Memory;
    else out.bottleneck=Bottleneck::Optimal;
    return out;
}

const char* bottleneck_name(Bottleneck b) noexcept { switch(b){case Bottleneck::Cpu:return "CPU";case Bottleneck::Gpu:return "GPU";case Bottleneck::Thermal:return "Térmica";case Bottleneck::Shader:return "Shaders";case Bottleneck::Memory:return "Memoria";case Bottleneck::Presentation:return "Presentación";default:return "Óptimo";} }
const char* advisor_text(Bottleneck b) noexcept { switch(b){case Bottleneck::Cpu:return "La CPU está cerca del límite del frame; prioriza un backend JIT cuando esté disponible.";case Bottleneck::Gpu:return "La GPU domina el frame; reducir escala interna puede recuperar margen.";case Bottleneck::Thermal:return "La temperatura está limitando el margen; evita forzar rendimiento sostenido.";case Bottleneck::Shader:return "Hay shaders pendientes; el tirón puede disminuir cuando termine la compilación.";case Bottleneck::Memory:return "El frame supera el presupuesto; revisa presión de memoria y cachés.";case Bottleneck::Presentation:return "La presentación consume demasiado tiempo; revisa sincronización y pacing.";default:return "El frame está dentro del presupuesto objetivo.";} }

std::string DiagnosticsCore::summary(double target_fps) const {
    const auto s=snapshot(target_fps); std::ostringstream o; o<<std::fixed<<std::setprecision(1);
    o<<"Estado: "<<bottleneck_name(s.bottleneck)<<";FPS: "<<s.fps<<";Frame: "<<s.frame_ms<<" ms;CPU: "<<s.cpu_ms<<" ms ("<<s.cpu_util<<"%);GPU: "<<s.gpu_ms<<" ms ("<<s.gpu_util<<"%);Presentación: "<<s.present_ms<<" ms;Jitter: "<<s.jitter_ms<<" ms;Temperatura: nivel "<<s.thermal_level<<";Shaders pendientes: "<<s.shader_pending<<";Caché shaders: "<<s.shader_cache_hits<<" hits / "<<s.shader_cache_misses<<" misses;Escala: "<<s.adaptive_scale<<"%"<<(s.adaptive_enabled?" (auto)":"");
    o<<";JIT: "<<(s.jit_enabled?"activo":"no integrado")<<";Vulkan: "<<(s.vulkan_ready?"preparado":"no disponible")<<";TLB: "<<s.tlb_entries<<" entradas;Muestras: "<<s.samples<<";Consejo: "<<advisor_text(s.bottleneck); return o.str();
}
} // namespace lg::performance
