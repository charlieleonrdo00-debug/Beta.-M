#pragma once
#include <cstdint>

namespace lg::performance {

// Render policy designed for the future Vulkan renderer. It keeps the output
// resolution independent from internal render resolution so an upscaler can
// reconstruct a sharp image without pretending to create extra GPU work.
struct AdaptiveScaleConfig {
    bool enabled{false};
    int target_fps{60};
    int min_scale{60};
    int max_scale{100};
};

struct AdaptiveScaleState {
    int scale{100};
    int stable_frames{0};
    double last_frame_ms{0.0};
};

class AdaptiveScaler {
public:
    explicit AdaptiveScaler(AdaptiveScaleConfig config = {});
    void set_enabled(bool enabled) noexcept;
    bool enabled() const noexcept;
    void reset() noexcept;
    int update(double frame_ms, double gpu_ms = 0.0, int thermal_level = 0) noexcept;
    const AdaptiveScaleState& state() const noexcept { return state_; }

private:
    AdaptiveScaleConfig config_;
    AdaptiveScaleState state_;
};

} // namespace lg::performance
