#pragma once
#include <atomic>
#include <cstdint>

namespace lg::performance {

struct FrameSample {
    double cpu_ms{};
    double gpu_ms{};
    double present_ms{};
    double frame_ms{};
};

class Telemetry {
public:
    void record(const FrameSample& sample) noexcept {
        last_cpu_us_.store(static_cast<uint64_t>(sample.cpu_ms * 1000.0));
        last_gpu_us_.store(static_cast<uint64_t>(sample.gpu_ms * 1000.0));
        last_frame_us_.store(static_cast<uint64_t>(sample.frame_ms * 1000.0));
    }
    FrameSample last() const noexcept {
        return {last_cpu_us_.load()/1000.0, last_gpu_us_.load()/1000.0,
                0.0, last_frame_us_.load()/1000.0};
    }
private:
    std::atomic<uint64_t> last_cpu_us_{};
    std::atomic<uint64_t> last_gpu_us_{};
    std::atomic<uint64_t> last_frame_us_{};
};

} // namespace lg::performance
