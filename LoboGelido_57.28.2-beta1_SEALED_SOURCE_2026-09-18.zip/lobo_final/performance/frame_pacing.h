#pragma once
#include <chrono>

namespace lg::performance {

class FramePacing {
public:
    explicit FramePacing(double target_fps = 60.0);
    void begin_frame();
    void end_frame();

private:
    std::chrono::steady_clock::time_point frame_start_{};
    std::chrono::nanoseconds budget_{};
};

} // namespace lg::performance
