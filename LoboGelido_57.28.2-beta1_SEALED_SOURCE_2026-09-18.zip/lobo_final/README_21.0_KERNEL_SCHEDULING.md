# Lobo Gélido 21.0 — Kernel Scheduling

Esta fase convierte el Scheduler 20.0 en la base de una capa de kernel de ejecución determinista.

## Implementado

- `ThreadManager`: creación, estados, prioridades, round-robin entre iguales, cambio de contexto, sleep/wake y terminación.
- `SyncManager`: eventos y semáforos con bloqueo/desbloqueo de hilos.
- `Kernel`: composición de Scheduler + ThreadManager + SyncManager + ServiceRegistry.
- `RuntimeCoordinator`: consume `Kernel::scheduler()` como reloj/event queue central.
- CMake host y Android actualizados.
- Android versionCode 2100 / versionName 21.0.

## Validación

14/14 pruebas nativas pasan.

La batería cubre decoder, sesión, intérprete, CPU, loader, MMU, adaptive scaler, diagnostics, runtime coordinator, scheduler y thread manager.

## Próxima capa

La siguiente evolución natural es conectar este kernel con un sistema de contexto CPU real, temporización por hilo, espera de IPC, colas de servicio y primitivas de sincronización asociadas al estado de ejecución del guest.

No se afirma todavía compatibilidad completa con el kernel real de Nintendo Switch, ni se incluyen firmware, claves o contenido propietario.
