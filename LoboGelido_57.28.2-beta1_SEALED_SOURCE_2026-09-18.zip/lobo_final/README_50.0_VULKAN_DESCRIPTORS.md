# Lobo Gélido 50.0 — Vulkan Descriptors & Resource Binding

Esta versión conecta la capa de recursos GPU con una capa real de descriptors Vulkan en Android.

## Incluye
- `VulkanDescriptorBackend` con `VkDescriptorPool`.
- `VkDescriptorSetLayout` y asignación de `VkDescriptorSet`.
- Bindings de buffers y sampled images usando recursos creados por `VulkanResourceBackend`.
- `vkUpdateDescriptorSets` real.
- `vkCmdBindDescriptorSets` real para el command buffer gráfico.
- El `GpuCommandProcessor` reconoce `BindDescriptorSet` y conserva el estado del set activo.
- CMake Android actualizado para incluir el backend de descriptors.
- Prueba host de seguridad/aislamiento: el backend Vulkan real no se simula fuera de Android.

## Alcance
Esto es una capa gráfica Vulkan real, pero todavía no constituye por sí sola un renderer completo de Nintendo Switch. La traducción de comandos gráficos del guest, shaders reales y gestión completa de estados/layouts siguen siendo trabajo posterior.

No se incluyen firmware, keys, ROMs ni contenido propietario.
