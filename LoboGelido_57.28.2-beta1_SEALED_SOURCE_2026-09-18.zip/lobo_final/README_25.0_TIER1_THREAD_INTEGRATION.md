# Lobo Gélido 25.0 — Tier-1 Thread/Block Integration

## What changed
- Guest CPU contexts are now the execution state owned by each guest thread.
- The Tier-1 BlockBackend can execute against an explicit `CpuState` instead of a single hidden CPU state.
- Guest thread dispatch now uses the block backend when available.
- `RuntimeCoordinator::run_frame()` routes the main guest thread through the kernel dispatcher rather than bypassing the thread layer.
- Block counters/instruction accounting remain observable.

## Important status
This release is **not** a native JIT. The block backend still executes validated ARM64 through the interpreter. It is the correct integration boundary for the next Dynarmic tier.

## Dynarmic
The project is prepared for an optional Dynarmic backend, but Dynarmic source is not bundled in this archive because the current build environment could not fetch the upstream repository. No proprietary Nintendo material is included.
