# Lobo Gélido 56.2 — Android Build Fix

## Objetivo

Corregir los fallos que impedían una compilación Android limpia y estable del runtime nativo tras las adiciones de 56.0 (GPU Resource Binding Runtime) y 56.1 (icono de launcher).

## Problemas corregidos

1. **JNI `ANativeWindow_fromSurface`**
   - Se pasaba `nullptr` como `JNIEnv*` → fallo en tiempo de ejecución al inicializar Vulkan.
   - Corregido a `ANativeWindow_fromSurface(env, surface)`.

2. **CMake de Android desincronizado**
   - Faltaban fuentes añadidas en 56.0:
     - `gpu/shader_program_manager.cpp`
     - `gpu/guest_gpu_translator.cpp`
     - `gpu/vulkan_resource_binding_runtime.cpp`
     - `gpu/render_graph.cpp`
   - Se reescribió `android/app/src/main/cpp/CMakeLists.txt` con rutas absolutas vía `${LG_ROOT}` y enlace a `log`.

3. **`android/app/build.gradle.kts` incompleto**
   - Añadidos: `compileOptions` / `kotlinOptions` (Java 17), `buildTypes`, `packaging`, `buildFeatures`, dependencias mínimas AndroidX/Kotlin y flags CMake (`c++_shared`, flexible page sizes).

4. **Versionado**
   - `versionName` → `56.2`
   - `versionCode` → `5620`
   - Cadena nativa `RuntimeBridge.version()` y `strings.xml` actualizados.
   - Artefacto CI renombrado a `Lobo-Gelido-56.2-APK`.

## Alcance legal / técnico

- No se incluye firmware, claves, ROMs ni assets propietarios de Nintendo.
- El camino Vulkan real sigue dependiendo de un dispositivo/emulador con soporte Vulkan.
- Host CTest permanece sin cambios en esta revisión (las correcciones son específicas del target Android).

## Cómo construir

```bash
# Host (pruebas unitarias)
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j$(nproc)
ctest --test-dir build --output-on-failure

# Android (requiere JDK 17 + SDK 36 + NDK 27.3.13750724)
cd android
./build-apk.sh
# o con Gradle 8.13:
# gradle --no-daemon assembleDebug
```

## Resultado esperado

- Biblioteca nativa `liblobogelido_android.so` (arm64-v8a) con todos los módulos 56.0 enlazados.
- APK debug firmado de depuración con icono 56.1 y versión 56.2.
- Inicialización Vulkan desde `Surface` sin crash por `JNIEnv` nulo.
