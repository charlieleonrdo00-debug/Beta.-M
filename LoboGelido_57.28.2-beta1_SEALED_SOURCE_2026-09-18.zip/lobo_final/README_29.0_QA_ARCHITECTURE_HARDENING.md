# Lobo Gélido 30.0 — QA / Architecture Hardening

## Audit scope

Reviewed the cumulative source tree through 28.0, with emphasis on lifecycle, memory mapping, runtime state, GPU capability reporting, scheduler reset behavior, Android JNI wiring, build configuration, and test validity.

## Corrections made

1. **Release tests were previously capable of becoming no-op tests.**
   The project used `assert(...)`, while Release builds defined `NDEBUG`. Test targets now explicitly undefine `NDEBUG`, so CTest validates the assertions in Release builds.

2. **GPU capability reporting could be mistaken for real hardware readiness.**
   The core GPU device model previously fabricated Vulkan 1.3 capabilities. It now starts unavailable and accepts capabilities only from an external/platform probe. Runtime diagnostics therefore report `GPU=off` until real Android Vulkan integration exists.

3. **Runtime reuse after stop was incomplete.**
   Session preparation now supports a clean `Stopped -> Ready` transition. Runtime stop clears GPU state, MMU mappings, guest memory, kernel objects and the active backend; preparation resets metrics.

4. **Address-space mapping was not transactional.**
   A partially successful map could leave pages behind when a later page collided. Mapping now validates the full range before mutating the page table.

5. **Scheduler reset was incomplete.**
   Clearing the scheduler now resets virtual time, event IDs, sequence state and statistics in addition to owned events.

6. **Stale tests contradicted the intended MMU semantics.**
   The MMU test now verifies VA-to-PA translation into host-backed memory and uses relative sleep time consistently with the scheduler API.

7. **Android diagnostics still seeded synthetic Vulkan readiness.**
   That seed is now disabled. Synthetic idle telemetry remains explicitly documented until real renderer hooks are connected.

## Validation

Release host build:

- **18/18 CTest passed**
- Decoder
- Session
- Interpreter
- CPU real/coverage/extended/advanced
- MMU
- Adaptive scaler
- Diagnostics
- Runtime coordinator
- Scheduler
- Thread manager/kernel runtime
- Tier-1 block backend
- JIT provider boundary
- GPU/render graph/shader cache

## Remaining architectural risks

- Android Vulkan instance/device/surface integration is not yet present in the core.
- Dynarmic must still be supplied and compiled as an external dependency for real JIT execution.
- `MainActivity.kt` remains larger than ideal and should be decomposed into screen/controller components before adding more consumer features.
- Guest HLE, IPC semantics, HID, audio, GPU translation and content loading remain incomplete for real Switch compatibility.
- The core is currently predominantly single-threaded at the guest scheduler level; host concurrency needs a deliberate synchronization design before parallel execution is introduced.
