# Lobo Gélido 12.0 — ARM64 + ASIMD/NEON Core

## Objetivo

El hito 12.0 continúa el camino hacia ejecución real de software ARM64 sin reconstruir el frontend. El foco es ampliar las instrucciones que aparecen con frecuencia en código moderno y reforzar la frontera CPU/memoria.

## Implementado en este hito

- ASIMD/NEON de tres operandos para ADD/SUB entero por lanes de 8/16/32/64 bits.
- ASIMD/NEON AND/ORR/EOR de registros de 64/128 bits.
- FADD/FSUB/FMUL vectorial para S y D en vectores de 64/128 bits.
- DUP desde registro general hacia lanes vectoriales de 8/16/32/64 bits.
- LD1/ST1 de un registro vectorial, incluido post-index por el tamaño del registro.
- Estado V0–V31 conservado como dos lanes de 64 bits, manteniendo la separación del estado escalar.
- Fast path de escritura de AddressSpace con incremento de época de escritura.
- Exclusivas LDXR/STXR ahora guardan la época de memoria observada y fallan si otra escritura ocurrió entre la carga exclusiva y el store exclusivo.
- La clasificación de extensiones SIMD no soportadas permanece deliberadamente estrecha para evitar ejecutar por accidente una codificación distinta.

## Arquitectura

`CPU state -> decoder -> cached instruction -> scalar/SIMD semantics -> memory/MMU -> exception`

El camino SIMD reutiliza la misma frontera de memoria y excepciones del intérprete escalar. Esto evita duplicar reglas de permisos y permite introducir posteriormente un backend de bloques/IR que trate instrucciones escalares y vectoriales desde una representación común.

## Verificación

- 9/9 pruebas CMake pasan después de la ampliación.
- `cpu_arm64_advanced` ahora valida instrucciones SIMD con codificaciones reales generadas por clang AArch64, LD1/ST1, post-index y pérdida de reserva exclusiva por escritura interviniente.

## Próximo salto

La siguiente fase debe ampliar ASIMD/NEON con permutas, comparaciones, shifts, widening/narrowing y cargas estructuradas; después conviene mover la ejecución repetitiva a una IR de bloques básica antes de abordar un JIT real. También faltan system registers, excepciones privilegiadas, scheduler multicore, fastmem con guard pages y una capa HLE/IPC suficientemente completa para software de Switch.
