# Lobo Gélido 55.9 — Guest Pipeline → Shader Program Binding

## Objetivo

Conectar el identificador de `pipeline_id` emitido por el flujo Guest GPU con el `program_id` administrado por `ShaderProgramManager`, sin introducir formatos propietarios de paquetes de Nintendo.

## Cambio principal

`GuestGpuPacket::BindPipeline` ahora conserva:

- `a = pipeline_id`
- `b = shader_program_id`

`GpuCommandProcessor` propaga ambos valores a `GpuState` como `pipeline_id` y `shader_program_id`.

La ruta queda preparada para que una capa de creación de pipelines haga:

`pipeline_id -> shader_program_id -> ShaderProgram(vertex, fragment) -> VulkanPipeline variant`

## Seguridad de diseño

- No se incluyen firmware, claves, ROMs ni contenido de juegos.
- El formato continúa siendo un IR backend-neutral de Lobo Gélido.
- `program_id = 0` puede utilizarse para una vinculación no especificada/compatibilidad.
- La ejecución Vulkan sigue consumiendo la variante mediante `pipeline_id`; la resolución del programa se mantiene separada de la grabación del command buffer.

## Validación

Las pruebas del procesador y del traductor verifican que `pipeline_id` y `shader_program_id` sobreviven intactos desde el paquete Guest GPU hasta `GpuState`.
