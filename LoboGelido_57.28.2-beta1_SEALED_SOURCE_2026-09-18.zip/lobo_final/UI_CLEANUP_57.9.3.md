# Lobo Gélido 57.9.3 — limpieza visual y datos reales

- Shell única: rail lateral permanente; no se usa navegación inferior Android.
- Eliminados fondos atmosféricos/wallpapers de las pantallas normales y del setup.
- Sin tarjetas de juegos de demostración: la biblioteca sólo muestra archivos SAF existentes, legibles y con formato soportado.
- La carátula sólo se acepta si procede de una imagen real local asociada al contenido o de una búsqueda remota con coincidencia de título; si no hay evidencia, se muestra `CARÁTULA NO DISPONIBLE`.
- Tamaño/formato se leen del archivo; versión permanece `No disponible` si no existe un lector verificable.
- Compatibilidad sólo cambia tras una comprobación real de preparación/inicio del runtime.
- Diagnóstico sin muestras ya no aparece como `Óptimo`: se muestra `Sin datos`.
- Rendimiento sin sesión ya no se presenta como `Sesión activa`.
- `showGameRuntime()` continúa usando `GameSurfaceView` + Vulkan + runtime nativo y no pinta gameplay ficticio.
