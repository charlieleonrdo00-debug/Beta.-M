# Lobo Gélido 56.3 — Visual Polish

## Objetivo

Alinear la interfaz Android con el mockup de diseño de referencia:
pantallas limpias, menos saturación, sin logos gigantes superpuestos y
jerarquía visual clara.

## Problemas del estado anterior (56.2)

- Hero de inicio con lobo a 190 dp solapando el texto
- Fondo `lobo_winter` a pantalla completa → aspecto saturado y ruidoso
- Tarjetas y bordes con cian demasiado intenso
- Pantalla de sesión de juego con foto de fondo a alta opacidad
- Espaciado apretado en header, contenido y navegación inferior

## Cambios 56.3

### Home (`LoboConsoleHomeRenderer`)
- Hero más bajo (200 dp) con gradiente suave en lugar de foto completa
- Logo del lobo reducido a 110 dp, sin solapar el copy
- Tipografía y CTA alineados al mockup (panel 1–2)
- Tarjetas de “Último juego” con gradientes suaves
- Accesos rápidos más limpios
- Status strip sobrio (CPU / GPU / Listo)

### Boot
- Splash centrado, sin foto de fondo ruidosa
- Ventana de carga acortada a ~12 s (antes 30 s forzados)

### Sesión de juego (`showGameRuntime`)
- Sin foto winter saturada
- Gradiente oscuro + marca del lobo muy sutil
- Botones y tipografía más legibles

### Chrome global (`MainActivity`)
- Nueva paleta (navy profundo, cian hielo, bordes más suaves)
- Cards, header y bottom nav actualizados
- Más padding / menos densidad visual

## Versión
- versionName: **56.3**
- versionCode: **5630**

## Limitaciones
- La biblioteca, ajustes y diagnóstico todavía usan el layout procedural
  existente; el pulido de esta revisión se centra en Home, Boot y sesión.
- No se incluyen assets propietarios de Nintendo.
