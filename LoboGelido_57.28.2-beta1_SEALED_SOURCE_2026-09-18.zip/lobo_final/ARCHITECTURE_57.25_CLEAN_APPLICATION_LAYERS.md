# Lobo Gélido 57.25 — Clean Application/Data/Domain boundary

## Completed
- Replaced empty application UseCase stubs with executable use cases.
- Added Android Data repositories for Settings, SAF permission persistence, Keys, Firmware, Games and Profiles.
- Moved key parsing/validation and firmware inspection/installation state out of MainActivity.
- Moved game-folder registration and game scanning into `AndroidGameRepository` and `ScanGamesUseCase`.
- Moved profile persistence and device-profile optimization into `AndroidProfileRepository` + `OptimizeGameProfileUseCase`.
- `SettingsFacade` now depends on `SettingsRepository`, not SharedPreferences.
- `SafFacade` retains only UI intent construction; persistable permission is executed by `PersistSafPermission` over the Data SAF repository.
- MainActivity continues to consume feature facades, preserving its current UI and navigation surface.

## Boundary rule
Presentation -> Application UseCases/Facades -> Domain contracts -> Data implementations.
Android `Context`, `ContentResolver`, `DocumentFile` and SharedPreferences are confined to Data/composition-root adapters.

## Intentional compatibility bridge
`GameCatalogStore` remains as a presentation-library compatibility store for favorite/recent/UI fields. New discovery and folder state are owned by the domain/Data game repository. This bridge is isolated behind `GameLibraryFacade` and is the next migration target, so the UI does not need to change during this architectural migration.

## Validation note
The environment used for this artifact does not contain Gradle 8.13, so an Android compile could not be executed here. Native 57.24 tests were previously verified at 43/43; this change is Kotlin/Android-only.
