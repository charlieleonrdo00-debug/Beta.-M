# Lobo Gélido 55.0 — Vulkan GPU Command Execution

## Objetivo
Conectar el flujo limpio `GuestGpuTranslator -> GpuCommandProcessor -> Vulkan` con ejecución real dentro de un `VkCommandBuffer` durante el render pass.

## Cambios
- Nuevo `gpu/vulkan_command_executor.h/.cpp`.
- Ejecuta realmente en Vulkan:
  - `SetViewport` -> `vkCmdSetViewport`.
  - `SetScissor` -> `vkCmdSetScissor`.
  - `Clear` -> `vkCmdClearAttachments`.
  - `Barrier` -> `vkCmdPipelineBarrier`.
  - `BindPipeline`, `BindVertexBuffer` y `Draw` requieren un `VulkanPipeline` válido y ejecutan sus comandos reales.
- `VulkanPresenter` ahora posee un `GpuCommandProcessor` y un `VulkanCommandExecutor`.
- `draw_frame()` usa la ruta de comandos GPU en vez de limitarse a un clear codificado directamente en el presenter.
- Se añadió `submit_commands()` para que una capa guest/runtime pueda entregar comandos ya traducidos al presenter.
- Diagnósticos ampliados con estadísticas de ejecución Vulkan.
- CMake Android incluye el nuevo ejecutor.
- Versión Android actualizada a 55.0 / versionCode 5500.
- Prueba `test_vulkan_command_executor` añadida.

## Validación
Build de host completado y **34/34 pruebas CTest pasaron**.

Nota: las pruebas host validan la API y la ruta estructural; la ejecución Vulkan real requiere Android + un dispositivo/driver Vulkan. Esta versión no incluye firmware, keys, ROMs ni código propietario de Nintendo.
