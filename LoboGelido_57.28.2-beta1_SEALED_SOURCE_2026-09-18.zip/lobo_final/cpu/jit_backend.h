#pragma once
#include <cstdint>
#include <memory>
#include "backend.h"
#include "interpreter.h"

namespace lg::cpu {

// Tier-2 JIT provider boundary. Providers are explicit so a build can never
// silently report a JIT that is not actually linked.
class JitProvider {
public:
    virtual ~JitProvider() = default;
    virtual core::Result<void> initialize() = 0;
    virtual core::Result<uint64_t> execute(CpuState& state, uint64_t quantum) = 0;
    virtual void invalidate_all() noexcept = 0;
    virtual const char* name() const noexcept = 0;
};

class JitBackend final : public Backend {
public:
    explicit JitBackend(std::unique_ptr<JitProvider> provider);
    core::Result<void> initialize() override;
    core::Result<void> execute(uint64_t guest_pc) override;
    core::Result<uint64_t> execute_state(CpuState& state, uint64_t quantum = 64);
    const char* name() const noexcept override { return provider_ ? provider_->name() : "JIT"; }
    BackendKind kind() const noexcept override { return BackendKind::Jit; }
    bool available() const noexcept { return provider_ != nullptr && initialized_; }
    void invalidate_all() noexcept;
private:
    std::unique_ptr<JitProvider> provider_;
    bool initialized_{};
};

} // namespace lg::cpu
