#pragma once

#include <memory>
#include "jit_backend.h"
#include "interpreter.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"

namespace lg::cpu {

class DynarmicProvider final : public JitProvider {
public:
    DynarmicProvider(memory::AddressSpace& memory, memory::Mmu& mmu, Interpreter& fallback);
    ~DynarmicProvider() override;

    core::Result<void> initialize() override;
    core::Result<uint64_t> execute(CpuState& state, uint64_t quantum) override;
    void invalidate_all() noexcept override;
    const char* name() const noexcept override { return "Dynarmic A64 JIT"; }

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

std::unique_ptr<JitProvider> make_dynarmic_provider(memory::AddressSpace& memory,
                                                     memory::Mmu& mmu,
                                                     Interpreter& fallback);

} // namespace lg::cpu
