#include "dynarmic_provider.h"

#if defined(LOBOGELIDO_HAS_DYNARMIC)

#include <algorithm>
#include <limits>
#include <optional>
#include <array>
#include <cstring>
#include <dynarmic/interface/A64/a64.h>
#include <dynarmic/interface/A64/config.h>

namespace lg::cpu {
namespace {

class Callbacks final : public Dynarmic::A64::UserCallbacks {
public:
    Callbacks(memory::AddressSpace& memory, memory::Mmu& mmu, Interpreter& fallback)
        : memory_(memory), mmu_(mmu), fallback_(fallback) {}

    CpuState* state{};
    uint64_t ticks_left{};
    uint64_t consumed_ticks{};
    uint64_t fallback_instructions{};
    bool faulted{};

    std::optional<std::uint32_t> MemoryReadCode(uint64_t vaddr) override {
        const auto value = read32(vaddr, true);
        return value;
    }
    std::uint8_t MemoryRead8(uint64_t vaddr) override {
        return read8(vaddr, false).value_or(0);
    }
    std::uint16_t MemoryRead16(uint64_t vaddr) override {
        const auto a = read8(vaddr, false), b = read8(vaddr + 1, false);
        return std::uint16_t(a.value_or(0)) | (std::uint16_t(b.value_or(0)) << 8);
    }
    std::uint32_t MemoryRead32(uint64_t vaddr) override {
        return read32(vaddr, false).value_or(0);
    }
    std::uint64_t MemoryRead64(uint64_t vaddr) override {
        return read64(vaddr, false).value_or(0);
    }
    Dynarmic::A64::Vector MemoryRead128(uint64_t vaddr) override {
        return {MemoryRead64(vaddr), MemoryRead64(vaddr + 8)};
    }
    void MemoryWrite8(uint64_t vaddr, uint8_t value) override {
        if (const auto physical = translate(vaddr, true, false)) memory_.write8(*physical, value);
    }
    void MemoryWrite16(uint64_t vaddr, uint16_t value) override {
        MemoryWrite8(vaddr, uint8_t(value)); MemoryWrite8(vaddr + 1, uint8_t(value >> 8));
    }
    void MemoryWrite32(uint64_t vaddr, uint32_t value) override {
        if ((vaddr & memory::Mmu::PageMask) <= memory::Mmu::PageSize - 4) {
            if (const auto physical = translate(vaddr, true, false)) memory_.write32(*physical, value);
            return;
        }
        for (unsigned i = 0; i < 4; ++i) MemoryWrite8(vaddr + i, uint8_t(value >> (8 * i)));
    }
    void MemoryWrite64(uint64_t vaddr, uint64_t value) override {
        if ((vaddr & memory::Mmu::PageMask) <= memory::Mmu::PageSize - 8) {
            if (const auto physical = translate(vaddr, true, false)) memory_.write64(*physical, value);
            return;
        }
        for (unsigned i = 0; i < 8; ++i) MemoryWrite8(vaddr + i, uint8_t(value >> (8 * i)));
    }
    void MemoryWrite128(uint64_t vaddr, Dynarmic::A64::Vector value) override {
        MemoryWrite64(vaddr, value[0]); MemoryWrite64(vaddr + 8, value[1]);
    }

    bool MemoryWriteExclusive8(uint64_t vaddr, uint8_t value, uint8_t expected) override {
        return exclusive(vaddr, value, expected, 1);
    }
    bool MemoryWriteExclusive16(uint64_t vaddr, uint16_t value, uint16_t expected) override {
        return exclusive(vaddr, value, expected, 2);
    }
    bool MemoryWriteExclusive32(uint64_t vaddr, uint32_t value, uint32_t expected) override {
        return exclusive(vaddr, value, expected, 4);
    }
    bool MemoryWriteExclusive64(uint64_t vaddr, uint64_t value, uint64_t expected) override {
        return exclusive(vaddr, value, expected, 8);
    }
    bool MemoryWriteExclusive128(uint64_t vaddr, Dynarmic::A64::Vector value,
                                 Dynarmic::A64::Vector expected) override {
        if (!state || !state->reservation_valid || state->reservation_address != vaddr ||
            state->reservation_size != 16 || state->reservation_epoch != memory_.write_epoch()) return false;
        if (MemoryRead128(vaddr) != expected) return false;
        MemoryWrite128(vaddr, value);
        state->reservation_valid = false;
        return true;
    }

    void InterpreterFallback(uint64_t pc, size_t count) override {
        if (!state) { faulted = true; return; }
        state->pc = pc;
        for (size_t i = 0; i < count && !state->halted; ++i) {
            if (!fallback_.step(*state)) { faulted = true; break; }
            ++fallback_instructions;
        }
    }

    void CallSVC(uint32_t /*swi*/) override {
        if (state) {
            state->exception.kind = ExceptionKind::Svc;
            state->exception.address = state->pc;
        }
        faulted = true;
    }

    void ExceptionRaised(uint64_t pc, Dynarmic::A64::Exception /*exception*/) override {
        if (state) {
            state->exception.kind = ExceptionKind::UndefinedInstruction;
            state->exception.address = pc;
        }
        faulted = true;
    }

    void AddTicks(uint64_t ticks) override {
        consumed_ticks += ticks;
        ticks_left = ticks >= ticks_left ? 0 : ticks_left - ticks;
    }
    uint64_t GetTicksRemaining() override { return ticks_left; }
    uint64_t GetCNTPCT() override { return state ? state->cntvct_el0 : 0; }
    uint64_t memory_write_epoch() const noexcept { return memory_.write_epoch(); }

private:
    struct CachedPage {
        uint64_t virtual_page{};
        uint64_t physical_page{};
        uint32_t permissions{};
        uint64_t generation{};
        uint8_t* host{};
        bool valid{};
    };
    static constexpr size_t CacheEntries = 32;

    CachedPage* cached_page(uint64_t vpn, bool write, bool execute) {
        auto& entry = tlb_cache_[static_cast<size_t>((vpn * 11400714819323198485ull) >> 59) & (CacheEntries - 1)];
        const uint64_t generation = mmu_.generation();
        if (entry.valid && entry.virtual_page == vpn && entry.generation == generation &&
            (!write || (entry.permissions & memory::Write)) &&
            (!execute || (entry.permissions & memory::Execute)) &&
            (write || execute || (entry.permissions & memory::Read))) {
            return &entry;
        }

        const auto result = mmu_.translate(vpn << memory::Mmu::PageBits, write, execute);
        if (!result.ok()) {
            faulted = true;
            if (state) {
                state->exception.kind = execute ? ExceptionKind::InstructionAbort : ExceptionKind::DataAbort;
                state->exception.address = vpn << memory::Mmu::PageBits;
            }
            entry.valid = false;
            return nullptr;
        }
        const uint64_t physical_page = result.value().physical >> memory::Mmu::PageBits;
        auto* host = memory_.host_ptr(physical_page << memory::Mmu::PageBits);
        if (!host) {
            faulted = true;
            if (state) {
                state->exception.kind = execute ? ExceptionKind::InstructionAbort : ExceptionKind::DataAbort;
                state->exception.address = vpn << memory::Mmu::PageBits;
            }
            entry.valid = false;
            return nullptr;
        }
        entry = CachedPage{vpn, physical_page, result.value().permissions, generation, host, true};
        return &entry;
    }

    std::optional<uint64_t> translate(uint64_t vaddr, bool write, bool execute) {
        const auto* page = cached_page(vaddr >> memory::Mmu::PageBits, write, execute);
        if (!page) return std::nullopt;
        return (page->physical_page << memory::Mmu::PageBits) | (vaddr & memory::Mmu::PageMask);
    }

    uint8_t* host_ptr(uint64_t vaddr, bool write, bool execute) {
        const auto* page = cached_page(vaddr >> memory::Mmu::PageBits, write, execute);
        if (!page) return nullptr;
        return page->host + (vaddr & memory::Mmu::PageMask);
    }

    std::optional<uint8_t> read8(uint64_t vaddr, bool execute) {
        if (auto* p = host_ptr(vaddr, false, execute)) return *p;
        return std::nullopt;
    }

    std::optional<uint32_t> read32(uint64_t vaddr, bool execute) {
        if ((vaddr & memory::Mmu::PageMask) <= memory::Mmu::PageSize - 4) {
            if (auto* p = host_ptr(vaddr, false, execute)) {
                uint32_t value{};
                std::memcpy(&value, p, sizeof(value));
                return value;
            }
            return std::nullopt;
        }
        uint32_t value{};
        for (unsigned i = 0; i < 4; ++i) {
            const auto byte = read8(vaddr + i, execute);
            if (!byte) return std::nullopt;
            value |= uint32_t(*byte) << (8 * i);
        }
        return value;
    }

    std::optional<uint64_t> read64(uint64_t vaddr, bool execute) {
        if ((vaddr & memory::Mmu::PageMask) <= memory::Mmu::PageSize - 8) {
            if (auto* p = host_ptr(vaddr, false, execute)) {
                uint64_t value{};
                std::memcpy(&value, p, sizeof(value));
                return value;
            }
            return std::nullopt;
        }
        uint64_t value{};
        for (unsigned i = 0; i < 8; ++i) {
            const auto byte = read8(vaddr + i, execute);
            if (!byte) return std::nullopt;
            value |= uint64_t(*byte) << (8 * i);
        }
        return value;
    }

    template <typename T>
    bool exclusive(uint64_t addr, T value, T expected, uint8_t size) {
        if (!state || !state->reservation_valid || state->reservation_address != addr ||
            state->reservation_size != size || state->reservation_epoch != memory_.write_epoch()) return false;
        T current{};
        if constexpr (sizeof(T) == 1) current = MemoryRead8(addr);
        if constexpr (sizeof(T) == 2) current = MemoryRead16(addr);
        if constexpr (sizeof(T) == 4) current = MemoryRead32(addr);
        if constexpr (sizeof(T) == 8) current = MemoryRead64(addr);
        if (current != expected) return false;
        if constexpr (sizeof(T) == 1) MemoryWrite8(addr, value);
        if constexpr (sizeof(T) == 2) MemoryWrite16(addr, value);
        if constexpr (sizeof(T) == 4) MemoryWrite32(addr, value);
        if constexpr (sizeof(T) == 8) MemoryWrite64(addr, value);
        state->reservation_valid = false;
        return true;
    }

    std::array<CachedPage, CacheEntries> tlb_cache_{};
    memory::AddressSpace& memory_;
    memory::Mmu& mmu_;
    Interpreter& fallback_;
};

} // namespace

class DynarmicProvider::Impl {
public:
    Impl(memory::AddressSpace& memory, memory::Mmu& mmu, Interpreter& fallback)
        : callbacks(memory, mmu, fallback), mmu(mmu) {}
    Callbacks callbacks;
    memory::Mmu& mmu;
    std::unique_ptr<Dynarmic::A64::Jit> jit;
    uint64_t observed_write_epoch{};
    uint64_t observed_mmu_generation{};
};

DynarmicProvider::DynarmicProvider(memory::AddressSpace& memory, memory::Mmu& mmu, Interpreter& fallback)
    : impl_(std::make_unique<Impl>(memory, mmu, fallback)) {}
DynarmicProvider::~DynarmicProvider() = default;

core::Result<void> DynarmicProvider::initialize() {
    Dynarmic::A64::UserConfig config{};
    config.callbacks = &impl_->callbacks;
    config.enable_cycle_counting = true;
    // Fastmem is deliberately disabled until AddressSpace can expose a stable,
    // contiguous guest arena. Enabling it against discontiguous pages would be
    // a correctness bug disguised as a performance optimization.
    config.fastmem_pointer = std::nullopt;
    config.page_table = nullptr;
    config.code_cache_size = 32 * 1024 * 1024;
    impl_->jit = std::make_unique<Dynarmic::A64::Jit>(config);
    impl_->observed_write_epoch = impl_->callbacks.memory_write_epoch();
    impl_->observed_mmu_generation = impl_->mmu.generation();
    return core::Result<void>::Ok();
}

core::Result<uint64_t> DynarmicProvider::execute(CpuState& state, uint64_t quantum) {
    if (!impl_->jit) {
        auto r = initialize();
        if (!r.ok()) return core::Result<uint64_t>::Error(r.error().c_str());
    }
    auto& j = *impl_->jit;
    // Writes performed by the guest invalidate translated code conservatively.
    // We check the epoch between dispatches so self-modifying code cannot keep
    // executing a stale translation on the next guest quantum.
    const auto current_epoch = impl_->callbacks.memory_write_epoch();
    const auto current_mmu_generation = impl_->mmu.generation();
    if (current_epoch != impl_->observed_write_epoch ||
        current_mmu_generation != impl_->observed_mmu_generation) {
        j.ClearCache();
        j.ClearExclusiveState();
        impl_->observed_write_epoch = current_epoch;
        impl_->observed_mmu_generation = current_mmu_generation;
    }
    j.SetRegisters(state.x);
    j.SetSP(state.sp);
    j.SetPC(state.pc);
    j.SetVectors(state.v);
    j.SetFpcr(state.fpcr);
    j.SetFpsr(state.fpsr);
    j.SetPstate(state.nzcv);
    impl_->callbacks.state = &state;
    impl_->callbacks.ticks_left = quantum;
    impl_->callbacks.consumed_ticks = 0;
    impl_->callbacks.fallback_instructions = 0;
    impl_->callbacks.faulted = false;
    j.Run();
    state.x = j.GetRegisters();
    state.sp = j.GetSP();
    state.pc = j.GetPC();
    state.v = j.GetVectors();
    state.fpcr = j.GetFpcr();
    state.fpsr = j.GetFpsr();
    state.nzcv = j.GetPstate() & 0xF0000000u;
    // Dynarmic ticks are timing units, not retired-instruction counts. Never
    // add them to CpuState::instructions; doing so corrupts profiling and block
    // statistics. Fallback instructions are actual retired interpreter steps.
    state.instructions += impl_->callbacks.fallback_instructions;
    impl_->callbacks.state = nullptr;
    if (impl_->callbacks.faulted) return core::Result<uint64_t>::Error("Dynarmic callback fault");
    return core::Result<uint64_t>::Ok(quantum - impl_->callbacks.ticks_left);
}

void DynarmicProvider::invalidate_all() noexcept {
    if (!impl_ || !impl_->jit) return;
    // Stop execution before invalidating translated code. This matters when a
    // provider is invalidated from a recovery or session-stop path.
    impl_->jit->HaltExecution();
    impl_->jit->ClearCache();
    impl_->jit->ClearExclusiveState();
}

std::unique_ptr<JitProvider> make_dynarmic_provider(memory::AddressSpace& memory, memory::Mmu& mmu, Interpreter& fallback) {
    return std::make_unique<DynarmicProvider>(memory, mmu, fallback);
}

} // namespace lg::cpu

#else

namespace lg::cpu {
class DynarmicProvider::Impl {};
DynarmicProvider::DynarmicProvider(memory::AddressSpace&, memory::Mmu&, Interpreter&) : impl_(std::make_unique<Impl>()) {}
DynarmicProvider::~DynarmicProvider() = default;
core::Result<void> DynarmicProvider::initialize() { return core::Result<void>::Error("Dynarmic not linked"); }
core::Result<uint64_t> DynarmicProvider::execute(CpuState&, uint64_t) { return core::Result<uint64_t>::Error("Dynarmic not linked"); }
void DynarmicProvider::invalidate_all() noexcept {}
std::unique_ptr<JitProvider> make_dynarmic_provider(memory::AddressSpace&, memory::Mmu&, Interpreter&) { return nullptr; }
}

#endif
