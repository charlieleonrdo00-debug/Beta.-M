#pragma once
#include <cstdint>
namespace lg::cpu {
enum class ExceptionKind : uint8_t {
    None, InstructionAbort, DataAbort, UndefinedInstruction, Alignment,
    Svc, Breakpoint, SystemRegister, ExclusiveFail
};
struct Exception {
    ExceptionKind kind{ExceptionKind::None};
    uint64_t address{};
    uint32_t syndrome{};
};
}
