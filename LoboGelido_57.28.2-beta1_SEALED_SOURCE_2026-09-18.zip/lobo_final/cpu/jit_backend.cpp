#include "jit_backend.h"

namespace lg::cpu {

JitBackend::JitBackend(std::unique_ptr<JitProvider> provider)
    : provider_(std::move(provider)) {}

core::Result<void> JitBackend::initialize() {
    initialized_ = false;
    if (!provider_) return core::Result<void>::Error("JIT provider unavailable");
    auto result = provider_->initialize();
    initialized_ = result.ok();
    return result;
}

core::Result<void> JitBackend::execute(uint64_t guest_pc) {
    if (!provider_ || !initialized_) return core::Result<void>::Error("JIT provider unavailable");
    CpuState state{};
    state.pc = guest_pc;
    auto r = provider_->execute(state, 64);
    if (!r.ok()) return core::Result<void>::Error(r.error().c_str());
    return core::Result<void>::Ok();
}

core::Result<uint64_t> JitBackend::execute_state(CpuState& state, uint64_t quantum) {
    if (!provider_ || !initialized_) return core::Result<uint64_t>::Error("JIT provider unavailable");
    return provider_->execute(state, quantum);
}

void JitBackend::invalidate_all() noexcept {
    if (provider_) provider_->invalidate_all();
}

} // namespace lg::cpu
