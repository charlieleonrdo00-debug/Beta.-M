#pragma once
#include <cstdint>
#include <unordered_map>
#include "backend.h"
#include "interpreter.h"

namespace lg::cpu {

// Tier-1 execution backend: caches hot guest entry points and executes a bounded
// block through the validated interpreter. This is intentionally not advertised
// as native-code JIT; it is the safe bridge toward a Dynarmic tier-2 backend.
class BlockBackend final : public Backend {
public:
    BlockBackend(memory::AddressSpace& memory, memory::Mmu& mmu, uint64_t quantum = 64);
    core::Result<void> initialize() override;
    core::Result<void> execute(uint64_t guest_pc) override;
    core::Result<uint64_t> execute_state(CpuState& state, uint64_t quantum_override = 0);
    const char* name() const noexcept override { return "Block"; }
    BackendKind kind() const noexcept override { return BackendKind::Block; }
    Interpreter& interpreter() noexcept { return cpu_; }
    uint64_t instructions() const noexcept { return instructions_; }
    uint64_t blocks() const noexcept { return compiled_blocks_; }
    uint64_t hot_hits() const noexcept { return hot_hits_; }
    uint64_t block_count() const noexcept { return blocks_.size(); }
    void clear() noexcept { blocks_.clear(); cpu_.clear_decode_cache(); initialized_ = false; instructions_ = compiled_blocks_ = hot_hits_ = 0; }
private:
    struct BlockInfo { uint32_t first_raw{}; uint32_t length{}; uint64_t hits{}; };
    Interpreter cpu_;
    std::unordered_map<uint64_t, BlockInfo> blocks_;
    uint64_t quantum_;
    uint64_t instructions_{};
    uint64_t compiled_blocks_{};
    uint64_t hot_hits_{};
    bool initialized_{};
    bool discover(uint64_t pc, BlockInfo& out) noexcept;
};

} // namespace lg::cpu
