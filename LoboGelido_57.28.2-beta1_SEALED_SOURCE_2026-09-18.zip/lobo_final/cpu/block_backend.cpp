#include "block_backend.h"

namespace lg::cpu {

BlockBackend::BlockBackend(memory::AddressSpace& memory, memory::Mmu& mmu, uint64_t quantum)
    : cpu_(memory, mmu), quantum_(quantum ? quantum : 1) {
    cpu_.set_strict_code_validation(true);
}

core::Result<void> BlockBackend::initialize() {
    initialized_ = true;
    return core::Result<void>::Ok();
}

bool BlockBackend::discover(uint64_t pc, BlockInfo& out) noexcept {
    auto* ptr = cpu_.interpreter_code_ptr(pc); // optional fast probe exposed by Interpreter.
    if (!ptr) return false;
    out.first_raw = *ptr;
    out.length = static_cast<uint32_t>(quantum_);
    return true;
}

core::Result<uint64_t> BlockBackend::execute_state(CpuState& state, uint64_t quantum_override) {
    if (!initialized_) return core::Result<uint64_t>::Error("block backend is not initialized");
    const uint64_t pc = state.pc;
    auto it = blocks_.find(pc);
    if (it == blocks_.end()) {
        BlockInfo info{};
        if (!discover(pc, info)) return core::Result<uint64_t>::Error("cannot discover guest block");
        it = blocks_.emplace(pc, info).first;
        ++compiled_blocks_;
    } else {
        ++hot_hits_;
    }
    ++it->second.hits;
    const auto before = state.instructions;
    const auto ran = cpu_.run(state, quantum_override ? quantum_override : quantum_);
    instructions_ += ran;
    it->second.length = static_cast<uint32_t>(state.instructions - before);
    if (state.exception.kind != ExceptionKind::None)
        return core::Result<uint64_t>::Error("block backend guest fault");
    return core::Result<uint64_t>::Ok(ran);
}

core::Result<void> BlockBackend::execute(uint64_t guest_pc) {
    CpuState state{};
    state.pc = guest_pc;
    auto r = execute_state(state);
    if (!r.ok()) return core::Result<void>::Error(r.error().c_str());
    return core::Result<void>::Ok();
}

} // namespace lg::cpu
