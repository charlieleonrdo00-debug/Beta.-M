#pragma once
#include <memory>
#include <vector>
#include "backend.h"

namespace lg::cpu {

class BackendManager {
public:
    void add(std::unique_ptr<Backend> backend);
    Backend* select_best(bool jit_available) const noexcept;
    Backend* find(BackendKind kind) const noexcept;
private:
    std::vector<std::unique_ptr<Backend>> backends_;
};

} // namespace lg::cpu
