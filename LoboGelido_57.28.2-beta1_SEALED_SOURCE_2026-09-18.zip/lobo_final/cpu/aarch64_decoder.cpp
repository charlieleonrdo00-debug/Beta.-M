#include "aarch64_decoder.h"
namespace lg::cpu {
static int64_t sx(uint64_t v,unsigned bits){const uint64_t m=1ull<<(bits-1);return int64_t((v^m)-m);}
OpcodeClass Decoder::classify(uint32_t x) noexcept {
    if(x==0xD503201Fu)return OpcodeClass::Nop;
    if((x&0x7F800000u)==0x52800000u||(x&0x7F800000u)==0x12800000u||(x&0x7F800000u)==0x72800000u)return OpcodeClass::MovWide;
    if((x&0x7F000000u)==0x11000000u)return OpcodeClass::AddSubImm;
        if((x&0x1FE0FC00u)==0x1A000000u)return OpcodeClass::AddSubCarry;
    if((x&0x1FE0FC00u)==0x1AC02000u || (x&0x1FE0FC00u)==0x1AC02400u || (x&0x1FE0FC00u)==0x1AC02800u || (x&0x1FE0FC00u)==0x1AC02C00u)return OpcodeClass::ShiftReg;
    if((x&0x1F200000u)==0x0B000000u)return OpcodeClass::AddSubReg;
    if((x&0x1F200000u)==0x0A000000u)return OpcodeClass::LogicalReg;
    if((x&0x7F800000u)==0x12000000u)return OpcodeClass::LogicalImm;
    if((x&0x1F000000u)==0x13000000u)return OpcodeClass::Bitfield;
    if((x&0x7FE00C00u)==0x1A800000u)return OpcodeClass::ConditionalSelect;
    if((x&0x1F000000u)==0x1B000000u)return OpcodeClass::Multiply;
    if((x&0x7FE0FC00u)==0x1AC00800u)return OpcodeClass::Div;
    if((x&0x3B000000u)==0x39000000u)return OpcodeClass::LoadStoreUnsigned;
    if((x&0x3A000000u)==0x28000000u)return OpcodeClass::LoadStorePair;
    if((x&0x3B000000u)==0x18000000u)return OpcodeClass::LoadStoreLiteral;
    if((x&0x3B200C00u)==0x38200800u)return OpcodeClass::LoadStoreReg;
    if((x&0x3F000000u)==0x08000000u)return OpcodeClass::Exclusive;
    if((x&0xFFFFF09Fu)==0xD503309Fu || (x&0xFFFFF09Fu)==0xD503309Fu)return OpcodeClass::Barrier;
    if((x&0xFFE0001Fu)==0xD4000001u || (x&0xFFE0001Fu)==0xD4200000u || (x&0xFFF00000u)==0xD5100000u || (x&0xFFF00000u)==0xD5300000u)return OpcodeClass::System;
    if((x&0xFFFFFC1Fu)==0xD65F0000u)return OpcodeClass::Return;
    if((x&0xFFFFFC1Fu)==0xD61F0000u || (x&0xFFFFFC1Fu)==0xD63F0000u)return OpcodeClass::BranchReg;
    if((x&0x7C000000u)==0x14000000u)return OpcodeClass::Branch;
    if((x&0x7F000000u)==0x34000000u || (x&0x7F000000u)==0x35000000u)return OpcodeClass::CompareBranch;
    if((x&0xFF000010u)==0x54000000u)return OpcodeClass::CondBranch;
    if((x&0x1F000000u)==0x10000000u)return OpcodeClass::Adr;
    if((x&0x9F000000u)==0x90000000u)return OpcodeClass::Adrp;
    if((x&0x7F000000u)==0x71000000u)return OpcodeClass::CompareImm;
    if((x&0x7F200000u)==0x6B000000u)return OpcodeClass::CompareReg;
    if((x&0xFFFFFC00u)==0x5AC00C00u || (x&0xFFFFFC00u)==0xDAC00C00u)return OpcodeClass::Rev;
    if((x&0xFFFFFC00u)==0xDAC01000u)return OpcodeClass::Clz;
    if((x&0xFFFFFC00u)==0xDAC00000u)return OpcodeClass::Rbit;
    if((x&0xFF20FC00u)==0x1E202800u || (x&0xFF20FC00u)==0x1E203800u || (x&0xFF20FC00u)==0x1E200800u || (x&0xFF20FC00u)==0x1E201800u || (x&0xFF3FFC00u)==0x1E204000u)return OpcodeClass::FPScalar;
    // Advanced SIMD / NEON: three-same arithmetic/logic, DUP and single-register LD1/ST1.
    // Keep the recognizer deliberately narrow: unsupported NEON encodings fall through to
    // UndefinedInstruction instead of being silently mis-executed.
    if((x&0x9FE0FC00u)==0x0E000C00u)return OpcodeClass::SimdDup;
    if((x&0x0F000400u)==0x0E000400u)return OpcodeClass::SimdThreeSame;
    if((x&0x3F000000u)==0x0C000000u)return OpcodeClass::SimdLoadStore;
    return OpcodeClass::Unknown;
}
std::optional<Instruction> Decoder::decode(uint32_t x) noexcept {
    Instruction i{}; i.raw=x; i.cls=classify(x); if(i.cls==OpcodeClass::Unknown)return std::nullopt;
    i.rd=x&31;i.rn=(x>>5)&31;i.rm=(x>>16)&31;i.ra=(x>>10)&31;i.sf=(x>>31)!=0;
    switch(i.cls){
    case OpcodeClass::MovWide:i.immediate=(uint64_t((x>>5)&0xFFFFu)<<16*((x>>21)&3));i.bit_invert=((x>>29)&1)!=0;break;
    case OpcodeClass::AddSubImm:i.immediate=(x>>10)&0xFFFu;if(x&(1u<<22))i.immediate<<=12;i.subtract=(x>>30)&1;i.set_flags=(x>>29)&1;break;
    case OpcodeClass::AddSubReg:i.subtract=(x>>30)&1;i.set_flags=(x>>29)&1;i.shift=(x>>10)&0x3F;break;
    case OpcodeClass::AddSubCarry:i.subtract=(x>>30)&1;i.set_flags=(x>>29)&1;break;
    case OpcodeClass::LogicalReg:i.bit_invert=(x>>21)&1;i.shift=(x>>10)&0x3F;break;
    case OpcodeClass::LogicalImm:i.immediate=(x>>10)&0xFFFu;i.shift=(x>>16)&0x3F;break;
    case OpcodeClass::ShiftReg:i.shift=(x>>10)&0x3F;break;
    case OpcodeClass::ShiftImm:i.shift=(x>>16)&0x3F;break;
    case OpcodeClass::LoadStoreUnsigned:{unsigned size=(x>>30)&3u;i.mem_size=uint8_t(1u<<size);unsigned opc=(x>>22)&3u;i.load=opc!=0;i.signed_load=opc==2;i.is_64=(size==3)||(i.signed_load&&size==2);i.immediate=(x>>10)&0xFFFu;i.immediate*=i.mem_size;break;}
    case OpcodeClass::LoadStorePair:{i.mem_size=i.sf?8:4;i.immediate=uint64_t(sx((x>>15)&0x7Fu,7))*i.mem_size;i.load=(x>>22)&1;unsigned mode=(x>>23)&3;i.post_index=mode==1;i.pre_index=mode==3;i.pair_writeback=i.pre_index||i.post_index;break;}
    case OpcodeClass::LoadStoreLiteral:i.immediate=uint64_t(sx((x>>5)&0x7FFFFu,19))*4;i.load=(x>>30)&1;i.is_64=i.sf;i.mem_size=i.is_64?8:4;break;
    case OpcodeClass::LoadStoreReg:i.load=(x>>22)&1;i.is_64=(x>>30)&1;i.mem_size=i.is_64?8:4;i.register_offset=true;i.shift=(x>>12)&7;break;
    case OpcodeClass::Exclusive:i.exclusive=true;i.load=((x>>22)&1)!=0;i.acquire=(x>>15)&1;i.release=(x>>15)&1;i.is_64=(x>>31)!=0;i.mem_size=i.is_64?8:4;i.ra=(x>>16)&31;break;
    case OpcodeClass::Barrier:i.sys_op=(x>>5)&7;break;
    case OpcodeClass::System:i.sys_imm=(x>>5)&0xFFFF;i.sys_op=(x>>21)&0x7F;break;
    case OpcodeClass::Branch:{i.displacement=sx(x&0x03FFFFFFu,26)<<2;i.link=x>>31;break;}
    case OpcodeClass::BranchReg:i.link=((x&0xFFFFFC1Fu)==0xD63F0000u);break;
    case OpcodeClass::CompareBranch:i.displacement=sx((x>>5)&0x7FFFFu,19)<<2;i.zero_test=!((x>>24)&1);break;
    case OpcodeClass::CondBranch:i.displacement=sx((x>>5)&0x7FFFFu,19)<<2;i.condition=x&15;break;
    case OpcodeClass::Adr:i.displacement=sx(((x>>5)&0x7FFFFu)|(((x>>29)&3u)<<19),21);break;
    case OpcodeClass::Adrp:i.displacement=sx(((x>>5)&0x7FFFFu)|(((x>>29)&3u)<<19),21)<<12;break;
    case OpcodeClass::CompareImm:i.immediate=(x>>10)&0xFFFu;if(x&(1u<<22))i.immediate<<=12;i.subtract=true;i.set_flags=true;break;
    case OpcodeClass::CompareReg:i.subtract=true;i.set_flags=true;i.shift=(x>>10)&0x3F;break;
    case OpcodeClass::ConditionalSelect:i.condition=x&15;i.rm=(x>>16)&31;i.bit_invert=(x>>30)&1;i.shift=(x>>10)&3;break;
    case OpcodeClass::Multiply:i.ra=(x>>10)&31;i.subtract=(x>>15)&1;break;
    case OpcodeClass::Div:i.signed_op=((x>>10)&1)!=0;break;
    case OpcodeClass::Bitfield:i.shift=(x>>16)&0x3F;i.immediate=(x>>10)&0x3F;i.bit_invert=(x>>30)&1;break;
    case OpcodeClass::FPScalar:i.fp64=((x>>22)&1)!=0;break;
    case OpcodeClass::SimdThreeSame:
        i.simd_q=((x>>30)&1)!=0; i.shift=(x>>22)&3; i.simd_sub=((x>>29)&1)!=0;
        i.simd_bitwise=((x>>11)&0x1F)==0x03; i.simd_fp=((x>>11)&0x1F)==0x1A || ((x>>11)&0x1F)==0x1B; break;
    case OpcodeClass::SimdMovi:
        i.simd_q=((x>>30)&1)!=0; i.immediate=(x>>5)&0xFFu; i.shift=(x>>16)&0x1F; break;
    case OpcodeClass::SimdDup:
        i.simd_q=((x>>30)&1)!=0; i.rm=(x>>5)&31; { const unsigned imm5=(x>>16)&0x1F; i.shift=(imm5==0?0:__builtin_ctz(imm5)); } i.simd_dup_scalar=true; break;
    case OpcodeClass::SimdLoadStore:
        i.simd_q=((x>>30)&1)!=0; i.simd_store=((x>>22)&1)==0; i.simd_post_index=((x>>23)&1)!=0; i.shift=(x>>10)&3; break;
    default:break;
    }
    return i;
}
}
