#include "backend_manager.h"

namespace lg::cpu {

void BackendManager::add(std::unique_ptr<Backend> backend) {
    if (backend) backends_.push_back(std::move(backend));
}

Backend* BackendManager::find(BackendKind kind) const noexcept {
    for (const auto& backend : backends_) {
        if (backend && backend->kind() == kind) return backend.get();
    }
    return nullptr;
}

Backend* BackendManager::select_best(bool jit_available) const noexcept {
    if (jit_available) {
        if (auto* jit = find(BackendKind::Jit)) return jit;
    }
    if (auto* block = find(BackendKind::Block)) return block;
    if (auto* interpreter = find(BackendKind::Interpreter)) return interpreter;
    return nullptr;
}

} // namespace lg::cpu
