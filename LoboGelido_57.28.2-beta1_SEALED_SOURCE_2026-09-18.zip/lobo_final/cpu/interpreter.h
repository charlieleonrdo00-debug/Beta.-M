#pragma once
#include <array>
#include <cstdint>
#include <unordered_map>
#include "aarch64_decoder.h"
#include "exceptions.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"
namespace lg::cpu {
struct CpuState {
    void reset() noexcept { *this = CpuState{}; }
    std::array<uint64_t,31> x{};
    uint64_t sp{}, pc{};
    uint32_t nzcv{}, fpcr{}, fpsr{};
    std::array<std::array<uint64_t,2>,32> v{};
    uint64_t tpidr_el0{}, cntvct_el0{};
    uint64_t reservation_address{};
    uint64_t reservation_value{};
    uint8_t reservation_size{};
    bool reservation_valid{}, halted{};
    uint64_t reservation_epoch{};
    uint64_t instructions{};
    Exception exception{};
};
class Interpreter {
public:
    explicit Interpreter(memory::AddressSpace& mem):memory_(mem){}
    Interpreter(memory::AddressSpace& mem, memory::Mmu& mmu):memory_(mem),mmu_(&mmu){}
    void attach_mmu(memory::Mmu& mmu) noexcept { mmu_=&mmu; }
    void detach_mmu() noexcept { mmu_=nullptr; }
    void clear_decode_cache() noexcept { cache_.clear(); }
    void set_strict_code_validation(bool enabled) noexcept { strict_code_validation_=enabled; }
    bool step(CpuState&) noexcept;
    uint64_t run(CpuState&,uint64_t) noexcept;
    const uint32_t* interpreter_code_ptr(uint64_t pc) const noexcept;
private:
    memory::AddressSpace& memory_;
    memory::Mmu* mmu_{};
    struct Cached { uint32_t raw{}; Instruction ins{}; };
    std::unordered_map<uint64_t,Cached> cache_;
    bool strict_code_validation_{true};
    uint64_t observed_write_epoch_{};
    uint64_t observed_mmu_generation_{};
    static uint64_t mask(bool) noexcept;
    static uint64_t reg(const CpuState&,unsigned,bool sp_allowed=false) noexcept;
    static void write_reg(CpuState&,unsigned,uint64_t,bool sp_allowed=false) noexcept;
    static uint32_t add_flags(uint64_t,uint64_t,uint64_t,bool,bool) noexcept;
    static bool condition(uint32_t,uint8_t) noexcept;
    static uint64_t ror(uint64_t,unsigned,unsigned) noexcept;
    static bool decode_logical_imm(const Instruction&,uint64_t&) noexcept;
    bool read8(uint64_t,uint8_t&,bool execute=false) noexcept;
    bool read32(uint64_t,uint32_t&,bool execute=false) noexcept;
    bool read64(uint64_t,uint64_t&,bool execute=false) noexcept;
    bool write8(uint64_t,uint8_t) noexcept;
    bool write32(uint64_t,uint32_t) noexcept;
    bool write64(uint64_t,uint64_t) noexcept;
    bool translate(uint64_t,bool,bool,uint64_t&) noexcept;
    static void fault(CpuState&,ExceptionKind,uint64_t,uint32_t=0) noexcept;
};
}
