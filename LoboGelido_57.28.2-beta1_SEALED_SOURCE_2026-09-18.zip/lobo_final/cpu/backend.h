#pragma once
#include <cstdint>
#include "../core/result.h"

namespace lg::cpu {

enum class BackendKind : uint8_t { Interpreter, Block, Jit, Nce };

class Backend {
public:
    virtual ~Backend() = default;
    virtual core::Result<void> initialize() = 0;
    virtual core::Result<void> execute(uint64_t guest_pc) = 0;
    virtual const char* name() const noexcept = 0;
    virtual BackendKind kind() const noexcept = 0;
};

} // namespace lg::cpu
