#pragma once
#include <cstdint>
#include <vector>

namespace lg::cpu {

enum class IROp : uint8_t {
    Nop,
    Add,
    Sub,
    And,
    Or,
    Xor,
    Load,
    Store,
    Branch,
    Compare,
    System
};

struct IRInstruction {
    IROp op{IROp::Nop};
    uint8_t dst{};
    uint8_t src1{};
    uint8_t src2{};
    uint64_t immediate{};
};

class IRBlock {
public:
    void push(IRInstruction instruction) { code_.push_back(instruction); }
    const std::vector<IRInstruction>& code() const noexcept { return code_; }
private:
    std::vector<IRInstruction> code_;
};

} // namespace lg::cpu
