#pragma once
#include <atomic>
#include <cstdint>
namespace lg::cpu {
class AtomicMemory {
public:
    static uint32_t load32(const uint32_t* p) noexcept { std::atomic_ref<const uint32_t> a(*p); return a.load(std::memory_order_acquire); }
    static uint64_t load64(const uint64_t* p) noexcept { std::atomic_ref<const uint64_t> a(*p); return a.load(std::memory_order_acquire); }
    static void store32(uint32_t* p,uint32_t v) noexcept { std::atomic_ref<uint32_t> a(*p); a.store(v,std::memory_order_release); }
    static void store64(uint64_t* p,uint64_t v) noexcept { std::atomic_ref<uint64_t> a(*p); a.store(v,std::memory_order_release); }
    static bool compare_exchange64(uint64_t* p,uint64_t& expected,uint64_t desired) noexcept { std::atomic_ref<uint64_t> a(*p); return a.compare_exchange_strong(expected,desired,std::memory_order_acq_rel); }
    static void barrier() noexcept { std::atomic_thread_fence(std::memory_order_seq_cst); }
};
}
