#include "interpreter.h"
#include <atomic>
#include <bit>
#include <cmath>
#include <cstring>
namespace lg::cpu {
uint64_t Interpreter::mask(bool sf) noexcept { return sf?~0ull:0xffffffffull; }
uint64_t Interpreter::reg(const CpuState&s,unsigned r,bool sp) noexcept { return r==31?(sp?s.sp:0):s.x[r]; }
void Interpreter::write_reg(CpuState&s,unsigned r,uint64_t v,bool sp) noexcept { if(r==31){if(sp)s.sp=v;return;}s.x[r]=v; }
uint32_t Interpreter::add_flags(uint64_t a,uint64_t b,uint64_t r,bool sub,bool sf) noexcept {
    const uint64_t m=mask(sf),aa=a&m,bb=b&m,rr=r&m; const unsigned top=sf?63:31;
    const bool z=rr==0,n=((rr>>top)&1)!=0,c=sub?aa>=bb:rr<aa;
    const bool v=sub?((((aa^bb)&(aa^rr))>>top)&1):(((((~(aa^bb))&(aa^rr))>>top)&1));
    return uint32_t((n?0x80000000:0)|(z?0x40000000:0)|(c?0x20000000:0)|(v?0x10000000:0));
}
bool Interpreter::condition(uint32_t f,uint8_t c) noexcept { bool n=f&0x80000000,z=f&0x40000000,cg=f&0x20000000,v=f&0x10000000;switch(c&15){case 0:return z;case 1:return !z;case 2:return cg;case 3:return !cg;case 4:return n;case 5:return !n;case 6:return v;case 7:return !v;case 8:return cg&&!z;case 9:return !cg||z;case 10:return n==v;case 11:return n!=v;case 12:return !z&&(n==v);case 13:return z||(n!=v);case 14:return true;default:return false;} }
uint64_t Interpreter::ror(uint64_t x,unsigned r,unsigned bits) noexcept { r%=bits;if(!r)return x;const uint64_t m=bits==64?~0ull:((1ull<<bits)-1);x&=m;return ((x>>r)|(x<<(bits-r)))&m; }
bool Interpreter::decode_logical_imm(const Instruction&i,uint64_t& out) noexcept {
    const uint32_t x=i.raw; const unsigned n=(x>>22)&1, immr=(x>>16)&0x3f, imms=x&0x3f; const unsigned width=i.sf?64:32;
    if(!i.sf && n) return false;
    const unsigned value=(n<<6)|((~imms)&0x3f); unsigned len=0; for(int b=6;b>=1;--b) if(value&(1u<<b)){len=b;break;} if(len==0)return false;
    const unsigned levels=(1u<<len)-1, s=imms&levels, r=immr&levels; if(s==levels)return false;
    const unsigned esize=1u<<len; uint64_t elem=(1ull<<(s+1))-1; elem=ror(elem,r,esize);
    out=0; for(unsigned pos=0;pos<width;pos+=esize) out|=elem<<pos; out&=mask(i.sf); return true;
}
void Interpreter::fault(CpuState&s,ExceptionKind k,uint64_t a,uint32_t syn) noexcept { s.exception={k,a,syn};s.halted=true; }
bool Interpreter::translate(uint64_t va,bool write,bool exec,uint64_t& pa) noexcept {
    if(!mmu_){pa=va;return true;}
    const auto t=mmu_->translate(va,write,exec);
    if(t.ok()){pa=t.value().physical;return true;}
    // When an MMU is active, a failed translation is a real guest fault.
    // Falling back to a host pointer here would bypass guest page permissions
    // and could turn an unmapped/execute-protected access into valid memory.
    return false;
}
bool Interpreter::read8(uint64_t a,uint8_t&v,bool exec) noexcept {
    uint64_t p; if(!translate(a,false,exec,p))return false;
    if(const auto* hp=memory_.host_ptr(p)){ v=*hp; return true; }
    auto x=memory_.read8(p); if(!x)return false; v=*x; return true;
}
bool Interpreter::read32(uint64_t a,uint32_t&v,bool exec) noexcept {
    if (a > UINT64_MAX - 3) return false;
    uint64_t p;
    if(translate(a,false,exec,p)){
        if(const auto* hp=memory_.host_ptr(p); hp && ((p&0xfffull)<=0xffc)){ std::memcpy(&v,hp,4); return true; }
    }
    v=0; for(unsigned j=0;j<4;++j){ uint8_t b; if(!read8(a+j,b,exec))return false; v|=uint32_t(b)<<(j*8); } return true;
}
bool Interpreter::read64(uint64_t a,uint64_t&v,bool exec) noexcept {
    if (a > UINT64_MAX - 7) return false;
    uint64_t p;
    if(translate(a,false,exec,p)){
        if(const auto* hp=memory_.host_ptr(p); hp && ((p&0xfffull)<=0xff8)){ std::memcpy(&v,hp,8); return true; }
    }
    v=0; for(unsigned j=0;j<8;++j){ uint8_t b; if(!read8(a+j,b,exec))return false; v|=uint64_t(b)<<(j*8); } return true;
}
bool Interpreter::write8(uint64_t a,uint8_t v) noexcept {
    uint64_t p; if(!translate(a,true,false,p))return false;
    memory_.write8(p,v); return memory_.host_ptr(p)!=nullptr;
}
bool Interpreter::write32(uint64_t a,uint32_t v) noexcept {
    if (a > UINT64_MAX - 3) return false;
    uint64_t p;
    if(translate(a,true,false,p)){
        if(memory_.host_ptr(p) && ((p&0xfffull)<=0xffc)){ memory_.write32(p,v); return true; }
    }
    for(unsigned j=0;j<4;++j){ if(!write8(a+j,uint8_t(v>>(j*8)))) return false; } return true;
}
bool Interpreter::write64(uint64_t a,uint64_t v) noexcept {
    if (a > UINT64_MAX - 7) return false;
    uint64_t p;
    if(translate(a,true,false,p)){
        if(memory_.host_ptr(p) && ((p&0xfffull)<=0xff8)){ memory_.write64(p,v); return true; }
    }
    for(unsigned j=0;j<8;++j){ if(!write8(a+j,uint8_t(v>>(j*8)))) return false; } return true;
}
bool Interpreter::step(CpuState&s) noexcept {
    if(s.halted)return false;
    // Keep the optional decode-cache mode coherent with guest code writes and
    // MMU remaps. Strict validation still checks the instruction word itself,
    // while the epoch/generation path makes the non-strict mode safe as well.
    const auto write_epoch = memory_.write_epoch();
    const auto mmu_generation = mmu_ ? mmu_->generation() : 0;
    if (write_epoch != observed_write_epoch_ || mmu_generation != observed_mmu_generation_) {
        cache_.clear();
        observed_write_epoch_ = write_epoch;
        observed_mmu_generation_ = mmu_generation;
    }
    if(s.pc&3){fault(s,ExceptionKind::Alignment,s.pc);return false;}
    uint32_t raw=0;Instruction d{};auto it=cache_.find(s.pc);if(it!=cache_.end()&&!strict_code_validation_){d=it->second.ins;}else{if(!read32(s.pc,raw,true)){fault(s,ExceptionKind::InstructionAbort,s.pc);return false;}if(it!=cache_.end()&&it->second.raw==raw)d=it->second.ins;else{auto dec=Decoder::decode(raw);if(!dec){fault(s,ExceptionKind::UndefinedInstruction,s.pc,raw);return false;}d=*dec;cache_[s.pc]=Cached{raw,d};}}
    uint64_t next=s.pc+4,m=mask(d.sf),a=reg(s,d.rn,true),b=reg(s,d.rm),r=0;
    switch(d.cls){
    case OpcodeClass::Nop: break;
    case OpcodeClass::MovWide:{unsigned sh=((d.raw>>21)&3)*16;uint64_t field=d.immediate;bool keep=(d.raw>>29)&1;r=keep?(reg(s,d.rd)&~(0xffffull<<sh)):0;r|=field;write_reg(s,d.rd,r&m);break;}
    case OpcodeClass::AddSubImm:{r=d.subtract?a-d.immediate:a+d.immediate;write_reg(s,d.rd,r&m,true);if(d.set_flags)s.nzcv=add_flags(a,d.immediate,r,d.subtract,d.sf);break;}
    case OpcodeClass::AddSubReg:{uint64_t y=b;unsigned st=(d.raw>>22)&3;if(d.shift){if(st==0)y=b<<d.shift;else if(st==1)y=b>>d.shift;else if(st==2)y=uint64_t(int64_t(b)>>d.shift);else y=ror(b,d.shift,d.sf?64:32);}r=d.subtract?a-y:a+y;write_reg(s,d.rd,r&m,true);if(d.set_flags)s.nzcv=add_flags(a,y,r,d.subtract,d.sf);break;}
    case OpcodeClass::AddSubCarry:{const bool c=(s.nzcv&0x20000000)!=0;uint64_t y=b; if(d.subtract)r=a-y-(c?0:1);else r=a+y+(c?1:0);write_reg(s,d.rd,r&m,true);if(d.set_flags)s.nzcv=add_flags(a,d.subtract?(y+(c?0:1)):(y+(c?1:0)),r,d.subtract,d.sf);break;}
    case OpcodeClass::LogicalReg:{uint64_t y=b;unsigned st=(d.raw>>22)&3;if(d.shift){if(st==0)y=b<<d.shift;else if(st==1)y=b>>d.shift;else if(st==2)y=uint64_t(int64_t(b)>>d.shift);else y=ror(b,d.shift,d.sf?64:32);}if(d.bit_invert)y=~y;unsigned op=(d.raw>>29)&3;r=op==0?a&y:op==1?a|y:a^y;write_reg(s,d.rd,r&m);break;}
    case OpcodeClass::LogicalImm:{uint64_t imm;if(!decode_logical_imm(d,imm)){fault(s,ExceptionKind::UndefinedInstruction,s.pc,d.raw);return false;}unsigned op=(d.raw>>29)&3;r=op==0?a&imm:op==1?a|imm:a^imm;write_reg(s,d.rd,r&m);break;}
    case OpcodeClass::ShiftReg:{unsigned op=(d.raw>>22)&3,sh=b&(d.sf?63:31);uint64_t x=a&m;r=op==0?(x<<sh):op==1?(x>>sh):uint64_t(int64_t((d.sf?x:uint32_t(x)))>>sh);write_reg(s,d.rd,r&m);break;}
    case OpcodeClass::Bitfield:{unsigned width=d.sf?64:32, immr=(d.raw>>16)&(width-1),imms=(d.raw>>10)&(width-1),op=(d.raw>>29)&3;uint64_t src=reg(s,d.rn)&m;uint64_t rot=ror(src,immr,width);unsigned w=((imms-immr)&(width-1))+1;uint64_t maskv=w==64?~0ull:((1ull<<w)-1);uint64_t val=rot&maskv;if(op==0 && w<width && ((val>>(w-1))&1))val|=~maskv;if(op==1){uint64_t old=reg(s,d.rd)&m;val=(old&~maskv)|(val&maskv);}write_reg(s,d.rd,val&m);break;}
    case OpcodeClass::LoadStoreUnsigned:{uint64_t addr=a+d.immediate;unsigned opc=(d.raw>>22)&3;unsigned mode=(d.raw>>10)&3;bool wb=((d.raw>>24)&1)==0 && (mode==1||mode==3);bool pre=wb&&mode==3;if(wb)addr=pre?a+d.immediate:a;if(!d.load && opc==0){bool ok=d.mem_size==8?write64(addr,reg(s,d.rd)):d.mem_size==4?write32(addr,uint32_t(reg(s,d.rd))):write8(addr,uint8_t(reg(s,d.rd)));if(!ok){fault(s,ExceptionKind::DataAbort,addr);return false;}}else{uint64_t val=0;bool ok=d.mem_size==8?read64(addr,val):d.mem_size==4?([&]{uint32_t q;bool z=read32(addr,q);val=q;return z;})():([&]{uint8_t q;bool z=read8(addr,q);val=q;return z;})();if(!ok){fault(s,ExceptionKind::DataAbort,addr);return false;}if(opc==2){unsigned bits=d.mem_size*8;uint64_t rawv=val&(bits==64?~0ull:(bits==32?0xffffffffull:(bits==16?0xffffull:0xffull)));if(bits<64 && ((rawv>>(bits-1))&1))rawv|=~((1ull<<bits)-1);val=rawv;}write_reg(s,d.rd,val&(d.is_64?~0ull:0xffffffffull));}if(wb)write_reg(s,d.rn,a+d.immediate,true);break;}
    case OpcodeClass::LoadStoreReg:{uint64_t addr=a+(b<<d.shift);uint64_t val=0; if(d.load){bool ok=d.mem_size==8?read64(addr,val):d.mem_size==4?([&]{uint32_t q;bool z=read32(addr,q);val=q;return z;})():([&]{uint8_t q;bool z=read8(addr,q);val=q;return z;})();if(!ok){fault(s,ExceptionKind::DataAbort,addr);return false;}write_reg(s,d.rd,val&m);}else{bool ok=d.mem_size==8?write64(addr,reg(s,d.rd)):d.mem_size==4?write32(addr,uint32_t(reg(s,d.rd))):write8(addr,uint8_t(reg(s,d.rd)));if(!ok){fault(s,ExceptionKind::DataAbort,addr);return false;}}break;}
    case OpcodeClass::LoadStorePair:{uint64_t addr=a;if(d.pre_index)addr+=d.immediate;if(d.load){if(d.sf){uint64_t p,q;if(!read64(addr,p)||!read64(addr+8,q)){fault(s,ExceptionKind::DataAbort,addr);return false;}write_reg(s,d.rd,p);write_reg(s,(d.rd+1)&31,q);}else{uint32_t p,q;if(!read32(addr,p)||!read32(addr+4,q)){fault(s,ExceptionKind::DataAbort,addr);return false;}write_reg(s,d.rd,p);write_reg(s,(d.rd+1)&31,q);}}else{bool ok=d.sf?write64(addr,reg(s,d.rd))&&write64(addr+8,reg(s,(d.rd+1)&31)):write32(addr,uint32_t(reg(s,d.rd)))&&write32(addr+4,uint32_t(reg(s,(d.rd+1)&31)));if(!ok){fault(s,ExceptionKind::DataAbort,addr);return false;}}if(d.pair_writeback)write_reg(s,d.rn,a+d.immediate,true);break;}
    case OpcodeClass::LoadStoreLiteral:{uint64_t addr=uint64_t(int64_t(s.pc)+d.immediate),val=0;bool ok=d.is_64?read64(addr,val):([&]{uint32_t q;bool z=read32(addr,q);val=q;return z;})();if(!ok){fault(s,ExceptionKind::DataAbort,addr);return false;}if(d.load)write_reg(s,d.rd,val&(d.is_64?~0ull:0xffffffffull));break;}
    case OpcodeClass::Exclusive:{uint64_t addr=a;if(d.load){uint64_t val=0;bool ok=d.is_64?read64(addr,val):([&]{uint32_t q;bool z=read32(addr,q);val=q;return z;})();if(!ok){fault(s,ExceptionKind::DataAbort,addr);return false;}write_reg(s,d.rd,val&m);s.reservation_address=addr;s.reservation_value=val;s.reservation_size=d.mem_size;s.reservation_epoch=memory_.write_epoch();s.reservation_valid=true;}else{bool ok=s.reservation_valid&&s.reservation_address==addr&&s.reservation_size==d.mem_size&&s.reservation_epoch==memory_.write_epoch();if(ok){if(d.is_64)ok=write64(addr,reg(s,d.rd));else ok=write32(addr,uint32_t(reg(s,d.rd)));}write_reg(s,d.ra,ok?0:1);s.reservation_valid=false;if(!ok && s.exception.kind==ExceptionKind::None)s.exception={ExceptionKind::ExclusiveFail,addr,0};}break;}
    case OpcodeClass::Barrier:std::atomic_thread_fence(std::memory_order_seq_cst);break;
    case OpcodeClass::System:{if((d.raw&0xFFE0001Fu)==0xD4000001u){fault(s,ExceptionKind::Svc,s.pc,(d.raw>>5)&0xFFFF);return false;}if((d.raw&0xFFE0001Fu)==0xD4200000u){fault(s,ExceptionKind::Breakpoint,s.pc,(d.raw>>5)&0xFFFF);return false;}if((d.raw&0xFFF0FFE0u)==0xD530D040u){write_reg(s,d.rd,s.tpidr_el0);break;}if((d.raw&0xFFF0FFE0u)==0xD510D040u){s.tpidr_el0=reg(s,d.rd);break;}if(d.raw==0xD53BE040u){write_reg(s,d.rd,s.cntvct_el0?++s.cntvct_el0:s.cntvct_el0=1);break;}break;}
    case OpcodeClass::Branch:if(d.link)s.x[30]=s.pc+4;next=uint64_t(int64_t(s.pc)+d.displacement);break;
    case OpcodeClass::BranchReg:if(d.link)s.x[30]=s.pc+4;next=reg(s,d.rn)&~3ull;break;
    case OpcodeClass::CompareBranch:{bool take=d.zero_test?(reg(s,d.rd)==0):(reg(s,d.rd)!=0);if(take)next=uint64_t(int64_t(s.pc)+d.displacement);break;}
    case OpcodeClass::CondBranch:if(condition(s.nzcv,d.condition))next=uint64_t(int64_t(s.pc)+d.displacement);break;
    case OpcodeClass::Adr:write_reg(s,d.rd,uint64_t(int64_t(s.pc)+d.displacement));break;
    case OpcodeClass::Adrp:write_reg(s,d.rd,(s.pc&~0xfffull)+d.displacement);break;
    case OpcodeClass::CompareImm:r=a-d.immediate;s.nzcv=add_flags(a,d.immediate,r,true,d.sf);break;
    case OpcodeClass::CompareReg:{uint64_t y=b<<d.shift;r=a-y;s.nzcv=add_flags(a,y,r,true,d.sf);break;}
    case OpcodeClass::ConditionalSelect:{uint64_t y=reg(s,d.rm),v;if(condition(s.nzcv,d.condition))v=a;else{unsigned op=((d.raw>>29)&3)<<1|((d.raw>>10)&1);if(op==1)v=y+1;else if(op==2)v=~y;else if(op==3)v=~y+1;else v=y;}write_reg(s,d.rd,v&m);break;}
    case OpcodeClass::Multiply:{uint64_t x=reg(s,d.rn),y=reg(s,d.rm),acc=reg(s,d.ra);r=d.subtract?acc-x*y:acc+x*y;write_reg(s,d.rd,r&m);break;}
    case OpcodeClass::Div:{uint64_t x=reg(s,d.rn),y=reg(s,d.rm);if(y==0)r=0;else if(d.signed_op){int64_t sx=int64_t(x),sy=int64_t(y);r=(sx==INT64_MIN&&sy==-1)?uint64_t(INT64_MIN):uint64_t(sx/sy);}else r=x/y;write_reg(s,d.rd,r&m);break;}
    case OpcodeClass::Rev:{uint64_t x=reg(s,d.rn);r=d.sf?__builtin_bswap64(x):__builtin_bswap32(uint32_t(x));write_reg(s,d.rd,r&m);break;}
    case OpcodeClass::Clz:{uint64_t x=reg(s,d.rn)&m;r=d.sf?(x?__builtin_clzll(x):64):(x?__builtin_clz(uint32_t(x)):32);write_reg(s,d.rd,r);break;}
    case OpcodeClass::Rbit:{uint64_t x=reg(s,d.rn),q=0;unsigned bits=d.sf?64:32;for(unsigned j=0;j<bits;j++)q|=((x>>j)&1)<<(bits-1-j);write_reg(s,d.rd,q&m);break;}
    case OpcodeClass::FPScalar:{double x,y,z;float xf,yf,zf;const unsigned op=d.raw&0x3f000000u;if(d.fp64){std::memcpy(&x,&s.v[d.rn][0],8);std::memcpy(&y,&s.v[d.rm][0],8);if((d.raw&0xFF20FC00u)==0x1E202800u)z=x+y;else if((d.raw&0xFF20FC00u)==0x1E203800u)z=x-y;else if((d.raw&0xFF20FC00u)==0x1E200800u)z=x*y;else if((d.raw&0xFF20FC00u)==0x1E201800u)z=x/y;else z=y;std::memcpy(&s.v[d.rd][0],&z,8);}else{uint32_t ux=uint32_t(s.v[d.rn][0]),uy=uint32_t(s.v[d.rm][0]),uz=0;std::memcpy(&xf,&ux,4);std::memcpy(&yf,&uy,4);if((d.raw&0xFF20FC00u)==0x1E202800u)zf=xf+yf;else if((d.raw&0xFF20FC00u)==0x1E203800u)zf=xf-yf;else if((d.raw&0xFF20FC00u)==0x1E200800u)zf=xf*yf;else if((d.raw&0xFF20FC00u)==0x1E201800u)zf=xf/yf;else zf=yf;std::memcpy(&uz,&zf,4);s.v[d.rd][0]=(s.v[d.rd][0]&~0xffffffffull)|uz;} (void)op;break;}
    case OpcodeClass::SimdThreeSame:{
        const unsigned op=(d.raw>>11)&0x1F, size=(d.raw>>22)&3, elem=1u<<size;
        const unsigned total=d.simd_q?16u:8u;
        if(elem>8 || (total%elem)!=0){fault(s,ExceptionKind::UndefinedInstruction,s.pc,d.raw);return false;}
        const unsigned lanes=total/elem;
        if(op==0x10 && !d.simd_fp){
            decltype(s.v) old{}; // keeps destination semantics independent of overlap.
            old=s.v;
            for(unsigned n=0;n<lanes;n++){
                const unsigned byte=n*elem, lane=byte>>3, off=(byte&7)*8, bits=elem*8;
                const uint64_t maskv=bits==64?~0ull:((1ull<<bits)-1);
                const uint64_t xv=(old[d.rn][lane]>>off)&maskv, yv=(old[d.rm][lane]>>off)&maskv;
                const uint64_t rv=(d.simd_sub?(xv-yv):(xv+yv))&maskv;
                s.v[d.rd][lane]=(s.v[d.rd][lane]&~(maskv<<off))|(rv<<off);
            }
        } else if(op==0x03 && !d.simd_fp){
            const unsigned logic=(d.raw>>22)&3;
            if(logic==0){ for(unsigned k=0;k<total/8;k++) s.v[d.rd][k]=s.v[d.rn][k]&s.v[d.rm][k]; }
            else if(logic==2){ for(unsigned k=0;k<total/8;k++) s.v[d.rd][k]=s.v[d.rn][k]|s.v[d.rm][k]; }
            else if(d.raw&(1u<<29)){ for(unsigned k=0;k<total/8;k++) s.v[d.rd][k]=s.v[d.rn][k]^s.v[d.rm][k]; }
            else {fault(s,ExceptionKind::UndefinedInstruction,s.pc,d.raw);return false;}
        } else if((op==0x1A || op==0x1B) && d.simd_fp){
            if(size!=0 && size!=3){fault(s,ExceptionKind::UndefinedInstruction,s.pc,d.raw);return false;}
            const unsigned count=total/(size==0?4u:8u);
            for(unsigned n=0;n<count;n++){
                const unsigned lane=(n*(size==0?4u:8u))>>3, off=(n&1)*32;
                if(size==0){
                    uint32_t ux=uint32_t(s.v[d.rn][lane]>>off), uy=uint32_t(s.v[d.rm][lane]>>off), uz=0; float x,y,z;
                    std::memcpy(&x,&ux,4); std::memcpy(&y,&uy,4);
                    if(op==0x1B) z=x*y; else if((d.raw>>22)&3u) z=x-y; else z=x+y;
                    std::memcpy(&uz,&z,4); s.v[d.rd][lane]=(s.v[d.rd][lane]&~(0xffffffffull<<off))|(uint64_t(uz)<<off);
                } else {
                    double x,y,z; std::memcpy(&x,&s.v[d.rn][lane],8); std::memcpy(&y,&s.v[d.rm][lane],8);
                    if(op==0x1B) z=x*y; else if((d.raw>>22)&3u) z=x-y; else z=x+y;
                    std::memcpy(&s.v[d.rd][lane],&z,8);
                }
            }
        } else {fault(s,ExceptionKind::UndefinedInstruction,s.pc,d.raw);return false;}
        break;}
    case OpcodeClass::SimdDup:{
        const unsigned esize=1u<<d.shift, total=d.simd_q?16u:8u;
        if(esize!=1&&esize!=2&&esize!=4&&esize!=8){fault(s,ExceptionKind::UndefinedInstruction,s.pc,d.raw);return false;}
        const unsigned lanes=total/esize, bits=esize*8; const uint64_t maskv=bits==64?~0ull:((1ull<<bits)-1);
        const uint64_t src=reg(s,d.rm);
        for(unsigned n=0;n<lanes;n++){const unsigned byte=n*esize,lane=byte>>3,off=(byte&7)*8;s.v[d.rd][lane]=(s.v[d.rd][lane]&~(maskv<<off))|((src&maskv)<<off);}
        break;}
    case OpcodeClass::SimdLoadStore:{
        const unsigned bytes=d.simd_q?16u:8u; uint64_t addr=reg(s,d.rn,true);
        if(d.simd_store){for(unsigned k=0;k<bytes/8;k++)if(!write64(addr+k*8,s.v[d.rd][k])){fault(s,ExceptionKind::DataAbort,addr);return false;}}
        else {for(unsigned k=0;k<bytes/8;k++){uint64_t val;if(!read64(addr+k*8,val)){fault(s,ExceptionKind::DataAbort,addr);return false;}s.v[d.rd][k]=val;}}
        if(d.simd_post_index) write_reg(s,d.rn,addr+bytes,true);
        break;}
    case OpcodeClass::SimdMovi:
        // MOVI encoding is recognized for future immediate-form expansion, but is not
        // executed until its cmode/op validation is complete.
        fault(s,ExceptionKind::UndefinedInstruction,s.pc,d.raw);return false;
    default:fault(s,ExceptionKind::UndefinedInstruction,s.pc,d.raw);return false;
    }
    s.pc=next;++s.instructions;return true;
}
uint64_t Interpreter::run(CpuState&s,uint64_t n) noexcept { uint64_t c=0;for(;c<n&&step(s);++c){}return c; }

const uint32_t* Interpreter::interpreter_code_ptr(uint64_t pc) const noexcept {
    return memory_.host_ptr(pc) ? reinterpret_cast<const uint32_t*>(memory_.host_ptr(pc)) : nullptr;
}
}
