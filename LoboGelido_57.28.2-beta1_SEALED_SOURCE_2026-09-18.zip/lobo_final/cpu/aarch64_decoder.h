#pragma once
#include <cstdint>
#include <optional>
namespace lg::cpu {
enum class OpcodeClass {
    Unknown,Nop,MovWide,AddSubImm,AddSubReg,AddSubCarry,LogicalReg,LogicalImm,ShiftReg,ShiftImm,
    LoadStoreUnsigned,LoadStorePair,LoadStoreLiteral,LoadStoreReg,Exclusive,Barrier,System,Branch,BranchReg,Return,
    CompareBranch,CondBranch,Adr,Adrp,CompareImm,CompareReg,ConditionalSelect,Multiply,Div,Bitfield,Extend,Rev,Clz,Rbit,
    FPScalar,SimdThreeSame,SimdMovi,SimdDup,SimdLoadStore
};
struct Instruction {
    uint32_t raw{}; OpcodeClass cls{OpcodeClass::Unknown}; uint8_t rd{},rn{},rm{},ra{}; uint64_t immediate{}; int64_t displacement{};
    uint8_t shift{}; uint8_t condition{}; uint8_t mem_size{8}; uint8_t sys_op{}; uint16_t sys_imm{};
    bool sf{},set_flags{},subtract{},load{},link{},zero_test{},bit_invert{},signed_op{},pair_writeback{},pre_index{},post_index{},
         exclusive{},acquire{},release{},register_offset{},writeback{},signed_load{},is_64{},fp64{},simd_q{},simd_store{},simd_post_index{},simd_fp{},simd_sub{},simd_bitwise{},simd_dup_scalar{};
};
class Decoder { public: static OpcodeClass classify(uint32_t) noexcept; static std::optional<Instruction> decode(uint32_t) noexcept; };
}
