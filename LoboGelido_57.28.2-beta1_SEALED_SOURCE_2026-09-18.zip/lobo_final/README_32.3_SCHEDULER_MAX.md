# Lobo Gélido 32.3 — Scheduler Max / Deterministic Guest Scheduling

## Objetivo

Esta iteración lleva el subsistema de scheduling del runtime a una arquitectura mucho más fuerte y medible, sin confundirlo con soporte de emulación completo.

## Cambios principales

- Cola de runnable determinista O(log N).
- Prioridad de huésped preservada.
- `vruntime` con contabilidad ponderada por prioridad para fairness.
- Deadlines opcionales como desempate sin permitir starvation permanente.
- `yield()` explícito.
- `preempt_current()` explícito.
- Afinidad de CPU registrada por hilo para preparar ejecución multicore real.
- Contadores por hilo: quanta, cambios de contexto, preempciones, yields, wakeups, CPU ticks, wait ticks y vruntime.
- Quantum adaptativo y acotado por prioridad.
- El runtime utiliza el quantum calculado y lo pasa al backend de CPU.
- El JIT/Block backend puede reportar el consumo real de ticks del hilo.
- Correcciones de transición Running/Sleeping/Blocked para no dejar un `current_` fantasma.
- Aritmética saturada para evitar overflow de contadores y vruntime.
- Pruebas ampliadas de fairness, deadlines, yield, afinidad y quantum.

## Validación

Host CMake/CTest: **20/20 pruebas pasan**.

Esto valida la arquitectura del scheduler y su integración actual con el runtime. No significa que Lobo Gélido tenga ya el mismo nivel de compatibilidad de juegos que un emulador maduro.

## Próximo salto real

El scheduler ya no debe ser el cuello de botella prioritario. La siguiente diferencia brutal frente a Michel debe venir de:

1. Integración real de Dynarmic AArch64 en Android.
2. Traducción MMU/fastmem real dentro de callbacks del JIT.
3. Backend Vulkan Android real.
4. GPU command processor y shaders.
5. HLE/IPC, HID, audio y loader/compatibilidad.

No se incluyen firmware, keys ni juegos.
