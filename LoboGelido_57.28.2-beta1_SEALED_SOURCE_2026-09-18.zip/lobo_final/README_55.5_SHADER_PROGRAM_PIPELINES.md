# Lobo Gélido 55.5 — Shader Programs → Vulkan Pipelines

## Objetivo

Conectar el registro backend-neutral de `ShaderProgramManager` con las variantes dinámicas de `VulkanPipeline`, de modo que cada pipeline pueda seleccionar explícitamente su propio vertex shader y fragment shader.

## Flujo

`ShaderProgramManager → ShaderProgram → Vulkan shader modules → PipelineLayout → VkGraphicsPipeline → BindPipeline/Draw`

## Cambios

- `VulkanPipeline::create_graphics_pipeline_variant_from_program(...)` acepta un `program_id` de `ShaderProgramManager`.
- Se validan las etapas vertex/fragment antes de crear el pipeline.
- Los módulos SPIR-V se crean en Vulkan y se mantienen en una caché por hash/etapa.
- Cada variante recibe su propio `VkPipelineLayout` y `VkPipeline`.
- Los descriptor set layouts suministrados se incorporan al layout de la variante.
- Se preservan las rutas anteriores para compatibilidad.
- La ruta Android usa `VK_SHADER_STAGE_VERTEX_BIT` y `VK_SHADER_STAGE_FRAGMENT_BIT` explícitamente, evitando confundir los IDs backend-neutrales con flags Vulkan.

## Validación

- CTest: **35/35** pruebas pasan en host.
- El host sigue usando stubs para las llamadas Vulkan Android; la creación de `VkShaderModule`/`VkGraphicsPipeline` se ejecuta en el target Android con Vulkan.
- No se incluyen firmware, keys, ROMs ni shaders propietarios de Nintendo.

## Próximo objetivo

Integrar esta selección de `ShaderProgram` con el flujo de comandos guest para que el `pipeline_id` pueda resolverse a un programa shader concreto y, posteriormente, incorporar caché persistente y traducción de shaders guest → SPIR-V.
