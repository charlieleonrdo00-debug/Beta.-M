# LOBO GÉLIDO 32.1 — Texto promocional

## LOBO GÉLIDO
### Rendimiento. Estabilidad. Precisión.

Una nueva identidad visual para una consola virtual ARM64: una interfaz oscura, helada y luminosa, diseñada para que el usuario sienta que está entrando en una consola y no en una herramienta técnica.

### Lo nuevo
- 🐺 Nuevo emblema oficial de Lobo Gélido en el arranque y la interfaz.
- ❄️ Splash cinematográfico con transición de inicio.
- 🎮 Home reconstruido con lenguaje visual de consola.
- 📚 Biblioteca y juegos accesibles desde una navegación compacta.
- ⚙️ Accesos rápidos a perfiles, pieles, controles y ajustes.
- 📊 Estado de CPU, GPU y runtime integrado sin invadir la pantalla principal.
- 🧩 Frontend desacoplado del runtime para poder evolucionarlo sin romper el núcleo.

### Nota técnica
Lobo Gélido sigue siendo un proyecto de emulación en desarrollo. Esta versión mejora principalmente la experiencia de usuario y la arquitectura del frontend; no implica que todas las funciones de emulación de Nintendo Switch estén completas.
