# Lobo Gélido 32.2 — Scheduler Max

Esta iteración eleva el scheduler de un round-robin por prioridad a un scheduler de CPU huésped determinista con contabilidad real de quantum.

## Cambios

- Cola de ejecución ordenada (`std::set`) para evitar escanear todos los hilos en cada decisión.
- Prioridad huésped estricta y determinista.
- `vruntime` por hilo para rotación justa dentro de la misma prioridad.
- `cpu_ticks`, `wait_ticks`, `last_run_tick` y `quanta` para observabilidad real.
- Despertar por evento con prioridad elevada y cancelación segura.
- El backend CPU puede reportar el quantum realmente consumido.
- Runtime avanza el reloj huésped según el quantum consumido en lugar de incrementar artificialmente un tick por frame.
- Métricas de decisiones, rotaciones de equidad y CPU ticks visibles en diagnóstico.
- Se mantiene la determinación: mismo estado + mismas entradas = mismo orden de ejecución.

## Validación

20/20 pruebas existentes pasan, incluyendo las nuevas pruebas de fairness y contabilidad del scheduler.

## Referencia técnica

El diseño toma como objetivo las mejoras modernas de scheduling de emuladores Android: separar el trabajo del hilo de UI, evitar cambios innecesarios de núcleo y usar señales de rendimiento del sistema cuando estén disponibles. Android documenta que los cambios frecuentes de core tienen coste de caché/TLB y recomienda ADPF para sugerir al sistema el nivel de rendimiento; Eden también ha evolucionado su threading Android hacia ADPF y ajustes de prioridad/afinidad. Esta versión deja el scheduler huésped determinista y preparado para conectar un gobernador Android/ADPF posteriormente.
