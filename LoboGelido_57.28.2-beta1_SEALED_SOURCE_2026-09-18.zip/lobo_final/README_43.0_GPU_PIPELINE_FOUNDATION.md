# Lobo Gélido 43.0 — GPU Pipeline Foundation

Esta versión continúa desde 42.0 y añade una base real para el runtime gráfico Vulkan de Android, sin fingir capacidades que no estén disponibles.

## Cambios
- `VulkanGpuRuntime`: inicializa un `VkPipelineCache` real en el dispositivo Vulkan.
- Detecta soporte real de timestamps mediante `timestampValidBits` y `timestampPeriod`.
- Crea un `VkQueryPool` de timestamps cuando el dispositivo lo permite.
- El presenter escribe timestamps GPU alrededor del trabajo de transferencia/clear y recoge el tiempo después de que la fence confirme la finalización de la submission.
- Los diagnósticos del presenter ahora incluyen estado del runtime GPU, pipeline cache, timestamps y `gpuMs` medido por GPU.
- El código Android incluye el nuevo módulo Vulkan en su CMake.
- Se mantiene el fallback host sin Vulkan para que los tests de arquitectura sigan siendo ejecutables en CI/host.

## Alcance
Esto es una fundación de pipeline y temporización Vulkan real. Todavía no constituye un renderer completo de Nintendo Switch: no se incluyen firmware, keys, ROMs, shaders propietarios ni código propietario de Nintendo.

## Validación
- CTest host: 26/26 pruebas aprobadas.
- El APK Android no se compiló en este entorno porque no dispone del toolchain Android/SDK necesario.
