# Lobo Gélido 35.0 — CPU Runtime + MMU Integration

Primera fase de Architecture Superiority: convertir el puente JIT en un runtime CPU/MMU coherente, sin fingir que Dynarmic está incluido en el árbol.

## Cambios

- Los callbacks Dynarmic ahora traducen cada acceso de guest virtual address mediante `Mmu::translate`.
- Fetch de instrucciones exige permiso `Execute`.
- Lecturas/escrituras que cruzan una página se resuelven byte a byte con traducción independiente por página.
- Accesos normales conservan fast paths cuando permanecen dentro de una página.
- La invalidación de código traducido observa el `AddressSpace::write_epoch`.
- La MMU expone una generación monotónica para invalidar traducciones cuando cambian los mappings.
- Las reservas exclusivas siguen usando dirección virtual + epoch de memoria.

## Qué mejora

Antes, el puente recibía una dirección del guest y accedía directamente a `AddressSpace`, dejando la MMU fuera de la ruta real del JIT. Ahora la cadena es:

`Dynarmic → MMU → physical address → AddressSpace`

Esto elimina una de las brechas arquitectónicas más importantes de la fase CPU.

## Limitaciones honestas

- El código fuente de Dynarmic no está incluido en este paquete; se enlaza externamente mediante `LOBOGELIDO_DYNARMIC_SOURCE_DIR`.
- Fastmem nativo de Dynarmic permanece desactivado hasta disponer de un guest arena contiguo y estable.
- Todavía falta conectar HLE/SVC real, kernel/IPC y el backend Vulkan Android real.

## Validación

El conjunto de pruebas host debe ejecutarse con CTest. La prueba MMU incluye validación de generación de mappings.
