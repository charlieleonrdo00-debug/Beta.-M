# Lobo Gélido 36.0 — MultiCore Foundation

This release establishes the architecture for a single-library, automatic platform experience.

## User experience

The frontend does not require the user to choose an emulator/core. Each library entry carries an
internal `GamePlatform` value and the platform detector resolves the backend from content/path
signals. The platform remains an implementation detail of the runtime.

Supported platform registrations:
- Game Boy Color
- Game Boy Advance
- Nintendo 64
- Nintendo DS
- GameCube
- Wii
- Nintendo 3DS
- Nintendo Switch

## Native architecture

`platform_registry.*` provides platform IDs, detection and core registration. `runtime/multicore_manager.*`
resolves a content path to an internal core ID without pretending that a backend is implemented.
Unknown formats remain unresolved and are handed back to the loader for deeper inspection later.

## Android frontend

`PlatformDetector.kt` mirrors the resolution model for library presentation. `GameEntry.platform` is
internal metadata; the UI can continue presenting one unified "Juegos" library.

## Safety / correctness

This is an architecture layer, not a claim of full compatibility. Registering a platform does not
fabricate emulation readiness. Real cores still need to be implemented/integrated and validated.
No proprietary firmware, keys, ROMs or game content is bundled.

## Validation

Host CTest is expected to pass all existing tests plus `platform_registry` and `multicore_manager`.
Android APK compilation is not performed in this environment because the Android SDK/Gradle toolchain
is not installed here.
