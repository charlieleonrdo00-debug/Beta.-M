#include "content_loader.h"
#include <fstream>
#include <array>
#include <cstring>
#include <limits>
#include <algorithm>
namespace lg::loader {
namespace {
uint32_t u32(const uint8_t* b, size_t o){ return uint32_t(b[o])|uint32_t(b[o+1])<<8|uint32_t(b[o+2])<<16|uint32_t(b[o+3])<<24; }
uint64_t u64(const uint8_t* b, size_t o){ return uint64_t(u32(b,o)) | (uint64_t(u32(b,o+4))<<32); }
}
bool ContentLoader::read_file(const std::string&p,std::vector<uint8_t>&o){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f)return false;auto n=f.tellg();if(n<0)return false;o.resize(size_t(n));f.seekg(0);return bool(f.read(reinterpret_cast<char*>(o.data()),n));}
ContentInfo ContentLoader::inspect(const std::string&p){
    ContentInfo i{}; i.path=p; std::ifstream f(p,std::ios::binary|std::ios::ate); if(!f)return i; auto n=f.tellg(); if(n<0)return i; i.size=uint64_t(n); f.seekg(0);
    std::array<uint8_t,0x100> b{}; f.read(reinterpret_cast<char*>(b.data()),b.size()); if(f.gcount()<4)return i;
    const std::string magic(reinterpret_cast<char*>(b.data()),4);
    if(magic=="NRO0") {
        i.format=Format::Nro; i.valid=i.size>=0x80;
        if(i.valid){
            // NRO segment table: text/ro/data offsets, sizes at 0x10..0x34.
            for(int k=0;k<3;k++) {
                // Lobo Gélido's plaintext loader keeps an explicit guest load
                // address for each segment. These addresses are intentionally
                // deterministic until the relocation/ASLR layer is implemented.
                const size_t o = 0x10 + size_t(k) * 0x10;
                const uint64_t off = u64(b.data(), o);
                const uint64_t sz = u64(b.data(), o + 8);
                if (sz) {
                    const uint32_t perms = k == 0
                        ? (memory::Read | memory::Execute | memory::User)
                        : (k == 1
                            ? (memory::Read | memory::User)
                            : (memory::Read | memory::Write | memory::User));
                    i.segments.push_back({off, sz, 0x100000ull + uint64_t(k) * 0x1000000ull, perms});
                }
            }
        }
    } else if(magic=="NSO0") {
        i.format=Format::Nso; i.valid=i.size>=0x100;
        if(i.valid){
            for(int k=0;k<3;k++) {
                const size_t o = 0x10 + size_t(k) * 8;
                const uint64_t off = u32(b.data(), o);
                const uint64_t sz = u32(b.data(), o + 4);
                const uint64_t load = u64(b.data(), 0x20 + size_t(k) * 8);
                if (sz) {
                    const uint32_t perms = k == 0
                        ? (memory::Read | memory::Execute | memory::User)
                        : (k == 1
                            ? (memory::Read | memory::User)
                            : (memory::Read | memory::Write | memory::User));
                    i.segments.push_back({off, sz, load, perms});
                }
            }
        }
    } else if(magic=="NCA3"||magic=="NCA2") { i.format=Format::Nca; i.valid=i.size>=0x4000; }
    return i;
}
bool ContentLoader::load_plaintext(const ContentInfo& info, memory::AddressSpace& memory, LoadResult& out) {
    out={}; if(!info.valid || (info.format!=Format::Nro && info.format!=Format::Nso) || info.segments.empty()) return false;
    std::vector<uint8_t> file; if(!read_file(info.path,file)) return false;
    uint64_t min_addr=std::numeric_limits<uint64_t>::max(), max_addr=0;
    for(const auto& s: info.segments){
        if(!s.file_size || s.file_offset>file.size() || s.file_size>file.size()-s.file_offset) return false;
        if(s.load_address > std::numeric_limits<uint64_t>::max()-s.file_size) return false;
        if (s.permissions == 0) return false;
        min_addr=std::min(min_addr,s.load_address); max_addr=std::max(max_addr,s.load_address+s.file_size);
    }
    const uint64_t page=4096, base=min_addr & ~(page-1), end=(max_addr+page-1)&~(page-1);
    if(end<=base || !memory.map(base,end-base)) return false;
    for(const auto& s: info.segments){ for(uint64_t n=0;n<s.file_size;){ const uint64_t chunk=std::min<uint64_t>(s.file_size-n,4096); for(uint64_t j=0;j<chunk;j++) memory.write8(s.load_address+n+j,file[size_t(s.file_offset+n+j)]); n+=chunk; } }
    out.image_base=base; out.image_size=end-base; out.segment_count=uint32_t(info.segments.size()); out.entry_point=info.segments.front().load_address; return true;
}
}
