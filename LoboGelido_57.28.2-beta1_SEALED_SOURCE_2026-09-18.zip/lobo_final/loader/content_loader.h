#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "../memory/address_space.h"
#include "../memory/mmu.h"
namespace lg::loader {
enum class Format { Unknown, Nro, Nso, Nca, RomFsContainer };
struct Segment {
    uint64_t file_offset{}, file_size{}, load_address{};
    uint32_t permissions{};
};
struct ContentInfo { Format format{Format::Unknown}; uint64_t size{}; std::string path; std::vector<Segment> segments; bool valid{}; };
struct LoadResult { uint64_t entry_point{}; uint64_t image_base{}; uint64_t image_size{}; uint32_t segment_count{}; };
class ContentLoader { public:
    static ContentInfo inspect(const std::string& path);
    static bool read_file(const std::string& path,std::vector<uint8_t>& out);
    // Loads only plaintext executable segments described by the container header.
    // It deliberately does not decrypt NCA/DRM-protected content.
    static bool load_plaintext(const ContentInfo& info, memory::AddressSpace& memory, LoadResult& out);
};
}
