# Lobo Gélido 57.9.4 — UI reference cleanup

- One compact left console rail; the legacy bottom Android-style navigation is not used.
- Deep navy/black surfaces with restrained ice-blue/cyan accents.
- Ordinary library, diagnostics, profiles and settings screens do not use the old full-screen wallpaper.
- Library entries come only from readable user-selected game files.
- No example game names, sizes, FPS, compatibility or hardware metrics are injected.
- Game artwork is shown only from a readable local cover or from an artwork lookup that passes an exact normalized title match. Otherwise the UI explicitly reports that the cover is unavailable.
- Native runtime/Vulkan remains responsible for game pixels and runtime telemetry.

The reference image is used only as a visual target; its example games and example measurements are not copied into the data model.
