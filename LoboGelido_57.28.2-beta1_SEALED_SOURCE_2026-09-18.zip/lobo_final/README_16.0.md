# Lobo Gélido 16.0

Frontend evolucionado a cobertura funcional completa de las áreas UX solicitadas, con persistencia y separación de responsabilidades.

## Arquitectura

`MainActivity → Screen composition`

`GameCatalogStore → Biblioteca / favoritos / recencia`

`GamePreviewStore → URI de gameplay por juego`

`PreviewPlayer → reproducción desacoplada`

`GameProfileStore → configuración por título`

`AppSettingsStore → preferencias globales / accesibilidad / tema`

`DiagnosticsPresenter → contrato nativo → UI`

El backend de emulación sigue siendo un trabajo independiente: este hito no afirma compatibilidad completa con Nintendo Switch.


## Evolución 17.0 — Pieles Nintendo Switch

Se añadió una sección **Pieles** inspirada en la organización visual de la referencia aportada: importar carpeta, importar ZIP, ocultar catálogo, catálogo de máscaras Nintendo Switch, miniaturas de Joy-Con/Pro Controller y selección persistente de la piel activa. Los paquetes importados aceptan imágenes `ic_controller_*.png`. Las opciones del catálogo son presets locales de Lobo Gélido; no incluyen material propietario de Nintendo ni paquetes de terceros.
