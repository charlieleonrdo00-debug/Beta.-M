# Lobo Gélido 55.2 — Dynamic Vulkan GPU Pipeline Variants

55.2 advances the clean-room guest GPU path from a single demonstration Vulkan pipeline to pipeline variants selected by the backend-neutral pipeline ID.

## Changes
- Multiple real Vulkan graphics-pipeline variants.
- `create_graphics_pipeline_variant(id, renderPass, descriptorLayouts)` creates a real `VkPipelineLayout` + `VkPipeline`.
- Existing `create_graphics_pipeline()` remains compatible as variant 0.
- `BindPipeline` selects the variant from `GpuState::pipeline_id`.
- `Draw` uses the selected variant.
- `BindDescriptorSet` resolves the layout for the selected variant.
- Diagnostics expose live variant count.
- Host tests remain valid; Android Vulkan remains guarded by `__ANDROID__`.

This remains a clean-room intermediate GPU backend and does not ship firmware, keys, ROMs, or copyrighted game assets.
