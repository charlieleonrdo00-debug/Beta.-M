# Lobo Gélido 11.0 — CPU ARM64 Core 100%

## Objetivo de este hito

Este hito sustituye el intérprete escalar anterior por una arquitectura de ejecución ARM64 mucho más rigurosa y separada por responsabilidades. El **100%** aquí significa cobertura completa de la lista de instrucciones y mecanismos definidos para el *Core Baseline 11.0*; no significa que ya esté implementada cada extensión de ARMv8/ARMv9, FP/ASIMD/NEON completo, SVE ni toda la arquitectura privilegiada.

## Implementado

- Estado de CPU: X0–X30, SP, PC, NZCV, FPCR/FPSR, V0–V31, TPIDR_EL0 y contador virtual.
- Decoder AArch64 con clases explícitas y campos normalizados.
- MOVZ/MOVN/MOVK.
- ADD/SUB inmediato y registro.
- ADC/ADCS/SBC/SBCS.
- AND/ORR/EOR/BIC registro e inmediatos con decodificación de bitmask AArch64.
- LSL/LSR/ASR/ROR registro e aliases de desplazamiento inmediato mediante bitfield.
- UBFM/SBFM/BFM y aliases habituales.
- CSEL/CSINC/CSINV/CSNEG.
- MADD/MSUB, UDIV/SDIV.
- CMP/condiciones y ramas B/BL/BR/BLR/CBZ/CBNZ/B.cond.
- ADR/ADRP.
- LDR/STR de 8/16/32/64 bits, cargas signadas habituales, offset por registro y literal.
- LDP/STP con offset, pre-index y post-index.
- LDXR/STXR/LDAXR/STLXR con reserva de CPU y código de estado.
- DMB/DSB/ISB mediante barrera de memoria del host.
- SVC/BRK con excepción explícita.
- TPIDR_EL0 y CNTVCT_EL0 básicos.
- FP escalar S/D: FADD/FSUB/FMUL/FDIV/FMOV.
- REV/CLZ/RBIT.
- MMU opcional integrada al fetch/load/store, permisos R/W/X y TLB con identificación correcta de página virtual y física.
- Excepciones diferenciadas: instruction abort, data abort, alignment, undefined instruction, SVC, breakpoint y exclusive failure.
- Decode cache caliente para evitar redescodificación; modo estricto disponible para código automodificable.
- Fast path de memoria host para lecturas/escrituras alineadas sin MMU.

## Arquitectura

`CPU state -> decoder -> cached instruction -> execution semantics -> memory/MMU -> exception`

El decoder no conoce la memoria, el estado de CPU no conoce Android y el backend de ejecución no depende de la interfaz gráfica. Esto permite añadir posteriormente un JIT/NCE sin reescribir el frontend ni la MMU.

## Verificación

- 9/9 pruebas CMake pasan.
- Nueva suite `cpu_arm64_advanced` cubre ADC/SBC, logical immediate, bitfield shifts, MMU virtual→physical, exclusivas y FP escalar.
- Benchmark de dispatch caliente: 1.000.000 instrucciones en ~88 ms en el entorno de compilación usado para este build (~11.3 MIPS). Este número es orientativo y no representa FPS de juegos.

## Comparación con Michel/Eden

La meta arquitectónica es evitar una implementación monolítica: CPU, MMU, excepciones, decoder y caché están desacoplados. No se ha copiado código propietario de Michel. Eden sigue siendo una referencia de código abierto válida; sus versiones actuales para Android ARM64 utilizan optimizaciones/JIT/NCE y siguen siendo un objetivo técnico de referencia.

## Pendiente para CPU de producción

Para superar realmente a un emulador maduro en compatibilidad/performance todavía hacen falta: ASIMD/NEON completo, atomics/exclusives de todas las variantes, system registers y excepciones privilegiadas completas, FP avanzada, traducción/JIT de bloques, fastmem con guard pages, scheduler de hilos de guest y validación contra suites grandes de binarios reales.
