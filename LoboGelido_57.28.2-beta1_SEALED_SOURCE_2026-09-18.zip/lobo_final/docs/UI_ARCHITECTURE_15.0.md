# Lobo Gélido 15.0 — Arquitectura UI/UX evolucionada

## Objetivo
Convertir la ficha de cada juego en el punto de decisión previo al lanzamiento: el usuario selecciona un título, observa una vista previa de gameplay del mismo título y después decide ejecutar, configurar o administrar el juego.

## Flujo visual

`Biblioteca → Ficha del juego → Vista previa / Gameplay → Ejecutar`

La ficha mantiene el lenguaje visual Lobo Gélido: negro profundo, azul hielo, cyan, magenta, tarjetas con bordes luminosos y el logotipo del lobo proporcionado por el usuario.

## Nuevo módulo: GamePreviewStore

`GamePreviewStore` es una capa pequeña y desacoplada que guarda una URI de vídeo por identidad de juego. El vídeo no se copia ni se distribuye con la aplicación: se selecciona desde el almacenamiento del usuario mediante Android Storage Access Framework.

Responsabilidades:
- `get(gameId)` devuelve la vista previa asociada.
- `set(gameId, uri)` registra una vista previa.
- `remove(gameId)` elimina la asociación.

Esto evita mezclar metadatos del emulador con la persistencia de la interfaz.

## Game Detail / Preview

La pantalla de detalle contiene ahora:
1. Cabecera y branding.
2. Tarjeta **VISTA PREVIA / GAMEPLAY**.
3. Reproductor cuando existe vídeo.
4. Estado vacío cuando todavía no existe vídeo.
5. Acciones Añadir/Cambiar/Quitar vídeo.
6. Botón Ejecutar.
7. Configuración y detalles.
8. Información del título.

El reproductor usa `VideoView` nativo, reproduce en bucle y silencia el audio para que la previsualización no interrumpa la navegación. Se ofrece `MediaController` para controles manuales.

## Evolución futura

La interfaz queda preparada para una capa `PreviewPlayer` abstracta. Esto permitirá migrar de `VideoView` a un reproductor más completo (por ejemplo, Media3) sin rediseñar `GameDetail`.

Posibles siguientes mejoras:
- miniatura automática y duración del vídeo;
- recordar posición / última vista previa;
- precarga controlada;
- reproducción solo con Wi‑Fi si en el futuro se permiten fuentes remotas;
- selección automática de preview desde una carpeta que el usuario autorice;
- integración de telemetría de reproducción sin confundirla con telemetría del emulador.

## Integridad y legalidad

Lobo Gélido no empaqueta gameplays, ROMs, firmware ni claves. La función trabaja con vídeos que el usuario seleccione y posea/pueda usar legítimamente.
