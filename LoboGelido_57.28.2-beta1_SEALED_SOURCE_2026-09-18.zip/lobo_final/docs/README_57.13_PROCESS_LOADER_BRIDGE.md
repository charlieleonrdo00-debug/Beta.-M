# Lobo Gélido 57.13 — Process ↔ Loader ↔ Runtime bridge

This release connects the executable loader's verified image metadata to a
small process-lifecycle model owned by the kernel. A content-backed prepare
creates a guest process record containing executable path, entry point, image
range and segment count. The process is started only when the runtime starts
and is stopped before kernel reset.

The process manager is deliberately not presented as a full Nintendo Switch
process manager: secure content, relocation/ASLR, full filesystem services,
process capability descriptors and broader HLE remain future work.

Verification: 38/38 CTest tests pass on the host core build.
