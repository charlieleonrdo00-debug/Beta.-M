# Lobo Gélido 57.15 — IPC Service Authorization

This revision connects per-process capabilities to the kernel service registry.

Implemented:
- each registered service may declare one required capability;
- kernel service connection checks the requesting process capability set;
- unauthorized processes receive no endpoint;
- revoking a capability immediately removes service access;
- unrelated capabilities do not grant access;
- runtime guest process receives only the capabilities required by its registered system/filesystem services;
- dedicated service-authorization regression test.

The existing UI is untouched. This is an internal kernel/HLE boundary and is not claimed to be a complete Nintendo Switch capability implementation.
