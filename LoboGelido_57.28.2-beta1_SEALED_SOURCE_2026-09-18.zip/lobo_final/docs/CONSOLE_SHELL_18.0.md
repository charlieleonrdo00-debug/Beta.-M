# Lobo Gélido 18.0 — Console Shell

18.0 closes the consumer-facing shell before deeper runtime integration.

## Consumer flow
Boot → Profile → Home → Library → Game Detail → Preview → Launch → Quick Menu → Suspend → Resume.

## Architecture
- `ConsoleShellState`: route/state machine independent of Activity rendering.
- `ConsoleUserStore`: persistent console identity and active profile.
- `GameSessionStore`: persistent game session lifecycle (`IDLE`, `PREPARING`, `RUNNING`, `SUSPENDED`).
- Existing stores remain isolated for catalog, game profiles, previews, settings and controller skins.
- `MainActivity` remains the Android composition root; runtime-facing state is now represented separately so a real core can subscribe without redesigning the consumer shell.

## Consumer principles
- Technical details are hidden from normal navigation.
- Game identity, profile, preview and session are first-class concepts.
- The shell is console-like but uses original Lobo Gélido visual language rather than copying a proprietary console UI.
- User-owned videos and controller skin packages remain user-provided.

## Honest runtime boundary
The 18.0 shell is complete as a consumer-facing architecture and flow, but the actual Switch CPU/GPU/runtime remains separate. The game screen explicitly indicates that the real runtime still needs to be connected; no fake gameplay metrics are presented as real emulation.

## 18.1 runtime bridge hardening
The consumer shell now calls the native core Session state machine for prepare/start/pause/resume/stop. The Kotlin GameSessionStore remains the durable UI/resume projection, while the native Session is the runtime authority. Diagnostics expose the native session state.
