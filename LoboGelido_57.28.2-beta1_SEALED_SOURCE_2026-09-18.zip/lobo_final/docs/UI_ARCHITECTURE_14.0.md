# Lobo Gélido 14.0 — UI / UX Architecture

## Objetivo
Implementar en código la composición visual mostrada en las referencias proporcionadas por el usuario, manteniendo el lenguaje visual ya existente: negro/navy hielo, bordes cyan, azul eléctrico, acciones magenta, tarjetas de vidrio oscuro y navegación inferior persistente.

## Recurso de identidad
`android/app/src/main/res/drawable-nodpi/lobo_logo_exact.jpg` es el logo de lobo proporcionado por el usuario. Se usa en la portada, cabecera, biblioteca, menú rápido, perfiles y Acerca de.

## Árbol de estados
- `HOME`: portada / último jugado / biblioteca.
- `LIBRARY`: buscador, filtros, tarjetas y selector de contenido.
- `GAME_DETAIL`: ficha, ejecución, configuración, detalles y metadatos.
- `QUICK_MENU`: overlay conceptual de sesión: continuar, guardar/cargar, ajustes, captura y salida.
- `PROFILES`: perfiles global/dispositivo/juego/sesión.
- `PERFORMANCE`: telemetría y escalado inteligente.
- `DIAGNOSTICS`: análisis, historial, recomendaciones y herramientas.
- `SETTINGS`: categorías globales.
- `GENERAL`, `GRAPHICS`, `AUDIO`, `CONTROLS`, `SYSTEM`, `ACCESSIBILITY`, `THEMES`, `ABOUT`.

## Componentes reutilizables
- `card()` — panel oscuro redondeado con borde de hielo.
- `button()` — acción normal o primaria.
- `logo()` — identidad Lobo Gélido.
- `topBar()` — navegación contextual.
- `rowSelect()` / `sliderRow()` / `setting()` — controles de configuración.
- `heroImage()` — fondo invernal con capa de lectura.

## Integración con runtime
La UI consume `nativeDiagnostics()` para mostrar el estado del núcleo y `nativeSelectContent()` para preparar el contenido seleccionado. La pantalla Quick Menu está separada de la lógica de runtime para permitir conectarla posteriormente a una superficie de emulación real sin rediseñar la interfaz.

## Contenido de usuario
No se empaquetan ROMs, firmware, claves ni material propietario de juegos. Las tarjetas de demostración son marcadores visuales y los contenidos reales se seleccionan mediante Storage Access Framework de Android.
