# Lobo Gélido 57.16 — IPC Channel Authorization

## Objetivo
Extender la autorización de servicios de 57.15 desde la conexión del endpoint a los canales y operaciones IPC.

## Cambios
- Los canales IPC autorizados quedan ligados a un `ProcessId` propietario.
- Cada canal conserva el nombre del servicio y la capability requerida.
- `send_authorized` y `receive_authorized` verifican propietario + capability en cada operación.
- Revocar una capability invalida inmediatamente las operaciones posteriores sobre el canal.
- Los canales autorizados rechazan el antiguo camino de `send/receive` sin identidad de proceso.
- `Kernel::connect_service_channel()` crea el canal únicamente después de validar el servicio.
- `Kernel::send_service()` y `receive_service()` aplican la autorización en cada operación.
- `Kernel::dispatch_service()` vuelve a validar canal, proceso, servicio y capability antes de ejecutar el endpoint.
- Un proceso distinto no puede reutilizar el canal de otro proceso.
- La UI no fue modificada.

## Validación
CTest: **41/41 PASS (100%)**.

Prueba nueva: `ipc_service_channel` cubre conexión denegada, conexión autorizada, aislamiento entre procesos, revocación y rechazo de reutilización por otro proceso.

## Alcance
Esto fortalece el aislamiento IPC del runtime de Lobo Gélido; no implica que la implementación sea todavía equivalente a todo el sistema IPC/HLE de una Nintendo Switch real.
