# Lobo Gélido 17.0 — Pieles Nintendo Switch

## Objetivo
Recrear el patrón de UX mostrado por el usuario para máscaras de controlador, adaptándolo a Nintendo Switch.

## Pantalla Pieles
- Título: Pieles.
- Descripción: máscaras de controlador personalizadas para Nintendo Switch.
- Importar carpeta de máscaras.
- Importar skin `.zip`.
- Ocultar máscaras descargables.
- Catálogo con miniatura, nombre, autor, cantidad de controles, descripción y acción Obtener.
- Piel activa persistente.

## Importación
Se aceptan imágenes PNG cuyo nombre empiece por `ic_controller_`. El ZIP se procesa dentro del almacenamiento privado de la aplicación. La carpeta se recorre mediante Storage Access Framework.

## Aplicación
La piel seleccionada queda guardada como estado activo y se muestra también en la pantalla Controles. El preview es nativo y no depende de assets de PlayStation.

## Legal
No se incluyen firmware, juegos, claves ni assets propietarios. Los presets visuales son diseños originales de Lobo Gélido.
