# Cómo se demostrará que Lobo Gélido es superior

No se usará una lista de funciones como prueba. La comparación será experimental.

## Ejes
1. Compatibilidad: títulos y casos de prueba que arrancan, renderizan y juegan.
2. Rendimiento: frametime P50/P95/P99 y FPS sostenido.
3. Stutter: pausas de presentación y compilación de shaders.
4. Latencia: input-to-frame cuando sea medible.
5. Eficiencia: CPU/GPU/RAM por carga equivalente.
6. Estabilidad: duración de sesiones y tasa de crashes.
7. Recuperación: comportamiento después de errores de driver/compilación.
8. Mantenibilidad: tests, modularidad y facilidad de diagnóstico.

## Regla
Misma máquina + mismo contenido legal + misma resolución + mismo backend + misma
configuración. Se guardan resultados en JSON para repetirlos.

## Meta
Superar a Michel en las métricas donde realmente sea posible, no mediante
marketing ni números inventados.


## 19.0 Beyond 100 Runtime Architecture
The 19.0 architecture treats 100% as feature completeness and >100% as engineering maturity: modular boundaries, observable lifecycle, recoverability, deterministic tests, replaceable CPU backends and explicit runtime telemetry. The RuntimeCoordinator is the composition root. A subsystem is not marked complete merely because its UI exists.

## 21.0 — Kernel Scheduling

El Scheduler deja de ser una pieza aislada y pasa a estar encapsulado en `system::Kernel`, junto con `ThreadManager`, `SyncManager` y `ServiceRegistry`. `ThreadManager` proporciona estados de hilo, prioridades, round-robin determinista, sleep/wake y cambios de contexto modelados; `SyncManager` proporciona eventos y semáforos con bloqueo/desbloqueo. Esto prepara la arquitectura para conectar posteriormente contexto CPU, timers, IPC y servicios HLE sin acoplarlos directamente a la UI.

## 24.0 — Tier-1 CPU execution

Lobo Gélido now has a bounded block execution backend above the interpreter. This is intentionally counted as Tier-1 acceleration, not as a native JIT. The next CPU milestone is a real Dynarmic-backed Tier-2 JIT with explicit memory callbacks and code invalidation.
