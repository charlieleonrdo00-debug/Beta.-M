# Lobo Gélido 57.23 — Global Domain Contracts

This increment establishes the architecture contracts before implementation details.

## Modules

- `domain/firmware`: Pulsar Firmware contracts and value models.
- `domain/keys`: Pulsar Claves contracts and value models.
- `domain/games`: discovery, format detection, metadata, artwork, folders and file-access contracts.
- `application`: use-case boundaries and the read-only system configuration contract.

## Dependency rule

UI -> Application -> Domain contracts <- Infrastructure

Domain contracts do not depend on Android, SAF, HTTP, Vulkan, CPU, MMU, RAM or Runtime implementation details.

## Runtime preservation

This architectural increment does not modify the existing CPU/MMU/RAM/Dynarmic, Runtime, Vulkan, filesystem, IPC/HLE or loader implementations.

## Next implementation order

1. Infrastructure adapters for file/SAF access.
2. Real firmware inspection, integrity verification and atomic installation.
3. Real key parsing/validation and secure storage.
4. Game format detection and real metadata extraction.
5. Artwork resolution with embedded/local/remote provider chain.
6. Application use cases.
7. UI wiring.

No firmware, keys or proprietary games are included.
