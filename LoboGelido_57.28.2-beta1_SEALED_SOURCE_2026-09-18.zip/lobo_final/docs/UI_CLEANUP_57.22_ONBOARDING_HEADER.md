# Lobo Gélido 57.22 — limpieza de onboarding y cabecera

- La pantalla de configuración inicial se muestra automáticamente únicamente mientras `firstRunCompleted` sea `false`.
- Al salir por **Atrás** o **Siguiente**, `firstRunCompleted` queda persistido para que el asistente no vuelva a aparecer en arranques posteriores.
- Las acciones de claves, firmware y carpeta de juegos regresan a **Sistema y almacenamiento** cuando la configuración inicial ya fue completada; no reabren el asistente.
- Se eliminó la barra superior global duplicada. La navegación lateral conserva el único acceso a **Ajustes** mediante su engranaje.
- No se modifican CPU, RAM, MMU, loader, Vulkan, firmware, claves, SAF ni las funciones de configuración existentes.
