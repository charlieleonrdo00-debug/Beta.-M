# Lobo Gélido — Adaptive Rendering 12.1

This release adds a single-user-facing **Escalado inteligente** control and a renderer-independent adaptive scaling policy.

## Goal

Protect frame pacing by changing the **internal render scale**, while keeping the final presentation resolution separate. This is the architecture required for a future FSR-like/upscaling stage.

## Policy

- Target: 60 FPS by default.
- Range: 60–100% internal scale.
- Downscale in 5-point steps when frame time is sustained above budget, GPU time is high, or thermal pressure is elevated.
- Recover in 2-point steps only after a sustained healthy window, reducing visible resolution pumping.
- Reset to 100% when disabled.

## Important

This is an adaptive policy and UI control; it does **not** claim that a complete FSR implementation or Vulkan game renderer is already present. The actual image reconstruction/upscaling pass will be attached when the Vulkan renderer is implemented.
