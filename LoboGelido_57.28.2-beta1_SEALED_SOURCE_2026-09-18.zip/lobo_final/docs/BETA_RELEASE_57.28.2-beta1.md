# Lobo Gélido — Cierre de hito Beta (57.28.2-beta1)

**Fecha:** 2026-09-18
**Rol:** Principal Android & Native Systems Architect
**Objetivo:** dejar el código sellado, limpio y listo para compilar el APK Beta en tu
Codespaces (con SDK/NDK) y llevarlo a pruebas de campo.

---

## 0. Nota de entorno (importante)

El APK **no se compila en este entorno**: aquí solo hay toolchain de host
(cmake/g++/ninja x86_64), **sin Android SDK/NDK ni Gradle/AGP**, y la red no permite
la descarga del SDK ni el `FetchContent` de Dynarmic que exige un build NDK. Todos tus
APK previos salieron de tu **Codespaces**; este también. La §4 trae la receta exacta.
No se entrega ningún `.apk` desde aquí para no darte un binario no verificable.

---

## 1. Cero stubs / implementación (auditado)

Escaneo del árbol nativo (`core/ cpu/ gpu/ memory/ runtime/ system/ loader/ performance/
graphics/`) y de la capa Kotlin:

| Comprobación | Resultado |
|---|---|
| `TODO`/`FIXME`/`placeholder`/`stub` (nativo) | **0** |
| `TODO`/`FIXME`/`NotImplementedError` (Kotlin) | **0** |
| Cuerpos vacíos `{}` que sean cascarones | **0** (los `{}` detectados son constructores con lista de inicialización, código real) |
| Notas "not implemented" | **1** — `runtime_coordinator.cpp:158`, límite de alcance de producto (ver §5), no código faltante |

**No hay lógica faltante que provoque caídas por "código ausente".** Los flujos
implementados corren de extremo a extremo (arranque → UI → Vulkan clear/submit/present →
telemetría; carga de homebrew NRO/NSO en texto plano). Rellenar la única frontera abierta
(pipeline de contenido cifrado) es alcance mayor de producto, no un stub — no se fabricó.

## 2. Integridad estructural (verificada, ejecutada)

| Comprobación | Resultado |
|---|---|
| Build host `lobogelido_core` (`-Wall -Wextra -Wpedantic`) | **0 warnings, 0 errores** |
| Suite CTest | **43/43 PASA** |
| Paridad JNI (Kotlin `external fun` ↔ `JNIEXPORT`) | **21/21** exacto, 0 huérfanos |
| Capas Kotlin (domain/data/application) | sin dependencias hacia arriba |
| Capas C++ (core→memory→cpu/gpu/system→runtime) | sin includes hacia arriba, sin ciclos |
| Presenter Vulkan (Frente 1) | frames-in-flight + fix `vkResetFences`; `-fsyntax-only` vs Khronos = **0 errores** |

Regla de Oro respetada: no se eliminó ninguna clase, función ni binding; todos los
cambios recientes fueron aditivos/correctivos.

## 3. Configuración Beta (test-ready)

`android/app/build.gradle.kts`:

| Parámetro | Valor |
|---|---|
| `versionName` / `versionCode` | `57.28.2-beta1` / `5729` |
| `applicationId` | `com.lobogelido` |
| `minSdk` / `targetSdk` / `compileSdk` | 29 / 36 / 36 |
| `ndkVersion` | 27.3.13750724 |
| ABI | `arm64-v8a` |
| C++ | C++20, `-fexceptions -frtti`, `ANDROID_STL=c++_shared` |
| 16 KB | `-Wl,-z,max-page-size=16384` + `common-page-size=16384`, `FLEXIBLE_PAGE_SIZES=ON`, `useLegacyPackaging=false` |
| Dynarmic | FetchContent con tag pinnable (`LOBOGELIDO_DYNARMIC_TAG`) |
| **Firma** | `release` firma con tu keystore si pasas `-PLOBO_KEYSTORE=…`, si no cae a la clave **debug** para que el APK sea instalable en pruebas sin configurar nada |

## 4. Receta de build del APK Beta (en tu Codespaces)

```bash
# 1) (primera vez) fija el commit de Dynarmic para builds reproducibles:
./gradlew :app:assembleRelease            # trae Dynarmic desde master la 1ª vez
SHA=$(git -C app/.cxx/**/dynarmic-src rev-parse HEAD 2>/dev/null || echo master)

# 2) build Beta instalable (firmado con debug si no pasas keystore):
./gradlew clean :app:assembleRelease -PLOBOGELIDO_DYNARMIC_TAG=$SHA

# 2-bis) build Beta firmado con TU keystore (recomendado para distribuir):
./gradlew clean :app:assembleRelease \
  -PLOBO_KEYSTORE=$HOME/keys/lobo.jks -PLOBO_KEYSTORE_PASSWORD=*** \
  -PLOBO_KEY_ALIAS=lobo -PLOBO_KEY_PASSWORD=***

# APK resultante:
#   app/build/outputs/apk/release/app-release.apk

# 3) verificaciones antes de instalar:
unzip -l app/build/outputs/apk/release/app-release.apk | grep lib/arm64-v8a
$ANDROID_HOME/build-tools/*/zipalign -c -P 16 -v 4 app-release.apk   # alineación 16 KB
llvm-readelf -l .../lib/arm64-v8a/liblobogelido_android.so | grep LOAD  # Align 0x4000
apksigner verify --print-certs app-release.apk                         # firma v2/v3

# 4) instalar en dispositivo:
adb install -r app-release.apk
```

## 5. Qué esperar en el dispositivo (alcance honesto de esta Beta)

- **Arranca** sin el cierre de tema (fix AppCompat aplicado) y sin caídas por interacción
  (puente JNI blindado).
- **Render:** frame de *clear* azul marino vía Vulkan (pipeline de presentación real,
  ahora con frames-in-flight). **Aún no** hay gráficos de juego reales.
- **Contenido:** carga homebrew NRO/NSO en texto plano; **no** ejecuta juegos comerciales
  cifrados (NSP/XCI/NCA) — es el límite documentado, para iteraciones futuras.
- **Diagnóstico:** `Ajustes → Diagnóstico → Guardar diagnóstico en Descargas` genera el ZIP
  (runtime/Vulkan/dispositivo/logcat/último crash, sin llaves ni ROMs) para depurar hallazgos.

## 6. Para la siguiente iteración
1. Instala y prueba en caliente; ante cualquier fallo, exporta el ZIP de diagnóstico y
   compártelo (o `adb logcat` durante el arranque).
2. Fija el SHA de Dynarmic tras el primer build exitoso.
3. Valida 16 KB en el `.so` con `llvm-readelf` (Align `0x4000`).

**Estado:** código sellado, limpio (0 warnings host, 43/43), estructuralmente íntegro y
configurado para Beta. Falta solo el paso que este entorno no puede ejecutar: compilar y
firmar el APK en tu Codespaces con la receta de §4.
