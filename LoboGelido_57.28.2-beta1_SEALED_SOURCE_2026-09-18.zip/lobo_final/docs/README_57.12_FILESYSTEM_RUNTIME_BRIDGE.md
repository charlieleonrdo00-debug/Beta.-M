# Lobo Gélido 57.12 — Filesystem HLE ↔ Runtime bridge

## Cambios

- `RuntimeCoordinator::prepare()` registra `fsp-srv:` en el mismo `ServiceRegistry` del kernel.
- El filesystem HLE queda disponible durante el ciclo de vida del runtime.
- El loader de NRO/NSO continúa siendo la fuente de verdad para cargar código ejecutable; el bridge no finge implementar el protocolo completo de FS de Switch.
- El servicio conserva límites de payload, handles y rutas establecidos en 57.11.
- No se modifica la UI ni la ruta Vulkan.

## Verificación

- 37/37 pruebas CTest pasan en build Release.
- Esta capa es una integración interna; no implica compatibilidad comercial completa.
