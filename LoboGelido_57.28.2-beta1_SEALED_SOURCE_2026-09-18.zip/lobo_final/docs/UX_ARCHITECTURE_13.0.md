# Lobo Gélido 13.0 — UX & Diagnostics Architecture

## Objetivo
Evolucionar la interfaz desde un conjunto de pantallas hacia un sistema de diseño y estado coherente, manteniendo el núcleo de emulación independiente de Android.

## Capas
- **UI State:** presentación y estado observable.
- **Runtime interfaces:** contratos entre UI y núcleo.
- **Telemetry Bus:** métricas de frame y eventos.
- **Diagnostics Core:** ventana móvil de muestras, utilización, jitter y clasificación de cuellos de botella.
- **Advisor:** explicación accionable del estado.
- **Performance Manager:** políticas como adaptive scaling.
- **Backends:** CPU, MMU, GPU, audio, input y loader intercambiables.

## Diagnóstico
DiagnosticsCore conserva hasta 120 muestras y calcula FPS medio, frame time, jitter, utilización estimada, nivel térmico y estado de shaders. El clasificador distingue CPU, GPU, térmica, shaders, memoria y presentación.

La telemetría actual del JNI usa una muestra sintética determinista hasta que se conecten los hooks reales del renderer/scheduler. No debe interpretarse como medición de un juego.

## UX
La interfaz 13.0 usa una identidad oscura hielo/cyan/magenta y comunica estados mediante jerarquía visual. Ajustes se presentan conceptualmente por capas: global → dispositivo → juego → sesión.

## Honestidad de estado
No se anuncian JIT, FSR, Vulkan renderer real ni compatibilidad de juegos como implementados cuando todavía son infraestructura/preparación. Esto es deliberado para evitar falsos indicadores de capacidad.
