# Lobo Gélido 57.18 — Runtime Synthetic E2E

This revision adds a deterministic end-to-end synthetic runtime test without changing the Android UI.

## Covered path

1. Creates a minimal plaintext NRO containing ARM64 NOP instructions.
2. Opens/inspects the executable through `ContentLoader`.
3. Loads its executable segment into guest memory.
4. Rebuilds the MMU mapping from the loader segment metadata.
5. Creates and initializes the guest process and its service capabilities.
6. Starts the process/session.
7. Dispatches real guest instructions through the CPU Block backend.
8. Exercises persistent guest CPU context, MMU translation and scheduler accounting.
9. Produces runtime diagnostics and frame metrics.
10. Exercises pause/resume and clean stop/reset.

## Fixes found by the E2E test

- `RuntimeCoordinator` now retains the created main process ID and actually starts that process instead of looking for a current process before one exists.
- The created guest process is explicitly marked initialized after its capabilities are installed.
- The content-backed MMU mapping now passes `(virtual_base, physical_base, size, permissions)` in the correct order.

## Verification

- 43/43 CTest tests passed.
- 0 failed.
- UI untouched.
- Android APK build/device Vulkan execution is not claimed by this host test.
