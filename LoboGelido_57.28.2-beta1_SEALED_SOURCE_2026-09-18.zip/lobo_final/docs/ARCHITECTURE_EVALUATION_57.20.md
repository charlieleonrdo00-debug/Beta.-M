# Lobo Gélido 57.20 — Evaluación y organización de arquitectura

## Alcance
Esta versión se construye tomando como base funcional la rama 57.20 CPU/RAM Bridge
y recuperando de 57.18 AndroidBuildRepaired v3 únicamente implementaciones que eran
internamente coherentes y que habían sido degradadas en 57.20. La UI/estética no se rediseña.

## Correcciones integradas
- Android Kotlin: se recuperan las implementaciones coherentes de `AppSettingsStore`,
  `ContentRecognition`, `GameSurfaceView`, `LoboChrome`, `LoboConsoleHomeRenderer` y
  `MainActivity`.
- C++ Vulkan Android: se recupera la conversión segura de handles Vulkan usada por 57.18.
- CMake Android: se vuelve a incluir `system/capability_manager.cpp`, requerido por la
  arquitectura de capacidades/IPC.
- Se conservan las optimizaciones 57.19/57.20 de RAM/MMU y el microcache CPU→MMU→RAM.
- Se conserva el logo centrado de la versión entregada para esta reparación.
- Metadatos de Android/native alineados a 57.20.

## Evaluación de arquitectura
La separación actual es razonable para continuar: Android/UI -> JNI/runtime ->
process/thread/scheduler -> CPU -> MMU -> AddressSpace/RAM; los servicios HLE/IPC y
la capa GPU quedan desacoplados del shell Android.

### Hallazgos técnicos
1. `cpu/dynarmic_provider.cpp`: el microcache de 32 entradas evita traducciones MMU
   repetidas para accesos de página caliente. La invalidación lógica depende de
   `Mmu::generation()`, y los permisos se vuelven a comprobar en el hit.
2. `memory/address_space.cpp`: el arena fastmem conserva una marca compacta por página
   en lugar de consultar un `unordered_set` en cada acceso.
3. `memory/mmu.h`: el TLB se amplía a 1024 entradas.
4. `android/app/src/main/cpp/CMakeLists.txt`: la composición del binario Android vuelve
   a incluir CapabilityManager además de IPC/servicios/proceso.
5. `gpu/android_vulkan_context.cpp`: la conversión de `void*` a handles Vulkan se
   mantiene explícita y consistente en `shutdown()`.

## Límites que no se deben ocultar
- Dynarmic real requiere que el entorno de compilación pueda obtener su fuente y que
  la API utilizada sea compatible con la versión obtenida.
- El fastmem nativo de Dynarmic NO se habilita automáticamente por este microcache.
- La compatibilidad completa de NCA/NSP/XCI, NSO comprimido, servicios Switch reales,
  GPU NVN completa, audio/HID y otras capas todavía requieren trabajo adicional.
- Las pruebas sintéticas del core no equivalen a un porcentaje de compatibilidad con
  juegos reales.

## Regla de mantenimiento
No mezclar cambios de UI con cambios del runtime. Las futuras optimizaciones deben
preservar el contrato CPU -> MMU -> AddressSpace y la invalidación por generación/epoch.
