# Engine status — 4.0

| Subsistema | Estado |
|---|---|
| Session/state | Implementado |
| AArch64 decoder | Base ejecutable |
| AArch64 interpreter | Base ejecutable + tests |
| Guest memory | Implementado para páginas host-backed |
| MMU/TLB | API/arquitectura, falta integración completa |
| JIT/NCE | Selector/contrato; implementación real pendiente |
| Scheduler | Base |
| HLE/IPC | Framework |
| NRO/NSO inspection | Implementado |
| Vulkan/NVN | Abstracción; backend completo pendiente |
| Shader cache | Implementado |
| Audio | Interfaz |
| Input | Interfaz |
| Android frontend | Pendiente de integración final |
| Compatibilidad comercial | No declarada |

La métrica de éxito será un conjunto de juegos/escenas reproducibles, frame-time p95/p99, latencia, crashes/hora y consumo térmico; no una afirmación subjetiva de “mejor”.

## Scheduler 20.0

Scheduler virtual determinista con prioridades, cancelación, eventos periódicos, presupuesto anti-storm, estadísticas y APIs relativas. El scheduler está listo como infraestructura de runtime; la compatibilidad Switch de alto nivel todavía requiere HLE de kernel/hilos/timers/IPC.
