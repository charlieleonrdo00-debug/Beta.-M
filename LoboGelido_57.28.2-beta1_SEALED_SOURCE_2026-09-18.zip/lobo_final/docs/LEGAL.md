# Límites de distribución

Lobo Gélido no distribuye firmware, claves criptográficas, ROMs, contenido de juegos ni
material propietario de Nintendo.

Si se integra código de terceros, debe conservarse su licencia, avisos y obligaciones de
distribución. No se copia ni redistribuye código propietario extraído de APKs de terceros.

El usuario debe aportar únicamente contenido que tenga derecho a usar.
