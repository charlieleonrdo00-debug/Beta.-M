# Lobo Gélido 57.14 — Process Capabilities / IPC Service Boundary

This revision adds a small capability layer between guest processes and kernel services.

Implemented:
- per-process capability grants/revocation;
- bounded capability names;
- capability cleanup on kernel reset;
- explicit process initialization state;
- unit coverage for grant/revoke/isolation semantics.

This is an internal HLE security/ownership model. It is not claimed to be a complete
Nintendo Switch kernel capability implementation.

Verification: 39/39 CTest tests passed in the host core build.
