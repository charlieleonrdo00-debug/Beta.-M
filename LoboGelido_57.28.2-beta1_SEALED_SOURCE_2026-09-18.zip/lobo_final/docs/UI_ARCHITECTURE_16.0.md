# Lobo Gélido 16.0 — Frontend 100% y arquitectura modular

Esta versión lleva a una implementación funcional de frontend los once objetivos solicitados:

1. Biblioteca y organización — catálogo centralizado, búsqueda, filtros Todos/Instalados/Favoritos, orden por nombre/recientes/tamaño, favoritos persistentes y recencia.
2. Vista previa de gameplay — URI de vídeo por juego mediante Android Storage Access Framework, reproducción en bucle/silencio, cambiar/quitar y abstracción `PreviewPlayer`.
3. Detalle del juego — ficha previa al lanzamiento con preview, metadatos, favorito, ejecución y acceso a perfil/configuración.
4. Diagnóstico/telemetría — parser de estado nativo, métricas, recomendaciones, actualización, copiar y compartir.
5. Perfiles por juego — persistencia independiente por título para gráficos, resolución, FPS, VSync, escalado, audio, controles, shaders y JIT.
6. Configuración gráfica UI — presets, resolución, escalado, FPS, filtro, AA, VSync y brillo interactivos.
7. Configuración de controles UI — perfil, remapeo A/B/X/Y/L/R/ZL/ZR/START/SELECT, sensibilidad y zona muerta persistentes.
8. Personalización de temas — Hielo, Nébula y Aurora, persistentes y aplicados al shell.
9. Accesibilidad UI — escala de texto, alto contraste, asistencia de color, gestos, vibración, sonidos de interfaz y reducción de movimiento.
10. Menú rápido en juego — continuar, guardar/cargar, ajustes, gráficos, controles, captura y salida, junto a panel de rendimiento.
11. Arquitectura modular — `GameCatalogStore`, `GameProfileStore`, `AppSettingsStore`, `GamePreviewStore`, `PreviewPlayer`, `DiagnosticsPresenter` y modelos compartidos, reduciendo el acoplamiento de la Activity.

## Límites técnicos

El 100% de este hito significa cobertura funcional del frontend solicitado, no compatibilidad 100% con juegos ni una implementación completa del backend de emulación. Las métricas nativas de Android siguen siendo un puente local/sintético hasta conectar hooks reales del renderer/scheduler.

No se empaquetan juegos, firmware, claves ni gameplays de terceros.
