#include <cassert>
#include "../core/session.h"

int main() {
    lg::core::Session s;
    assert(s.prepare().ok());
    assert(s.start().ok());
    assert(s.pause().ok());
    assert(s.resume().ok());
    assert(s.stop().ok());
    assert(s.prepare().ok());
    return 0;
}
