#include <cassert>
#include <cstring>
#include "../cpu/interpreter.h"
#include "../memory/mmu.h"
static uint64_t bits(double v){uint64_t x;std::memcpy(&x,&v,8);return x;}
static double dbl(uint64_t x){double v;std::memcpy(&v,&x,8);return v;}
int main(){using namespace lg;
    memory::AddressSpace mem; assert(mem.map(0x1000,0x9000));
    cpu::CpuState s{}; s.pc=0x1000; cpu::Interpreter c(mem);
    const uint32_t p[]={
        0xD2800020u,0xD2800041u,0xAB010002u,0x9A010003u,0xDA000024u,
        0x92401C65u,0xD37DF0A6u,0xD503201Fu};
    for(unsigned i=0;i<sizeof(p)/sizeof(p[0]);++i) mem.write32(0x1000+4*i,p[i]);
    assert(c.run(s,8)==8); assert(s.x[2]==3); assert(s.x[3]==3); assert(s.x[4]==0); assert(s.x[5]==3); assert(s.x[6]==24);
    // MMU virtual->physical execution and data permissions.
    memory::AddressSpace phys; assert(phys.map(0x8000,0x3000));
    memory::Mmu mmu; assert(mmu.map(0x4000,0x8000,0x3000,memory::Read|memory::Write|memory::Execute));
    phys.write32(0x8000,0xD28000A0u); // mov x0,#5
    phys.write32(0x8004,0xD503201Fu);
    cpu::CpuState v{}; v.pc=0x4000; cpu::Interpreter vm(phys,mmu); assert(vm.run(v,2)==2); assert(v.x[0]==5);
    // Exclusive pair: LDXR/STXR must round-trip and report success in Wstatus.
    phys.write64(0x8100,0x1234); v={}; v.pc=0x4008; v.x[1]=0x4100;
    phys.write32(0x8008,0xC85F7C20u); // ldxr x0,[x1]
    phys.write32(0x800c,0xC8027C20u); // stxr w2,x0,[x1]
    assert(vm.run(v,2)==2); assert(v.x[0]==0x1234 && v.x[2]==0 && *phys.read64(0x8100)==0x1234);
    // A write by another agent invalidates the reservation epoch.
    cpu::CpuState inv{}; inv.pc=0x4020; inv.x[1]=0x4100;
    phys.write32(0x8020,0xC85F7C20u); // ldxr x0,[x1]
    phys.write32(0x8024,0xC8027C20u); // stxr w2,x0,[x1]
    assert(vm.step(inv)); assert(inv.reservation_valid);
    phys.write64(0x8100,0x5678);
    assert(vm.step(inv)); assert(inv.x[2]==1 && *phys.read64(0x8100)==0x5678);
    // FP scalar.
    cpu::CpuState f{}; f.v[1][0]=bits(1.5); f.v[2][0]=bits(2.25); f.pc=0x4010; phys.write32(0x8010,0x1E622820u); assert(vm.step(f)); assert(dbl(f.v[0][0])==3.75);

    // Advanced SIMD / NEON golden encodings from clang's AArch64 assembler.
    cpu::CpuState n{}; n.pc=0x4020; n.x[1]=0x8200;
    for(unsigned k=0;k<8;k++){ n.v[1][0]=(n.v[1][0]<<8)|0x01; n.v[2][0]=(n.v[2][0]<<8)|0x02; }
    const uint32_t neon[]={
        0x4E228420u, // add v0.16b, v1.16b, v2.16b
        0x4E281CE6u, // and v6.16b, v7.16b, v8.16b
        0x4EAB1D49u, // orr v9.16b, v10.16b, v11.16b
        0x6E2E1DACu, // eor v12.16b, v13.16b, v14.16b
        0x4E040C62u, // dup v2.4s, w3
        0x4E26D4A4u, // fadd v4.4s, v5.4s, v6.4s
        0x4EE9D507u, // fsub v7.2d, v8.2d, v9.2d
        0x6E2CDD6Au  // fmul v10.4s, v11.4s, v12.4s
    };
    for(unsigned i=0;i<8;i++) phys.write32(0x8020+4*i,neon[i]);
    n.x[3]=0xA5A5A5A5u;
    assert(vm.run(n,8)==8);
    assert(n.v[0][0]==0x0303030303030303ull);
    assert(n.v[2][0]==0xA5A5A5A5A5A5A5A5ull);

    // Single-register LD1/ST1 with post-index keeps guest pointer semantics.
    cpu::CpuState ls{}; ls.pc=0x4040; ls.x[1]=0x4300;
    ls.v[0][0]=0x1122334455667788ull; ls.v[0][1]=0x99AABBCCDDEEFF00ull;
    phys.write32(0x8040,0x4C007020u); // st1 {v0.16b}, [x1]
    phys.write32(0x8044,0x4CDF7441u); // ld1 {v1.8h}, [x2], #16
    ls.x[2]=0x4300; assert(vm.run(ls,2)==2);
    assert(*phys.read64(0x8300)==0x1122334455667788ull);
    assert(*phys.read64(0x8308)==0x99AABBCCDDEEFF00ull);
    assert(ls.x[2]==0x4310);
    assert(ls.v[1][0]==0x1122334455667788ull && ls.v[1][1]==0x99AABBCCDDEEFF00ull);
    return 0;
}
