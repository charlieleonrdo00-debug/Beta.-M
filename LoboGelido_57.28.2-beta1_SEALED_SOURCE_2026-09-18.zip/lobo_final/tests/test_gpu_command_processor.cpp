#include <cassert>
#include "../gpu/gpu_command_processor.h"
int main(){
 lg::gpu::GpuCommandProcessor p;
 assert(p.submit({lg::gpu::GpuOp::BindPipeline,7,12}).ok());
 assert(p.state().pipeline_id==7 && p.state().shader_program_id==12);
 assert(p.submit({lg::gpu::GpuOp::BindVertexBuffer,9}).ok());
 assert(p.submit({lg::gpu::GpuOp::SetViewport,0,0,0,0,0,0,640,480}).ok());
 assert(p.submit({lg::gpu::GpuOp::Draw,3}).ok());
 assert(p.stats().draws==1 && p.state().pipeline_id==7 && p.state().shader_program_id==12);
 lg::gpu::RenderGraph g; auto r=p.compile_graph(g); assert(r.ok()); assert(r.value().size()==4);
 p.reset(); assert(p.commands().empty()); assert(!p.has_draw_work());
 return 0;
}
