#include "../loader/content_loader.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"
#include <cassert>
#include <fstream>
#include <cstdint>
int main(){
    std::ofstream f("loader_test.nro",std::ios::binary);
    std::vector<uint8_t> h(0x100,0); h[0]='N';h[1]='R';h[2]='O';h[3]='0';
    auto put64=[&](size_t o,uint64_t v){for(int i=0;i<8;i++)h[o+i]=uint8_t(v>>(8*i));};
    put64(0x10,0x100); put64(0x18,4); put64(0x20,0); put64(0x28,0); put64(0x30,0); put64(0x38,0);
    f.write(reinterpret_cast<char*>(h.data()),h.size()); uint8_t code[]={0xAA,0xBB,0xCC,0xDD}; f.write(reinterpret_cast<char*>(code),4); f.close();
    auto x=lg::loader::ContentLoader::inspect("loader_test.nro"); assert(x.valid&&x.format==lg::loader::Format::Nro&&x.size==0x104&&x.segments.size()==1); assert((x.segments.front().permissions & lg::memory::Execute) != 0);
    lg::memory::AddressSpace mem; lg::loader::LoadResult r; assert(lg::loader::ContentLoader::load_plaintext(x,mem,r)); assert(r.entry_point==0x100000ull); assert(mem.read32(r.entry_point).value()==0xDDCCBBAA); return 0;
}