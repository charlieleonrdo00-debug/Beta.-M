#include "runtime/multicore_manager.h"
#include <cassert>
int main() {
    lg::runtime::MultiCoreManager m;
    auto a = m.resolve("Pokemon.gba");
    assert(a.detection.platform == lg::platform::Platform::GameBoyAdvance);
    assert(a.core_id == "gba");
    assert(!a.launchable);
    auto b = m.resolve("Mario.z64");
    assert(b.detection.platform == lg::platform::Platform::Nintendo64);
    auto c = m.resolve("unknown.bin");
    assert(!c.launchable);
    return 0;
}
