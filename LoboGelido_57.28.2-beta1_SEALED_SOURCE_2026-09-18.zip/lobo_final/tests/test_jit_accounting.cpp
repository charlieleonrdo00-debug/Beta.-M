#include <cassert>
#include "../cpu/dynarmic_provider.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"
#include "../cpu/interpreter.h"

int main() {
    lg::memory::AddressSpace memory;
    lg::memory::Mmu mmu;
    lg::cpu::Interpreter interpreter(memory, mmu);
    auto provider = lg::cpu::make_dynarmic_provider(memory, mmu, interpreter);
#if defined(LOBOGELIDO_HAS_DYNARMIC)
    assert(provider != nullptr);
#else
    assert(provider == nullptr);
#endif
    return 0;
}
