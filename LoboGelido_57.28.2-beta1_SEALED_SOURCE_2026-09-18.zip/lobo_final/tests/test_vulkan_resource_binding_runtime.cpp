#include <cassert>
#include <iostream>
#include "../gpu/vulkan_resource_binding_runtime.h"

using namespace lg::gpu;

int main() {
    ShaderProgramManager programs;
    VulkanDescriptorBackend descriptors;
    VulkanResourceBackend resources;
    VulkanPipeline pipelines;
    VulkanResourceBindingRuntime runtime;

    auto init = runtime.initialize(&programs, &descriptors, &resources, &pipelines);
    assert(!init.ok());
    assert(runtime.prepared_program_count() == 0);
    assert(runtime.prepared_set_count() == 0);
    assert(runtime.descriptor_set_id(1, 0) == 0);
    assert(runtime.descriptor_layout_id(1, 0) == 0);
    assert(runtime.diagnostics() == "vkBindingRuntime=OFF;programs=0;sets=0");

    auto r = runtime.prepare_program(1);
    assert(!r.ok());
    runtime.reset();
    assert(runtime.diagnostics() == "vkBindingRuntime=OFF;programs=0;sets=0");

    std::cout << "vulkan resource binding runtime host safety OK\n";
    return 0;
}
