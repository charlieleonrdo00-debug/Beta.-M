#include <cassert>
#include <iostream>
#include "../runtime/runtime_coordinator.h"

int main() {
    lg::runtime::RuntimeCoordinator rt;
    assert(rt.state() == lg::runtime::State::Cold);
    assert(rt.prepare().ok());
    assert(rt.state() == lg::runtime::State::Ready);
    assert(rt.cpu_backend_name() == std::string("Block"));
    assert(rt.start().ok());
    // NOP at the mapped guest PC.
    const uint64_t pc = 0x10000000ull;
    // AddressSpace is intentionally private; the coordinator must remain a black-box lifecycle API.
    // Running an unmapped instruction should trigger recovery rather than crash the process.
    auto result = rt.run_frame(pc);
    assert(result.ok());
    assert(rt.metrics().frames == 1 || rt.metrics().recoveries == 1);
    assert(rt.pause().ok());
    assert(rt.resume().ok());
    assert(rt.stop().ok());
    assert(rt.state() == lg::runtime::State::Stopped);
    assert(rt.prepare().ok());
    assert(rt.cpu_backend_name() == std::string("Block"));
    std::cout << "runtime coordinator ok\n";
}
