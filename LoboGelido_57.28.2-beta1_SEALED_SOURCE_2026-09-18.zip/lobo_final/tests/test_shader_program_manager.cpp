#include <cassert>
#include <vector>
#include "../gpu/shader_program_manager.h"
int main() {
    // Minimal structurally valid SPIR-V module (header only is rejected? validate permits 5 words).
    const std::vector<uint32_t> v{0x07230203u, 0x00010000u, 0u, 8u, 1u};
    const std::vector<uint32_t> f{0x07230203u, 0x00010000u, 0u, 9u, 1u};
    lg::gpu::ShaderProgramManager m;
    auto vs=m.add_shader(v, lg::gpu::ShaderStage::Vertex, "vs");
    auto vs2=m.add_shader(v, lg::gpu::ShaderStage::Vertex, "duplicate");
    auto fs=m.add_shader(f, lg::gpu::ShaderStage::Fragment, "fs");
    assert(vs.ok() && vs2.ok() && fs.ok() && vs.value()==vs2.value());
    auto p=m.create_program(vs.value(), fs.value());
    auto p2=m.create_program(vs.value(), fs.value());
    assert(p.ok() && p2.ok() && p.value()==p2.value());
    assert(m.shader_count()==2 && m.program_count()==1);
    assert(!m.create_program(fs.value(), vs.value()).ok());
    std::vector<lg::gpu::ShaderResourceBinding> iface{{0, 0, lg::gpu::ShaderResourceType::UniformBuffer, 1, 1u},
                                                       {0, 1, lg::gpu::ShaderResourceType::SampledImage, 1, 2u}};
    assert(m.set_resource_interface(p.value(), iface).ok());
    assert(m.resource_interface(p.value()) != nullptr);
    assert(m.resource_interface(p.value())->size() == 2);
    assert(m.validate_resource_interface(p.value()).ok());
    auto grouped = m.descriptor_bindings_by_set(p.value());
    assert(grouped.ok() && grouped.value().size() == 1 && grouped.value()[0].size() == 2);
    assert(grouped.value()[0][0].binding == 0 && grouped.value()[0][1].binding == 1);

    // Small descriptor-bearing SPIR-V modules used to exercise reflection.
    auto make_vertex = [] {
        std::vector<uint32_t> w{0x07230203u, 0x00010000u, 0u, 32u, 1u};
        auto add=[&](uint16_t op, std::initializer_list<uint32_t> o){ w.push_back((static_cast<uint32_t>(o.size()+1)<<16)|op); w.insert(w.end(),o); };
        add(21,{8,32,0});          // OpTypeInt %8
        add(30,{2});               // OpTypeStruct %2
        add(43,{8,6,3});           // OpConstant %8 %6 3
        add(28,{5,2,6});           // OpTypeArray %5
        add(32,{7,2,5});           // OpTypePointer %7 Uniform %5
        add(71,{4,33,0});          // Binding 0
        add(71,{4,34,0});          // Set 0
        add(59,{7,4,2});            // Uniform variable
        return w;
    };
    auto make_fragment = [] {
        std::vector<uint32_t> w{0x07230203u, 0x00010000u, 0u, 32u, 1u};
        auto add=[&](uint16_t op, std::initializer_list<uint32_t> o){ w.push_back((static_cast<uint32_t>(o.size()+1)<<16)|op); w.insert(w.end(),o); };
        add(21,{8,32,0});
        add(25,{10,8,1,0,0,1,0,0}); // OpTypeImage %10
        add(32,{11,0,10});           // UniformConstant pointer
        add(71,{12,33,1});           // Binding 1
        add(71,{12,34,0});            // Set 0
        add(59,{11,12,0});            // Sampled-image variable
        return w;
    };
    auto rv=m.add_shader(make_vertex(), lg::gpu::ShaderStage::Vertex, "reflected-vs");
    auto rf=m.add_shader(make_fragment(), lg::gpu::ShaderStage::Fragment, "reflected-fs");
    assert(rv.ok() && rf.ok());
    auto vr=m.reflect_shader_interface(rv.value());
    auto fr=m.reflect_shader_interface(rf.value());
    assert(vr.ok() && fr.ok());
    assert(vr.value().size()==1 && vr.value()[0].set==0 && vr.value()[0].binding==0);
    assert(vr.value()[0].type==lg::gpu::ShaderResourceType::UniformBuffer &&
           vr.value()[0].count==3 && vr.value()[0].stage_mask==1u);
    assert(fr.value().size()==1 && fr.value()[0].binding==1);
    assert(fr.value()[0].type==lg::gpu::ShaderResourceType::SampledImage &&
           fr.value()[0].stage_mask==2u);
    auto rp=m.create_program(rv.value(), rf.value());
    assert(rp.ok());
    assert(m.reflect_program_interface(rp.value()).ok());
    const auto* ri=m.resource_interface(rp.value());
    assert(ri && ri->size()==2);
    assert((*ri)[0].stage_mask==1u && (*ri)[1].stage_mask==2u);
    std::vector<lg::gpu::ShaderResourceBinding> bad{{0, 0, lg::gpu::ShaderResourceType::UniformBuffer, 0, 1u}};
    assert(!m.set_resource_interface(p.value(), bad).ok());
    return 0;
}
