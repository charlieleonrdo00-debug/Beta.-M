#include <cassert>
#include <iostream>
#include "../system/kernel.h"
#include "../system/hl_services.h"

int main() {
    lg::system::Kernel kernel;
    assert(kernel.services().register_service(
        "secure:", lg::system::make_system_service(kernel.scheduler()), "svc:secure"));

    const auto process_a = kernel.processes().create("a", "/romfs/a.nro", 0x1000, 0x1000, 0x1000, 1);
    const auto process_b = kernel.processes().create("b", "/romfs/b.nro", 0x2000, 0x2000, 0x1000, 1);
    assert(process_a && process_b && process_a != process_b);

    assert(kernel.connect_service(process_a, "secure:") == nullptr);
    assert(kernel.connect_service(process_b, "secure:") == nullptr);

    assert(kernel.capabilities().grant(process_a, "svc:secure"));
    assert(kernel.connect_service(process_a, "secure:") != nullptr);
    assert(kernel.connect_service(process_b, "secure:") == nullptr);

    assert(kernel.capabilities().revoke(process_a, "svc:secure"));
    assert(kernel.connect_service(process_a, "secure:") == nullptr);

    assert(kernel.capabilities().grant(process_b, "svc:other"));
    assert(kernel.connect_service(process_b, "secure:") == nullptr);

    std::cout << "service authorization ok\n";
}
