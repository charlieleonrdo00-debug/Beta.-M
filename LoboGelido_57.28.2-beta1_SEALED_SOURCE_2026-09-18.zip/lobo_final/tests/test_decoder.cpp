#include <cassert>
#include "../cpu/aarch64_decoder.h"
int main(){using namespace lg::cpu;
 assert(Decoder::classify(0x14000000u)==OpcodeClass::Branch);
 assert(Decoder::classify(0x8B020020u)==OpcodeClass::AddSubReg);
 assert(Decoder::classify(0x9AC20820u)==OpcodeClass::Div);
 assert(Decoder::classify(0x9B1A6F38u)==OpcodeClass::Multiply);
 assert(Decoder::classify(0x54000000u)==OpcodeClass::CondBranch);
 assert(Decoder::classify(0xD503201Fu)==OpcodeClass::Nop);
 assert(!Decoder::decode(0).has_value());
 auto a=Decoder::decode(0x9B1A6F38u);assert(a&&a->ra==27&&a->rn==25&&a->rm==26);
 return 0;
}
