#include <cassert>
#include <iostream>
#include "../system/kernel.h"

class SecureEndpoint final : public lg::system::IpcEndpoint {
public:
    lg::core::Result<lg::system::IpcMessage> dispatch(const lg::system::IpcMessage& request) override {
        return lg::core::Result<lg::system::IpcMessage>::Ok(request);
    }
};

int main() {
    lg::system::Kernel k;
    assert(k.services().register_service("secure:", std::make_unique<SecureEndpoint>(), "svc:secure"));
    const auto a = k.processes().create("A", "a.nro", 0x1000, 0x1000, 0x100, 1);
    const auto b = k.processes().create("B", "b.nro", 0x2000, 0x2000, 0x100, 1);
    assert(a && b);

    assert(k.connect_service_channel(a, "secure:") == 0);
    assert(k.capabilities().grant(a, "svc:secure"));
    const auto ch = k.connect_service_channel(a, "secure:");
    assert(ch);

    lg::system::IpcMessage msg{7, {1,2,3}}, out;
    assert(k.send_service(ch, a, msg));
    assert(!k.receive_service(ch, b, out));
    assert(k.receive_service(ch, a, out));
    assert(out.command_id == 7 && out.payload.size() == 3);

    assert(k.capabilities().revoke(a, "svc:secure"));
    assert(!k.send_service(ch, a, msg));
    assert(!k.receive_service(ch, a, out));
    assert(!k.dispatch_service(ch, a, msg).ok());

    assert(k.capabilities().grant(b, "svc:secure"));
    assert(k.connect_service_channel(b, "secure:"));
    assert(!k.send_service(ch, b, msg));

    std::cout << "ipc service channel authorization ok\n";
    return 0;
}
