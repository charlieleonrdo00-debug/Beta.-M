#include "../cpu/interpreter.h"
#include <cassert>
int main(){using namespace lg;memory::AddressSpace m;assert(m.map(0x1000,0x3000));
 cpu::CpuState s{};s.pc=0x1000;cpu::Interpreter i(m);
 // MOVZ X0,#3; MOVZ X1,#4; ADD X0,X0,X1; STR X0,[X2,#0]; LDR X3,[X2,#0]; B +8; MOVZ X3,#99; NOP
 m.write32(0x1000,0xD2800060u);m.write32(0x1004,0xD2800081u);m.write32(0x1008,0x8B010000u);m.write32(0x100c,0xF9000040u);m.write32(0x1010,0xF9400043u);m.write32(0x1014,0x14000002u);m.write32(0x1018,0xD2800C63u);m.write32(0x101c,0xD503201Fu);s.x[2]=0x2000;assert(i.run(s,6)==6);assert(s.x[0]==7&&s.x[3]==7&&s.pc==0x101c);return 0;}
