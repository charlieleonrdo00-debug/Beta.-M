#include <cassert>
#include <cstring>
#include <string>
#include "../system/filesystem_service.h"
using namespace lg;
int main(){
    system::FileSystemService fs;
    assert(fs.seed_file("/romfs/main.nro", {1,2,3,4}));
    assert(!fs.seed_file("../escape", {1}));
    auto open=fs.dispatch({system::FileSystemService::kOpen, {'/','r','o','m','f','s','/','m','a','i','n','.','n','r','o'}});
    assert(open.ok() && open.value().payload.size()==4);
    uint32_t h{}; std::memcpy(&h, open.value().payload.data(), 4); assert(h);
    std::vector<uint8_t> rp(8); uint32_t n=3; std::memcpy(rp.data(),&h,4); std::memcpy(rp.data()+4,&n,4);
    auto read=fs.dispatch({system::FileSystemService::kRead,rp}); assert(read.ok() && read.value().payload==std::vector<uint8_t>({1,2,3}));
    auto list=fs.dispatch({system::FileSystemService::kList,{}}); assert(list.ok() && list.value().payload.size()>2);
    std::vector<uint8_t> cp(4); std::memcpy(cp.data(),&h,4); assert(fs.dispatch({system::FileSystemService::kClose,cp}).ok());
    assert(!fs.dispatch({system::FileSystemService::kRead,rp}).ok());
    return 0;
}
