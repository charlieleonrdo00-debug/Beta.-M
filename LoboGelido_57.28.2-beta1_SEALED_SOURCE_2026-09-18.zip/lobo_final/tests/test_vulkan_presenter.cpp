#include <cassert>
#include "../gpu/vulkan_presenter.h"
int main(){ lg::gpu::VulkanPresenter p; assert(!p.ready()); assert(!p.draw_frame().ok()); assert(p.diagnostics().find("presenter=OFF")!=std::string::npos); return 0; }
