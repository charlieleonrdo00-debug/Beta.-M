#include <cassert>
#include "performance/adaptive_scaler.h"
using namespace lg::performance;
int main() {
    AdaptiveScaler s({true,60,60,100});
    assert(s.update(25.0, 20.0, 0) == 95);
    assert(s.update(25.0, 20.0, 0) == 90);
    for (int i=0;i<45;i++) s.update(14.0, 10.0, 0);
    assert(s.state().scale >= 90);
    s.set_enabled(false);
    assert(s.state().scale == 100);
    return 0;
}
