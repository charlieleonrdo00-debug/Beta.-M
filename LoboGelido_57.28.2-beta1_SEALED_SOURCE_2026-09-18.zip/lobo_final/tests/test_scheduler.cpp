#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
#include "../system/scheduler.h"

int main() {
    lg::system::Scheduler s;
    std::vector<int> order;

    // Stable deterministic ordering: same tick -> priority -> insertion sequence.
    s.schedule(10, [&] { order.push_back(1); }, 1);
    s.schedule(10, [&] { order.push_back(3); }, 3);
    s.schedule(10, [&] { order.push_back(2); }, 2);
    auto first = s.run_until(10);
    assert(first.executed == 3);
    assert((order == std::vector<int>{3, 2, 1}));
    assert(s.now() == 10);

    // Cancellation is O(1) at the API level and lazily pruned from the heap.
    auto cancelled = s.schedule(20, [&] { order.push_back(99); });
    assert(s.cancel(cancelled));
    assert(!s.contains(cancelled));
    s.run_until(20);
    assert(order.back() != 99);

    // Relative scheduling and periodic cadence do not drift with callback time.
    int pulses = 0;
    auto periodic = s.schedule_periodic(30, 5, [&] { ++pulses; });
    assert(s.next_deadline() == 30);
    auto periodic_run = s.run_until(47);
    assert(periodic_run.executed == 4); // 30,35,40,45
    assert(pulses == 4);
    assert(s.contains(periodic));
    assert(s.cancel(periodic));

    // Event budget prevents a zero-time event storm from monopolizing the CPU.
    int storm = 0;
    s.schedule(50, [&] {
        ++storm;
        s.schedule(50, [&] { ++storm; });
    });
    auto budget = s.run_until(50, 1);
    assert(budget.budget_exhausted);
    assert(budget.executed == 1);
    assert(storm == 1);
    auto rest = s.run_until(50, 8);
    assert(rest.executed == 1);
    assert(storm == 2);

    // Overflow-safe relative scheduling and empty behavior.
    assert(s.schedule_after(2, [&] { order.push_back(7); }) != 0);
    s.run_for(2);
    assert(order.back() == 7);

    const auto id_before_clear = s.schedule(100, [&] {});
    assert(id_before_clear != 0);
    s.clear();
    assert(s.empty());
    assert(s.pending() == 0);

    // Event IDs are handles, not reusable array indexes. A clear must never
    // make an old handle valid for a newly-created event.
    const auto id_after_clear = s.schedule(101, [&] {});
    assert(id_after_clear != 0);
    assert(id_after_clear != id_before_clear);
    assert(!s.cancel(id_before_clear));
    assert(s.cancel(id_after_clear));

    std::cout << "scheduler ok\n";
}
