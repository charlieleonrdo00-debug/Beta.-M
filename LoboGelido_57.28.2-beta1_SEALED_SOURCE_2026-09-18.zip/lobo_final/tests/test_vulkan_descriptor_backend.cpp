#include <cassert>
#include <iostream>
#include "../gpu/vulkan_descriptor_backend.h"
#include "../gpu/vulkan_resource_backend.h"
using namespace lg::gpu;
int main(){
    VulkanResourceBackend resources;
    VulkanDescriptorBackend descriptors;
    auto init=descriptors.initialize(reinterpret_cast<void*>(1),reinterpret_cast<void*>(2),&resources);
#if defined(__ANDROID__)
    assert(!init.ok());
#else
    assert(!init.ok());
    assert(descriptors.diagnostics()=="vkDescriptors=OFF;layouts=0;sets=0");
#endif
    std::cout<<"vulkan descriptor backend host safety OK\n";
    return 0;
}
