#include <cassert>
#include <cstring>
#include "../runtime/runtime_coordinator.h"
#include "../system/kernel.h"
#include "../system/hl_services.h"
using namespace lg;
int main(){
    system::Kernel k;
    auto svc=k.services().register_service("sm:", system::make_system_service(k.scheduler()));
    assert(svc);
    auto* ep=k.services().find("sm:"); assert(ep);
    assert(k.services().required_capability("sm:") == nullptr ||
           *k.services().required_capability("sm:") == "");
    auto tick=ep->dispatch(system::IpcMessage{0,{}}); assert(tick.ok()&&tick.value().payload.size()==8);
    assert(k.services().size()==1);
    assert(k.services().contains("sm:"));
    auto pid=k.processes().create("test", "/romfs/test.nro", 0x1000, 0x1000, 0x1000, 1);
    assert(pid);
    assert(k.services().register_service("secure:", system::make_system_service(k.scheduler()), "svc:secure"));
    assert(k.connect_service(pid, "secure:") == nullptr);
    assert(k.capabilities().grant(pid, "svc:secure"));
    assert(k.connect_service(pid, "secure:") != nullptr);
    assert(k.capabilities().revoke(pid, "svc:secure"));
    assert(k.connect_service(pid, "secure:") == nullptr);
    const auto service_names=k.services().names();
    assert(service_names.size()==2 && service_names.front()=="secure:" && service_names.back()=="sm:");
    auto version=ep->dispatch(system::IpcMessage{2,{}}); assert(version.ok());
    assert(std::string(version.value().payload.begin(),version.value().payload.end())=="LoboGelido-SystemService-v1");

    auto ch=k.ipc().create_channel(); assert(ch);
    system::IpcMessage msg{7,{1,2,3}}; assert(k.ipc().send(ch,msg,k.threads()));
    system::IpcMessage out; assert(k.ipc().receive(ch,out,0,k.threads())); assert(out.command_id==7&&out.payload.size()==3);
    auto tid=k.threads().create("guest",64,[](uint64_t){}); assert(tid);
    assert(k.contexts().create(tid,0x1000,0x2000));
    assert(k.contexts().get(tid)->pc==0x1000);
    auto timer=k.timers().create(10); assert(k.timers().armed(timer)); k.timers().pump(10); assert(k.timers().expired(timer));
    return 0;
}
