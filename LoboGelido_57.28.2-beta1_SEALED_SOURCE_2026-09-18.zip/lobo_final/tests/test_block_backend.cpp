#include <cassert>
#include <iostream>
#include "../cpu/block_backend.h"
#include "../memory/address_space.h"
#include "../memory/mmu.h"

int main() {
    lg::memory::AddressSpace mem;
    assert(mem.map(0x10000000, 0x1000));
    lg::memory::Mmu mmu;
    assert(mmu.map(0x10000000, 0x10000000, 0x1000,
                   lg::memory::Read | lg::memory::Write | lg::memory::Execute | lg::memory::User));
    // MOV W0,#1 ; ADD W0,W0,#2 ; NOP
    mem.write32(0x10000000, 0x52800020u);
    mem.write32(0x10000004, 0x11000800u);
    mem.write32(0x10000008, 0xD503201Fu);
    lg::cpu::BlockBackend backend(mem, mmu, 3);
    assert(backend.initialize().ok());
    assert(backend.execute(0x10000000).ok());
    assert(backend.instructions() == 3);
    assert(backend.block_count() == 1);
    assert(backend.execute(0x10000000).ok());
    assert(backend.hot_hits() == 1);
    std::cout << "block backend ok\n";
}
