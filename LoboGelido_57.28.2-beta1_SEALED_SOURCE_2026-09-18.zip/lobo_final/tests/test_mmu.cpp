#include <cassert>
#include <cstdint>
#include "../memory/mmu.h"
#include "../memory/address_space.h"
#include "../cpu/interpreter.h"
using namespace lg;
int main(){
    memory::Mmu m;
    const auto generation0 = m.generation();
    assert(m.map(0x1000,0x8000,0x2000,memory::Read|memory::Write|memory::Execute));
    assert(m.generation() != generation0);
    auto a=m.translate(0x1abc,false); assert(a.ok() && a.value().physical==0x8abc);
    auto b=m.translate(0x1004,true); assert(b.ok());
    assert(m.translate(0x1004,true).value().permissions&memory::Write);
    assert(m.translate(0x1004,true,true).ok());
    assert(!m.translate(0x3000,false).ok());
    assert(m.translate(0x1004,false,true).ok());
    assert(m.map(0x4000,0xA000,0x1000,memory::Read));
    assert(m.translate(0x4ABC,false).value().physical == 0xAABC);
    assert(!m.translate(0x4ABC,true).ok());
    assert(m.unmap(0x4000,0x1000));
    assert(!m.translate(0x4ABC,false).ok());
    memory::AddressSpace mem; assert(mem.map(0x8000,0x2000));
    cpu::Interpreter cpu(mem,m); cpu::CpuState st{}; st.pc=0x1000;
    mem.write32(0x8000,0xD2800020u); // MOV X0, #1
    assert(cpu.step(st)); // MMU translates VA 0x1000 to the host-backed 0x8000 page.
    assert(st.x[0] == 1);
    const auto generation1 = m.generation();
    assert(m.unmap(0x1000,0x2000));
    assert(m.generation() != generation1);
    assert(!m.translate(0x1000,false).ok());

    // Decode-cache coherence: non-strict mode must discard a cached instruction
    // after guest code is rewritten.
    memory::AddressSpace code_mem; assert(code_mem.map(0x1000, 0x1000));
    code_mem.write32(0x1000, 0xD2800020u); // mov x0,#1
    cpu::Interpreter cached(code_mem); cached.set_strict_code_validation(false);
    cpu::CpuState cs{}; cs.pc = 0x1000; assert(cached.step(cs)); assert(cs.x[0] == 1);
    cs.pc = 0x1000; code_mem.write32(0x1000, 0xD2800040u); // mov x0,#2
    assert(cached.step(cs)); assert(cs.x[0] == 2);
    return 0;
}
