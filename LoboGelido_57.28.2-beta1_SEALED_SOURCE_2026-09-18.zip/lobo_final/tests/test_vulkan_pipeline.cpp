#include <cassert>
#include <vector>
#include "../gpu/vulkan_pipeline.h"
int main(){
    lg::gpu::VulkanPipeline p;
    assert(!p.ready());
    auto r=p.initialize(nullptr,nullptr); assert(!r.ok());
    assert(p.shader_count()==0);
    return 0;
}
