#include <cassert>
#include <iostream>
#include "../system/kernel.h"

class Endpoint final : public lg::system::IpcEndpoint {
public:
    lg::core::Result<lg::system::IpcMessage> dispatch(const lg::system::IpcMessage& r) override {
        return lg::core::Result<lg::system::IpcMessage>::Ok(r);
    }
};

int main() {
    lg::system::Kernel k;
    assert(k.services().register_service("secure:", std::make_unique<Endpoint>(), "svc:secure"));
    const auto p = k.processes().create("P", "p.nro", 0x1000, 0x1000, 0x100, 1);
    assert(p);
    assert(k.capabilities().grant(p, "svc:secure"));

    const auto old = k.connect_service_channel(p, "secure:");
    assert(old);
    lg::system::IpcMessage msg{9, {4,5}}, out;
    assert(k.send_service(old, p, msg));

    // Process destruction closes all of its IPC channels.
    assert(k.processes().stop(p) || true);
    assert(k.destroy_process(p));
    assert(!k.send_service(old, p, msg));
    assert(!k.receive_service(old, p, out));
    assert(!k.dispatch_service(old, p, msg).ok());

    // Reset must not make an old opaque handle valid again.
    k.reset();
    assert(k.services().register_service("secure:", std::make_unique<Endpoint>(), "svc:secure"));
    const auto p2 = k.processes().create("P2", "p2.nro", 0x2000, 0x2000, 0x100, 1);
    assert(p2);
    assert(k.capabilities().grant(p2, "svc:secure"));
    const auto fresh = k.connect_service_channel(p2, "secure:");
    assert(fresh);
    assert(fresh != old);
    assert(!k.send_service(old, p2, msg));

    std::cout << "ipc handle lifecycle ok\n";
    return 0;
}
