#include <cassert>
#include <string>
#include "../gpu/vulkan_gpu_runtime.h"
int main(){ lg::gpu::VulkanGpuRuntime g; assert(!g.ready()); assert(!g.timestamp_supported()); assert(g.diagnostics().find("pipelineCache=OFF")!=std::string::npos); assert(!g.write_begin_timestamp(nullptr)); assert(!g.write_end_timestamp(nullptr)); return 0; }
