#include <cassert>
#include <iostream>
#include "../system/capability_manager.h"
int main() {
    lg::system::CapabilityManager cm;
    assert(cm.grant(7, "fsp-srv"));
    assert(cm.has(7, "fsp-srv"));
    assert(cm.count(7) == 1);
    assert(!cm.grant(7, "fsp-srv"));
    assert(!cm.grant(0, "x"));
    assert(cm.revoke(7, "fsp-srv"));
    assert(!cm.has(7, "fsp-srv"));
    cm.grant(7, "svc:a");
    cm.grant(7, "svc:b");
    cm.clear(7);
    assert(cm.count(7) == 0);
    std::cout << "capability manager ok\n";
}
