#include "../cpu/interpreter.h"
#include <cassert>
int main(){lg::memory::AddressSpace m;m.map(0x1000,0x2000); // MOVZ X0,#5; ADD X0,X0,#7; NOP
m.write32(0x1000,0xD28000A0u);m.write32(0x1004,0x91001C00u);m.write32(0x1008,0xD503201Fu);lg::cpu::CpuState s{};s.pc=0x1000;lg::cpu::Interpreter i(m);assert(i.step(s));assert(s.x[0]==5);assert(i.step(s));assert(s.x[0]==12);return 0;}
