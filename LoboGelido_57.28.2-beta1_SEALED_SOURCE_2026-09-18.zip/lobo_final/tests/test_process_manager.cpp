#include <cassert>
#include <iostream>
#include "../system/process_manager.h"
int main() {
    lg::system::ProcessManager pm;
    auto id = pm.create("main", "/romfs/main.nro", 0x1000, 0x1000, 0x3000, 3);
    assert(id != 0);
    assert(pm.size() == 1);
    assert(pm.get(id) && !pm.get(id)->running);
    assert(pm.start(id));
    assert(pm.current() && pm.current()->id == id && pm.current()->running);
    assert(!pm.start(id));
    assert(pm.stop(id));
    assert(pm.current() == nullptr);
    assert(pm.destroy(id));
    assert(pm.size() == 0);
    std::cout << "process manager ok\n";
}
