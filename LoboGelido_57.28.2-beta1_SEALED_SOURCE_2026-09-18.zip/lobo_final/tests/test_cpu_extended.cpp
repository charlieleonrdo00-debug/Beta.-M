#include <cassert>
#include "../cpu/interpreter.h"
int main(){using namespace lg; memory::AddressSpace m;assert(m.map(0x1000,0x5000));cpu::CpuState s{};s.pc=0x1000;cpu::Interpreter c(m);
 // mov x0,#20; mov x1,#3; udiv x2,x0,x1; mov x3,#0x10; add x3,x3,x3; cbnz x2,+8; mov x4,#99; rev x5,x3; clz x6,x3; rbit x7,x3; nop
 m.write32(0x1000,0xD2800280u);m.write32(0x1004,0xD2800061u);m.write32(0x1008,0x9AC10802u);m.write32(0x100c,0xD2800203u);m.write32(0x1010,0x8B030063u);m.write32(0x1014,0xB5000042u);m.write32(0x1018,0xD2800C64u);m.write32(0x101c,0xDAC00C65u);m.write32(0x1020,0xDAC01066u);m.write32(0x1024,0xDAC00067u);m.write32(0x1028,0xD503201Fu);
 assert(c.run(s,10)==10);assert(s.x[2]==6);assert(s.x[3]==0x20);assert(s.x[4]==0);assert(s.x[5]==0x2000000000000000ull);assert(s.x[6]==58);assert(s.x[7]!=0);return 0;}
