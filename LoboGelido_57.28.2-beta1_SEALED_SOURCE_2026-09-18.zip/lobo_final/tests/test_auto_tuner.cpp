#include <cassert>
#include "performance/auto_tuner.h"
using namespace lg::performance;
int main() {
    AutoTuner t;
    auto stable = t.update({5.0, 6.0, 14.0, 0});
    assert(stable.resolution_scale == 100);
    assert(stable.pipeline_workers == 4);
    assert(stable.target_fps == 60);
    assert(stable.confidence >= 80);

    auto gpu = t.update({7.0, 18.0, 24.0, 0});
    assert(gpu.resolution_scale == 85);
    assert(gpu.pipeline_workers == 4);
    assert(gpu.gpu_async);
    assert(gpu.dynamic_resolution);

    auto thermal = t.update({8.0, 9.0, 29.0, 4});
    assert(thermal.resolution_scale == 75);
    assert(!thermal.async_shaders);
    assert(!thermal.gpu_async);
    assert(!thermal.async_present);
    assert(thermal.target_fps == 30);
    assert(thermal.dynamic_resolution);
    return 0;
}
