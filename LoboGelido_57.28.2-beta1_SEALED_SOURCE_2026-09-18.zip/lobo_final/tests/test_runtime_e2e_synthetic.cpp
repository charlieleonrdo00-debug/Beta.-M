#include <cassert>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include "../runtime/runtime_coordinator.h"

static void put32(std::vector<uint8_t>& b, size_t o, uint32_t v) {
    b[o] = static_cast<uint8_t>(v); b[o+1] = static_cast<uint8_t>(v >> 8);
    b[o+2] = static_cast<uint8_t>(v >> 16); b[o+3] = static_cast<uint8_t>(v >> 24);
}
static void put64(std::vector<uint8_t>& b, size_t o, uint64_t v) {
    put32(b, o, static_cast<uint32_t>(v)); put32(b, o+4, static_cast<uint32_t>(v >> 32));
}

int main() {
    namespace fs = std::filesystem;
    const fs::path path = fs::temp_directory_path() / "lobo_gelido_synthetic_e2e.nro";
    constexpr size_t kTextSize = 2048;
    std::vector<uint8_t> nro(0x80 + kTextSize, 0);
    nro[0]='N'; nro[1]='R'; nro[2]='O'; nro[3]='0';
    put64(nro, 0x10, 0x80); put64(nro, 0x18, kTextSize);
    for (size_t off=0x80; off<nro.size(); off+=4) put32(nro, off, 0xD503201F); // ARM64 NOP
    { std::ofstream out(path, std::ios::binary|std::ios::trunc); assert(out); out.write(reinterpret_cast<const char*>(nro.data()), nro.size()); assert(out.good()); }

    lg::runtime::RuntimeCoordinator rt;
    assert(rt.state() == lg::runtime::State::Cold);

    // Open -> inspect -> load -> process creation -> real runtime preparation.
    auto prep = rt.prepare(path.string());
    assert(prep.ok());
    assert(rt.state() == lg::runtime::State::Ready);
    assert(rt.entry_point() == 0x100000ull);
    assert(rt.process() == nullptr); // created, but not running/current yet

    // Start must actually transition the created guest process to running/current.
    assert(rt.start().ok());
    assert(rt.state() == lg::runtime::State::Running);
    assert(rt.process() != nullptr);
    assert(rt.process()->running);
    assert(rt.process()->initialized);
    assert(rt.process()->entry_point == 0x100000ull);
    assert(rt.process()->segment_count == 1);

    // Execute enough real ARM64 NOPs to exercise persistent guest PC + CPU/MMU/scheduler.
    for (int i=0; i<3; ++i) { auto r = rt.run_frame(rt.entry_point()); if (!r.ok()) { std::cerr << "frame " << i << " failed: " << r.error() << "\n" << rt.diagnostics() << "\n"; return 2; } }
    assert(rt.metrics().frames == 3);
    assert(rt.metrics().instructions > 0);
    assert(rt.metrics().scheduler_ticks > 0);
    assert(rt.metrics().guest_dispatches > 0);
    assert(rt.metrics().thread_context_switches > 0);
    assert(rt.metrics().faults == 0);
    const std::string d = rt.diagnostics();
    assert(d.find("MMU=ready") != std::string::npos);
    assert(d.find("frames=3") != std::string::npos);

    // Pause/resume and another frame, then full shutdown/reset.
    assert(rt.pause().ok()); assert(rt.resume().ok()); assert(rt.run_frame(rt.entry_point()).ok());
    assert(rt.metrics().frames == 4);
    assert(rt.stop().ok());
    assert(rt.state() == lg::runtime::State::Stopped);
    assert(rt.process() == nullptr);

    std::error_code ec; fs::remove(path, ec);
    std::cout << "runtime synthetic e2e ok: open -> load -> process -> start -> CPU/MMU -> scheduler -> 4 frames -> diagnostics -> stop\n";
}
