#include <cassert>
#include <memory>
#include "../core/result.h"
#include "../cpu/jit_backend.h"

using namespace lg;      // makes lg::core visible so unqualified core::Result resolves
using namespace lg::cpu;

namespace {
class RejectingProvider final : public JitProvider {
public:
    core::Result<void> initialize() override { return core::Result<void>::Error("test provider unavailable"); }
    core::Result<uint64_t> execute(CpuState&, uint64_t) override { return core::Result<uint64_t>::Error("test provider unavailable"); }
    void invalidate_all() noexcept override {}
    const char* name() const noexcept override { return "TestRejectingProvider"; }
};
}

int main() {
    JitBackend jit(std::make_unique<RejectingProvider>());
    auto init = jit.initialize();
    assert(!init.ok());
    CpuState state{};
    auto run = jit.execute_state(state, 16);
    assert(!run.ok());
    jit.invalidate_all();
    return 0;
}
