#include <cassert>
#include <filesystem>
#include <vector>
#include "../gpu/gpu_device.h"
#include "../gpu/render_graph.h"
#include "../graphics/shader_cache.h"

int main() {
    lg::gpu::GpuDevice device;
    assert(!device.initialize().ok());
    lg::gpu::DeviceInfo actual{};
    actual.backend = lg::gpu::Backend::Vulkan;
    actual.api = "Vulkan";
    actual.api_version = 0x00403000;
    actual.timeline_semaphore = true;
    actual.dynamic_rendering = true;
    actual.descriptor_indexing = true;
    actual.shader_int16 = true;
    actual.initialized = true;
    assert(device.initialize(actual).ok());
    assert(device.ready());
    assert(device.info().backend == lg::gpu::Backend::Vulkan);
    assert(device.info().dynamic_rendering);
    assert(device.info().descriptor_indexing);

    lg::gpu::RenderGraph graph;
    assert(graph.add({lg::gpu::PassType::Transfer, 1, {}}).ok());
    assert(graph.add({lg::gpu::PassType::Compute, 2, {1}}).ok());
    assert(graph.add({lg::gpu::PassType::Graphics, 3, {2}}).ok());
    auto order = graph.compile();
    assert(order.ok() && order.value().size() == 3);
    assert(order.value()[0] == 1 && order.value()[1] == 2 && order.value()[2] == 3);

    lg::gpu::RenderGraph cycle;
    assert(cycle.add({lg::gpu::PassType::Compute, 10, {11}}).ok());
    assert(cycle.add({lg::gpu::PassType::Compute, 11, {10}}).ok());
    assert(!cycle.compile().ok());

    const auto root = std::filesystem::temp_directory_path() / "lobogelido_shader_cache_test";
    lg::graphics::ShaderCache cache(root);
    const lg::graphics::ShaderCacheKey key{0x11, 0x22, 7};
    const std::vector<uint8_t> payload{1, 2, 3, 4};
    assert(cache.put(key, payload));
    std::vector<uint8_t> loaded;
    assert(cache.get(key, loaded) && loaded == payload);
    cache.clear();
    return 0;
}
