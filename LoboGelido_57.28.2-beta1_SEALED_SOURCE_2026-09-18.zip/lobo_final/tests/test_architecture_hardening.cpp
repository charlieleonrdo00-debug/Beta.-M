#include <cassert>
#include <iostream>
#include "../memory/address_space.h"
#include "../cpu/jit_backend.h"
#include "../system/thread_manager.h"
#include "../system/scheduler.h"
#include "../runtime/runtime_coordinator.h"

namespace {
class RejectingProvider final : public lg::cpu::JitProvider {
public:
    lg::core::Result<void> initialize() override { return lg::core::Result<void>::Error("test provider unavailable"); }
    lg::core::Result<uint64_t> execute(lg::cpu::CpuState&, uint64_t) override { return lg::core::Result<uint64_t>::Error("test provider unavailable"); }
    void invalidate_all() noexcept override {}
    const char* name() const noexcept override { return "TestRejectingProvider"; }
};
}

int main() {
    {
        lg::memory::AddressSpace mem;
        assert(mem.write_epoch() == 0);
        assert(mem.map(0x1000, 0x1000));
        const auto mapped_epoch = mem.write_epoch();
        assert(mapped_epoch != 0);
        assert(mem.unmap(0x1000, 0x1000));
        assert(mem.write_epoch() != mapped_epoch);
    }

    {
        lg::runtime::RuntimeCoordinator runtime;
        assert(runtime.prepare().ok());
        assert(runtime.start().ok());
        assert(runtime.run_frame(0x10000000).ok());
        assert(runtime.stop().ok());
        assert(runtime.prepare().ok());
        assert(runtime.start().ok());
        assert(runtime.stop().ok());
    }

    {
        lg::cpu::CpuState state{};
        state.x[0] = 0x1234;
        state.pc = 0x1000;
        state.instructions = 99;
        state.reservation_valid = true;
        state.reset();
        assert(state.x[0] == 0);
        assert(state.pc == 0);
        assert(state.instructions == 0);
        assert(!state.reservation_valid);
    }

    {
        lg::cpu::JitBackend jit(std::make_unique<RejectingProvider>());
        assert(!jit.available());
        assert(!jit.initialize().ok());
        assert(!jit.available());
    }

    {
        lg::system::Scheduler scheduler;
        lg::system::ThreadManager threads(scheduler);
        int ran = 0;
        auto id = threads.create("t", 10, [&](auto) { ++ran; });
        assert(id != 0);
        assert(threads.dispatch_next(64));
        assert(ran == 1);
        // Dispatch does not advance virtual time; the kernel's outer tick loop owns it.
        assert(scheduler.now() == 0);
    }


    {
        lg::memory::AddressSpace mem;
        assert(mem.map(0x1000, 0x2000));
        mem.write8(0x1fff, 0xaa);
        mem.write8(0x2000, 0xbb);
        auto cross = mem.read32(0x1ffe);
        assert(cross.has_value());
        assert((*cross & 0xffffffu) == 0xbbaa00u);
        assert(!mem.read32(UINT64_MAX - 1).has_value());
        assert(!mem.read64(UINT64_MAX - 3).has_value());
    }

    {
        lg::memory::AddressSpace mem;
        lg::memory::Mmu mmu;
        assert(mem.map(0x8000, 0x8000));
        assert(mmu.map(0x4000, 0x8000, 0x1000, lg::memory::Read | lg::memory::Execute));
        lg::cpu::Interpreter interp(mem, mmu);
        lg::cpu::CpuState state{};
        state.pc = 0x4000;
        mem.write32(0x8000, 0xd2800020u);
        assert(interp.step(state));
        assert(state.x[0] == 1);
        assert(!mmu.translate(0x4000, true, false).ok());
    }

    std::cout << "architecture hardening ok\n";
}
