#include <cassert>
#include "../gpu/spirv_module.h"
int main(){ using namespace lg::gpu; auto bad=validate_spirv({1,2,3,4,5}); assert(!bad.ok()); auto shortm=validate_spirv({0x07230203u,1,0,1,1}); assert(shortm.ok()); auto malformed=validate_spirv({0x07230203u,1,0,1,1,0}); assert(!malformed.ok()); return 0; }
