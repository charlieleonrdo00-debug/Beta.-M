#include "platform_registry.h"
#include <cassert>
#include <vector>
#include <cstdint>
int main() {
    using namespace lg::platform;
    assert(detect_path("game.gbc").platform == Platform::GameBoyColor);
    assert(detect_path("game.gba").platform == Platform::GameBoyAdvance);
    assert(detect_path("game.z64").platform == Platform::Nintendo64);
    assert(detect_path("game.nds").platform == Platform::NintendoDS);
    assert(detect_path("game.3ds").platform == Platform::Nintendo3DS);
    assert(detect_path("game.nsp").platform == Platform::NintendoSwitch);
    assert(detect_path("game.rvz").platform == Platform::Wii);
    std::vector<uint8_t> n64 = {0x80,0x37,0x12,0x40};
    assert(detect_magic(n64, "unknown.bin").platform == Platform::Nintendo64);
    std::vector<uint8_t> nro = {'N','R','O','0'};
    assert(detect_magic(nro).platform == Platform::NintendoSwitch);
    assert(CoreRegistry::find(Platform::Nintendo64));
    assert(CoreRegistry::all().size() == 8);
    return 0;
}
