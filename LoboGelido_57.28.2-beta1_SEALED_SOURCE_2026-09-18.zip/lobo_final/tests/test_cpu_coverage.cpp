#include <cassert>
#include "../cpu/interpreter.h"
int main(){using namespace lg; memory::AddressSpace m; assert(m.map(0x1000,0x4000)); cpu::CpuState s{};s.pc=0x1000;cpu::Interpreter cpu(m);
 // MOVZ X0,#7; MOVZ X1,#5; MADD X2,X0,X1,XZR =>35; SUBS X3,X2,#35; B.EQ +8; MOVZ X4,#1; NOP
 m.write32(0x1000,0xD28000E0u);m.write32(0x1004,0xD28000A1u);m.write32(0x1008,0x9B017C02u);m.write32(0x100c,0xF1008C43u);m.write32(0x1010,0x54000040u);m.write32(0x1014,0xD2800024u);m.write32(0x1018,0xD503201Fu);
 assert(cpu.run(s,6)==6); assert(s.x[2]==35); assert(s.x[3]==0); assert(s.x[4]==0); return 0;}
