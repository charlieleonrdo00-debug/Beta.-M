#include "performance/diagnostics.h"
#include <cassert>
#include <string>
using namespace lg::performance;
int main(){ DiagnosticsCore d; d.set_runtime(false,true,100,false); for(int i=0;i<10;i++) d.record(3.0,12.0,1.0); auto s=d.snapshot(); assert(s.samples==10); assert(s.bottleneck==Bottleneck::Gpu); assert(s.gpu_util>70); auto t=d.summary(); assert(t.find("GPU")!=std::string::npos); d.record(2,2,1,3); assert(d.snapshot().bottleneck==Bottleneck::Thermal); return 0; }
