#include <cassert>
#include "../gpu/vulkan_command_executor.h"
int main(){
    lg::gpu::GpuCommandProcessor p;
    lg::gpu::GpuCommand c{}; c.op=lg::gpu::GpuOp::Clear; c.x=.1f; c.y=.2f; c.z=.3f; c.w=1.f;
    assert(p.submit(c).ok());
    lg::gpu::VulkanCommandExecutor e;
    auto r=e.execute(nullptr,p,nullptr);
    assert(!r.ok());
    return 0;
}
