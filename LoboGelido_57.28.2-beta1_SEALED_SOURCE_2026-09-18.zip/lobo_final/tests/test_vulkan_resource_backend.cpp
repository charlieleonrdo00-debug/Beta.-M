#include <cassert>
#include <iostream>
#include "../gpu/vulkan_resource_backend.h"
int main(){
    lg::gpu::VulkanResourceBackend b;
    auto r=b.initialize(nullptr,nullptr); assert(!r.ok());
    assert(b.diagnostics()=="vkResources=OFF;buffers=0;images=0;memory=0");
    std::cout<<"vulkan resource backend host contract ok\n";
}
