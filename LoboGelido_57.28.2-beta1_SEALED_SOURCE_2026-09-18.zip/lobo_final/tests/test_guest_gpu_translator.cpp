#include <cassert>
#include <iostream>
#include "../gpu/guest_gpu_translator.h"
using namespace lg::gpu;
int main(){
    GuestGpuTranslator t;
    std::vector<GuestGpuPacket> p={
        {GuestGpuTranslator::SetViewport,0,0,0,0,0,0,1280,720},
        {GuestGpuTranslator::SetScissor,1280,720},
        {GuestGpuTranslator::BindPipeline,7,12},
        {GuestGpuTranslator::BindVertexBuffer,9},
        {GuestGpuTranslator::BindDescriptorSet,11},
        {GuestGpuTranslator::Draw,3}
    };
    auto r=t.translate(p); assert(r.ok()); assert(r.value().size()==p.size());
    assert(r.value()[2].op==GpuOp::BindPipeline && r.value()[2].a==7 && r.value()[2].b==12);
    GpuCommandProcessor cp; auto cr=cp.submit(r.value()); assert(cr.ok()); assert(cp.stats().draws==1);
    auto bad=t.translate(std::vector<GuestGpuPacket>{{999}}); assert(!bad.ok()); assert(t.stats().rejected==1);
    std::cout << "guest GPU translator OK\n";
}
