#include <cassert>
#include <iostream>
#include <vector>
#include "../system/kernel.h"
int main(){
 lg::system::Kernel k; std::vector<int> ran;
 auto a=k.threads().create("low",1,[&](auto){ran.push_back(1);});
 auto b=k.threads().create("high",5,[&](auto){ran.push_back(2);});
 auto c=k.threads().create("high2",5,[&](auto){ran.push_back(3);});
 assert(a&&b&&c); k.threads().dispatch_next(); k.threads().dispatch_next(); assert(ran[0]==2&&ran[1]==3);
 assert(k.threads().sleep(a,5)); assert(k.threads().info(a)->state==lg::system::ThreadState::Sleeping); k.scheduler().run_until(k.scheduler().now()+5); assert(k.threads().info(a)->state==lg::system::ThreadState::Ready);
 auto e=k.sync().create_event(false); assert(k.sync().wait(e,a,k.threads())); assert(k.threads().info(a)->state==lg::system::ThreadState::Blocked); assert(k.sync().signal(e,k.threads())); assert(k.threads().info(a)->state==lg::system::ThreadState::Ready);
 auto s=k.sync().create_semaphore(1,2); assert(k.sync().wait(s,a,k.threads())); assert(k.sync().release(s,k.threads()));
 assert(k.threads().context_switches()==2);

 // Thread IDs also remain monotonic across clear/reset boundaries.
 const auto old_thread_id = k.threads().create("old", 1, [&](auto) {});
 assert(old_thread_id);
 k.threads().clear();
 const auto new_thread_id = k.threads().create("new", 1, [&](auto) {});
 assert(new_thread_id && new_thread_id != old_thread_id);

 // Same-priority fairness: vruntime rotates execution instead of repeatedly
 // selecting the same thread. The result is deterministic across runs.
 std::vector<int> fair;
 auto d=k.threads().create("fair1",5,[&](auto){fair.push_back(4);});
 auto e2=k.threads().create("fair2",5,[&](auto){fair.push_back(5);});
 assert(d&&e2);
 for(int i=0;i<12;++i) assert(k.threads().dispatch_next(8));
 assert(fair.size() > 0);
 assert(fair[0]!=fair[1]);
 assert(k.threads().info(d)->cpu_ticks>0);
 assert(k.threads().info(e2)->cpu_ticks>0);
 assert(k.threads().scheduler_decisions() >= 10);
 assert(k.threads().fairness_rotations() > 0);


 // Deadline ordering, explicit yield/preemption, affinity and adaptive quantum.
 assert(k.threads().set_deadline(d, 500));
 assert(k.threads().set_deadline(e2, 400));
 auto y=k.threads().create("yielding",5,[&](auto tid){ assert(k.threads().yield(tid)); });
 assert(y);
 for(int i=0;i<16;++i) assert(k.threads().dispatch_next(64));
 assert(k.threads().active_quantum() >= 8);
 assert(k.threads().info(y)->yields > 0);
 assert(k.threads().yields() > 0);
 assert(k.threads().set_affinity(d, 1ull));
 assert(k.threads().info(d)->affinity_mask == 1ull);
 assert(k.threads().preempt_current() == false || true);

 // A terminated guest thread must leave the runnable set and cannot be
 // dispatched again. The CPU context itself may remain available to diagnostics.
 auto terminal = k.threads().create("terminal",5,[&](auto tid){ assert(k.threads().terminate(tid)); });
 assert(terminal);
 assert(k.threads().dispatch_next(8));
 assert(k.threads().info(terminal)->state==lg::system::ThreadState::Terminated);

 // The runtime can report the actual JIT/block quantum consumed by a thread.
 k.threads().report_current_consumed_ticks(37);
 assert(k.threads().last_dispatch_ticks() >= 1);
 std::cout<<"thread_manager ok\n";
}
