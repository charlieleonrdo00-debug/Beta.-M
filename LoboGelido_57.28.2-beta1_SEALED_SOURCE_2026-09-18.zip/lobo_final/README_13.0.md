# Lobo Gélido 13.0

Reingeniería UX + Diagnostics Core sobre la base 12.1.

Incluye:
- sistema visual hielo/cyan/magenta renovado
- diagnóstico estructurado con rolling window de 120 muestras
- clasificador de cuello de botella y consejo accionable
- arquitectura de telemetría independiente de Android
- preparación para perfiles por capas
- adaptive scaling existente integrado en la visión de rendimiento
- 11 pruebas C++ automatizadas

No incluye firmware, keys ni juegos.
