# Lobo Gélido 42.0 — Vulkan Sync Hardening

## Objetivo
Endurecer el presenter Android construido en 40/41 antes de conectar renderizado 3D real.

## Cambios
- El semáforo de adquisición continúa siendo único y se reutiliza después de esperar el fence de trabajo.
- Los semáforos de presentación ahora son **uno por imagen del swapchain**. Esto evita reutilizar un semáforo de señalización de presentación mientras una operación `vkQueuePresentKHR` anterior puede seguir pendiente.
- `draw_frame()` selecciona el semáforo asociado al índice obtenido por `vkAcquireNextImageKHR`.
- `recreate()` y `shutdown()` destruyen todos los semáforos de presentación.
- Fallos parciales durante la creación de semáforos limpian los recursos ya creados.
- Los diagnósticos exponen `presentSemaphores`.

## Por qué importa
La sincronización Vulkan no debe depender únicamente del fence de `vkQueueSubmit`: una presentación es una operación posterior en la cola y puede seguir utilizando el semáforo después de que el fence de la sumisión haya señalado. Asociar el semáforo a la imagen del swapchain elimina esa reutilización prematura.

## Alcance
Esta versión no afirma tener renderizado de Switch. El presenter solo gestiona correctamente el camino Android Vulkan acquire → command buffer → submit → present y la operación clear introducida en 41.0.

## Validación
Host CTest: 25/25 pruebas pasaron.

APK Android: no compilado en este entorno por ausencia del toolchain Android completo.
