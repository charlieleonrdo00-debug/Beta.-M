# Lobo Gélido 55.10 — Descriptor Layout Auto-Generation

55.10 builds Vulkan descriptor-set layouts directly from the reflected ShaderProgram resource interface.

Flow:
`SPIR-V reflection -> ShaderProgram resources -> bindings grouped by set -> VulkanDescriptorBackend -> VkDescriptorSetLayout -> VulkanPipeline`

The generator preserves descriptor type, array count and vertex/fragment stage visibility. Missing set indices receive empty layouts so Vulkan set numbering remains stable.

This is an architectural backend feature; proprietary Nintendo firmware, keys, ROMs and copyrighted game assets are not bundled.
