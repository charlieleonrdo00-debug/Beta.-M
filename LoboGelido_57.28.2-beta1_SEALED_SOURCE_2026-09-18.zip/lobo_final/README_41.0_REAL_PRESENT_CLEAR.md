# Lobo Gélido 41.0 — Real Present/Clear Path

This increment connects the Android Vulkan presenter to an actual GPU image operation.

## Implemented

- Validates that the surface supports `VK_IMAGE_USAGE_TRANSFER_DST_BIT` before creating the swapchain.
- Tracks first use of every swapchain image.
- Transitions acquired images from `UNDEFINED` on first use and from `PRESENT_SRC_KHR` on subsequent frames.
- Clears the acquired swapchain image through `vkCmdClearColorImage`.
- Transitions the image back to `PRESENT_SRC_KHR` before `vkQueuePresentKHR`.
- Keeps the existing acquire -> submit -> present synchronization path.
- Updates Android application/engine version metadata to 40.0.

This is still deliberately not a 3D renderer: no game shaders, render graph execution, depth buffer, or guest framebuffer translation is claimed here. The presenter now has a real GPU write, which is the correct foundation for those layers.
