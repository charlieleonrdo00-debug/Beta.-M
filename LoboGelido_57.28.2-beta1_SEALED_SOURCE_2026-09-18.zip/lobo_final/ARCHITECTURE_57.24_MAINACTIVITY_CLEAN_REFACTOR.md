# Lobo Gélido 57.24 — MainActivity Clean Architecture Refactor

## Scope
This refactor removes feature/business ownership from `MainActivity` without changing the visual hierarchy, layouts, styling, navigation appearance, or runtime UI composition.

## Presentation layer
`MainActivity` is now responsible for:
- Activity lifecycle and Android UI rendering.
- Navigation between existing screens.
- Forwarding user actions to application facades.
- Receiving Activity results and dispatching them to the SAF/application boundary.
- Runtime lifecycle coordination through the existing `RuntimeLifecycleController`.

`MainActivity` no longer constructs or owns the persistence/content implementations for settings, games, profiles, previews, users, sessions, achievements, GPU drivers, or content recognition.

## Application/composition layer
`application/LoboApplicationGraph.kt` is the composition root exposed to the Activity. It owns the feature facades:

- `SettingsFacade` — settings and legacy preference compatibility.
- `GameLibraryFacade` — catalog/index synchronization, artwork enrichment, favorites/recent state.
- `ProfileFacade` — per-game profile persistence and device optimization.
- `PreviewFacade` — gameplay preview persistence.
- `SkinFacade` — controller skin persistence and SAF-backed import of ZIP/folder assets.
- `UserFacade` — console user/profile identity state.
- `SessionFacade` — durable consumer session state.
- `AchievementFacade` — achievement persistence.
- `GpuDriverFacade` — GPU driver management boundary.
- `SetupFacade` — keys/firmware/game-folder/GPU recognition and setup orchestration.
- `SafFacade` — SAF intent construction, request-code mapping and persistable URI permissions.

The existing domain contracts in `domain/firmware`, `domain/keys`, and `domain/games` remain available as the intended long-term boundary for replacing concrete implementations with repositories/use cases.

## SAF boundary
All SAF intent construction and persistable-permission handling is centralized in `SafFacade`. Game indexing and skin import consume SAF URIs through application services instead of querying `ContentResolver` from `MainActivity`.

## Runtime safety
This refactor does not alter the native runtime lifecycle, Vulkan ownership, RAM mappings, MMU state, JIT caches, scheduler, or `RuntimeLifecycleController` semantics.

The Activity continues to use the existing runtime bridge. Pausing remains a pause operation rather than a stop/reset operation, so the runtime state is not discarded merely because Android temporarily pauses the Activity.

## Visual compatibility
No XML/layout resources or visual component hierarchy were redesigned. `LoboConsoleHomeRenderer` only lost unused concrete store parameters from its boot warm-up call; its rendered output and timing remain unchanged.
