# Lobo Gélido 57.20 — CPU/RAM Bridge Fast Path

Esta versión añade una microcaché de traducciones en el puente CPU→MMU→RAM usado por Dynarmic.

## Cambios
- 32 entradas direct-mapped de traducción por páginas.
- Cada entrada conserva VA page, PA page, permisos, generación de MMU y puntero host.
- Los accesos repetidos dentro de la misma página evitan volver a ejecutar `Mmu::translate()`.
- La caché se invalida lógicamente cuando cambia `Mmu::generation()`.
- Los punteros host se resuelven una sola vez por entrada y se reutilizan para lecturas rápidas.
- Se mantiene la ruta segura de callbacks para cruces de página, fallos y memoria no mapeada.
- No se habilita `fastmem_pointer` nativo de Dynarmic porque el arena actual es de 16 MiB y no representa por sí solo un espacio de direcciones completo de 36 bits.
- La UI y el flujo Android no se modifican.

## Verificación
- Compilación del core sin Dynarmic: correcta.
- CTest: 43/43 pruebas, 0 fallos.
- La compilación con Dynarmic no pudo verificarse en este entorno porque no hay acceso de red para descargar el repositorio de Dynarmic.
