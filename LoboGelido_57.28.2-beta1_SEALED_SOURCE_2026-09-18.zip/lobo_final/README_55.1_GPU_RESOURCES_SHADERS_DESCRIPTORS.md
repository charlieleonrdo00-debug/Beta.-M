# Lobo Gélido 55.1 — GPU resources, shaders y descriptors reales

Esta iteración profundiza la ruta Vulkan sin incluir firmware, keys ni contenido propietario.

## Cambios

- `VulkanPipeline::create_graphics_pipeline()` acepta layouts de descriptor Vulkan reales y los incorpora al `VkPipelineLayout`.
- `VulkanPipeline::draw()` ejecuta un `vkCmdDraw` con `vertex_count` y `first_vertex` procedentes del comando GPU.
- `VulkanDescriptorBackend::layout_handle()` expone el handle Vulkan del layout para construir el pipeline layout.
- `VulkanCommandExecutor` ejecuta `BindDescriptorSet` mediante `vkCmdBindDescriptorSets` y pasa `Draw` con conteo/offset reales.
- `VulkanPresenter` inicializa y destruye `VulkanResourceBackend` y `VulkanDescriptorBackend`, y entrega el backend de descriptors al ejecutor.
- La arquitectura queda preparada para que el traductor guest cree recursos, layouts, sets, actualizaciones y pipelines específicos y los consuma en la misma command stream.

## Importante

La ruta todavía no es un renderer Switch completo: no se inventan formatos de comandos propietarios ni shaders de Nintendo. La creación de shader modules sigue requiriendo SPIR-V proporcionado por una capa de traducción legítima.

## Validación

Host CTest: **34/34 pruebas pasan**.
