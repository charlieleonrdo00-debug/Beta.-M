# Arquitectura 2.0

## Regla principal
El núcleo no conoce Android. Android es una plataforma/adaptador.

Android
  -> Application
  -> Emulator Session
  -> CPU / Memory / Kernel-HLE / GPU / Audio / Input
  -> Platform abstractions

## CPU
- Decoder AArch64 aislado.
- IR intermedia para facilitar intérprete, JIT y análisis.
- Backend Interpreter como referencia determinista.
- Interface CodeCache/JIT.
- Interface NCE para dispositivos compatibles.

## Memory
- AddressSpace.
- MMU/page tables.
- Memory permissions.
- Fast-path translation cache.
- Instrumentación opcional.

## System
- Virtual scheduler.
- IPC endpoints.
- HLE service registry.
- Virtual filesystem.
- Save/content metadata.

## GPU
- Abstract GPU device.
- Command submission.
- Vulkan device/context.
- Shader/pipeline/texture caches.
- Timeline synchronization.
- Presentation/frame pacing.

## Performance
- Frame budget.
- CPU/GPU timing samples.
- Thermal state.
- Adaptive quality policy.
- Persistent per-game profiles.

## Robustez
- Explicit Result<T>.
- Session state machine.
- Cancellation.
- Watchdog.
- Safe mode.
- Crash diagnostics.

## Métrica de superioridad
No se considera "superior" por cantidad de carpetas. Debe demostrar:
- menor stutter,
- menor tiempo de carga,
- menor uso de CPU a igual carga,
- recuperación de errores,
- mejor estabilidad,
- y compatibilidad medida mediante una suite reproducible.
