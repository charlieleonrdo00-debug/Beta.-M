# Lobo Gélido 57.9.2 — UI real + datos reales

- La biblioteca se alimenta exclusivamente de documentos SAF que existen, son legibles y usan formatos reconocidos.
- No se muestran juegos de demostración ni títulos de ejemplo.
- Las carátulas nunca se reemplazan por el logo de Lobo Gélido. Se usan carátulas locales reales encontradas junto al juego o con el mismo nombre dentro de la carpeta de juegos. Si no existe una carátula real, se muestra `CARÁTULA NO DISPONIBLE`.
- Tamaño y formato se leen del archivo real.
- La versión del juego no se inventa: queda `No disponible` hasta que exista un lector de metadatos que pueda obtenerla de forma verificable.
- La compatibilidad no se inventa: comienza como `No evaluada`, cambia a `Inició correctamente en este dispositivo` cuando una sesión real arranca, o registra que el runtime rechazó/falló al iniciar.
- FPS, frame time, CPU y diagnósticos proceden del runtime nativo; si no hay muestras, la UI lo indica.
- La pantalla de juego utiliza `GameSurfaceView` + `initializeVulkan()` + `runRuntimeFrame()` + `drawVulkanFrame()`; no pinta gameplay ficticio.
- El logo del arranque es el recurso `lobo_logo_exact`.
