# Lobo Gélido 56.0 — GPU Resource Binding Runtime

## Objetivo

Conectar la interfaz reflejada de los ShaderProgram con recursos Vulkan reales mediante una capa de coordinación que prepara descriptor-set layouts, asigna descriptor sets, valida bindings, actualiza descriptores y los enlaza al pipeline activo.

## Flujo

`Guest GPU → pipeline_id + shader_program_id → SPIR-V Reflection → descriptor layouts → descriptor sets → resource writes → pipeline layout → vkCmdBindDescriptorSets → Draw`

## Cambios

- Nuevo `VulkanResourceBindingRuntime`.
- Preparación automática de layouts y descriptor sets por programa.
- Mapeo estable `program_id + set → layout_id / descriptor_set_id`.
- Binding de buffers e imágenes desde IDs del backend de recursos.
- Validación de interfaz por set antes de actualizar/bindear.
- Preparación de pipeline con los descriptor layouts generados automáticamente.
- `VulkanCommandExecutor` puede usar el runtime para resolver pipeline + recursos antes de `BindDescriptorSet`.
- Corrección del backend de descriptores para respetar `UNIFORM_BUFFER` frente a `STORAGE_BUFFER` durante `vkUpdateDescriptorSets`.
- Diagnóstico `vkBindingRuntime=READY/OFF;programs=N;sets=N`.

## Limitaciones deliberadas

- La capa actual soporta `UniformBuffer`, `StorageBuffer` y `SampledImage`.
- Los arrays de descriptores se reflejan, pero el camino de actualización actual escribe un descriptor por operación de binding; no pretende resolver todavía un array completo de recursos guest.
- Las imágenes requieren un `VkImageView` ya creado por `VulkanResourceBackend` y se actualizan con `VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL`; la transición de layout completa y el sistema de samplers quedan para una etapa posterior.
- El vertex input sigue siendo el contrato de prueba existente (posición vec2 + color vec3); todavía no es un traductor completo de formatos de vertex del guest.
- Los módulos SPIR-V de los tests de host son módulos estructuralmente válidos para el parser/reflection; no se afirma que sean shaders Vulkan completos capaces de crear un pipeline real.
- El árbol no contiene firmware, claves, ROMs ni otros datos propietarios de Nintendo.

## Validación

Configuración host: CMake + C++20.

Resultado: **36/36 CTest pasan (100%)**.

La creación/ejecución de objetos Vulkan reales requiere compilar y ejecutar el camino Android con un dispositivo Vulkan compatible.
