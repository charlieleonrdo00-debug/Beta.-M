# Lobo Gélido 32.5 — Startup Optimizer

- El arranque visual mantiene el logo de Lobo Gélido durante una ventana de preparación de ~30 segundos.
- El trabajo ocurre en un hilo de fondo; la interfaz no se bloquea.
- Descubre las entradas de la biblioteca registradas, lee sus metadatos disponibles y genera/guarda un perfil por juego.
- El perfil adapta resolución, FPS, escalado y nivel gráfico de forma conservadora según núcleos y memoria disponibles.
- Muestra progreso durante el arranque: búsqueda, metadatos, perfiles, cachés, CPU/GPU y finalización.
- No se afirma que una heurística conozca la carga gráfica real de un juego: las opciones específicas del backend siguen dependiendo de Vulkan/Dynarmic y del runtime.
- Si el trabajo termina antes, el splash conserva la ventana solicitada; si se tarda más, termina cuando acaba.

## Rendimiento Android

La preparación es asíncrona para evitar bloquear el hilo de UI. Para optimizar el código de arranque también se recomienda usar Baseline/Startup Profiles en la compilación de lanzamiento.
